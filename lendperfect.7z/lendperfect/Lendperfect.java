

package com.sai.lendperfect;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.boot.SpringApplication;



@SpringBootApplication(scanBasePackages={"com.sai.lendperfect"})
public class Lendperfect extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(Lendperfect.class);
    }
    
    public static void main(String[] args) {
		SpringApplication.run(Lendperfect.class, args);
	}

}
