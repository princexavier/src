package com.sai.lendperfect.cbsmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Date;


/**
 * The persistent class for the CUSTDETAILS database table.
 * 
 */
@Entity
@Table(name="CUSTDETAILS")
@NamedQuery(name="Custdetails.findAll", query="SELECT c FROM Custdetails c")
public class Custdetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="AADHAR_NUM")
	private String aadharNum;

	@Column(name="ADDRESS_LINE1")
	private String addressLine1;

	@Column(name="ADDRESS_LINE2")
	private String addressLine2;

	@Column(name="ADDRESS_LINE3")
	private String addressLine3;

	@Column(name="APP_RCVD_FROM")
	private String appRcvdFrom;

	@Column(name="BUSINESS_ADDRESS_1")
	private String businessAddress1;

	@Column(name="BUSINESS_ADDRESS_2")
	private String businessAddress2;

	@Column(name="BUSINESS_ADDRESS_3")
	private String businessAddress3;

	@Column(name="BUSINESS_CITY")
	private String businessCity;

	@Column(name="BUSINESS_COUNTRY")
	private String businessCountry;

	@Column(name="BUSINESS_EMAIL")
	private String businessEmail;

	@Column(name="BUSINESS_PHONENO")
	private String businessPhoneno;

	@Column(name="BUSINESS_PIN_CODE")
	private String businessPinCode;

	@Column(name="BUSINESS_STATE")
	private String businessState;

	@Id
	@Column(name="CIF_ID")
	private String cifId;

	private String city;

	private String country;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="CUST_DOB")
	private Date custDob;

	@Column(name="CUST_TITLE_CODE")
	private String custTitleCode;

	@Column(name="CUST_TYPE")
	private String custType;

	private String director;

	private String education;

	private String employerid;

	@Column(name="EMPLOYERID_CODE")
	private String employeridCode;

	private String employersname;

	@Column(name="EMPLOYMENT_STATUS")
	private String employmentStatus;

	private String gender;

	private String isstaff;

	@Column(name="MAILING_ADDRESS_1")
	private String mailingAddress1;

	@Column(name="MAILING_ADDRESS_2")
	private String mailingAddress2;

	@Column(name="MAILING_ADDRESS_3")
	private String mailingAddress3;

	@Column(name="MAILING_CITY")
	private String mailingCity;

	@Column(name="MAILING_COUNTRY")
	private String mailingCountry;

	@Column(name="MAILING_EMAIL")
	private String mailingEmail;

	@Column(name="MAILING_PHONENO")
	private String mailingPhoneno;

	@Column(name="MAILING_PIN_CODE")
	private String mailingPinCode;

	@Column(name="MAILING_STATE")
	private String mailingState;

	@Column(name="MARITAL_STATUS")
	private String maritalStatus;

	private String name;

	private String nationality;

	@Column(name="PAN_GIR_NUM")
	private String panGirNum;

	@Column(name="PERM_EMAIL")
	private String permEmail;

	@Column(name="PERM_PHONENO")
	private String permPhoneno;

	private String pincode;

	@Column(name="PRESENT_ADDRESS_1")
	private String presentAddress1;

	@Column(name="PRESENT_ADDRESS_2")
	private String presentAddress2;

	@Column(name="PRESENT_ADDRESS_3")
	private String presentAddress3;

	@Column(name="PRESENT_CITY")
	private String presentCity;

	@Column(name="PRESENT_COUNTRY")
	private String presentCountry;

	@Column(name="PRESENT_EMAIL")
	private String presentEmail;

	@Column(name="PRESENT_PHONENO")
	private String presentPhoneno;

	@Column(name="PRESENT_PIN_CODE")
	private String presentPinCode;

	@Column(name="PRESENT_STATE")
	private String presentState;

	@Column(name="PSPRT_DET")
	private String psprtDet;

	@Temporal(TemporalType.DATE)
	@Column(name="PSPRT_EXP_DATE")
	private Date psprtExpDate;

	@Temporal(TemporalType.DATE)
	@Column(name="PSPRT_ISSU_DATE")
	private Date psprtIssuDate;

	@Column(name="PSPRT_NUM")
	private String psprtNum;

	private String religion;

	@Column(name="SHORT_NAME")
	private String shortName;

	@Column(name="\"STATE\"")
	private String state;

	@Column(name="STF_EMP_ID")
	private String stfEmpId;

	private String url;

	public Custdetails() {
	}

	public String getAadharNum() {
		return this.aadharNum;
	}

	public void setAadharNum(String aadharNum) {
		this.aadharNum = aadharNum;
	}

	public String getAddressLine1() {
		return this.addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return this.addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getAddressLine3() {
		return this.addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	public String getAppRcvdFrom() {
		return this.appRcvdFrom;
	}

	public void setAppRcvdFrom(String appRcvdFrom) {
		this.appRcvdFrom = appRcvdFrom;
	}

	public String getBusinessAddress1() {
		return this.businessAddress1;
	}

	public void setBusinessAddress1(String businessAddress1) {
		this.businessAddress1 = businessAddress1;
	}

	public String getBusinessAddress2() {
		return this.businessAddress2;
	}

	public void setBusinessAddress2(String businessAddress2) {
		this.businessAddress2 = businessAddress2;
	}

	public String getBusinessAddress3() {
		return this.businessAddress3;
	}

	public void setBusinessAddress3(String businessAddress3) {
		this.businessAddress3 = businessAddress3;
	}

	public String getBusinessCity() {
		return this.businessCity;
	}

	public void setBusinessCity(String businessCity) {
		this.businessCity = businessCity;
	}

	public String getBusinessCountry() {
		return this.businessCountry;
	}

	public void setBusinessCountry(String businessCountry) {
		this.businessCountry = businessCountry;
	}

	public String getBusinessEmail() {
		return this.businessEmail;
	}

	public void setBusinessEmail(String businessEmail) {
		this.businessEmail = businessEmail;
	}

	public String getBusinessPhoneno() {
		return this.businessPhoneno;
	}

	public void setBusinessPhoneno(String businessPhoneno) {
		this.businessPhoneno = businessPhoneno;
	}

	public String getBusinessPinCode() {
		return this.businessPinCode;
	}

	public void setBusinessPinCode(String businessPinCode) {
		this.businessPinCode = businessPinCode;
	}

	public String getBusinessState() {
		return this.businessState;
	}

	public void setBusinessState(String businessState) {
		this.businessState = businessState;
	}

	public String getCifId() {
		return this.cifId;
	}

	public void setCifId(String cifId) {
		this.cifId = cifId;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Date getCustDob() {
		return this.custDob;
	}

	public void setCustDob(Date custDob) {
		this.custDob = custDob;
	}

	public String getCustTitleCode() {
		return this.custTitleCode;
	}

	public void setCustTitleCode(String custTitleCode) {
		this.custTitleCode = custTitleCode;
	}

	public String getCustType() {
		return this.custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getDirector() {
		return this.director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getEducation() {
		return this.education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getEmployerid() {
		return this.employerid;
	}

	public void setEmployerid(String employerid) {
		this.employerid = employerid;
	}

	public String getEmployeridCode() {
		return this.employeridCode;
	}

	public void setEmployeridCode(String employeridCode) {
		this.employeridCode = employeridCode;
	}

	public String getEmployersname() {
		return this.employersname;
	}

	public void setEmployersname(String employersname) {
		this.employersname = employersname;
	}

	public String getEmploymentStatus() {
		return this.employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getIsstaff() {
		return this.isstaff;
	}

	public void setIsstaff(String isstaff) {
		this.isstaff = isstaff;
	}

	public String getMailingAddress1() {
		return this.mailingAddress1;
	}

	public void setMailingAddress1(String mailingAddress1) {
		this.mailingAddress1 = mailingAddress1;
	}

	public String getMailingAddress2() {
		return this.mailingAddress2;
	}

	public void setMailingAddress2(String mailingAddress2) {
		this.mailingAddress2 = mailingAddress2;
	}

	public String getMailingAddress3() {
		return this.mailingAddress3;
	}

	public void setMailingAddress3(String mailingAddress3) {
		this.mailingAddress3 = mailingAddress3;
	}

	public String getMailingCity() {
		return this.mailingCity;
	}

	public void setMailingCity(String mailingCity) {
		this.mailingCity = mailingCity;
	}

	public String getMailingCountry() {
		return this.mailingCountry;
	}

	public void setMailingCountry(String mailingCountry) {
		this.mailingCountry = mailingCountry;
	}

	public String getMailingEmail() {
		return this.mailingEmail;
	}

	public void setMailingEmail(String mailingEmail) {
		this.mailingEmail = mailingEmail;
	}

	public String getMailingPhoneno() {
		return this.mailingPhoneno;
	}

	public void setMailingPhoneno(String mailingPhoneno) {
		this.mailingPhoneno = mailingPhoneno;
	}

	public String getMailingPinCode() {
		return this.mailingPinCode;
	}

	public void setMailingPinCode(String mailingPinCode) {
		this.mailingPinCode = mailingPinCode;
	}

	public String getMailingState() {
		return this.mailingState;
	}

	public void setMailingState(String mailingState) {
		this.mailingState = mailingState;
	}

	public String getMaritalStatus() {
		return this.maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNationality() {
		return this.nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPanGirNum() {
		return this.panGirNum;
	}

	public void setPanGirNum(String panGirNum) {
		this.panGirNum = panGirNum;
	}

	public String getPermEmail() {
		return this.permEmail;
	}

	public void setPermEmail(String permEmail) {
		this.permEmail = permEmail;
	}

	public String getPermPhoneno() {
		return this.permPhoneno;
	}

	public void setPermPhoneno(String permPhoneno) {
		this.permPhoneno = permPhoneno;
	}

	public String getPincode() {
		return this.pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getPresentAddress1() {
		return this.presentAddress1;
	}

	public void setPresentAddress1(String presentAddress1) {
		this.presentAddress1 = presentAddress1;
	}

	public String getPresentAddress2() {
		return this.presentAddress2;
	}

	public void setPresentAddress2(String presentAddress2) {
		this.presentAddress2 = presentAddress2;
	}

	public String getPresentAddress3() {
		return this.presentAddress3;
	}

	public void setPresentAddress3(String presentAddress3) {
		this.presentAddress3 = presentAddress3;
	}

	public String getPresentCity() {
		return this.presentCity;
	}

	public void setPresentCity(String presentCity) {
		this.presentCity = presentCity;
	}

	public String getPresentCountry() {
		return this.presentCountry;
	}

	public void setPresentCountry(String presentCountry) {
		this.presentCountry = presentCountry;
	}

	public String getPresentEmail() {
		return this.presentEmail;
	}

	public void setPresentEmail(String presentEmail) {
		this.presentEmail = presentEmail;
	}

	public String getPresentPhoneno() {
		return this.presentPhoneno;
	}

	public void setPresentPhoneno(String presentPhoneno) {
		this.presentPhoneno = presentPhoneno;
	}

	public String getPresentPinCode() {
		return this.presentPinCode;
	}

	public void setPresentPinCode(String presentPinCode) {
		this.presentPinCode = presentPinCode;
	}

	public String getPresentState() {
		return this.presentState;
	}

	public void setPresentState(String presentState) {
		this.presentState = presentState;
	}

	public String getPsprtDet() {
		return this.psprtDet;
	}

	public void setPsprtDet(String psprtDet) {
		this.psprtDet = psprtDet;
	}

	public Date getPsprtExpDate() {
		return this.psprtExpDate;
	}

	public void setPsprtExpDate(Date psprtExpDate) {
		this.psprtExpDate = psprtExpDate;
	}

	public Date getPsprtIssuDate() {
		return this.psprtIssuDate;
	}

	public void setPsprtIssuDate(Date psprtIssuDate) {
		this.psprtIssuDate = psprtIssuDate;
	}

	public String getPsprtNum() {
		return this.psprtNum;
	}

	public void setPsprtNum(String psprtNum) {
		this.psprtNum = psprtNum;
	}

	public String getReligion() {
		return this.religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getShortName() {
		return this.shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStfEmpId() {
		return this.stfEmpId;
	}

	public void setStfEmpId(String stfEmpId) {
		this.stfEmpId = stfEmpId;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}