package com.sai.lendperfect.cbsmodel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;


/**
 * The persistent class for the CUSTACCOUNTS database table.
 * 
 */
@Entity
@Table(name="CUSTACCOUNTS")
@NamedQuery(name="Custaccount.findAll", query="SELECT c FROM Custaccount c")
public class Custaccount implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ACCT_CREATION_MODE")
	private String acctCreationMode;

	@Temporal(TemporalType.DATE)
	@Column(name="ACCT_OPN_DATE")
	private Date acctOpnDate;

	@Column(name="APPLICANT_TYPE")
	private String applicantType;

	@Column(name="CIF_ID")
	private String cifId;

	@Column(name="CLR_BAL_AMT")
	private BigDecimal clrBalAmt;

	@Column(name="DEPOSITOR_NAME")
	private String depositorName;
	
	@Id
	@Column(name="FORACID")
	private String foracid;

	@Temporal(TemporalType.DATE)
	@Column(name="LIM_SANCT_DATE")
	private Date limSanctDate;

	@Column(name="SANCT_LIM")
	private BigDecimal sanctLim;

	@Column(name="SCHM_DESC")
	private String schmDesc;

	@Column(name="SCHM_TYPE")
	private String schmType;

	@Column(name="SERIAL_NUM")
	private String serialNum;

	@Column(name="SOL_DESC")
	private String solDesc;

	@Column(name="SOL_ID")
	private String solId;

	public Custaccount() {
	}

	public String getAcctCreationMode() {
		return this.acctCreationMode;
	}

	public void setAcctCreationMode(String acctCreationMode) {
		this.acctCreationMode = acctCreationMode;
	}

	public Date getAcctOpnDate() {
		return this.acctOpnDate;
	}

	public void setAcctOpnDate(Date acctOpnDate) {
		this.acctOpnDate = acctOpnDate;
	}

	public String getApplicantType() {
		return this.applicantType;
	}

	public void setApplicantType(String applicantType) {
		this.applicantType = applicantType;
	}

	public String getCifId() {
		return this.cifId;
	}

	public void setCifId(String cifId) {
		this.cifId = cifId;
	}

	public BigDecimal getClrBalAmt() {
		return this.clrBalAmt;
	}

	public void setClrBalAmt(BigDecimal clrBalAmt) {
		this.clrBalAmt = clrBalAmt;
	}

	public String getDepositorName() {
		return this.depositorName;
	}

	public void setDepositorName(String depositorName) {
		this.depositorName = depositorName;
	}

	public String getForacid() {
		return this.foracid;
	}

	public void setForacid(String foracid) {
		this.foracid = foracid;
	}

	public Date getLimSanctDate() {
		return this.limSanctDate;
	}

	public void setLimSanctDate(Date limSanctDate) {
		this.limSanctDate = limSanctDate;
	}

	public BigDecimal getSanctLim() {
		return this.sanctLim;
	}

	public void setSanctLim(BigDecimal sanctLim) {
		this.sanctLim = sanctLim;
	}

	public String getSchmDesc() {
		return this.schmDesc;
	}

	public void setSchmDesc(String schmDesc) {
		this.schmDesc = schmDesc;
	}

	public String getSchmType() {
		return this.schmType;
	}

	public void setSchmType(String schmType) {
		this.schmType = schmType;
	}

	public String getSerialNum() {
		return this.serialNum;
	}

	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	public String getSolDesc() {
		return this.solDesc;
	}

	public void setSolDesc(String solDesc) {
		this.solDesc = solDesc;
	}

	public String getSolId() {
		return this.solId;
	}

	public void setSolId(String solId) {
		this.solId = solId;
	}

}