package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SEC_PROPERTY_COP_MOF database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown =true)
@Entity
@Table(name="LPCOM_SEC_PROPERTY_COP_MOF")
@NamedQuery(name="LpcomSecPropertyCopMof.findAll", query="SELECT l FROM LpcomSecPropertyCopMof l")
public class LpcomSecPropertyCopMof implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LSPC_ROW_ID")
	private long lspcRowId;

	@Column(name="LSPC_COMMENTS")
	private String lspcComments;

	@Temporal(TemporalType.DATE)
	@Column(name="LSPC_CREATED_DATE")
	private Date lspcCreatedDate;

	@Column(name="LSPC_CREATEDBY")
	private String lspcCreatedby;

	@Column(name="LSPC_EOC1")
	private BigDecimal lspcEoc1;

	@Column(name="LSPC_EOC_TOT")
	private BigDecimal lspcEocTot;

	@Column(name="LSPC_EOS")
	private BigDecimal lspcEos;

	@Column(name="LSPC_EOS_TOT")
	private BigDecimal lspcEosTot;

	@Temporal(TemporalType.DATE)
	@Column(name="LSPC_MODIFIED_DATE")
	private Date lspcModifiedDate;

	@Column(name="LSPC_MODIFIEDBY")
	private String lspcModifiedby;

	@Column(name="LSPC_SEC_ID")
	private BigDecimal lspcSecId;

	@Column(name="LSPC_TYPE")
	private String lspcType;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LSPC_APPNO")
	private LpcomProposal lpcomProposal;

	public LpcomSecPropertyCopMof() {
	}

	public long getLspcRowId() {
		return this.lspcRowId;
	}

	public void setLspcRowId(long lspcRowId) {
		this.lspcRowId = lspcRowId;
	}

	public String getLspcComments() {
		return this.lspcComments;
	}

	public void setLspcComments(String lspcComments) {
		this.lspcComments = lspcComments;
	}

	public Date getLspcCreatedDate() {
		return this.lspcCreatedDate;
	}

	public void setLspcCreatedDate(Date lspcCreatedDate) {
		this.lspcCreatedDate = lspcCreatedDate;
	}

	public String getLspcCreatedby() {
		return this.lspcCreatedby;
	}

	public void setLspcCreatedby(String lspcCreatedby) {
		this.lspcCreatedby = lspcCreatedby;
	}


	public BigDecimal getLspcEocTot() {
		return this.lspcEocTot;
	}

	public void setLspcEocTot(BigDecimal lspcEocTot) {
		this.lspcEocTot = lspcEocTot;
	}

	public BigDecimal getLspcEos() {
		return this.lspcEos;
	}

	public void setLspcEos(BigDecimal lspcEos) {
		this.lspcEos = lspcEos;
	}

	public BigDecimal getLspcEosTot() {
		return this.lspcEosTot;
	}

	public void setLspcEosTot(BigDecimal lspcEosTot) {
		this.lspcEosTot = lspcEosTot;
	}

	public Date getLspcModifiedDate() {
		return this.lspcModifiedDate;
	}

	public void setLspcModifiedDate(Date lspcModifiedDate) {
		this.lspcModifiedDate = lspcModifiedDate;
	}

	public String getLspcModifiedby() {
		return this.lspcModifiedby;
	}

	public void setLspcModifiedby(String lspcModifiedby) {
		this.lspcModifiedby = lspcModifiedby;
	}

	public BigDecimal getLspcSecId() {
		return this.lspcSecId;
	}

	public void setLspcSecId(BigDecimal lspcSecId) {
		this.lspcSecId = lspcSecId;
	}

	public String getLspcType() {
		return this.lspcType;
	}

	public void setLspcType(String lspcType) {
		this.lspcType = lspcType;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public BigDecimal getLspcEoc1() {
		return lspcEoc1;
	}

	public void setLspcEoc1(BigDecimal lspcEoc1) {
		this.lspcEoc1 = lspcEoc1;
	}

}