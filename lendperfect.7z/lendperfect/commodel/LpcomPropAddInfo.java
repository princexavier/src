package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.application.model.LpcustApplicantData;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_PROP_ADD_INFO database table.
 * 
 */
@Entity
@Table(name="LPCOM_PROP_ADD_INFO")
@NamedQuery(name="LpcomPropAddInfo.findAll", query="SELECT l FROM LpcomPropAddInfo l")
public class LpcomPropAddInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPAI_CMT_FOR")
	private String lpaiCmtFor;
	
	@Column(name="LPAI_CMT_HEADING")
	private String lpaiCmtHeading;

	@Column(name="LPAI_CMT_ID")
	private BigDecimal lpaiCmtId;

	@Lob
	@Column(name="LPAI_COMMENTS")
	private String lpaiComments;

	@Column(name="LPAI_CREATED_BY")
	private String lpaiCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPAI_CREATED_ON")
	private Date lpaiCreatedOn;

	@Column(name="LPAI_MODIFIED_BY",nullable=false)
	private String lpaiModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPAI_MODIFIED_ON",nullable=false)
	private Date lpaiModifiedOn;

	
	@Id
	@Column(name="LPAI_ROW_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private BigDecimal lpaiRowId;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LPAI_PROP_NO")
	private LpcomProposal lpcomProposal;
	
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LPAI_APP_ID")
	private LpcustApplicantData lpcustApplicantData;

	public LpcomPropAddInfo() {
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}

	public String getLpaiCmtFor() {
		return this.lpaiCmtFor;
	}

	public void setLpaiCmtFor(String lpaiCmtFor) {
		this.lpaiCmtFor = lpaiCmtFor;
	}

	public BigDecimal getLpaiCmtId() {
		return this.lpaiCmtId;
	}

	public void setLpaiCmtId(BigDecimal lpaiCmtId) {
		this.lpaiCmtId = lpaiCmtId;
	}

	public String getLpaiComments() {
		return this.lpaiComments;
	}

	public void setLpaiComments(String lpaiComments) {
		this.lpaiComments = lpaiComments;
	}

	public String getLpaiCreatedBy() {
		return this.lpaiCreatedBy;
	}

	public void setLpaiCreatedBy(String lpaiCreatedBy) {
		this.lpaiCreatedBy = lpaiCreatedBy;
	}

	public Date getLpaiCreatedOn() {
		return this.lpaiCreatedOn;
	}

	public void setLpaiCreatedOn(Date lpaiCreatedOn) {
		this.lpaiCreatedOn = lpaiCreatedOn;
	}

	public String getLpaiModifiedBy() {
		return this.lpaiModifiedBy;
	}

	public void setLpaiModifiedBy(String lpaiModifiedBy) {
		this.lpaiModifiedBy = lpaiModifiedBy;
	}

	public Date getLpaiModifiedOn() {
		return this.lpaiModifiedOn;
	}

	public void setLpaiModifiedOn(Date lpaiModifiedOn) {
		this.lpaiModifiedOn = lpaiModifiedOn;
	}

	

	public BigDecimal getLpaiRowId() {
		return this.lpaiRowId;
	}

	public void setLpaiRowId(BigDecimal lpaiRowId) {
		this.lpaiRowId = lpaiRowId;
	}
	public String getLpaiCmtHeading() {
		return lpaiCmtHeading;
	}

	public void setLpaiCmtHeading(String lpaiCmtHeading) {
		this.lpaiCmtHeading = lpaiCmtHeading;
	}
  
	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}
	public LpcomPropAddInfo(String lpaiCmtFor, BigDecimal lpaiCmtId, String lpaiComments, String lpaiCreatedBy,
			Date lpaiCreatedOn, String lpaiModifiedBy, Date lpaiModifiedOn) {
		super();
		this.lpaiCmtFor = lpaiCmtFor;
		this.lpaiCmtId = lpaiCmtId;
		this.lpaiComments = lpaiComments;
		this.lpaiCreatedBy = lpaiCreatedBy;
		this.lpaiCreatedOn = lpaiCreatedOn;
		this.lpaiModifiedBy = lpaiModifiedBy;
		this.lpaiModifiedOn = lpaiModifiedOn;
		
	}
	public LpcomPropAddInfo(String lpaiCmtFor, BigDecimal lpaiCmtId, String lpaiComments, String lpaiCreatedBy,
			Date lpaiCreatedOn) {
		super();
		this.lpaiCmtFor = lpaiCmtFor;
		this.lpaiCmtId = lpaiCmtId;
		this.lpaiComments = lpaiComments;
		this.lpaiCreatedBy = lpaiCreatedBy;
		this.lpaiCreatedOn = lpaiCreatedOn;
		
	}
}
