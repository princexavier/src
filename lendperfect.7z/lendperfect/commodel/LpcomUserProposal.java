package com.sai.lendperfect.commodel;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sai.lendperfect.setupmodel.LpstpUser;

/**
 * The persistent class for the LPCOM_USER_PROPOSAL database table.
 * 
 */
@Entity
@Table(name="LPCOM_USER_PROPOSAL")
@NamedQuery(name="LpcomUserProposal.findAll", query="SELECT l FROM LpcomUserProposal l")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LpcomUserProposal implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LUP_SNO")
	private long lupSno;

	@Temporal(TemporalType.DATE)
	@Column(name="LUP_MODIFIED_DATE")
	private Date lupModifiedDate;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LUP_PROP_NO")
	private LpcomProposal lpcomProposal;

	//bi-directional many-to-one association to LpstpUser
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LUP_USER_ID")
	private LpstpUser lpstpUser;

	public LpcomUserProposal() {
	}

	public long getLupSno() {
		return this.lupSno;
	}

	public void setLupSno(long lupSno) {
		this.lupSno = lupSno;
	}

	public Date getLupModifiedDate() {
		return this.lupModifiedDate;
	}

	public void setLupModifiedDate(Date lupModifiedDate) {
		this.lupModifiedDate = lupModifiedDate;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpstpUser getLpstpUser() {
		return this.lpstpUser;
	}

	public void setLpstpUser(LpstpUser lpstpUser) {
		this.lpstpUser = lpstpUser;
	}

}
