package com.sai.lendperfect.commodel;
import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_CUST_DATA_IND database table.
 * 
 */
@Entity
@Table(name="LPCOM_CUST_DATA_IND")
@NamedQuery(name="LpcomCustDataInd.findAll", query="SELECT l FROM LpcomCustDataInd l")
public class LpcomCustDataInd implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LCI_AADHAR_ID")
	private BigDecimal lciAadharId;

	@Column(name="LCI_ACCOUNT_TYPE")
	private String lciAccountType;

	@Column(name="LCI_ADDR_PROOF")
	private String lciAddrProof;

	@Column(name="LCI_ADDR_PROOF_NO")
	private String lciAddrProofNo;

	@Column(name="LCI_BANKING_SINCE")
	private BigDecimal lciBankingSince;

	@Column(name="LCI_BRANCH_CODE")
	private String lciBranchCode;

	@Column(name="LCI_BRANCH_NAME")
	private String lciBranchName;

	@Column(name="LCI_CASTE")
	private String lciCaste;

	@Column(name="LCI_CAT_OTHERS")
	private String lciCatOthers;

	@Column(name="LCI_CATEGORY")
	private String lciCategory;

	@Column(name="LCI_CERSAI_UPDATE")
	private String lciCersaiUpdate;

	@Column(name="LCI_CLASSI_CATGRY")
	private String lciClassiCatgry;

	@Column(name="LCI_CONT_PERSON_NAME")
	private String lciContPersonName;

	@Column(name="LCI_CP_EMAIL")
	private String lciCpEmail;

	@Column(name="LCI_CP_ID")
	private String lciCpId;

	@Column(name="LCI_CP_MOB_NO")
	private String lciCpMobNo;

	@Column(name="LCI_CP_PHNE_NO")
	private String lciCpPhneNo;

	@Column(name="LCI_CREATED_BY")
	private String lciCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_CREATED_ON")
	private Date lciCreatedOn;

	@Column(name="LCI_CUST_LOB")
	private String lciCustLob;

	@Column(name="LCI_CUST_SEGMENT")
	private String lciCustSegment;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_DL_EXPIRY")
	private Date lciDlExpiry;

	@Column(name="LCI_DL_NO")
	private String lciDlNo;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_DOB")
	private Date lciDob;

	@Column(name="LCI_EDU_LEVEL")
	private String lciEduLevel;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_EFF_FROM")
	private Date lciEffFrom;

	@Column(name="LCI_EMPLOY_TYPE")
	private String lciEmployType;

	@Column(name="LCI_EWS_FLAG")
	private String lciEwsFlag;

	@Column(name="LCI_FATHER_NAME")
	private String lciFatherName;

	@Column(name="LCI_FILLER_1")
	private String lciFiller1;

	@Column(name="LCI_FILLER_2")
	private String lciFiller2;

	@Column(name="LCI_FILLER_3")
	private String lciFiller3;

	@Column(name="LCI_FILLER_4")
	private String lciFiller4;

	@Column(name="LCI_FIRST_NAME")
	private String lciFirstName;

	@Column(name="LCI_GENDER")
	private String lciGender;

	@Column(name="LCI_ID_PROOF")
	private String lciIdProof;

	@Column(name="LCI_ID_PROOF_NO")
	private String lciIdProofNo;

	@Column(name="LCI_INCOME_SLAB")
	private String lciIncomeSlab;

	@Column(name="LCI_IT_TYPE")
	private String lciItType;

	@Column(name="LCI_KYC_NO")
	private String lciKycNo;

	@Column(name="LCI_LAST_NAME")
	private String lciLastName;

	@Column(name="LCI_MAIDEN_NAME")
	private String lciMaidenName;

	@Column(name="LCI_MARITAL_STATUS")
	private String lciMaritalStatus;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_MARRIAGE_DATE")
	private Date lciMarriageDate;

	@Column(name="LCI_MIDDLE_NAME")
	private String lciMiddleName;

	@Column(name="LCI_MODIFIED_BY")
	private String lciModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_MODIFIED_ON")
	private Date lciModifiedOn;

	@Column(name="LCI_MOTHER_NAME")
	private String lciMotherName;

	@Column(name="LCI_NATIONALITY")
	private String lciNationality;

	@Column(name="LCI_NREGA_JC_NO")
	private String lciNregaJcNo;

	@Column(name="LCI_OTHER_ID")
	private String lciOtherId;

	@Column(name="LCI_OTHER_ID_NO")
	private String lciOtherIdNo;

	@Column(name="LCI_PAN_NO")
	private String lciPanNo;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_PASSPORT_EXPIRY")
	private Date lciPassportExpiry;

	@Column(name="LCI_PASSPORT_NO")
	private String lciPassportNo;

	@Column(name="LCI_PREF_LANG")
	private String lciPrefLang;

	@Column(name="LCI_RED_FLAG")
	private String lciRedFlag;

	@Column(name="LCI_RELATION")
	private String lciRelation;

	@Column(name="LCI_RELIGION")
	private String lciReligion;

	@Column(name="LCI_REMARKS")
	private String lciRemarks;

	@Column(name="LCI_RESI_TYPE")
	private String lciResiType;

	@Column(name="LCI_RISK_PROFILE")
	private String lciRiskProfile;

	@Column(name="LCI_RLN_WITH_BANK")
	private String lciRlnWithBank;

	@Column(name="LCI_RM_EMP_ID")
	private String lciRmEmpId;

	@Column(name="LCI_RM_EMP_NAME")
	private String lciRmEmpName;

	@Id
	@Column(name="LCI_ROW_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private BigDecimal lciRowId;

	@Column(name="LCI_SHORT_NAME")
	private String lciShortName;

	@Column(name="LCI_SPOUSE_NAME")
	private String lciSpouseName;

	@Column(name="LCI_SUBCLASSI_CAT")
	private String lciSubclassiCat;

	@Column(name="LCI_TITLE")
	private String lciTitle;

	@Column(name="LCI_VOTER_ID")
	private String lciVoterId;

	//bi-directional many-to-one association to LpcomCustInfo
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LCI_NEW_ID")
	private LpcomCustInfo lpcomCustInfo;

	public LpcomCustDataInd() {
	}

	public BigDecimal getLciAadharId() {
		return this.lciAadharId;
	}

	public void setLciAadharId(BigDecimal lciAadharId) {
		this.lciAadharId = lciAadharId;
	}

	public String getLciAccountType() {
		return this.lciAccountType;
	}

	public void setLciAccountType(String lciAccountType) {
		this.lciAccountType = lciAccountType;
	}

	public String getLciAddrProof() {
		return this.lciAddrProof;
	}

	public void setLciAddrProof(String lciAddrProof) {
		this.lciAddrProof = lciAddrProof;
	}

	public String getLciAddrProofNo() {
		return this.lciAddrProofNo;
	}

	public void setLciAddrProofNo(String lciAddrProofNo) {
		this.lciAddrProofNo = lciAddrProofNo;
	}

	public BigDecimal getLciBankingSince() {
		return this.lciBankingSince;
	}

	public void setLciBankingSince(BigDecimal lciBankingSince) {
		this.lciBankingSince = lciBankingSince;
	}

	public String getLciBranchCode() {
		return this.lciBranchCode;
	}

	public void setLciBranchCode(String lciBranchCode) {
		this.lciBranchCode = lciBranchCode;
	}

	public String getLciBranchName() {
		return this.lciBranchName;
	}

	public void setLciBranchName(String lciBranchName) {
		this.lciBranchName = lciBranchName;
	}

	public String getLciCaste() {
		return this.lciCaste;
	}

	public void setLciCaste(String lciCaste) {
		this.lciCaste = lciCaste;
	}

	public String getLciCatOthers() {
		return this.lciCatOthers;
	}

	public void setLciCatOthers(String lciCatOthers) {
		this.lciCatOthers = lciCatOthers;
	}

	public String getLciCategory() {
		return this.lciCategory;
	}

	public void setLciCategory(String lciCategory) {
		this.lciCategory = lciCategory;
	}

	public String getLciCersaiUpdate() {
		return this.lciCersaiUpdate;
	}

	public void setLciCersaiUpdate(String lciCersaiUpdate) {
		this.lciCersaiUpdate = lciCersaiUpdate;
	}

	public String getLciClassiCatgry() {
		return this.lciClassiCatgry;
	}

	public void setLciClassiCatgry(String lciClassiCatgry) {
		this.lciClassiCatgry = lciClassiCatgry;
	}

	public String getLciContPersonName() {
		return this.lciContPersonName;
	}

	public void setLciContPersonName(String lciContPersonName) {
		this.lciContPersonName = lciContPersonName;
	}

	public String getLciCpEmail() {
		return this.lciCpEmail;
	}

	public void setLciCpEmail(String lciCpEmail) {
		this.lciCpEmail = lciCpEmail;
	}

	public String getLciCpId() {
		return this.lciCpId;
	}

	public void setLciCpId(String lciCpId) {
		this.lciCpId = lciCpId;
	}

	public String getLciCpMobNo() {
		return this.lciCpMobNo;
	}

	public void setLciCpMobNo(String lciCpMobNo) {
		this.lciCpMobNo = lciCpMobNo;
	}

	public String getLciCpPhneNo() {
		return this.lciCpPhneNo;
	}

	public void setLciCpPhneNo(String lciCpPhneNo) {
		this.lciCpPhneNo = lciCpPhneNo;
	}

	public String getLciCreatedBy() {
		return this.lciCreatedBy;
	}

	public void setLciCreatedBy(String lciCreatedBy) {
		this.lciCreatedBy = lciCreatedBy;
	}

	public Date getLciCreatedOn() {
		return this.lciCreatedOn;
	}

	public void setLciCreatedOn(Date lciCreatedOn) {
		this.lciCreatedOn = lciCreatedOn;
	}

	public String getLciCustLob() {
		return this.lciCustLob;
	}

	public void setLciCustLob(String lciCustLob) {
		this.lciCustLob = lciCustLob;
	}

	public String getLciCustSegment() {
		return this.lciCustSegment;
	}

	public void setLciCustSegment(String lciCustSegment) {
		this.lciCustSegment = lciCustSegment;
	}

	public Date getLciDlExpiry() {
		return this.lciDlExpiry;
	}

	public void setLciDlExpiry(Date lciDlExpiry) {
		this.lciDlExpiry = lciDlExpiry;
	}

	public String getLciDlNo() {
		return this.lciDlNo;
	}

	public void setLciDlNo(String lciDlNo) {
		this.lciDlNo = lciDlNo;
	}

	public Date getLciDob() {
		return this.lciDob;
	}

	public void setLciDob(Date lciDob) {
		this.lciDob = lciDob;
	}

	public String getLciEduLevel() {
		return this.lciEduLevel;
	}

	public void setLciEduLevel(String lciEduLevel) {
		this.lciEduLevel = lciEduLevel;
	}

	public Date getLciEffFrom() {
		return this.lciEffFrom;
	}

	public void setLciEffFrom(Date lciEffFrom) {
		this.lciEffFrom = lciEffFrom;
	}

	public String getLciEmployType() {
		return this.lciEmployType;
	}

	public void setLciEmployType(String lciEmployType) {
		this.lciEmployType = lciEmployType;
	}

	public String getLciEwsFlag() {
		return this.lciEwsFlag;
	}

	public void setLciEwsFlag(String lciEwsFlag) {
		this.lciEwsFlag = lciEwsFlag;
	}

	public String getLciFatherName() {
		return this.lciFatherName;
	}

	public void setLciFatherName(String lciFatherName) {
		this.lciFatherName = lciFatherName;
	}

	public String getLciFiller1() {
		return this.lciFiller1;
	}

	public void setLciFiller1(String lciFiller1) {
		this.lciFiller1 = lciFiller1;
	}

	public String getLciFiller2() {
		return this.lciFiller2;
	}

	public void setLciFiller2(String lciFiller2) {
		this.lciFiller2 = lciFiller2;
	}

	public String getLciFiller3() {
		return this.lciFiller3;
	}

	public void setLciFiller3(String lciFiller3) {
		this.lciFiller3 = lciFiller3;
	}

	public String getLciFiller4() {
		return this.lciFiller4;
	}

	public void setLciFiller4(String lciFiller4) {
		this.lciFiller4 = lciFiller4;
	}

	public String getLciFirstName() {
		return this.lciFirstName;
	}

	public void setLciFirstName(String lciFirstName) {
		this.lciFirstName = lciFirstName;
	}

	public String getLciGender() {
		return this.lciGender;
	}

	public void setLciGender(String lciGender) {
		this.lciGender = lciGender;
	}

	public String getLciIdProof() {
		return this.lciIdProof;
	}

	public void setLciIdProof(String lciIdProof) {
		this.lciIdProof = lciIdProof;
	}

	public String getLciIdProofNo() {
		return this.lciIdProofNo;
	}

	public void setLciIdProofNo(String lciIdProofNo) {
		this.lciIdProofNo = lciIdProofNo;
	}

	public String getLciIncomeSlab() {
		return this.lciIncomeSlab;
	}

	public void setLciIncomeSlab(String lciIncomeSlab) {
		this.lciIncomeSlab = lciIncomeSlab;
	}

	public String getLciItType() {
		return this.lciItType;
	}

	public void setLciItType(String lciItType) {
		this.lciItType = lciItType;
	}

	public String getLciKycNo() {
		return this.lciKycNo;
	}

	public void setLciKycNo(String lciKycNo) {
		this.lciKycNo = lciKycNo;
	}

	public String getLciLastName() {
		return this.lciLastName;
	}

	public void setLciLastName(String lciLastName) {
		this.lciLastName = lciLastName;
	}

	public String getLciMaidenName() {
		return this.lciMaidenName;
	}

	public void setLciMaidenName(String lciMaidenName) {
		this.lciMaidenName = lciMaidenName;
	}

	public String getLciMaritalStatus() {
		return this.lciMaritalStatus;
	}

	public void setLciMaritalStatus(String lciMaritalStatus) {
		this.lciMaritalStatus = lciMaritalStatus;
	}

	public Date getLciMarriageDate() {
		return this.lciMarriageDate;
	}

	public void setLciMarriageDate(Date lciMarriageDate) {
		this.lciMarriageDate = lciMarriageDate;
	}

	public String getLciMiddleName() {
		return this.lciMiddleName;
	}

	public void setLciMiddleName(String lciMiddleName) {
		this.lciMiddleName = lciMiddleName;
	}

	public String getLciModifiedBy() {
		return this.lciModifiedBy;
	}

	public void setLciModifiedBy(String lciModifiedBy) {
		this.lciModifiedBy = lciModifiedBy;
	}

	public Date getLciModifiedOn() {
		return this.lciModifiedOn;
	}

	public void setLciModifiedOn(Date lciModifiedOn) {
		this.lciModifiedOn = lciModifiedOn;
	}

	public String getLciMotherName() {
		return this.lciMotherName;
	}

	public void setLciMotherName(String lciMotherName) {
		this.lciMotherName = lciMotherName;
	}

	public String getLciNationality() {
		return this.lciNationality;
	}

	public void setLciNationality(String lciNationality) {
		this.lciNationality = lciNationality;
	}

	public String getLciNregaJcNo() {
		return this.lciNregaJcNo;
	}

	public void setLciNregaJcNo(String lciNregaJcNo) {
		this.lciNregaJcNo = lciNregaJcNo;
	}

	public String getLciOtherId() {
		return this.lciOtherId;
	}

	public void setLciOtherId(String lciOtherId) {
		this.lciOtherId = lciOtherId;
	}

	public String getLciOtherIdNo() {
		return this.lciOtherIdNo;
	}

	public void setLciOtherIdNo(String lciOtherIdNo) {
		this.lciOtherIdNo = lciOtherIdNo;
	}

	public String getLciPanNo() {
		return this.lciPanNo;
	}

	public void setLciPanNo(String lciPanNo) {
		this.lciPanNo = lciPanNo;
	}

	public Date getLciPassportExpiry() {
		return this.lciPassportExpiry;
	}

	public void setLciPassportExpiry(Date lciPassportExpiry) {
		this.lciPassportExpiry = lciPassportExpiry;
	}

	public String getLciPassportNo() {
		return this.lciPassportNo;
	}

	public void setLciPassportNo(String lciPassportNo) {
		this.lciPassportNo = lciPassportNo;
	}

	public String getLciPrefLang() {
		return this.lciPrefLang;
	}

	public void setLciPrefLang(String lciPrefLang) {
		this.lciPrefLang = lciPrefLang;
	}

	public String getLciRedFlag() {
		return this.lciRedFlag;
	}

	public void setLciRedFlag(String lciRedFlag) {
		this.lciRedFlag = lciRedFlag;
	}

	public String getLciRelation() {
		return this.lciRelation;
	}

	public void setLciRelation(String lciRelation) {
		this.lciRelation = lciRelation;
	}

	public String getLciReligion() {
		return this.lciReligion;
	}

	public void setLciReligion(String lciReligion) {
		this.lciReligion = lciReligion;
	}

	public String getLciRemarks() {
		return this.lciRemarks;
	}

	public void setLciRemarks(String lciRemarks) {
		this.lciRemarks = lciRemarks;
	}

	public String getLciResiType() {
		return this.lciResiType;
	}

	public void setLciResiType(String lciResiType) {
		this.lciResiType = lciResiType;
	}

	public String getLciRiskProfile() {
		return this.lciRiskProfile;
	}

	public void setLciRiskProfile(String lciRiskProfile) {
		this.lciRiskProfile = lciRiskProfile;
	}

	public String getLciRlnWithBank() {
		return this.lciRlnWithBank;
	}

	public void setLciRlnWithBank(String lciRlnWithBank) {
		this.lciRlnWithBank = lciRlnWithBank;
	}

	public String getLciRmEmpId() {
		return this.lciRmEmpId;
	}

	public void setLciRmEmpId(String lciRmEmpId) {
		this.lciRmEmpId = lciRmEmpId;
	}

	public String getLciRmEmpName() {
		return this.lciRmEmpName;
	}

	public void setLciRmEmpName(String lciRmEmpName) {
		this.lciRmEmpName = lciRmEmpName;
	}

	public BigDecimal getLciRowId() {
		return this.lciRowId;
	}

	public void setLciRowId(BigDecimal lciRowId) {
		this.lciRowId = lciRowId;
	}

	public String getLciShortName() {
		return this.lciShortName;
	}

	public void setLciShortName(String lciShortName) {
		this.lciShortName = lciShortName;
	}

	public String getLciSpouseName() {
		return this.lciSpouseName;
	}

	public void setLciSpouseName(String lciSpouseName) {
		this.lciSpouseName = lciSpouseName;
	}

	public String getLciSubclassiCat() {
		return this.lciSubclassiCat;
	}

	public void setLciSubclassiCat(String lciSubclassiCat) {
		this.lciSubclassiCat = lciSubclassiCat;
	}

	public String getLciTitle() {
		return this.lciTitle;
	}

	public void setLciTitle(String lciTitle) {
		this.lciTitle = lciTitle;
	}

	public String getLciVoterId() {
		return this.lciVoterId;
	}

	public void setLciVoterId(String lciVoterId) {
		this.lciVoterId = lciVoterId;
	}

	public LpcomCustInfo getLpcomCustInfo() {
		return this.lpcomCustInfo;
	}

	public void setLpcomCustInfo(LpcomCustInfo lpcomCustInfo) {
		this.lpcomCustInfo = lpcomCustInfo;
	}

}