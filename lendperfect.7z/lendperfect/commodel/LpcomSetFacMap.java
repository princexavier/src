package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SET_FAC_MAP database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown =true)
@Entity
@Table(name="LPCOM_SET_FAC_MAP")
@NamedQueries({
@NamedQuery(name="LpcomSetFacMap.findAll", query="SELECT l FROM LpcomSetFacMap l"),
@NamedQuery(name="LpcomSetFacMap.findUniqueSetIdinFacMap", query="SELECT lsb FROM LpcomSetFacMap lsb where lsb.lbsmSetId=:lbsmSetId AND lsb.lpcomProposal=:lpcomProposalObject")
})
public class LpcomSetFacMap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LBSM_CREATED_BY")
	private String lbsmCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBSM_CREATED_ON")
	private Date lbsmCreatedOn;

	@Column(name="LBSM_FAC_NO")
	private BigDecimal lbsmFacNo;

	@Column(name="LBSM_MODIFIED_BY")
	private String lbsmModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBSM_MODIFIED_ON")
	private Date lbsmModifiedOn;


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LBSM_ROW_ID")
	private BigDecimal lbsmRowId;

	@Column(name="LBSM_SET_ID")
	private BigDecimal lbsmSetId;
	
	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LBSM_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomSetFacMap() {
	}

	public String getLbsmCreatedBy() {
		return this.lbsmCreatedBy;
	}

	public void setLbsmCreatedBy(String lbsmCreatedBy) {
		this.lbsmCreatedBy = lbsmCreatedBy;
	}

	public Date getLbsmCreatedOn() {
		return this.lbsmCreatedOn;
	}

	public void setLbsmCreatedOn(Date lbsmCreatedOn) {
		this.lbsmCreatedOn = lbsmCreatedOn;
	}

	public BigDecimal getLbsmFacNo() {
		return this.lbsmFacNo;
	}

	public void setLbsmFacNo(BigDecimal lbsmFacNo) {
		this.lbsmFacNo = lbsmFacNo;
	}

	public String getLbsmModifiedBy() {
		return this.lbsmModifiedBy;
	}

	public void setLbsmModifiedBy(String lbsmModifiedBy) {
		this.lbsmModifiedBy = lbsmModifiedBy;
	}

	public Date getLbsmModifiedOn() {
		return this.lbsmModifiedOn;
	}

	public void setLbsmModifiedOn(Date lbsmModifiedOn) {
		this.lbsmModifiedOn = lbsmModifiedOn;
	}


	public BigDecimal getLbsmRowId() {
		return this.lbsmRowId;
	}

	public void setLbsmRowId(BigDecimal lbsmRowId) {
		this.lbsmRowId = lbsmRowId;
	}

	public BigDecimal getLbsmSetId() {
		return this.lbsmSetId;
	}

	public void setLbsmSetId(BigDecimal lbsmSetId) {
		this.lbsmSetId = lbsmSetId;
	}
	
	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}