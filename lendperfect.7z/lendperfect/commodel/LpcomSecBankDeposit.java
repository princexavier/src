package com.sai.lendperfect.commodel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * The persistent class for the LPCOM_SEC_BANK_DEPOSITS database table.
 * 
 */
@Entity
@Table(name = "LPCOM_SEC_BANK_DEPOSITS")
@NamedQuery(name = "LpcomSecBankDeposit.findAll", query = "SELECT l FROM LpcomSecBankDeposit l")
public class LpcomSecBankDeposit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "LSBD_ACCT_NO")
	private BigDecimal lsbdAcctNo;

	@Column(name = "LSBD_BANK")
	private String lsbdBank;

	@Column(name = "LSBD_BOOK_VALUE")
	private BigDecimal lsbdBookValue;

	@Column(name = "LSBD_BRANCH_NAME")
	private String lsbdBranchName;

	@Column(name = "LSBD_BANK_NAME")
	private String lsbdBankName;

	@Column(name = "LSBD_CREATED_BY")
	private String lsbdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LSBD_CREATED_ON")
	private Date lsbdCreatedOn;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name = "LSBD_DATE_OF_ISSUE")
	private Date lsbdDateOfIssue;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name = "LSBD_DUE_DATE")
	private Date lsbdDueDate;

	@Column(name = "LSBD_MATURITY_VALUE")
	private BigDecimal lsbdMaturityValue;

	@Column(name = "LSBD_MODIFIED_BY")
	private String lsbdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LSBD_MODIFIED_ON")
	private Date lsbdModifiedOn;

	@Column(name = "LSBD_PRINCIPLE_VALUE")
	private BigDecimal lsbdPrincipleValue;

	@Column(name = "LSBD_ROI")
	private BigDecimal lsbdRoi;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LSBD_ROW_ID", columnDefinition = "NUMERIC(19,0)")
	private BigDecimal lsbdRowId;

	// bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "LSBD_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomSecBankDeposit() {
	}

	public BigDecimal getLsbdAcctNo() {
		return this.lsbdAcctNo;
	}

	public void setLsbdAcctNo(BigDecimal lsbdAcctNo) {
		this.lsbdAcctNo = lsbdAcctNo;
	}

	public String getLsbdBank() {
		return this.lsbdBank;
	}

	public void setLsbdBank(String lsbdBank) {
		this.lsbdBank = lsbdBank;
	}

	public String getLsbdBankName() {
		return lsbdBankName;
	}

	public void setLsbdBankName(String lsbdBankName) {
		this.lsbdBankName = lsbdBankName;
	}

	public BigDecimal getLsbdBookValue() {
		return this.lsbdBookValue;
	}

	public void setLsbdBookValue(BigDecimal lsbdBookValue) {
		this.lsbdBookValue = lsbdBookValue;
	}

	public String getLsbdBranchName() {
		return this.lsbdBranchName;
	}

	public void setLsbdBranchName(String lsbdBranchName) {
		this.lsbdBranchName = lsbdBranchName;
	}

	public String getLsbdCreatedBy() {
		return this.lsbdCreatedBy;
	}

	public void setLsbdCreatedBy(String lsbdCreatedBy) {
		this.lsbdCreatedBy = lsbdCreatedBy;
	}

	public Date getLsbdCreatedOn() {
		return this.lsbdCreatedOn;
	}

	public void setLsbdCreatedOn(Date lsbdCreatedOn) {
		this.lsbdCreatedOn = lsbdCreatedOn;
	}

	public Date getLsbdDateOfIssue() {
		return this.lsbdDateOfIssue;
	}

	public void setLsbdDateOfIssue(Date lsbdDateOfIssue) {
		this.lsbdDateOfIssue = lsbdDateOfIssue;
	}

	public Date getLsbdDueDate() {
		return this.lsbdDueDate;
	}

	public void setLsbdDueDate(Date lsbdDueDate) {
		this.lsbdDueDate = lsbdDueDate;
	}

	public BigDecimal getLsbdMaturityValue() {
		return this.lsbdMaturityValue;
	}

	public void setLsbdMaturityValue(BigDecimal lsbdMaturityValue) {
		this.lsbdMaturityValue = lsbdMaturityValue;
	}

	public String getLsbdModifiedBy() {
		return this.lsbdModifiedBy;
	}

	public void setLsbdModifiedBy(String lsbdModifiedBy) {
		this.lsbdModifiedBy = lsbdModifiedBy;
	}

	public Date getLsbdModifiedOn() {
		return this.lsbdModifiedOn;
	}

	public void setLsbdModifiedOn(Date lsbdModifiedOn) {
		this.lsbdModifiedOn = lsbdModifiedOn;
	}

	public BigDecimal getLsbdPrincipleValue() {
		return this.lsbdPrincipleValue;
	}

	public void setLsbdPrincipleValue(BigDecimal lsbdPrincipleValue) {
		this.lsbdPrincipleValue = lsbdPrincipleValue;
	}

	public BigDecimal getLsbdRoi() {
		return this.lsbdRoi;
	}

	public void setLsbdRoi(BigDecimal lsbdRoi) {
		this.lsbdRoi = lsbdRoi;
	}

	public BigDecimal getLsbdRowId() {
		return this.lsbdRowId;
	}

	public void setLsbdRowId(BigDecimal lsbdRowId) {
		this.lsbdRowId = lsbdRowId;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

	@Override
	public String toString() {
		return "LpcomSecBankDeposit [lsbdAcctNo=" + lsbdAcctNo + ", lsbdBank=" + lsbdBank + ", lsbdBookValue=" + lsbdBookValue + ", lsbdBranchName=" + lsbdBranchName + ", lsbdCreatedBy=" + lsbdCreatedBy + ", lsbdCreatedOn=" + lsbdCreatedOn + ", lsbdDateOfIssue=" + lsbdDateOfIssue + ", lsbdDueDate="
				+ lsbdDueDate + ", lsbdMaturityValue=" + lsbdMaturityValue + ", lsbdModifiedBy=" + lsbdModifiedBy + ", lsbdModifiedOn=" + lsbdModifiedOn + ", lsbdPrincipleValue=" + lsbdPrincipleValue + ", lsbdRoi=" + lsbdRoi + ", lsbdRowId=" + lsbdRowId + ", lpcomSecurity=" + lpcomSecurity + "]";
	}

}