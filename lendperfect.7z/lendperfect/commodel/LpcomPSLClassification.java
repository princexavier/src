package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_PSL_CLASSIFICATION database table.
 * 
 */
@Entity
@Table(name="LPCOM_PSL_CLASSIFICATION")
@NamedQuery(name="LpcomPSLClassification.findAll", query="SELECT l FROM LpcomPSLClassification l")
public class LpcomPSLClassification implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPC_BSR_CODE")
	private String lpcBsrCode;

	@Column(name="LPC_COMMUNITY")
	private String lpcCommunity;

	@Column(name="LPC_CREATED_BY")
	private String lpcCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPC_CREATED_ON")
	private Date lpcCreatedOn;

	@Column(name="LPC_CUST_TYPE")
	private String lpcCustType;

	@Column(name="LPC_FAC_NO")
	private BigDecimal lpcFacNo;

	@Column(name="LPC_FARMER_CAT")
	private String lpcFarmerCat;

	@Column(name="LPC_IND_TYPE")
	private String lpcIndType;

	@Column(name="LPC_LAND_ACRE")
	private BigDecimal lpcLandAcre;

	@Column(name="LPC_LOAN_PURP")
	private String lpcLoanPurp;

	@Column(name="LPC_LOAN_SUB_PURP")
	private String lpcLoanSubPurp;

	@Column(name="LPC_LOCATION")
	private String lpcLocation;

	@Column(name="LPC_MAIN_ACTIVITY")
	private String lpcMainActivity;

	@Column(name="LPC_MODIFIED_BY")
	private String lpcModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPC_MODIFIED_ON")
	private Date lpcModifiedOn;

	@Column(name="LPC_MSE_SUB_CAT")
	private String lpcMseSubCat;

	@Column(name="LPC_PM_VALUE")
	private BigDecimal lpcPmValue;

	@Column(name="LPC_PROP_NO")
	private BigDecimal lpcPropNo;

	@Column(name="LPC_PSL_TYPE")
	private String lpcPslType;

	@Id
	@Column(name="LPC_ROW_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private BigDecimal lpcRowId;

	@Column(name="LPC_SECTOR")
	private String lpcSector;

	@Column(name="LPC_WEAKER_SEC")
	private String lpcWeakerSec;

	public LpcomPSLClassification() {
	}

	public String getLpcBsrCode() {
		return this.lpcBsrCode;
	}

	public void setLpcBsrCode(String lpcBsrCode) {
		this.lpcBsrCode = lpcBsrCode;
	}

	public String getLpcCommunity() {
		return this.lpcCommunity;
	}

	public void setLpcCommunity(String lpcCommunity) {
		this.lpcCommunity = lpcCommunity;
	}

	public String getLpcCreatedBy() {
		return this.lpcCreatedBy;
	}

	public void setLpcCreatedBy(String lpcCreatedBy) {
		this.lpcCreatedBy = lpcCreatedBy;
	}

	public Date getLpcCreatedOn() {
		return this.lpcCreatedOn;
	}

	public void setLpcCreatedOn(Date lpcCreatedOn) {
		this.lpcCreatedOn = lpcCreatedOn;
	}

	public String getLpcCustType() {
		return this.lpcCustType;
	}

	public void setLpcCustType(String lpcCustType) {
		this.lpcCustType = lpcCustType;
	}

	public BigDecimal getLpcFacNo() {
		return this.lpcFacNo;
	}

	public void setLpcFacNo(BigDecimal lpcFacNo) {
		this.lpcFacNo = lpcFacNo;
	}

	public String getLpcFarmerCat() {
		return this.lpcFarmerCat;
	}

	public void setLpcFarmerCat(String lpcFarmerCat) {
		this.lpcFarmerCat = lpcFarmerCat;
	}

	public String getLpcIndType() {
		return this.lpcIndType;
	}

	public void setLpcIndType(String lpcIndType) {
		this.lpcIndType = lpcIndType;
	}

	public BigDecimal getLpcLandAcre() {
		return this.lpcLandAcre;
	}

	public void setLpcLandAcre(BigDecimal lpcLandAcre) {
		this.lpcLandAcre = lpcLandAcre;
	}

	public String getLpcLoanPurp() {
		return this.lpcLoanPurp;
	}

	public void setLpcLoanPurp(String lpcLoanPurp) {
		this.lpcLoanPurp = lpcLoanPurp;
	}

	public String getLpcLoanSubPurp() {
		return this.lpcLoanSubPurp;
	}

	public void setLpcLoanSubPurp(String lpcLoanSubPurp) {
		this.lpcLoanSubPurp = lpcLoanSubPurp;
	}

	public String getLpcLocation() {
		return this.lpcLocation;
	}

	public void setLpcLocation(String lpcLocation) {
		this.lpcLocation = lpcLocation;
	}

	public String getLpcMainActivity() {
		return this.lpcMainActivity;
	}

	public void setLpcMainActivity(String lpcMainActivity) {
		this.lpcMainActivity = lpcMainActivity;
	}

	public String getLpcModifiedBy() {
		return this.lpcModifiedBy;
	}

	public void setLpcModifiedBy(String lpcModifiedBy) {
		this.lpcModifiedBy = lpcModifiedBy;
	}

	public Date getLpcModifiedOn() {
		return this.lpcModifiedOn;
	}

	public void setLpcModifiedOn(Date lpcModifiedOn) {
		this.lpcModifiedOn = lpcModifiedOn;
	}

	public String getLpcMseSubCat() {
		return this.lpcMseSubCat;
	}

	public void setLpcMseSubCat(String lpcMseSubCat) {
		this.lpcMseSubCat = lpcMseSubCat;
	}

	public BigDecimal getLpcPmValue() {
		return this.lpcPmValue;
	}

	public void setLpcPmValue(BigDecimal lpcPmValue) {
		this.lpcPmValue = lpcPmValue;
	}

	public BigDecimal getLpcPropNo() {
		return this.lpcPropNo;
	}

	public void setLpcPropNo(BigDecimal lpcPropNo) {
		this.lpcPropNo = lpcPropNo;
	}

	public String getLpcPslType() {
		return this.lpcPslType;
	}

	public void setLpcPslType(String lpcPslType) {
		this.lpcPslType = lpcPslType;
	}

	public BigDecimal getLpcRowId() {
		return this.lpcRowId;
	}

	public void setLpcRowId(BigDecimal lpcRowId) {
		this.lpcRowId = lpcRowId;
	}

	public String getLpcSector() {
		return this.lpcSector;
	}

	public void setLpcSector(String lpcSector) {
		this.lpcSector = lpcSector;
	}

	public String getLpcWeakerSec() {
		return this.lpcWeakerSec;
	}

	public void setLpcWeakerSec(String lpcWeakerSec) {
		this.lpcWeakerSec = lpcWeakerSec;
	}

}