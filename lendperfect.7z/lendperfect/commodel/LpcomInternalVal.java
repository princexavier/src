package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_INTERNAL_VAL database table.
 * 
 */
@Entity
@Table(name="LPCOM_INTERNAL_VAL")
@NamedQuery(name="LpcomInternalVal.findAll", query="SELECT l FROM LpcomInternalVal l")
public class LpcomInternalVal implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LIV_BUILDER_NAME")
	private String livBuilderName;

	@Column(name="LIV_CP_DET")
	private String livCpDet;

	@Column(name="LIV_CREATED_BY")
	private String livCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LIV_CREATED_ON")
	private Date livCreatedOn;

	@Column(name="LIV_CUST_NAME")
	private String livCustName;

	@Column(name="LIV_DEMAN_DET")
	private BigDecimal livDemanDet;

	@Column(name="LIV_EAST")
	private String livEast;

	@Column(name="LIV_EXT_VAL_NAME")
	private String livExtValName;

	@Column(name="LIV_EXTERNAL_VALUE")
	private BigDecimal livExternalValue;

	@Column(name="LIV_FINAL_VALUE")
	private BigDecimal livFinalValue;

	@Column(name="LIV_FLOORS")
	private BigDecimal livFloors;

	@Column(name="LIV_HOUSE_NAME")
	private String livHouseName;

	@Column(name="LIV_INT_VAL_DONE")
	private String livIntValDone;

	@Column(name="LIV_INTERNAL_VALUE")
	private BigDecimal livInternalValue;

	@Column(name="LIV_LANDMARK")
	private String livLandmark;

	@Column(name="LIV_LATITUDE")
	private String livLatitude;

	@Column(name="LIV_LONGITUDE")
	private String livLongitude;

	@Column(name="LIV_MODIFIED_BY")
	private String livModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LIV_MODIFIED_ON")
	private Date livModifiedOn;

	@Column(name="LIV_NORTH")
	private String livNorth;

	@Column(name="LIV_OCC_DET")
	private BigDecimal livOccDet;

	@Column(name="LIV_PINCODE")
	private BigDecimal livPincode;

	@Column(name="LIV_PROJ_ID")
	private BigDecimal livProjId;

	@Column(name="LIV_PROJ_NAME")
	private String livProjName;

	@Column(name="LIV_PROP_ADDR")
	private String livPropAddr;

	@Column(name="LIV_PROP_AGE")
	private BigDecimal livPropAge;

	@Column(name="LIV_PROP_TYPE")
	private String livPropType;

	@Column(name="LIV_RES_FLAT")
	private String livResFlat;

	@Column(name="LIV_RM_NAME")
	private String livRmName;

	@Id
	@Column(name="LIV_ROW_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private BigDecimal livRowId;

	@Column(name="LIV_SELECTED")
	private String livSelected;

	@Column(name="LIV_SOUTH")
	private String livSouth;

	@Column(name="LIV_STATE")
	private String livState;

	@Column(name="LIV_STRUCT_TYPE")
	private String livStructType;

	@Column(name="LIV_VAL_TYPE")
	private String livValType;

	@Column(name="LIV_WEST")
	private String livWest;
	
	@Column(name="LIV_STATUS")
	private String livStatus;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LIV_PROP_NO")
	private LpcomProposal lpcomProposal;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LIV_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomInternalVal() {
	}

	public String getLivBuilderName() {
		return this.livBuilderName;
	}

	public void setLivBuilderName(String livBuilderName) {
		this.livBuilderName = livBuilderName;
	}

	public String getLivCpDet() {
		return this.livCpDet;
	}

	public void setLivCpDet(String livCpDet) {
		this.livCpDet = livCpDet;
	}

	public String getLivCreatedBy() {
		return this.livCreatedBy;
	}

	public void setLivCreatedBy(String livCreatedBy) {
		this.livCreatedBy = livCreatedBy;
	}

	public Date getLivCreatedOn() {
		return this.livCreatedOn;
	}

	public void setLivCreatedOn(Date livCreatedOn) {
		this.livCreatedOn = livCreatedOn;
	}

	public String getLivCustName() {
		return this.livCustName;
	}

	public void setLivCustName(String livCustName) {
		this.livCustName = livCustName;
	}

	public BigDecimal getLivDemanDet() {
		return this.livDemanDet;
	}

	public void setLivDemanDet(BigDecimal livDemanDet) {
		this.livDemanDet = livDemanDet;
	}

	public String getLivEast() {
		return this.livEast;
	}

	public void setLivEast(String livEast) {
		this.livEast = livEast;
	}

	public String getLivExtValName() {
		return this.livExtValName;
	}

	public void setLivExtValName(String livExtValName) {
		this.livExtValName = livExtValName;
	}

	public BigDecimal getLivExternalValue() {
		return this.livExternalValue;
	}

	public void setLivExternalValue(BigDecimal livExternalValue) {
		this.livExternalValue = livExternalValue;
	}

	public BigDecimal getLivFinalValue() {
		return this.livFinalValue;
	}

	public void setLivFinalValue(BigDecimal livFinalValue) {
		this.livFinalValue = livFinalValue;
	}

	public BigDecimal getLivFloors() {
		return this.livFloors;
	}

	public void setLivFloors(BigDecimal livFloors) {
		this.livFloors = livFloors;
	}

	public String getLivHouseName() {
		return this.livHouseName;
	}

	public void setLivHouseName(String livHouseName) {
		this.livHouseName = livHouseName;
	}

	public String getLivIntValDone() {
		return this.livIntValDone;
	}

	public void setLivIntValDone(String livIntValDone) {
		this.livIntValDone = livIntValDone;
	}

	public BigDecimal getLivInternalValue() {
		return this.livInternalValue;
	}

	public void setLivInternalValue(BigDecimal livInternalValue) {
		this.livInternalValue = livInternalValue;
	}

	public String getLivLandmark() {
		return this.livLandmark;
	}

	public void setLivLandmark(String livLandmark) {
		this.livLandmark = livLandmark;
	}

	public String getLivLatitude() {
		return this.livLatitude;
	}

	public void setLivLatitude(String livLatitude) {
		this.livLatitude = livLatitude;
	}

	public String getLivLongitude() {
		return this.livLongitude;
	}

	public void setLivLongitude(String livLongitude) {
		this.livLongitude = livLongitude;
	}

	public String getLivModifiedBy() {
		return this.livModifiedBy;
	}

	public void setLivModifiedBy(String livModifiedBy) {
		this.livModifiedBy = livModifiedBy;
	}

	public Date getLivModifiedOn() {
		return this.livModifiedOn;
	}

	public void setLivModifiedOn(Date livModifiedOn) {
		this.livModifiedOn = livModifiedOn;
	}

	public String getLivNorth() {
		return this.livNorth;
	}

	public void setLivNorth(String livNorth) {
		this.livNorth = livNorth;
	}

	public BigDecimal getLivOccDet() {
		return this.livOccDet;
	}

	public void setLivOccDet(BigDecimal livOccDet) {
		this.livOccDet = livOccDet;
	}

	public BigDecimal getLivPincode() {
		return this.livPincode;
	}

	public void setLivPincode(BigDecimal livPincode) {
		this.livPincode = livPincode;
	}

	public BigDecimal getLivProjId() {
		return this.livProjId;
	}

	public void setLivProjId(BigDecimal livProjId) {
		this.livProjId = livProjId;
	}

	public String getLivProjName() {
		return this.livProjName;
	}

	public void setLivProjName(String livProjName) {
		this.livProjName = livProjName;
	}

	public String getLivPropAddr() {
		return this.livPropAddr;
	}

	public void setLivPropAddr(String livPropAddr) {
		this.livPropAddr = livPropAddr;
	}

	public BigDecimal getLivPropAge() {
		return this.livPropAge;
	}

	public void setLivPropAge(BigDecimal livPropAge) {
		this.livPropAge = livPropAge;
	}

	public String getLivPropType() {
		return this.livPropType;
	}

	public void setLivPropType(String livPropType) {
		this.livPropType = livPropType;
	}

	public String getLivResFlat() {
		return this.livResFlat;
	}

	public void setLivResFlat(String livResFlat) {
		this.livResFlat = livResFlat;
	}

	public String getLivRmName() {
		return this.livRmName;
	}

	public void setLivRmName(String livRmName) {
		this.livRmName = livRmName;
	}

	public BigDecimal getLivRowId() {
		return this.livRowId;
	}

	public void setLivRowId(BigDecimal livRowId) {
		this.livRowId = livRowId;
	}

	public String getLivSelected() {
		return this.livSelected;
	}

	public void setLivSelected(String livSelected) {
		this.livSelected = livSelected;
	}

	public String getLivSouth() {
		return this.livSouth;
	}

	public void setLivSouth(String livSouth) {
		this.livSouth = livSouth;
	}

	public String getLivState() {
		return this.livState;
	}

	public void setLivState(String livState) {
		this.livState = livState;
	}

	public String getLivStructType() {
		return this.livStructType;
	}

	public void setLivStructType(String livStructType) {
		this.livStructType = livStructType;
	}

	public String getLivValType() {
		return this.livValType;
	}

	public void setLivValType(String livValType) {
		this.livValType = livValType;
	}

	public String getLivWest() {
		return this.livWest;
	}

	public void setLivWest(String livWest) {
		this.livWest = livWest;
	}

	public String getLivStatus() {
		return this.livStatus;
	}

	public void setLivStatus(String livStatus) {
		this.livStatus = livStatus;
	}
	
	
	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

}