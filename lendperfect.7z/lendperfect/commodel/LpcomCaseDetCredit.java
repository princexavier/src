package com.sai.lendperfect.commodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_CASE_DET_CREDIT database table.
 * 
 */
@Entity
@Table(name="LPCOM_CASE_DET_CREDIT")
@NamedQuery(name="LpcomCaseDetCredit.findAll", query="SELECT l FROM LpcomCaseDetCredit l")
public class LpcomCaseDetCredit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LP_CREATED_BY")
	private String lpCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LP_CREATED_ON")
	private Date lpCreatedOn;

	@Column(name="LP_MODIFIED_BY")
	private String lpModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LP_MODIFIED_ON")
	private Date lpModifiedOn;

	@Column(name="LPCDC_FILLER_FOUR")
	private String lpcdcFillerFour;

	@Column(name="LPCDC_FILLER_ONE")
	private String lpcdcFillerOne;

	@Column(name="LPCDC_FILLER_THREE")
	private String lpcdcFillerThree;

	@Column(name="LPCDC_FILLER_TWO")
	private String lpcdcFillerTwo;

	@Column(name="LPCDC_GRP_NAME")
	private String lpcdcGrpName;

	@Column(name="LPCDC_IND_ACT")
	private String lpcdcIndAct;

	@Column(name="LPCDC_IND_CODE")
	private String lpcdcIndCode;

	@Column(name="LPCDC_REAL_ESTATE_EXP")
	private String lpcdcRealEstateExp;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPCDC_ROW_ID")
	private BigDecimal lpcdcRowId;

	@Temporal(TemporalType.DATE)
	@Column(name="LPCDC_SANCD_DATE")
	private Date lpcdcSancdDate;

	@Column(name="LPCDC_SECURED")
	private String lpcdcSecured;

	@Column(name="LPCDC_SUSTAINABILITY")
	private String lpcdcSustainability;

	@Column(name="LPCDC_TAKEOVER")
	private String lpcdcTakeover;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LPCDC_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomCaseDetCredit() {
	}

	public String getLpCreatedBy() {
		return this.lpCreatedBy;
	}

	public void setLpCreatedBy(String lpCreatedBy) {
		this.lpCreatedBy = lpCreatedBy;
	}

	public Date getLpCreatedOn() {
		return this.lpCreatedOn;
	}

	public void setLpCreatedOn(Date lpCreatedOn) {
		this.lpCreatedOn = lpCreatedOn;
	}

	public String getLpModifiedBy() {
		return this.lpModifiedBy;
	}

	public void setLpModifiedBy(String lpModifiedBy) {
		this.lpModifiedBy = lpModifiedBy;
	}

	public Date getLpModifiedOn() {
		return this.lpModifiedOn;
	}

	public void setLpModifiedOn(Date lpModifiedOn) {
		this.lpModifiedOn = lpModifiedOn;
	}

	public String getLpcdcFillerFour() {
		return this.lpcdcFillerFour;
	}

	public void setLpcdcFillerFour(String lpcdcFillerFour) {
		this.lpcdcFillerFour = lpcdcFillerFour;
	}

	public String getLpcdcFillerOne() {
		return this.lpcdcFillerOne;
	}

	public void setLpcdcFillerOne(String lpcdcFillerOne) {
		this.lpcdcFillerOne = lpcdcFillerOne;
	}

	public String getLpcdcFillerThree() {
		return this.lpcdcFillerThree;
	}

	public void setLpcdcFillerThree(String lpcdcFillerThree) {
		this.lpcdcFillerThree = lpcdcFillerThree;
	}

	public String getLpcdcFillerTwo() {
		return this.lpcdcFillerTwo;
	}

	public void setLpcdcFillerTwo(String lpcdcFillerTwo) {
		this.lpcdcFillerTwo = lpcdcFillerTwo;
	}

	public String getLpcdcGrpName() {
		return this.lpcdcGrpName;
	}

	public void setLpcdcGrpName(String lpcdcGrpName) {
		this.lpcdcGrpName = lpcdcGrpName;
	}

	public String getLpcdcIndAct() {
		return this.lpcdcIndAct;
	}

	public void setLpcdcIndAct(String lpcdcIndAct) {
		this.lpcdcIndAct = lpcdcIndAct;
	}

	public String getLpcdcIndCode() {
		return this.lpcdcIndCode;
	}

	public void setLpcdcIndCode(String lpcdcIndCode) {
		this.lpcdcIndCode = lpcdcIndCode;
	}

	public String getLpcdcRealEstateExp() {
		return this.lpcdcRealEstateExp;
	}

	public void setLpcdcRealEstateExp(String lpcdcRealEstateExp) {
		this.lpcdcRealEstateExp = lpcdcRealEstateExp;
	}

	public BigDecimal getLpcdcRowId() {
		return this.lpcdcRowId;
	}

	public void setLpcdcRowId(BigDecimal lpcdcRowId) {
		this.lpcdcRowId = lpcdcRowId;
	}

	public Date getLpcdcSancdDate() {
		return this.lpcdcSancdDate;
	}

	public void setLpcdcSancdDate(Date lpcdcSancdDate) {
		this.lpcdcSancdDate = lpcdcSancdDate;
	}

	public String getLpcdcSecured() {
		return this.lpcdcSecured;
	}

	public void setLpcdcSecured(String lpcdcSecured) {
		this.lpcdcSecured = lpcdcSecured;
	}

	public String getLpcdcSustainability() {
		return this.lpcdcSustainability;
	}

	public void setLpcdcSustainability(String lpcdcSustainability) {
		this.lpcdcSustainability = lpcdcSustainability;
	}

	public String getLpcdcTakeover() {
		return this.lpcdcTakeover;
	}

	public void setLpcdcTakeover(String lpcdcTakeover) {
		this.lpcdcTakeover = lpcdcTakeover;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}