package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SEC_OWNER database table.
 * 
 */
@Entity
@Table(name="LPCOM_SEC_OWNER")
//@NamedQuery(name="LpcomSecOwner.findAll", query="SELECT l FROM LpcomSecOwner l")
public class LpcomSecOwner implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LSO_CREATED_BY")
	private String lsoCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSO_CREATED_ON")
	private Date lsoCreatedOn;

	@Column(name="LSO_MODIFIED_BY")
	private String lsoModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSO_MODIFIED_ON")
	private Date lsoModifiedOn;

	@Column(name="LSO_OWNER_ID")
	private BigDecimal lsoOwnerId;

	@Column(name="LSO_OWNER_SNO")
	private BigDecimal lsoOwnerSno;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LSO_ROW_ID",columnDefinition = "NUMERIC(19,0)")
	private BigDecimal lsoRowId;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LSO_SEC_ID")
	private LpcomSecurity lpcomSecurity;	
	
	@Column(name="LS_PRODUCT_ID")
	private BigDecimal lsProductId;

	@Column(name="LSO_PROPOSAL_NO")
	private BigDecimal lsProposalNo;
	
	
	public LpcomSecOwner() {
	}

	public String getLsoCreatedBy() {
		return this.lsoCreatedBy;
	}

	public void setLsoCreatedBy(String lsoCreatedBy) {
		this.lsoCreatedBy = lsoCreatedBy;
	}

	public Date getLsoCreatedOn() {
		return this.lsoCreatedOn;
	}

	public void setLsoCreatedOn(Date lsoCreatedOn) {
		this.lsoCreatedOn = lsoCreatedOn;
	}

	public String getLsoModifiedBy() {
		return this.lsoModifiedBy;
	}

	public void setLsoModifiedBy(String lsoModifiedBy) {
		this.lsoModifiedBy = lsoModifiedBy;
	}

	public Date getLsoModifiedOn() {
		return this.lsoModifiedOn;
	}

	public void setLsoModifiedOn(Date lsoModifiedOn) {
		this.lsoModifiedOn = lsoModifiedOn;
	}

	public BigDecimal getLsoOwnerId() {
		return this.lsoOwnerId;
	}

	public void setLsoOwnerId(BigDecimal lsoOwnerId) {
		this.lsoOwnerId = lsoOwnerId;
	}

	public BigDecimal getLsoOwnerSno() {
		return this.lsoOwnerSno;
	}

	public void setLsoOwnerSno(BigDecimal lsoOwnerSno) {
		this.lsoOwnerSno = lsoOwnerSno;
	}

	public BigDecimal getLsoRowId() {
		return this.lsoRowId;
	}

	public void setLsoRowId(BigDecimal lsoRowId) {
		this.lsoRowId = lsoRowId;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

	public BigDecimal getLsProductId() {
		return lsProductId;
	}

	public void setLsProductId(BigDecimal lsProductId) {
		this.lsProductId = lsProductId;
	}
	
	public BigDecimal getLsProposalNo() {
		return lsProposalNo;
	}

	public void setLsProposalNo(BigDecimal lsProposalNo) {
		this.lsProposalNo = lsProposalNo;
	}

	@Override
	public String toString() {
		return "LpcomSecOwner [lsoCreatedBy=" + lsoCreatedBy + ", lsoCreatedOn=" + lsoCreatedOn + ", lsoModifiedBy="
				+ lsoModifiedBy + ", lsoModifiedOn=" + lsoModifiedOn + ", lsoOwnerId=" + lsoOwnerId + ", lsoOwnerSno="
				+ lsoOwnerSno + ", lsoRowId=" + lsoRowId + ", lpcomSecurity=" + lpcomSecurity + "]";
	}

}