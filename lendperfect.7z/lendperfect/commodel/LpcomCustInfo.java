package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the LPCOM_CUST_INFO database table.
 * 
 */
@Entity
@Table(name="LPCOM_CUST_INFO")
@NamedQueries({
@NamedQuery(name="LpcomCustInfo.findAll", query="SELECT l FROM LpcomCustInfo l"),
@NamedQuery(name="LpcomCustInfo.getDataByPropNumandCustomerTypefromPropNumPartyMapping",
			query="SELECT lps FROM LpcomCustInfo lps WHERE  lps.lciCustId IN "
			+ " ( SELECT  DISTINCT lps2.lppCustId FROM LpcomPropParty lps2  WHERE lps2.lppCustType=:lppCustType AND lps2.lpcomProposal=:lpcomProposalObject  ) "
			+ " ORDER BY  lps.lciCustId "
	)
})
public class LpcomCustInfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LCI_NEW_ID")
	private long lciNewId;

	@Column(name="LCI_BCIF_CREATION")
	private String lciBcifCreation;

	@Column(name="LCI_BCIF_NO")
	private String lciBcifNo;

	@Column(name="LCI_COMPLETED")
	private String lciCompleted;

	@Column(name="LCI_CREATED_BY")
	private String lciCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_CREATED_ON")
	private Date lciCreatedOn;

	
	@Column(name="LCI_CUST_ID")
	private BigDecimal lciCustId;

	@Column(name="LCI_CUST_NAME")
	private String lciCustName;

	@Column(name="LCI_CUST_TYPE")
	private String lciCustType;

	@Column(name="LCI_EXISTING_CUST")
	private String lciExistingCust;

	@Column(name="LCI_MODIFIED_BY")
	private String lciModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCI_MODIFIED_ON")
	private Date lciModifiedOn;

	@Column(name="LCI_PSBL_BCIF_NO")
	private String lciPsblBcifNo;

	@Column(name="LCI_RECENT")
	private String lciRecent;
	
	@Column(name="LCI_PAN_STATUS")
	private String lciPanStatus;
	
	@Column(name="LCI_CIBIL_SCORE")
	private BigDecimal lciCibilScore;
	
	@Column(name="LCI_NCIF_STATUS")
	private String lciNcifStatus;

	//bi-directional many-to-one association to LpcomCustAddr
	@OneToMany(mappedBy="lpcomCustInfo")
	@Fetch(FetchMode.SELECT)
	@JsonIgnore
	private List<LpcomCustAddr> lpcomCustAddrs;

	//bi-directional many-to-one association to LpcomCustContctDet
	@OneToMany(mappedBy="lpcomCustInfo")
	@Fetch(FetchMode.SELECT)
	@JsonIgnore
	private List<LpcomCustContctDet> lpcomCustContctDets;

	//bi-directional many-to-one association to LpcomCustDataInd
	@OneToMany(mappedBy="lpcomCustInfo")
	@Fetch(FetchMode.SELECT)
	@JsonIgnore
	private List<LpcomCustDataInd> lpcomCustDataInds;

	//bi-directional many-to-one association to LpcomCustDataNind
	@OneToMany(mappedBy="lpcomCustInfo")
	@Fetch(FetchMode.SELECT)
	@JsonIgnore
	private List<LpcomCustDataNind> lpcomCustDataNinds;

	//bi-directional many-to-one association to LpcomPropParty
	@OneToMany(mappedBy="lpcomCustInfo")
	@Fetch(FetchMode.SELECT)
	@JsonIgnore
	private List<LpcomPropParty> lpcomPropParties;
	
	public LpcomCustInfo() {
	}

	public long getLciNewId() {
		return this.lciNewId;
	}

	public void setLciNewId(long lciNewId) {
		this.lciNewId = lciNewId;
	}

	public String getLciBcifCreation() {
		return this.lciBcifCreation;
	}

	public void setLciBcifCreation(String lciBcifCreation) {
		this.lciBcifCreation = lciBcifCreation;
	}

	public String getLciBcifNo() {
		return this.lciBcifNo;
	}

	public void setLciBcifNo(String lciBcifNo) {
		this.lciBcifNo = lciBcifNo;
	}

	public String getLciCompleted() {
		return this.lciCompleted;
	}

	public void setLciCompleted(String lciCompleted) {
		this.lciCompleted = lciCompleted;
	}

	public String getLciCreatedBy() {
		return this.lciCreatedBy;
	}

	public void setLciCreatedBy(String lciCreatedBy) {
		this.lciCreatedBy = lciCreatedBy;
	}

	public Date getLciCreatedOn() {
		return this.lciCreatedOn;
	}

	public void setLciCreatedOn(Date lciCreatedOn) {
		this.lciCreatedOn = lciCreatedOn;
	}

	public BigDecimal getLciCustId() {
		return this.lciCustId;
	}

	public void setLciCustId(BigDecimal lciCustId) {
		this.lciCustId = lciCustId;
	}

	public String getLciCustName() {
		return this.lciCustName;
	}

	public void setLciCustName(String lciCustName) {
		this.lciCustName = lciCustName;
	}

	public String getLciCustType() {
		return this.lciCustType;
	}

	public void setLciCustType(String lciCustType) {
		this.lciCustType = lciCustType;
	}

	public String getLciExistingCust() {
		return this.lciExistingCust;
	}

	public void setLciExistingCust(String lciExistingCust) {
		this.lciExistingCust = lciExistingCust;
	}

	public String getLciModifiedBy() {
		return this.lciModifiedBy;
	}

	public void setLciModifiedBy(String lciModifiedBy) {
		this.lciModifiedBy = lciModifiedBy;
	}

	public Date getLciModifiedOn() {
		return this.lciModifiedOn;
	}

	public void setLciModifiedOn(Date lciModifiedOn) {
		this.lciModifiedOn = lciModifiedOn;
	}

	public String getLciPsblBcifNo() {
		return this.lciPsblBcifNo;
	}

	public void setLciPsblBcifNo(String lciPsblBcifNo) {
		this.lciPsblBcifNo = lciPsblBcifNo;
	}

	public String getLciRecent() {
		return this.lciRecent;
	}

	public void setLciRecent(String lciRecent) {
		this.lciRecent = lciRecent;
	}

	public List<LpcomCustAddr> getLpcomCustAddrs() {
		return this.lpcomCustAddrs;
	}

	public String getLciPanStatus() {
		return lciPanStatus;
	}

	public void setLciPanStatus(String lciPanStatus) {
		this.lciPanStatus = lciPanStatus;
	}

	public BigDecimal getLciCibilScore() {
		return lciCibilScore;
	}

	public void setLciCibilScore(BigDecimal lciCibilScore) {
		this.lciCibilScore = lciCibilScore;
	}

	public String getLciNcifStatus() {
		return lciNcifStatus;
	}

	public void setLciNcifStatus(String lciNcifStatus) {
		this.lciNcifStatus = lciNcifStatus;
	}

	public void setLpcomCustAddrs(List<LpcomCustAddr> lpcomCustAddrs) {
		this.lpcomCustAddrs = lpcomCustAddrs;
	}

	public LpcomCustAddr addLpcomCustAddr(LpcomCustAddr lpcomCustAddr) {
		getLpcomCustAddrs().add(lpcomCustAddr);
		lpcomCustAddr.setLpcomCustInfo(this);

		return lpcomCustAddr;
	}

	public LpcomCustAddr removeLpcomCustAddr(LpcomCustAddr lpcomCustAddr) {
		getLpcomCustAddrs().remove(lpcomCustAddr);
		lpcomCustAddr.setLpcomCustInfo(null);

		return lpcomCustAddr;
	}

	public List<LpcomCustContctDet> getLpcomCustContctDets() {
		return this.lpcomCustContctDets;
	}

	public void setLpcomCustContctDets(List<LpcomCustContctDet> lpcomCustContctDets) {
		this.lpcomCustContctDets = lpcomCustContctDets;
	}

	public LpcomCustContctDet addLpcomCustContctDet(LpcomCustContctDet lpcomCustContctDet) {
		getLpcomCustContctDets().add(lpcomCustContctDet);
		lpcomCustContctDet.setLpcomCustInfo(this);

		return lpcomCustContctDet;
	}

	public LpcomCustContctDet removeLpcomCustContctDet(LpcomCustContctDet lpcomCustContctDet) {
		getLpcomCustContctDets().remove(lpcomCustContctDet);
		lpcomCustContctDet.setLpcomCustInfo(null);

		return lpcomCustContctDet;
	}

	public List<LpcomCustDataInd> getLpcomCustDataInds() {
		return this.lpcomCustDataInds;
	}

	public void setLpcomCustDataInds(List<LpcomCustDataInd> lpcomCustDataInds) {
		this.lpcomCustDataInds = lpcomCustDataInds;
	}

	public LpcomCustDataInd addLpcomCustDataInd(LpcomCustDataInd lpcomCustDataInd) {
		getLpcomCustDataInds().add(lpcomCustDataInd);
		lpcomCustDataInd.setLpcomCustInfo(this);

		return lpcomCustDataInd;
	}

	public LpcomCustDataInd removeLpcomCustDataInd(LpcomCustDataInd lpcomCustDataInd) {
		getLpcomCustDataInds().remove(lpcomCustDataInd);
		lpcomCustDataInd.setLpcomCustInfo(null);

		return lpcomCustDataInd;
	}

	public List<LpcomCustDataNind> getLpcomCustDataNinds() {
		return this.lpcomCustDataNinds;
	}

	public void setLpcomCustDataNinds(List<LpcomCustDataNind> lpcomCustDataNinds) {
		this.lpcomCustDataNinds = lpcomCustDataNinds;
	}

	public LpcomCustDataNind addLpcomCustDataNind(LpcomCustDataNind lpcomCustDataNind) {
		getLpcomCustDataNinds().add(lpcomCustDataNind);
		lpcomCustDataNind.setLpcomCustInfo(this);

		return lpcomCustDataNind;
	}

	public LpcomCustDataNind removeLpcomCustDataNind(LpcomCustDataNind lpcomCustDataNind) {
		getLpcomCustDataNinds().remove(lpcomCustDataNind);
		lpcomCustDataNind.setLpcomCustInfo(null);

		return lpcomCustDataNind;
	}
	public List<LpcomPropParty> getLpcomPropParties() {
		return this.lpcomPropParties;
	}

	public void setLpcomPropParties(List<LpcomPropParty> lpcomPropParties) {
		this.lpcomPropParties = lpcomPropParties;
	}

	public LpcomPropParty addLpcomPropParty(LpcomPropParty lpcomPropParty) {
		getLpcomPropParties().add(lpcomPropParty);
		lpcomPropParty.setLpcomCustInfo(this);

		return lpcomPropParty;
	}

	public LpcomPropParty removeLpcomPropParty(LpcomPropParty lpcomPropParty) {
		getLpcomPropParties().remove(lpcomPropParty);
		lpcomPropParty.setLpcomCustInfo(null);

		return lpcomPropParty;
	}

}