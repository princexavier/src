package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_PROP_TERMS_COND database table.
 * 
 */
@Entity
@Table(name="LPCOM_PROP_TERMS_COND")
@NamedQuery(name="LpcomPropTermsCond.findAll", query="SELECT l FROM LpcomPropTermsCond l")
public class LpcomPropTermsCond implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPTC_CREATED_BY")
	private String lptcCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPTC_CREATED_ON")
	private Date lptcCreatedOn;

	@Column(name="LPTC_DELETED")
	private String lptcDeleted;

	@Column(name="LPTC_DELETED_BY")
	private String lptcDeletedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPTC_DELETED_ON")
	private Date lptcDeletedOn;

	@Column(name="LPTC_DISB_TYPE")
	private String lptcDisbType;

	@Column(name="LPTC_FAC_NO")
	private BigDecimal lptcFacNo;

	@Column(name="LPTC_INT_EXT")
	private String lptcIntExt;

	@Column(name="LPTC_MANDATORY")
	private String lptcMandatory;

	@Column(name="LPTC_MODIFIED_BY")
	private String lptcModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPTC_MODIFIED_ON")
	private Date lptcModifiedOn;
	
			
	@Column(name="LPTC_DEFERRABLE")
	private String lptcdeferrable;
	
	@Column(name="LPTC_DUE_DATE")
	private Date lptcduedate;
	
	@Column(name="LPTC_FREQUENCY")
	private String lptcfrequency;
	
	@Column(name="LPTC_SL_PRINT")
	private String lptcSlPrint;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LPTC_ROW_ID",columnDefinition = "NUMERIC(19,0)")
	private BigDecimal lptcRowId;

	@Column(name="LPTC_TERMS_DESC")
	private String lptcTermsDesc;

	@Column(name="LPTC_TERMS_FOR")
	private String lptcTermsFor;

	@Column(name="LPTC_TERMS_ID")
	private BigDecimal lptcTermsId;

	@Column(name="LPTC_TYPE")
	private String lptcType;

	@Column(name="LPTC_TERMFLAG")
	private String lptcTermFlag;
	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LPTC_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomPropTermsCond() {
	}

	public String getLptcCreatedBy() {
		return this.lptcCreatedBy;
	}

	public void setLptcCreatedBy(String lptcCreatedBy) {
		this.lptcCreatedBy = lptcCreatedBy;
	}

	public Date getLptcCreatedOn() {
		return this.lptcCreatedOn;
	}

	public void setLptcCreatedOn(Date lptcCreatedOn) {
		this.lptcCreatedOn = lptcCreatedOn;
	}

	public String getLptcDeleted() {
		return this.lptcDeleted;
	}

	public void setLptcDeleted(String lptcDeleted) {
		this.lptcDeleted = lptcDeleted;
	}

	public String getLptcDeletedBy() {
		return this.lptcDeletedBy;
	}

	public void setLptcDeletedBy(String lptcDeletedBy) {
		this.lptcDeletedBy = lptcDeletedBy;
	}

	public Date getLptcDeletedOn() {
		return this.lptcDeletedOn;
	}

	public void setLptcDeletedOn(Date lptcDeletedOn) {
		this.lptcDeletedOn = lptcDeletedOn;
	}

	public String getLptcDisbType() {
		return this.lptcDisbType;
	}

	public void setLptcDisbType(String lptcDisbType) {
		this.lptcDisbType = lptcDisbType;
	}

	public BigDecimal getLptcFacNo() {
		return this.lptcFacNo;
	}

	public void setLptcFacNo(BigDecimal lptcFacNo) {
		this.lptcFacNo = lptcFacNo;
	}

	public String getLptcIntExt() {
		return this.lptcIntExt;
	}

	public void setLptcIntExt(String lptcIntExt) {
		this.lptcIntExt = lptcIntExt;
	}

	public String getLptcMandatory() {
		return this.lptcMandatory;
	}

	public void setLptcMandatory(String lptcMandatory) {
		this.lptcMandatory = lptcMandatory;
	}

	public String getLptcModifiedBy() {
		return this.lptcModifiedBy;
	}

	public void setLptcModifiedBy(String lptcModifiedBy) {
		this.lptcModifiedBy = lptcModifiedBy;
	}

	public Date getLptcModifiedOn() {
		return this.lptcModifiedOn;
	}

	public void setLptcModifiedOn(Date lptcModifiedOn) {
		this.lptcModifiedOn = lptcModifiedOn;
	}

	public BigDecimal getLptcRowId() {
		return this.lptcRowId;
	}

	public void setLptcRowId(BigDecimal lptcRowId) {
		this.lptcRowId = lptcRowId;
	}

	public String getLptcTermsDesc() {
		return this.lptcTermsDesc;
	}

	public void setLptcTermsDesc(String lptcTermsDesc) {
		this.lptcTermsDesc = lptcTermsDesc;
	}

	public String getLptcTermsFor() {
		return this.lptcTermsFor;
	}

	public void setLptcTermsFor(String lptcTermsFor) {
		this.lptcTermsFor = lptcTermsFor;
	}

	public BigDecimal getLptcTermsId() {
		return this.lptcTermsId;
	}

	public void setLptcTermsId(BigDecimal lptcTermsId) {
		this.lptcTermsId = lptcTermsId;
	}

	public String getLptcType() {
		return this.lptcType;
	}

	public void setLptcType(String lptcType) {
		this.lptcType = lptcType;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}





	public Date getLptcduedate() {
		return lptcduedate;
	}

	public void setLptcduedate(Date lptcduedate) {
		this.lptcduedate = lptcduedate;
	}

	public String getLptcdeferrable() {
		return lptcdeferrable;
	}

	public void setLptcdeferrable(String lptcdeferrable) {
		this.lptcdeferrable = lptcdeferrable;
	}

	public String getLptcfrequency() {
		return lptcfrequency;
	}

	public void setLptcfrequency(String lptcfrequency) {
		this.lptcfrequency = lptcfrequency;
	}

	public String getLptcSlPrint() {
		return lptcSlPrint;
	}

	public void setLptcSlPrint(String lptcSlPrint) {
		this.lptcSlPrint = lptcSlPrint;
	}

	public String getLptcTermFlag() {
		return lptcTermFlag;
	}

	public void setLptcTermFlag(String lptcTermFlag) {
		this.lptcTermFlag = lptcTermFlag;
	}

	@Override
	public String toString() {
		return "LpcomPropTermsCond [lptcCreatedBy=" + lptcCreatedBy + ", lptcCreatedOn=" + lptcCreatedOn
				+ ", lptcDeleted=" + lptcDeleted + ", lptcDeletedBy=" + lptcDeletedBy + ", lptcDeletedOn="
				+ lptcDeletedOn + ", lptcDisbType=" + lptcDisbType + ", lptcFacNo=" + lptcFacNo + ", lptcIntExt="
				+ lptcIntExt + ", lptcMandatory=" + lptcMandatory + ", lptcModifiedBy=" + lptcModifiedBy
				+ ", lptcModifiedOn=" + lptcModifiedOn + ", lptcdeferrable=" + lptcdeferrable + ", lptcduedate="
				+ lptcduedate + ", lptcfrequency=" + lptcfrequency + ", lptcSlPrint=" + lptcSlPrint + ", lptcRowId="
				+ lptcRowId + ", lptcTermsDesc=" + lptcTermsDesc + ", lptcTermsFor=" + lptcTermsFor + ", lptcTermsId="
				+ lptcTermsId + ", lptcType=" + lptcType + ", lptcTermFlag=" + lptcTermFlag + ", lpcomProposal="
				+ lpcomProposal + "]";
	}

}