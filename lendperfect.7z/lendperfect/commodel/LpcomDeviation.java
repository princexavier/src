package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_DEVIATION database table.
 * 
 */
@Entity
@Table(name="LPCOM_DEVIATION")
@NamedQuery(name="LpcomDeviation.findAll", query="SELECT l FROM LpcomDeviation l")
public class LpcomDeviation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LD_APPROVED_BY")
	private String ldApprovedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LD_APPROVED_ON")
	private Date ldApprovedOn;

	@Column(name="LD_CREATED_BY")
	private String ldCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LD_CREATED_ON")
	private Date ldCreatedOn;

	@Column(name="LD_DEV_CONDITION")
	private String ldDevCondition;

	@Column(name="LD_DEV_ID")
	private BigDecimal ldDevId;

	@Column(name="LD_DEV_NAME")
	private String ldDevName;

	@Column(name="LD_DEV_STATUS")
	private String ldDevStatus;

	@Column(name="LD_DEV_TYPE")
	private String ldDevType;

	@Column(name="LD_FAC_ID")
	private BigDecimal ldFacId;

	@Column(name="LD_MIN_APP_AUTH")
	private BigDecimal ldMinAppAuth;

	@Column(name="LD_MODIFIED_BY")
	private String ldModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LD_MODIFIED_ON")
	private Date ldModifiedOn;

	@Column(name="LD_PARTY_ID")
	private BigDecimal ldPartyId;

	@Column(name="LD_PROP_NO")
	private BigDecimal ldPropNo;

	@Column(name="LD_REMARKS")
	private String ldRemarks;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LD_ROW_ID")
	private BigDecimal ldRowId;

	public LpcomDeviation() {
	}

	public String getLdApprovedBy() {
		return this.ldApprovedBy;
	}

	public void setLdApprovedBy(String ldApprovedBy) {
		this.ldApprovedBy = ldApprovedBy;
	}

	public Date getLdApprovedOn() {
		return this.ldApprovedOn;
	}

	public void setLdApprovedOn(Date ldApprovedOn) {
		this.ldApprovedOn = ldApprovedOn;
	}

	public String getLdCreatedBy() {
		return this.ldCreatedBy;
	}

	public void setLdCreatedBy(String ldCreatedBy) {
		this.ldCreatedBy = ldCreatedBy;
	}

	public Date getLdCreatedOn() {
		return this.ldCreatedOn;
	}

	public void setLdCreatedOn(Date ldCreatedOn) {
		this.ldCreatedOn = ldCreatedOn;
	}

	public String getLdDevCondition() {
		return this.ldDevCondition;
	}

	public void setLdDevCondition(String ldDevCondition) {
		this.ldDevCondition = ldDevCondition;
	}

	public BigDecimal getLdDevId() {
		return this.ldDevId;
	}

	public void setLdDevId(BigDecimal ldDevId) {
		this.ldDevId = ldDevId;
	}

	public String getLdDevName() {
		return this.ldDevName;
	}

	public void setLdDevName(String ldDevName) {
		this.ldDevName = ldDevName;
	}

	public String getLdDevStatus() {
		return this.ldDevStatus;
	}

	public void setLdDevStatus(String ldDevStatus) {
		this.ldDevStatus = ldDevStatus;
	}

	public String getLdDevType() {
		return this.ldDevType;
	}

	public void setLdDevType(String ldDevType) {
		this.ldDevType = ldDevType;
	}

	public BigDecimal getLdFacId() {
		return this.ldFacId;
	}

	public void setLdFacId(BigDecimal ldFacId) {
		this.ldFacId = ldFacId;
	}

	public BigDecimal getLdMinAppAuth() {
		return this.ldMinAppAuth;
	}

	public void setLdMinAppAuth(BigDecimal ldMinAppAuth) {
		this.ldMinAppAuth = ldMinAppAuth;
	}

	public String getLdModifiedBy() {
		return this.ldModifiedBy;
	}

	public void setLdModifiedBy(String ldModifiedBy) {
		this.ldModifiedBy = ldModifiedBy;
	}

	public Date getLdModifiedOn() {
		return this.ldModifiedOn;
	}

	public void setLdModifiedOn(Date ldModifiedOn) {
		this.ldModifiedOn = ldModifiedOn;
	}

	public BigDecimal getLdPartyId() {
		return this.ldPartyId;
	}

	public void setLdPartyId(BigDecimal ldPartyId) {
		this.ldPartyId = ldPartyId;
	}

	public BigDecimal getLdPropNo() {
		return this.ldPropNo;
	}

	public void setLdPropNo(BigDecimal ldPropNo) {
		this.ldPropNo = ldPropNo;
	}

	public String getLdRemarks() {
		return this.ldRemarks;
	}

	public void setLdRemarks(String ldRemarks) {
		this.ldRemarks = ldRemarks;
	}

	public BigDecimal getLdRowId() {
		return this.ldRowId;
	}

	public void setLdRowId(BigDecimal ldRowId) {
		this.ldRowId = ldRowId;
	}

}