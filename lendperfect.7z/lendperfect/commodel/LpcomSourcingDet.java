package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SOURCING_DET database table.
 * 
 */
@Entity
@Table(name="LPCOM_SOURCING_DET")
@NamedQuery(name="LpcomSourcingDet.findAll", query="SELECT l FROM LpcomSourcingDet l")
public class LpcomSourcingDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LSD_BSS_DESC")
	private String lsdBssDesc;

	@Column(name="LSD_BSS_VERTICAL")
	private String lsdBssVertical;

	@Column(name="LSD_CREATED_BY")
	private String lsdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSD_CREATED_ON")
	private Date lsdCreatedOn;

	@Column(name="LSD_DSA_CONT_NO")
	private BigDecimal lsdDsaContNo;

	@Column(name="LSD_FILLER_FOUR")
	private String lsdFillerFour;

	@Column(name="LSD_FILLER_ONE")
	private String lsdFillerOne;

	@Column(name="LSD_FILLER_THREE")
	private String lsdFillerThree;

	@Column(name="LSD_FILLER_TWO")
	private String lsdFillerTwo;

	@Column(name="LSD_HOME_BRANCH")
	private String lsdHomeBranch;

	@Column(name="LSD_KLEAD_ID")
	private String lsdKleadId;

	@Column(name="LSD_LOB")
	private String lsdLob;

	@Column(name="LSD_MODIFIED_BY")
	private String lsdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSD_MODIFIED_ON")
	private Date lsdModifiedOn;

	@Column(name="LSD_OP_HANDOVER")
	private String lsdOpHandover;

	@Column(name="LSD_REMARKS")
	private String lsdRemarks;

	@Column(name="LSD_RM_EMP_ID")
	private String lsdRmEmpId;

	@Column(name="LSD_RM_EMP_NAME")
	private String lsdRmEmpName;

	@Column(name="LSD_RM_USER")
	private String lsdRmUser;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LSD_ROW_ID")
	private BigDecimal lsdRowId;

	@Column(name="LSD_SOURCE_NAME")
	private String lsdSourceName;

	@Column(name="LSD_SOURCED_BY")
	private String lsdSourcedBy;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LSD_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomSourcingDet() {
	}

	public String getLsdBssDesc() {
		return this.lsdBssDesc;
	}

	public void setLsdBssDesc(String lsdBssDesc) {
		this.lsdBssDesc = lsdBssDesc;
	}

	public String getLsdBssVertical() {
		return this.lsdBssVertical;
	}

	public void setLsdBssVertical(String lsdBssVertical) {
		this.lsdBssVertical = lsdBssVertical;
	}

	public String getLsdCreatedBy() {
		return this.lsdCreatedBy;
	}

	public void setLsdCreatedBy(String lsdCreatedBy) {
		this.lsdCreatedBy = lsdCreatedBy;
	}

	public Date getLsdCreatedOn() {
		return this.lsdCreatedOn;
	}

	public void setLsdCreatedOn(Date lsdCreatedOn) {
		this.lsdCreatedOn = lsdCreatedOn;
	}

	public BigDecimal getLsdDsaContNo() {
		return this.lsdDsaContNo;
	}

	public void setLsdDsaContNo(BigDecimal lsdDsaContNo) {
		this.lsdDsaContNo = lsdDsaContNo;
	}

	public String getLsdFillerFour() {
		return this.lsdFillerFour;
	}

	public void setLsdFillerFour(String lsdFillerFour) {
		this.lsdFillerFour = lsdFillerFour;
	}

	public String getLsdFillerOne() {
		return this.lsdFillerOne;
	}

	public void setLsdFillerOne(String lsdFillerOne) {
		this.lsdFillerOne = lsdFillerOne;
	}

	public String getLsdFillerThree() {
		return this.lsdFillerThree;
	}

	public void setLsdFillerThree(String lsdFillerThree) {
		this.lsdFillerThree = lsdFillerThree;
	}

	public String getLsdFillerTwo() {
		return this.lsdFillerTwo;
	}

	public void setLsdFillerTwo(String lsdFillerTwo) {
		this.lsdFillerTwo = lsdFillerTwo;
	}

	public String getLsdHomeBranch() {
		return this.lsdHomeBranch;
	}

	public void setLsdHomeBranch(String lsdHomeBranch) {
		this.lsdHomeBranch = lsdHomeBranch;
	}

	public String getLsdKleadId() {
		return this.lsdKleadId;
	}

	public void setLsdKleadId(String lsdKleadId) {
		this.lsdKleadId = lsdKleadId;
	}

	public String getLsdLob() {
		return this.lsdLob;
	}

	public void setLsdLob(String lsdLob) {
		this.lsdLob = lsdLob;
	}

	public String getLsdModifiedBy() {
		return this.lsdModifiedBy;
	}

	public void setLsdModifiedBy(String lsdModifiedBy) {
		this.lsdModifiedBy = lsdModifiedBy;
	}

	public Date getLsdModifiedOn() {
		return this.lsdModifiedOn;
	}

	public void setLsdModifiedOn(Date lsdModifiedOn) {
		this.lsdModifiedOn = lsdModifiedOn;
	}

	public String getLsdOpHandover() {
		return this.lsdOpHandover;
	}

	public void setLsdOpHandover(String lsdOpHandover) {
		this.lsdOpHandover = lsdOpHandover;
	}

	public String getLsdRemarks() {
		return this.lsdRemarks;
	}

	public void setLsdRemarks(String lsdRemarks) {
		this.lsdRemarks = lsdRemarks;
	}

	public String getLsdRmEmpId() {
		return this.lsdRmEmpId;
	}

	public void setLsdRmEmpId(String lsdRmEmpId) {
		this.lsdRmEmpId = lsdRmEmpId;
	}

	public String getLsdRmEmpName() {
		return this.lsdRmEmpName;
	}

	public void setLsdRmEmpName(String lsdRmEmpName) {
		this.lsdRmEmpName = lsdRmEmpName;
	}

	public String getLsdRmUser() {
		return this.lsdRmUser;
	}

	public void setLsdRmUser(String lsdRmUser) {
		this.lsdRmUser = lsdRmUser;
	}

	public BigDecimal getLsdRowId() {
		return this.lsdRowId;
	}

	public void setLsdRowId(BigDecimal lsdRowId) {
		this.lsdRowId = lsdRowId;
	}

	public String getLsdSourceName() {
		return this.lsdSourceName;
	}

	public void setLsdSourceName(String lsdSourceName) {
		this.lsdSourceName = lsdSourceName;
	}

	public String getLsdSourcedBy() {
		return this.lsdSourcedBy;
	}

	public void setLsdSourcedBy(String lsdSourcedBy) {
		this.lsdSourcedBy = lsdSourcedBy;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	@Override
	public String toString() {
		return "LpcomSourcingDet [lsdBssDesc=" + lsdBssDesc + ", lsdBssVertical=" + lsdBssVertical + ", lsdCreatedBy="
				+ lsdCreatedBy + ", lsdCreatedOn=" + lsdCreatedOn + ", lsdDsaContNo=" + lsdDsaContNo
				+ ", lsdFillerFour=" + lsdFillerFour + ", lsdFillerOne=" + lsdFillerOne + ", lsdFillerThree="
				+ lsdFillerThree + ", lsdFillerTwo=" + lsdFillerTwo + ", lsdHomeBranch=" + lsdHomeBranch
				+ ", lsdKleadId=" + lsdKleadId + ", lsdLob=" + lsdLob + ", lsdModifiedBy=" + lsdModifiedBy
				+ ", lsdModifiedOn=" + lsdModifiedOn + ", lsdOpHandover=" + lsdOpHandover + ", lsdRemarks=" + lsdRemarks
				+ ", lsdRmEmpId=" + lsdRmEmpId + ", lsdRmEmpName=" + lsdRmEmpName + ", lsdRmUser=" + lsdRmUser
				+ ", lsdRowId=" + lsdRowId + ", lsdSourceName=" + lsdSourceName + ", lsdSourcedBy=" + lsdSourcedBy
				+ ", lpcomProposal=" + lpcomProposal + "]";
	}

}