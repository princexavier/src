package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_ASSESSMENT database table.
 * 
 */
@Entity
@Table(name="LPCOM_ASSESSMENT")
@NamedQuery(name="LpcomAssessment.findAll", query="SELECT l FROM LpcomAssessment l")
public class LpcomAssessment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LAS_ROW_ID")
	private BigDecimal lasRowId;

	@Column(name="LAS_CREATED_BY")
	private String lasCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LAS_CREATED_ON")
	private Date lasCreatedOn;

	@Column(name="LAS_FAC_NO")
	private BigDecimal lasFacNo;

	@Column(name="LAS_MODIFIED_BY")
	private String lasModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LAS_MODIFIED_ON")
	private Date lasModifiedOn;

	@Column(name="LAS_PARTY_ID")
	private BigDecimal lasPartyId;

	@Column(name="LAS_PROP_NO")
	private BigDecimal lasPropNo;

	@Column(name="LAS_VAR_DESC")
	private String lasVarDesc;

	@Column(name="LAS_VAR_ID")
	private BigDecimal lasVarId;

	@Column(name="LAS_VAR_VALUE")
	private BigDecimal lasVarValue;

	@Column(name="LAS_ASSTYPE")
	private String lasAsstype;
	
	public LpcomAssessment() {
	}

	public String getLasCreatedBy() {
		return this.lasCreatedBy;
	}

	public void setLasCreatedBy(String lasCreatedBy) {
		this.lasCreatedBy = lasCreatedBy;
	}

	public Date getLasCreatedOn() {
		return this.lasCreatedOn;
	}

	public void setLasCreatedOn(Date lasCreatedOn) {
		this.lasCreatedOn = lasCreatedOn;
	}

	public BigDecimal getLasFacNo() {
		return this.lasFacNo;
	}

	public void setLasFacNo(BigDecimal lasFacNo) {
		this.lasFacNo = lasFacNo;
	}

	public String getLasModifiedBy() {
		return this.lasModifiedBy;
	}

	public void setLasModifiedBy(String lasModifiedBy) {
		this.lasModifiedBy = lasModifiedBy;
	}

	public Date getLasModifiedOn() {
		return this.lasModifiedOn;
	}

	public void setLasModifiedOn(Date lasModifiedOn) {
		this.lasModifiedOn = lasModifiedOn;
	}

	public BigDecimal getLasPartyId() {
		return this.lasPartyId;
	}

	public void setLasPartyId(BigDecimal lasPartyId) {
		this.lasPartyId = lasPartyId;
	}

	public BigDecimal getLasPropNo() {
		return this.lasPropNo;
	}

	public void setLasPropNo(BigDecimal lasPropNo) {
		this.lasPropNo = lasPropNo;
	}

	public BigDecimal getLasRowId() {
		return this.lasRowId;
	}

	public void setLasRowId(BigDecimal lasRowId) {
		this.lasRowId = lasRowId;
	}

	public String getLasVarDesc() {
		return this.lasVarDesc;
	}

	public void setLasVarDesc(String lasVarDesc) {
		this.lasVarDesc = lasVarDesc;
	}

	public BigDecimal getLasVarId() {
		return this.lasVarId;
	}

	public void setLasVarId(BigDecimal lasVarId) {
		this.lasVarId = lasVarId;
	}

	public BigDecimal getLasVarValue() {
		return this.lasVarValue;
	}

	public void setLasVarValue(BigDecimal lasVarValue) {
		this.lasVarValue = lasVarValue;
	}
	
	public String getLasAsstype() {
		return this.lasAsstype;
	}

	public void setLasAsstype(String lasAsstype) {
		this.lasAsstype = lasAsstype;
	}
}