package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_PROF_SAMPLING database table.
 * 
 */
@Entity
@Table(name="LPCOM_PROF_SAMPLING")
@NamedQuery(name="LpcomProfSampling.findAll", query="SELECT l FROM LpcomProfSampling l")
public class LpcomProfSampling implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPS_AGENCY_ACTION")
	private String lpsAgencyAction;

	@Column(name="LPS_AGENCY_ID")
	private BigDecimal lpsAgencyId;

	@Column(name="LPS_AGENCY_REMARKS")
	private String lpsAgencyRemarks;

	@Column(name="LPS_CIBIL_STATUS")
	private String lpsCibilStatus;

	@Column(name="LPS_CREATED_BY")
	private String lpsCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPS_CREATED_ON")
	private Date lpsCreatedOn;

	@Column(name="LPS_CUST_ID")
	private BigDecimal lpsCustId;

	@Column(name="LPS_DOC_STATUS")
	private String lpsDocStatus;

	@Column(name="LPS_INITIATOR_REMARKS")
	private String lpsInitiatorRemarks;

	@Column(name="LPS_LOCAL_OGL")
	private String lpsLocalOgl;

	@Column(name="LPS_MODIFIED_BY")
	private String lpsModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPS_MODIFIED_ON")
	private Date lpsModifiedOn;

	@Column(name="LPS_NCIF_STATUS")
	private String lpsNcifStatus;

	@Column(name="LPS_RCU_ACTION")
	private String lpsRcuAction;

	@Column(name="LPS_REJ_CODE")
	private String lpsRejCode;
	
	@Column(name="LPS_HOLDER")
	private String lpsHolder;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPS_ROW_ID")
	private BigDecimal lpsRowId;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LPS_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomProfSampling() {
	}

	public String getLpsAgencyAction() {
		return this.lpsAgencyAction;
	}

	public void setLpsAgencyAction(String lpsAgencyAction) {
		this.lpsAgencyAction = lpsAgencyAction;
	}

	public BigDecimal getLpsAgencyId() {
		return this.lpsAgencyId;
	}

	public void setLpsAgencyId(BigDecimal lpsAgencyId) {
		this.lpsAgencyId = lpsAgencyId;
	}

	public String getLpsAgencyRemarks() {
		return this.lpsAgencyRemarks;
	}

	public void setLpsAgencyRemarks(String lpsAgencyRemarks) {
		this.lpsAgencyRemarks = lpsAgencyRemarks;
	}

	public String getLpsCibilStatus() {
		return this.lpsCibilStatus;
	}

	public void setLpsCibilStatus(String lpsCibilStatus) {
		this.lpsCibilStatus = lpsCibilStatus;
	}

	public String getLpsCreatedBy() {
		return this.lpsCreatedBy;
	}

	public void setLpsCreatedBy(String lpsCreatedBy) {
		this.lpsCreatedBy = lpsCreatedBy;
	}

	public Date getLpsCreatedOn() {
		return this.lpsCreatedOn;
	}

	public void setLpsCreatedOn(Date lpsCreatedOn) {
		this.lpsCreatedOn = lpsCreatedOn;
	}

	public BigDecimal getLpsCustId() {
		return this.lpsCustId;
	}

	public void setLpsCustId(BigDecimal lpsCustId) {
		this.lpsCustId = lpsCustId;
	}

	public String getLpsDocStatus() {
		return this.lpsDocStatus;
	}

	public void setLpsDocStatus(String lpsDocStatus) {
		this.lpsDocStatus = lpsDocStatus;
	}

	public String getLpsInitiatorRemarks() {
		return this.lpsInitiatorRemarks;
	}

	public void setLpsInitiatorRemarks(String lpsInitiatorRemarks) {
		this.lpsInitiatorRemarks = lpsInitiatorRemarks;
	}

	public String getLpsLocalOgl() {
		return this.lpsLocalOgl;
	}

	public void setLpsLocalOgl(String lpsLocalOgl) {
		this.lpsLocalOgl = lpsLocalOgl;
	}

	public String getLpsModifiedBy() {
		return this.lpsModifiedBy;
	}

	public void setLpsModifiedBy(String lpsModifiedBy) {
		this.lpsModifiedBy = lpsModifiedBy;
	}

	public Date getLpsModifiedOn() {
		return this.lpsModifiedOn;
	}

	public void setLpsModifiedOn(Date lpsModifiedOn) {
		this.lpsModifiedOn = lpsModifiedOn;
	}

	public String getLpsNcifStatus() {
		return this.lpsNcifStatus;
	}

	public void setLpsNcifStatus(String lpsNcifStatus) {
		this.lpsNcifStatus = lpsNcifStatus;
	}

	public String getLpsRcuAction() {
		return this.lpsRcuAction;
	}

	public void setLpsRcuAction(String lpsRcuAction) {
		this.lpsRcuAction = lpsRcuAction;
	}

	public String getLpsRejCode() {
		return this.lpsRejCode;
	}

	public void setLpsRejCode(String lpsRejCode) {
		this.lpsRejCode = lpsRejCode;
	}

	public BigDecimal getLpsRowId() {
		return this.lpsRowId;
	}

	public void setLpsRowId(BigDecimal lpsRowId) {
		this.lpsRowId = lpsRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}
	public String getLpsHolder() {
		return this.lpsHolder;
	}

	public void setLpsHolder(String lpsHolder) {
		this.lpsHolder = lpsHolder;
	}

}