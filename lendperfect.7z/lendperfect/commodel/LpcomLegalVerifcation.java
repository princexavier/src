package com.sai.lendperfect.commodel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * The persistent class for the LPCOM_LEGAL_VERIFCATION database table.
 * 
 */
@Entity
@Table(name="LPCOM_LEGAL_VERIFCATION")
@NamedQuery(name="LpcomLegalVerifcation.findAll", query="SELECT l FROM LpcomLegalVerifcation l")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LpcomLegalVerifcation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LLV_ROW_ID")
	private long llvRowId;

	@Column(name="LLV_APPROVED_BY")
	private String llvApprovedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LLV_APPROVED_ON")
	private Date llvApprovedOn;

	@Column(name="LLV_BRANCH")
	private String llvBranch;

	@Column(name="LLV_CREATED_BY")
	private String llvCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LLV_CREATED_ON")
	private Date llvCreatedOn;

	@Column(name="LLV_LOCATION")
	private String llvLocation;

	@Column(name="LLV_MODIFIED_BY")
	private String llvModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LLV_MODIFIED_ON")
	private Date llvModifiedOn;

	@Column(name="LLV_MORTGAGE_TYPE")
	private String llvMortgageType;

	@Column(name="LLV_OWNER_ID")
	private BigDecimal llvOwnerId;

	@Column(name="LLV_PROP_ADDRESS")
	private String llvPropAddress;

	@Column(name="LLV_PROP_TYPE")
	private String llvPropType;

	@Column(name="LLV_REGION")
	private String llvRegion;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LLV_REPORT_DATE")
	private Date llvReportDate;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LLV_REQUEST_DATE")
	private Date llvRequestDate;

	@Column(name="LLV_SEC_TYPE")
	private String llvSecType;

	@Column(name="LLV_SRCH_CLR")
	private String llvSrchClr;
	
	@Column(name="LLV_SRCH_REMARKS")
	private String llvSrchRemarks;
	
	@Column(name="LLV_LEG_OPN_TITLE_APP")
	private String llvLegOpnTitleApp;
	
	@Column(name="LLV_VAL_MORT_FAV_BANK")
	private String llvValMortFavBank;
	
	@Column(name="LLV_COND_BY_THE_LAWYER")
	private String llvCondByTheLawyer;
	
	@Column(name="LLV_REMARKS")
	private String llvRemarks;
	
	@Column(name="LLV_SRCH_OBT_YRS")
	private BigDecimal llvSrchObtYrs;

	@Column(name="LLV_STATUS")
	private String llvStatus;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LLV_VETTING_DATE")
	private Date llvVettingDate;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LLV_PROP_NO")
	private LpcomProposal lpcomProposal;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LLV_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomLegalVerifcation() {
	}

	public long getLlvRowId() {
		return this.llvRowId;
	}

	public void setLlvRowId(long llvRowId) {
		this.llvRowId = llvRowId;
	}

	public String getLlvApprovedBy() {
		return this.llvApprovedBy;
	}

	public void setLlvApprovedBy(String llvApprovedBy) {
		this.llvApprovedBy = llvApprovedBy;
	}

	public Date getLlvApprovedOn() {
		return this.llvApprovedOn;
	}

	public void setLlvApprovedOn(Date llvApprovedOn) {
		this.llvApprovedOn = llvApprovedOn;
	}

	public String getLlvBranch() {
		return this.llvBranch;
	}

	public void setLlvBranch(String llvBranch) {
		this.llvBranch = llvBranch;
	}

	public String getLlvCreatedBy() {
		return this.llvCreatedBy;
	}

	public void setLlvCreatedBy(String llvCreatedBy) {
		this.llvCreatedBy = llvCreatedBy;
	}

	public Date getLlvCreatedOn() {
		return this.llvCreatedOn;
	}

	public void setLlvCreatedOn(Date llvCreatedOn) {
		this.llvCreatedOn = llvCreatedOn;
	}

	public String getLlvLocation() {
		return this.llvLocation;
	}

	public void setLlvLocation(String llvLocation) {
		this.llvLocation = llvLocation;
	}

	public String getLlvModifiedBy() {
		return this.llvModifiedBy;
	}

	public void setLlvModifiedBy(String llvModifiedBy) {
		this.llvModifiedBy = llvModifiedBy;
	}

	public Date getLlvModifiedOn() {
		return this.llvModifiedOn;
	}

	public void setLlvModifiedOn(Date llvModifiedOn) {
		this.llvModifiedOn = llvModifiedOn;
	}

	public String getLlvMortgageType() {
		return this.llvMortgageType;
	}

	public void setLlvMortgageType(String llvMortgageType) {
		this.llvMortgageType = llvMortgageType;
	}

	public BigDecimal getLlvOwnerId() {
		return this.llvOwnerId;
	}

	public void setLlvOwnerId(BigDecimal llvOwnerId) {
		this.llvOwnerId = llvOwnerId;
	}

	public String getLlvPropAddress() {
		return this.llvPropAddress;
	}

	public void setLlvPropAddress(String llvPropAddress) {
		this.llvPropAddress = llvPropAddress;
	}

	public String getLlvPropType() {
		return this.llvPropType;
	}

	public void setLlvPropType(String llvPropType) {
		this.llvPropType = llvPropType;
	}

	public String getLlvRegion() {
		return this.llvRegion;
	}

	public void setLlvRegion(String llvRegion) {
		this.llvRegion = llvRegion;
	}

	public Date getLlvReportDate() {
		return this.llvReportDate;
	}

	public void setLlvReportDate(Date llvReportDate) {
		this.llvReportDate = llvReportDate;
	}

	public Date getLlvRequestDate() {
		return this.llvRequestDate;
	}

	public void setLlvRequestDate(Date llvRequestDate) {
		this.llvRequestDate = llvRequestDate;
	}

	public String getLlvSecType() {
		return this.llvSecType;
	}

	public void setLlvSecType(String llvSecType) {
		this.llvSecType = llvSecType;
	}

	public String getLlvStatus() {
		return this.llvStatus;
	}

	public void setLlvStatus(String llvStatus) {
		this.llvStatus = llvStatus;
	}

	public Date getLlvVettingDate() {
		return this.llvVettingDate;
	}

	public void setLlvVettingDate(Date llvVettingDate) {
		this.llvVettingDate = llvVettingDate;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}
	
	public String getLlvSrchClr() {
		return llvSrchClr;
	}

	public void setLlvSrchClr(String llvSrchClr) {
		this.llvSrchClr = llvSrchClr;
	}

	public String getLlvSrchRemarks() {
		return llvSrchRemarks;
	}

	public void setLlvSrchRemarks(String llvSrchRemarks) {
		this.llvSrchRemarks = llvSrchRemarks;
	}

	public String getLlvLegOpnTitleApp() {
		return llvLegOpnTitleApp;
	}

	public void setLlvLegOpnTitleApp(String llvLegOpnTitleApp) {
		this.llvLegOpnTitleApp = llvLegOpnTitleApp;
	}

	public String getLlvValMortFavBank() {
		return llvValMortFavBank;
	}

	public void setLlvValMortFavBank(String llvValMortFavBank) {
		this.llvValMortFavBank = llvValMortFavBank;
	}

	public String getLlvCondByTheLawyer() {
		return llvCondByTheLawyer;
	}

	public void setLlvCondByTheLawyer(String llvCondByTheLawyer) {
		this.llvCondByTheLawyer = llvCondByTheLawyer;
	}

	public String getLlvRemarks() {
		return llvRemarks;
	}

	public void setLlvRemarks(String llvRemarks) {
		this.llvRemarks = llvRemarks;
	}

	public BigDecimal getLlvSrchObtYrs() {
		return llvSrchObtYrs;
	}

	public void setLlvSrchObtYrs(BigDecimal llvSrchObtYrs) {
		this.llvSrchObtYrs = llvSrchObtYrs;
	}

}
