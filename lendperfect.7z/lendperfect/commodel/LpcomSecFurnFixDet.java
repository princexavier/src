package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SEC_FURN_FIX_DET database table.
 * 
 */
@Entity
@Table(name="LPCOM_SEC_FURN_FIX_DET")
@NamedQuery(name="LpcomSecFurnFixDet.findAll", query="SELECT l FROM LpcomSecFurnFixDet l")
public class LpcomSecFurnFixDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LSFFD_CREATED_BY")
	private String lsffdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFFD_CREATED_ON")
	private Date lsffdCreatedOn;

	@Column(name="LSFFD_MAKE")
	private BigDecimal lsffdMake;

	@Column(name="LSFFD_MODEL")
	private BigDecimal lsffdModel;

	@Column(name="LSFFD_MODIFIED_BY")
	private String lsffdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFFD_MODIFIED_ON")
	private Date lsffdModifiedOn;

	@Column(name="LSFFD_NATURE_OF_ASSET")
	private String lsffdNatureOfAsset;

	@Column(name="LSFFD_PRESENT_VALUE")
	private BigDecimal lsffdPresentValue;

	@Column(name="LSFFD_PURCHASE_VALUE")
	private BigDecimal lsffdPurchaseValue;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LSFFD_ROW_ID")
	private BigDecimal lsffdRowId;

	@Column(name="LSFFD_VALUE")
	private BigDecimal lsffdValue;

	@Column(name="LSFFD_YEAR_OF_MNFC")
	private BigDecimal lsffdYearOfMnfc;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LSFFD_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomSecFurnFixDet() {
	}

	public String getLsffdCreatedBy() {
		return this.lsffdCreatedBy;
	}

	public void setLsffdCreatedBy(String lsffdCreatedBy) {
		this.lsffdCreatedBy = lsffdCreatedBy;
	}

	public Date getLsffdCreatedOn() {
		return this.lsffdCreatedOn;
	}

	public void setLsffdCreatedOn(Date lsffdCreatedOn) {
		this.lsffdCreatedOn = lsffdCreatedOn;
	}

	public BigDecimal getLsffdMake() {
		return this.lsffdMake;
	}

	public void setLsffdMake(BigDecimal lsffdMake) {
		this.lsffdMake = lsffdMake;
	}

	public BigDecimal getLsffdModel() {
		return this.lsffdModel;
	}

	public void setLsffdModel(BigDecimal lsffdModel) {
		this.lsffdModel = lsffdModel;
	}

	public String getLsffdModifiedBy() {
		return this.lsffdModifiedBy;
	}

	public void setLsffdModifiedBy(String lsffdModifiedBy) {
		this.lsffdModifiedBy = lsffdModifiedBy;
	}

	public Date getLsffdModifiedOn() {
		return this.lsffdModifiedOn;
	}

	public void setLsffdModifiedOn(Date lsffdModifiedOn) {
		this.lsffdModifiedOn = lsffdModifiedOn;
	}

	public String getLsffdNatureOfAsset() {
		return this.lsffdNatureOfAsset;
	}

	public void setLsffdNatureOfAsset(String lsffdNatureOfAsset) {
		this.lsffdNatureOfAsset = lsffdNatureOfAsset;
	}

	public BigDecimal getLsffdPresentValue() {
		return this.lsffdPresentValue;
	}

	public void setLsffdPresentValue(BigDecimal lsffdPresentValue) {
		this.lsffdPresentValue = lsffdPresentValue;
	}

	public BigDecimal getLsffdPurchaseValue() {
		return this.lsffdPurchaseValue;
	}

	public void setLsffdPurchaseValue(BigDecimal lsffdPurchaseValue) {
		this.lsffdPurchaseValue = lsffdPurchaseValue;
	}

	public BigDecimal getLsffdRowId() {
		return this.lsffdRowId;
	}

	public void setLsffdRowId(BigDecimal lsffdRowId) {
		this.lsffdRowId = lsffdRowId;
	}

	public BigDecimal getLsffdValue() {
		return this.lsffdValue;
	}

	public void setLsffdValue(BigDecimal lsffdValue) {
		this.lsffdValue = lsffdValue;
	}

	public BigDecimal getLsffdYearOfMnfc() {
		return this.lsffdYearOfMnfc;
	}

	public void setLsffdYearOfMnfc(BigDecimal lsffdYearOfMnfc) {
		this.lsffdYearOfMnfc = lsffdYearOfMnfc;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

	@Override
	public String toString() {
		return "LpcomSecFurnFixDet [lsffdCreatedBy=" + lsffdCreatedBy + ", lsffdCreatedOn=" + lsffdCreatedOn
				+ ", lsffdMake=" + lsffdMake + ", lsffdModel=" + lsffdModel + ", lsffdModifiedBy=" + lsffdModifiedBy
				+ ", lsffdModifiedOn=" + lsffdModifiedOn + ", lsffdNatureOfAsset=" + lsffdNatureOfAsset
				+ ", lsffdPresentValue=" + lsffdPresentValue + ", lsffdPurchaseValue=" + lsffdPurchaseValue
				+ ", lsffdRowId=" + lsffdRowId + ", lsffdValue=" + lsffdValue + ", lsffdYearOfMnfc=" + lsffdYearOfMnfc
				+ ", lpcomSecurity=" + lpcomSecurity + "]";
	}

}