package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_GLOBAL_VARIABLE database table.
 * 
 */
@Entity
@Table(name="LPCOM_GLOBAL_VARIABLE")
@NamedQuery(name="LpcomGlobalVariable.findAll", query="SELECT l FROM LpcomGlobalVariable l")
public class LpcomGlobalVariable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LGV_CREATED_BY")
	private String lgvCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LGV_CREATED_ON")
	private Date lgvCreatedOn;

	@Column(name="LGV_FAC_NO")
	private BigDecimal lgvFacNo;

	@Column(name="LGV_GL_VAR_DATATYPE")
	private String lgvGlVarDatatype;

	@Column(name="LGV_GL_VAR_DESC")
	private String lgvGlVarDesc;

	@Column(name="LGV_GL_VAR_FILTER")
	private String lgvGlVarFilter;

	@Column(name="LGV_GL_VAR_ID")
	private BigDecimal lgvGlVarId;

	@Column(name="LGV_GL_VAR_VALUE")
	private String lgvGlVarValue;

	@Column(name="LGV_MODIFIED_BY")
	private String lgvModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LGV_MODIFIED_ON")
	private Date lgvModifiedOn;

	@Column(name="LGV_PARTY_ID")
	private BigDecimal lgvPartyId;

	@Column(name="LGV_PROP_NO")
	private BigDecimal lgvPropNo;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LGV_ROW_ID")
	private long lgvRowId;
	

	public LpcomGlobalVariable() {
	}

	public String getLgvCreatedBy() {
		return this.lgvCreatedBy;
	}

	public void setLgvCreatedBy(String lgvCreatedBy) {
		this.lgvCreatedBy = lgvCreatedBy;
	}

	public Date getLgvCreatedOn() {
		return this.lgvCreatedOn;
	}

	public void setLgvCreatedOn(Date lgvCreatedOn) {
		this.lgvCreatedOn = lgvCreatedOn;
	}

	public BigDecimal getLgvFacNo() {
		return this.lgvFacNo;
	}

	public void setLgvFacNo(BigDecimal lgvFacNo) {
		this.lgvFacNo = lgvFacNo;
	}

	public String getLgvGlVarDatatype() {
		return this.lgvGlVarDatatype;
	}

	public void setLgvGlVarDatatype(String lgvGlVarDatatype) {
		this.lgvGlVarDatatype = lgvGlVarDatatype;
	}

	public String getLgvGlVarDesc() {
		return this.lgvGlVarDesc;
	}

	public void setLgvGlVarDesc(String lgvGlVarDesc) {
		this.lgvGlVarDesc = lgvGlVarDesc;
	}

	public String getLgvGlVarFilter() {
		return this.lgvGlVarFilter;
	}

	public void setLgvGlVarFilter(String lgvGlVarFilter) {
		this.lgvGlVarFilter = lgvGlVarFilter;
	}

	public BigDecimal getLgvGlVarId() {
		return this.lgvGlVarId;
	}

	public void setLgvGlVarId(BigDecimal lgvGlVarId) {
		this.lgvGlVarId = lgvGlVarId;
	}

	public String getLgvGlVarValue() {
		return this.lgvGlVarValue;
	}

	public void setLgvGlVarValue(String lgvGlVarValue) {
		this.lgvGlVarValue = lgvGlVarValue;
	}

	public String getLgvModifiedBy() {
		return this.lgvModifiedBy;
	}

	public void setLgvModifiedBy(String lgvModifiedBy) {
		this.lgvModifiedBy = lgvModifiedBy;
	}

	public Date getLgvModifiedOn() {
		return this.lgvModifiedOn;
	}

	public void setLgvModifiedOn(Date lgvModifiedOn) {
		this.lgvModifiedOn = lgvModifiedOn;
	}

	public BigDecimal getLgvPartyId() {
		return this.lgvPartyId;
	}

	public void setLgvPartyId(BigDecimal lgvPartyId) {
		this.lgvPartyId = lgvPartyId;
	}

	public BigDecimal getLgvPropNo() {
		return this.lgvPropNo;
	}

	public void setLgvPropNo(BigDecimal lgvPropNo) {
		this.lgvPropNo = lgvPropNo;
	}

	public long getLgvRowId() {
		return this.lgvRowId;
	}

	public void setLgvRowId(long lgvRowId) {
		this.lgvRowId = lgvRowId;
	}

}