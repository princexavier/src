package com.sai.lendperfect.commodel;



import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_CUST_DATA_NIND database table.
 * 
 */
@Entity
@Table(name="LPCOM_CUST_DATA_NIND")
@NamedQuery(name="LpcomCustDataNind.findAll", query="SELECT l FROM LpcomCustDataNind l")
public class LpcomCustDataNind implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LCN_BANKING_SINCE")
	private BigDecimal lcnBankingSince;

	@Column(name="LCN_BRANCH_CODE")
	private String lcnBranchCode;

	@Column(name="LCN_BRANCH_NAME")
	private String lcnBranchName;

	@Column(name="LCN_BUSS_NAME")
	private String lcnBussName;

	@Column(name="LCN_CIN_NO")
	private String lcnCinNo;

	@Column(name="LCN_CLASSI_CATGRY")
	private String lcnClassiCatgry;

	@Column(name="LCN_CONSTITUTION")
	private String lcnConstitution;

	@Column(name="LCN_CP_EMAIL")
	private String lcnCpEmail;

	@Column(name="LCN_CP_ID")
	private String lcnCpId;

	@Column(name="LCN_CP_MOB_NO")
	private String lcnCpMobNo;

	@Column(name="LCN_CP_NAME")
	private String lcnCpName;

	@Column(name="LCN_CP_OFC_PHNE")
	private String lcnCpOfcPhne;

	@Column(name="LCN_CP_LOCATION")
	private String lcnCplocation;

	@Column(name="LCN_CP_RESI_PHNE")
	private String lcnCpResiPhne;

	@Column(name="LCN_CREATED_BY")
	private String lcnCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCN_CREATED_ON")
	private Date lcnCreatedOn;

	@Column(name="LCN_CUST_LOB")
	private String lcnCustLob;

	@Column(name="LCN_CUST_SEGMENT")
	private String lcnCustSegment;

	@Temporal(TemporalType.DATE)
	@Column(name="LCN_DOI")
	private Date lcnDoi;

	@Temporal(TemporalType.DATE)
	@Column(name="LCN_EFF_FROM")
	private Date lcnEffFrom;

	@Column(name="LCN_EWS_FLAG")
	private String lcnEwsFlag;

	@Column(name="LCN_FILLER_1")
	private String lcnFiller1;

	@Column(name="LCN_FILLER_2")
	private String lcnFiller2;

	@Column(name="LCN_FILLER_3")
	private String lcnFiller3;

	@Column(name="LCN_FILLER_4")
	private String lcnFiller4;

	@Column(name="LCN_GST_NO")
	private String lcnGstNo;

	@Column(name="LCN_INCOME_SLAB")
	private String lcnIncomeSlab;

	@Column(name="LCN_IT_TYPE")
	private String lcnItType;

	@Column(name="LCN_MODIFIED_BY")
	private String lcnModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCN_MODIFIED_ON")
	private Date lcnModifiedOn;

	@Column(name="LCN_NATIONALITY")
	private String lcnNationality;

	@Column(name="LCN_NETWORTH")
	private BigDecimal lcnNetworth;

	@Column(name="LCN_PAN_NO")
	private String lcnPanNo;

	@Column(name="LCN_PREF_LANG")
	private String lcnPrefLang;

	@Column(name="LCN_RED_FLAG")
	private String lcnRedFlag;

	@Temporal(TemporalType.DATE)
	@Column(name="LCN_REG_DATE")
	private Date lcnRegDate;

	@Column(name="LCN_REG_NO")
	private String lcnRegNo;

	@Column(name="LCN_RESI_TYPE")
	private String lcnResiType;

	@Column(name="LCN_RISK_CATEGORY")
	private String lcnRiskCategory;

	@Column(name="LCN_RISK_PROFILE")
	private String lcnRiskProfile;

	@Column(name="LCN_RLN_WITH_BANK")
	private String lcnRlnWithBank;

	@Id
	@Column(name="LCN_ROW_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private BigDecimal lcnRowId;

	@Column(name="LCN_SHORT_NAME")
	private String lcnShortName;

	@Column(name="LCN_SUBCLASSI_CAT")
	private String lcnSubclassiCat;

	@Column(name="LCN_TURNOVER_Y1")
	private BigDecimal lcnTurnoverY1;

	@Column(name="LCN_TURNOVER_Y2")
	private BigDecimal lcnTurnoverY2;

	@Column(name="LCN_TURNOVER_Y3")
	private BigDecimal lcnTurnoverY3;

	//bi-directional many-to-one association to LpcomCustInfo
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LCN_NEW_ID")
	private LpcomCustInfo lpcomCustInfo;

	public LpcomCustDataNind() {
	}

	public BigDecimal getLcnBankingSince() {
		return this.lcnBankingSince;
	}

	public void setLcnBankingSince(BigDecimal lcnBankingSince) {
		this.lcnBankingSince = lcnBankingSince;
	}

	public String getLcnBranchCode() {
		return this.lcnBranchCode;
	}

	public void setLcnBranchCode(String lcnBranchCode) {
		this.lcnBranchCode = lcnBranchCode;
	}

	public String getLcnBranchName() {
		return this.lcnBranchName;
	}

	public void setLcnBranchName(String lcnBranchName) {
		this.lcnBranchName = lcnBranchName;
	}

	public String getLcnBussName() {
		return this.lcnBussName;
	}

	public void setLcnBussName(String lcnBussName) {
		this.lcnBussName = lcnBussName;
	}

	public String getLcnCinNo() {
		return this.lcnCinNo;
	}

	public void setLcnCinNo(String lcnCinNo) {
		this.lcnCinNo = lcnCinNo;
	}

	public String getLcnClassiCatgry() {
		return this.lcnClassiCatgry;
	}

	public void setLcnClassiCatgry(String lcnClassiCatgry) {
		this.lcnClassiCatgry = lcnClassiCatgry;
	}

	public String getLcnConstitution() {
		return this.lcnConstitution;
	}

	public void setLcnConstitution(String lcnConstitution) {
		this.lcnConstitution = lcnConstitution;
	}

	public String getLcnCpEmail() {
		return this.lcnCpEmail;
	}

	public void setLcnCpEmail(String lcnCpEmail) {
		this.lcnCpEmail = lcnCpEmail;
	}

	public String getLcnCpId() {
		return this.lcnCpId;
	}

	public void setLcnCpId(String lcnCpId) {
		this.lcnCpId = lcnCpId;
	}

	public String getLcnCpMobNo() {
		return this.lcnCpMobNo;
	}

	public void setLcnCpMobNo(String lcnCpMobNo) {
		this.lcnCpMobNo = lcnCpMobNo;
	}

	public String getLcnCpName() {
		return this.lcnCpName;
	}

	public void setLcnCpName(String lcnCpName) {
		this.lcnCpName = lcnCpName;
	}

	public String getLcnCpOfcPhne() {
		return this.lcnCpOfcPhne;
	}

	public void setLcnCpOfcPhne(String lcnCpOfcPhne) {
		this.lcnCpOfcPhne = lcnCpOfcPhne;
	}


	public String getLcnCpResiPhne() {
		return this.lcnCpResiPhne;
	}

	public void setLcnCpResiPhne(String lcnCpResiPhne) {
		this.lcnCpResiPhne = lcnCpResiPhne;
	}

	public String getLcnCreatedBy() {
		return this.lcnCreatedBy;
	}

	public void setLcnCreatedBy(String lcnCreatedBy) {
		this.lcnCreatedBy = lcnCreatedBy;
	}

	public Date getLcnCreatedOn() {
		return this.lcnCreatedOn;
	}

	public void setLcnCreatedOn(Date lcnCreatedOn) {
		this.lcnCreatedOn = lcnCreatedOn;
	}

	public String getLcnCustLob() {
		return this.lcnCustLob;
	}

	public void setLcnCustLob(String lcnCustLob) {
		this.lcnCustLob = lcnCustLob;
	}

	public String getLcnCustSegment() {
		return this.lcnCustSegment;
	}

	public void setLcnCustSegment(String lcnCustSegment) {
		this.lcnCustSegment = lcnCustSegment;
	}

	public Date getLcnDoi() {
		return this.lcnDoi;
	}

	public void setLcnDoi(Date lcnDoi) {
		this.lcnDoi = lcnDoi;
	}

	public Date getLcnEffFrom() {
		return this.lcnEffFrom;
	}

	public void setLcnEffFrom(Date lcnEffFrom) {
		this.lcnEffFrom = lcnEffFrom;
	}

	public String getLcnEwsFlag() {
		return this.lcnEwsFlag;
	}

	public void setLcnEwsFlag(String lcnEwsFlag) {
		this.lcnEwsFlag = lcnEwsFlag;
	}

	public String getLcnFiller1() {
		return this.lcnFiller1;
	}

	public void setLcnFiller1(String lcnFiller1) {
		this.lcnFiller1 = lcnFiller1;
	}

	public String getLcnFiller2() {
		return this.lcnFiller2;
	}

	public void setLcnFiller2(String lcnFiller2) {
		this.lcnFiller2 = lcnFiller2;
	}

	public String getLcnFiller3() {
		return this.lcnFiller3;
	}

	public void setLcnFiller3(String lcnFiller3) {
		this.lcnFiller3 = lcnFiller3;
	}

	public String getLcnFiller4() {
		return this.lcnFiller4;
	}

	public void setLcnFiller4(String lcnFiller4) {
		this.lcnFiller4 = lcnFiller4;
	}

	public String getLcnGstNo() {
		return this.lcnGstNo;
	}

	public void setLcnGstNo(String lcnGstNo) {
		this.lcnGstNo = lcnGstNo;
	}

	public String getLcnIncomeSlab() {
		return this.lcnIncomeSlab;
	}

	public void setLcnIncomeSlab(String lcnIncomeSlab) {
		this.lcnIncomeSlab = lcnIncomeSlab;
	}

	public String getLcnItType() {
		return this.lcnItType;
	}

	public void setLcnItType(String lcnItType) {
		this.lcnItType = lcnItType;
	}

	public String getLcnModifiedBy() {
		return this.lcnModifiedBy;
	}

	public void setLcnModifiedBy(String lcnModifiedBy) {
		this.lcnModifiedBy = lcnModifiedBy;
	}

	public Date getLcnModifiedOn() {
		return this.lcnModifiedOn;
	}

	public void setLcnModifiedOn(Date lcnModifiedOn) {
		this.lcnModifiedOn = lcnModifiedOn;
	}

	public String getLcnNationality() {
		return this.lcnNationality;
	}

	public void setLcnNationality(String lcnNationality) {
		this.lcnNationality = lcnNationality;
	}

	public BigDecimal getLcnNetworth() {
		return this.lcnNetworth;
	}

	public void setLcnNetworth(BigDecimal lcnNetworth) {
		this.lcnNetworth = lcnNetworth;
	}

	public String getLcnPanNo() {
		return this.lcnPanNo;
	}

	public void setLcnPanNo(String lcnPanNo) {
		this.lcnPanNo = lcnPanNo;
	}

	public String getLcnPrefLang() {
		return this.lcnPrefLang;
	}

	public void setLcnPrefLang(String lcnPrefLang) {
		this.lcnPrefLang = lcnPrefLang;
	}

	public String getLcnRedFlag() {
		return this.lcnRedFlag;
	}

	public void setLcnRedFlag(String lcnRedFlag) {
		this.lcnRedFlag = lcnRedFlag;
	}

	public Date getLcnRegDate() {
		return this.lcnRegDate;
	}

	public void setLcnRegDate(Date lcnRegDate) {
		this.lcnRegDate = lcnRegDate;
	}

	public String getLcnRegNo() {
		return this.lcnRegNo;
	}

	public void setLcnRegNo(String lcnRegNo) {
		this.lcnRegNo = lcnRegNo;
	}

	public String getLcnResiType() {
		return this.lcnResiType;
	}

	public void setLcnResiType(String lcnResiType) {
		this.lcnResiType = lcnResiType;
	}

	public String getLcnRiskCategory() {
		return this.lcnRiskCategory;
	}

	public void setLcnRiskCategory(String lcnRiskCategory) {
		this.lcnRiskCategory = lcnRiskCategory;
	}

	public String getLcnRiskProfile() {
		return this.lcnRiskProfile;
	}

	public void setLcnRiskProfile(String lcnRiskProfile) {
		this.lcnRiskProfile = lcnRiskProfile;
	}

	public String getLcnRlnWithBank() {
		return this.lcnRlnWithBank;
	}

	public void setLcnRlnWithBank(String lcnRlnWithBank) {
		this.lcnRlnWithBank = lcnRlnWithBank;
	}

	public BigDecimal getLcnRowId() {
		return this.lcnRowId;
	}

	public void setLcnRowId(BigDecimal lcnRowId) {
		this.lcnRowId = lcnRowId;
	}

	public String getLcnShortName() {
		return this.lcnShortName;
	}

	public void setLcnShortName(String lcnShortName) {
		this.lcnShortName = lcnShortName;
	}

	public String getLcnSubclassiCat() {
		return this.lcnSubclassiCat;
	}

	public void setLcnSubclassiCat(String lcnSubclassiCat) {
		this.lcnSubclassiCat = lcnSubclassiCat;
	}

	public BigDecimal getLcnTurnoverY1() {
		return this.lcnTurnoverY1;
	}

	public void setLcnTurnoverY1(BigDecimal lcnTurnoverY1) {
		this.lcnTurnoverY1 = lcnTurnoverY1;
	}

	public BigDecimal getLcnTurnoverY2() {
		return this.lcnTurnoverY2;
	}

	public void setLcnTurnoverY2(BigDecimal lcnTurnoverY2) {
		this.lcnTurnoverY2 = lcnTurnoverY2;
	}

	public BigDecimal getLcnTurnoverY3() {
		return this.lcnTurnoverY3;
	}

	public void setLcnTurnoverY3(BigDecimal lcnTurnoverY3) {
		this.lcnTurnoverY3 = lcnTurnoverY3;
	}

	public String getLcnCplocation() {
		return lcnCplocation;
	}

	public void setLcnCplocation(String lcnCplocation) {
		this.lcnCplocation = lcnCplocation;
	}

	public LpcomCustInfo getLpcomCustInfo() {
		return this.lpcomCustInfo;
	}

	public void setLpcomCustInfo(LpcomCustInfo lpcomCustInfo) {
		this.lpcomCustInfo = lpcomCustInfo;
	}

}