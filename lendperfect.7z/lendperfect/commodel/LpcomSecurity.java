package com.sai.lendperfect.commodel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The persistent class for the LPCOM_SECURITIES database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "LPCOM_SECURITIES")
@NamedQuery(name = "LpcomSecurity.findAll", query = "SELECT l FROM LpcomSecurity l")
public class LpcomSecurity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LS_SEC_ID", columnDefinition = "NUMERIC(19,0)")
	private long lsSecId;

	@Column(name = "LS_ALREADY_CHARGED")
	private String lsAlreadyCharged;

	@Column(name = "LS_CHARGED_AMT")
	private BigDecimal lsChargedAmt;

	@Column(name = "LS_CHARGED_INSTITUTION")
	private String lsChargedInstitution;

	@Column(name = "LS_CREATED_BY")
	private String lsCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LS_CREATED_ON")
	private Date lsCreatedOn;

	@Column(name = "LS_INSURANCE_COMPANY")
	private String lsInsuranceCompany;

	@Column(name = "LS_INSURED_AMT")
	private BigDecimal lsInsuredAmt;

	@Column(name = "LS_MODIFIED_BY")
	private String lsModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LS_MODIFIED_ON")
	private Date lsModifiedOn;

	@Column(name = "LS_NATURE_OF_CHARGE")
	private String lsNatureOfCharge;

	@Column(name = "LS_NET_SEC_VALUE")
	private BigDecimal lsNetSecValue;

	@Column(name = "LS_RES_RISK_FLAG")
	private String lsResRiskFlag;

	@Column(name = "LS_SEC_CLASSIFICATION")
	private BigDecimal lsSecClassification;

	@Temporal(TemporalType.DATE)
	@Column(name = "LS_SEC_CREATED_ON")
	private Date lsSecCreatedOn;

	@Column(name = "LS_SEC_DESC")
	private String lsSecDesc;

	@Column(name = "LS_SEC_TYPE")
	private BigDecimal lsSecType;

	@Column(name = "LS_TOTAL_SECURITY_VAL")
	private BigDecimal lsTotalSecurityVal;

	@Column(name = "LS_TYPE_OF_CHARGE")
	private String lsTypeOfCharge;

	// bi-directional many-to-one association to LpcomSecBankDeposit
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecBankDeposit> lpcomSecBankDeposits;

	// bi-directional many-to-one association to LpcomSecFindocNtrade
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecFindocNtrade> lpcomSecFindocNtrades;

	// bi-directional many-to-one association to LpcomSecFindocTrade
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecFindocTrade> lpcomSecFindocTrades;

	// bi-directional many-to-one association to LpcomSecFurnFixDet
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecFurnFixDet> lpcomSecFurnFixDets;

	// bi-directional many-to-one association to LpcomSecGoodsDet
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecGoodsDet> lpcomSecGoodsDets;

	// bi-directional many-to-one association to LpcomSecJewelDet
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecJewelDet> lpcomSecJewelDets;

	// bi-directional many-to-one association to LpcomSecOwner
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecOwner> lpcomSecOwners;

	// bi-directional many-to-one association to LpcomSecPlntMcnry
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecPlntMcnry> lpcomSecPlntMcnries;

	// bi-directional many-to-one association to LpcomSecProperty
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecProperty> lpcomSecProperties;

	// bi-directional many-to-one association to LpcomSecVehicleDet
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecVehicleDet> lpcomSecVehicleDets;

	// bi-directional many-to-one association to LpcomSecFacMapping
	@JsonIgnore
	@OneToMany(mappedBy = "lpcomSecurity")
	private List<LpcomSecFacMapping> lpcomSecFacMappings;
	
	//bi-directional many-to-one association to LpcomLegalDocDetail
	@JsonIgnore
	@OneToMany(mappedBy="lpcomSecurity")
	private List<LpcomLegalDocDetail> lpcomLegalDocDetails;

	//bi-directional many-to-one association to LpcomLegalVerifcation
	@JsonIgnore
	@OneToMany(mappedBy="lpcomSecurity")
	private List<LpcomLegalVerifcation> lpcomLegalVerifcations;

	public LpcomSecurity() {
	}

	public long getLsSecId() {
		return this.lsSecId;
	}

	public void setLsSecId(long lsSecId) {
		this.lsSecId = lsSecId;
	}

	public String getLsAlreadyCharged() {
		return this.lsAlreadyCharged;
	}

	public void setLsAlreadyCharged(String lsAlreadyCharged) {
		this.lsAlreadyCharged = lsAlreadyCharged;
	}

	public BigDecimal getLsChargedAmt() {
		return this.lsChargedAmt;
	}

	public void setLsChargedAmt(BigDecimal lsChargedAmt) {
		this.lsChargedAmt = lsChargedAmt;
	}

	public String getLsChargedInstitution() {
		return this.lsChargedInstitution;
	}

	public void setLsChargedInstitution(String lsChargedInstitution) {
		this.lsChargedInstitution = lsChargedInstitution;
	}

	public String getLsCreatedBy() {
		return this.lsCreatedBy;
	}

	public void setLsCreatedBy(String lsCreatedBy) {
		this.lsCreatedBy = lsCreatedBy;
	}

	public Date getLsCreatedOn() {
		return this.lsCreatedOn;
	}

	public void setLsCreatedOn(Date lsCreatedOn) {
		this.lsCreatedOn = lsCreatedOn;
	}

	public String getLsInsuranceCompany() {
		return this.lsInsuranceCompany;
	}

	public void setLsInsuranceCompany(String lsInsuranceCompany) {
		this.lsInsuranceCompany = lsInsuranceCompany;
	}

	public BigDecimal getLsInsuredAmt() {
		return this.lsInsuredAmt;
	}

	public void setLsInsuredAmt(BigDecimal lsInsuredAmt) {
		this.lsInsuredAmt = lsInsuredAmt;
	}

	public String getLsModifiedBy() {
		return this.lsModifiedBy;
	}

	public void setLsModifiedBy(String lsModifiedBy) {
		this.lsModifiedBy = lsModifiedBy;
	}

	public Date getLsModifiedOn() {
		return this.lsModifiedOn;
	}

	public void setLsModifiedOn(Date lsModifiedOn) {
		this.lsModifiedOn = lsModifiedOn;
	}

	public String getLsNatureOfCharge() {
		return this.lsNatureOfCharge;
	}

	public void setLsNatureOfCharge(String lsNatureOfCharge) {
		this.lsNatureOfCharge = lsNatureOfCharge;
	}

	public BigDecimal getLsNetSecValue() {
		return this.lsNetSecValue;
	}

	public void setLsNetSecValue(BigDecimal lsNetSecValue) {
		this.lsNetSecValue = lsNetSecValue;
	}

	public String getLsResRiskFlag() {
		return this.lsResRiskFlag;
	}

	public void setLsResRiskFlag(String lsResRiskFlag) {
		this.lsResRiskFlag = lsResRiskFlag;
	}

	public BigDecimal getLsSecClassification() {
		return this.lsSecClassification;
	}

	public void setLsSecClassification(BigDecimal lsSecClassification) {
		this.lsSecClassification = lsSecClassification;
	}

	public Date getLsSecCreatedOn() {
		return this.lsSecCreatedOn;
	}

	public void setLsSecCreatedOn(Date lsSecCreatedOn) {
		this.lsSecCreatedOn = lsSecCreatedOn;
	}

	public String getLsSecDesc() {
		return this.lsSecDesc;
	}

	public void setLsSecDesc(String lsSecDesc) {
		this.lsSecDesc = lsSecDesc;
	}

	public BigDecimal getLsSecType() {
		return this.lsSecType;
	}

	public void setLsSecType(BigDecimal lsSecType) {
		this.lsSecType = lsSecType;
	}

	public BigDecimal getLsTotalSecurityVal() {
		return this.lsTotalSecurityVal;
	}

	public void setLsTotalSecurityVal(BigDecimal lsTotalSecurityVal) {
		this.lsTotalSecurityVal = lsTotalSecurityVal;
	}

	public String getLsTypeOfCharge() {
		return this.lsTypeOfCharge;
	}

	public void setLsTypeOfCharge(String lsTypeOfCharge) {
		this.lsTypeOfCharge = lsTypeOfCharge;
	}

	public List<LpcomSecBankDeposit> getLpcomSecBankDeposits() {
		return this.lpcomSecBankDeposits;
	}

	public void setLpcomSecBankDeposits(List<LpcomSecBankDeposit> lpcomSecBankDeposits) {
		this.lpcomSecBankDeposits = lpcomSecBankDeposits;
	}

	public LpcomSecBankDeposit addLpcomSecBankDeposit(LpcomSecBankDeposit lpcomSecBankDeposit) {
		getLpcomSecBankDeposits().add(lpcomSecBankDeposit);
		lpcomSecBankDeposit.setLpcomSecurity(this);

		return lpcomSecBankDeposit;
	}

	public LpcomSecBankDeposit removeLpcomSecBankDeposit(LpcomSecBankDeposit lpcomSecBankDeposit) {
		getLpcomSecBankDeposits().remove(lpcomSecBankDeposit);
		lpcomSecBankDeposit.setLpcomSecurity(null);

		return lpcomSecBankDeposit;
	}

	public List<LpcomSecFindocNtrade> getLpcomSecFindocNtrades() {
		return this.lpcomSecFindocNtrades;
	}

	public void setLpcomSecFindocNtrades(List<LpcomSecFindocNtrade> lpcomSecFindocNtrades) {
		this.lpcomSecFindocNtrades = lpcomSecFindocNtrades;
	}

	public LpcomSecFindocNtrade addLpcomSecFindocNtrade(LpcomSecFindocNtrade lpcomSecFindocNtrade) {
		getLpcomSecFindocNtrades().add(lpcomSecFindocNtrade);
		lpcomSecFindocNtrade.setLpcomSecurity(this);

		return lpcomSecFindocNtrade;
	}

	public LpcomSecFindocNtrade removeLpcomSecFindocNtrade(LpcomSecFindocNtrade lpcomSecFindocNtrade) {
		getLpcomSecFindocNtrades().remove(lpcomSecFindocNtrade);
		lpcomSecFindocNtrade.setLpcomSecurity(null);

		return lpcomSecFindocNtrade;
	}

	public List<LpcomSecFindocTrade> getLpcomSecFindocTrades() {
		return this.lpcomSecFindocTrades;
	}

	public void setLpcomSecFindocTrades(List<LpcomSecFindocTrade> lpcomSecFindocTrades) {
		this.lpcomSecFindocTrades = lpcomSecFindocTrades;
	}

	public LpcomSecFindocTrade addLpcomSecFindocTrade(LpcomSecFindocTrade lpcomSecFindocTrade) {
		getLpcomSecFindocTrades().add(lpcomSecFindocTrade);
		lpcomSecFindocTrade.setLpcomSecurity(this);

		return lpcomSecFindocTrade;
	}

	public LpcomSecFindocTrade removeLpcomSecFindocTrade(LpcomSecFindocTrade lpcomSecFindocTrade) {
		getLpcomSecFindocTrades().remove(lpcomSecFindocTrade);
		lpcomSecFindocTrade.setLpcomSecurity(null);

		return lpcomSecFindocTrade;
	}

	public List<LpcomSecFurnFixDet> getLpcomSecFurnFixDets() {
		return this.lpcomSecFurnFixDets;
	}

	public void setLpcomSecFurnFixDets(List<LpcomSecFurnFixDet> lpcomSecFurnFixDets) {
		this.lpcomSecFurnFixDets = lpcomSecFurnFixDets;
	}

	public LpcomSecFurnFixDet addLpcomSecFurnFixDet(LpcomSecFurnFixDet lpcomSecFurnFixDet) {
		getLpcomSecFurnFixDets().add(lpcomSecFurnFixDet);
		lpcomSecFurnFixDet.setLpcomSecurity(this);

		return lpcomSecFurnFixDet;
	}

	public LpcomSecFurnFixDet removeLpcomSecFurnFixDet(LpcomSecFurnFixDet lpcomSecFurnFixDet) {
		getLpcomSecFurnFixDets().remove(lpcomSecFurnFixDet);
		lpcomSecFurnFixDet.setLpcomSecurity(null);

		return lpcomSecFurnFixDet;
	}

	public List<LpcomSecGoodsDet> getLpcomSecGoodsDets() {
		return this.lpcomSecGoodsDets;
	}

	public void setLpcomSecGoodsDets(List<LpcomSecGoodsDet> lpcomSecGoodsDets) {
		this.lpcomSecGoodsDets = lpcomSecGoodsDets;
	}

	public LpcomSecGoodsDet addLpcomSecGoodsDet(LpcomSecGoodsDet lpcomSecGoodsDet) {
		getLpcomSecGoodsDets().add(lpcomSecGoodsDet);
		lpcomSecGoodsDet.setLpcomSecurity(this);

		return lpcomSecGoodsDet;
	}

	public LpcomSecGoodsDet removeLpcomSecGoodsDet(LpcomSecGoodsDet lpcomSecGoodsDet) {
		getLpcomSecGoodsDets().remove(lpcomSecGoodsDet);
		lpcomSecGoodsDet.setLpcomSecurity(null);

		return lpcomSecGoodsDet;
	}

	public List<LpcomSecJewelDet> getLpcomSecJewelDets() {
		return this.lpcomSecJewelDets;
	}

	public void setLpcomSecJewelDets(List<LpcomSecJewelDet> lpcomSecJewelDets) {
		this.lpcomSecJewelDets = lpcomSecJewelDets;
	}

	public LpcomSecJewelDet addLpcomSecJewelDet(LpcomSecJewelDet lpcomSecJewelDet) {
		getLpcomSecJewelDets().add(lpcomSecJewelDet);
		lpcomSecJewelDet.setLpcomSecurity(this);

		return lpcomSecJewelDet;
	}

	public LpcomSecJewelDet removeLpcomSecJewelDet(LpcomSecJewelDet lpcomSecJewelDet) {
		getLpcomSecJewelDets().remove(lpcomSecJewelDet);
		lpcomSecJewelDet.setLpcomSecurity(null);

		return lpcomSecJewelDet;
	}

	public List<LpcomSecOwner> getLpcomSecOwners() {
		return this.lpcomSecOwners;
	}

	public void setLpcomSecOwners(List<LpcomSecOwner> lpcomSecOwners) {
		this.lpcomSecOwners = lpcomSecOwners;
	}

	public LpcomSecOwner addLpcomSecOwner(LpcomSecOwner lpcomSecOwner) {
		getLpcomSecOwners().add(lpcomSecOwner);
		lpcomSecOwner.setLpcomSecurity(this);

		return lpcomSecOwner;
	}

	public LpcomSecOwner removeLpcomSecOwner(LpcomSecOwner lpcomSecOwner) {
		getLpcomSecOwners().remove(lpcomSecOwner);
		lpcomSecOwner.setLpcomSecurity(null);

		return lpcomSecOwner;
	}

	public List<LpcomSecPlntMcnry> getLpcomSecPlntMcnries() {
		return this.lpcomSecPlntMcnries;
	}

	public void setLpcomSecPlntMcnries(List<LpcomSecPlntMcnry> lpcomSecPlntMcnries) {
		this.lpcomSecPlntMcnries = lpcomSecPlntMcnries;
	}

	public LpcomSecPlntMcnry addLpcomSecPlntMcnry(LpcomSecPlntMcnry lpcomSecPlntMcnry) {
		getLpcomSecPlntMcnries().add(lpcomSecPlntMcnry);
		lpcomSecPlntMcnry.setLpcomSecurity(this);

		return lpcomSecPlntMcnry;
	}

	public LpcomSecPlntMcnry removeLpcomSecPlntMcnry(LpcomSecPlntMcnry lpcomSecPlntMcnry) {
		getLpcomSecPlntMcnries().remove(lpcomSecPlntMcnry);
		lpcomSecPlntMcnry.setLpcomSecurity(null);

		return lpcomSecPlntMcnry;
	}

	public List<LpcomSecProperty> getLpcomSecProperties() {
		return this.lpcomSecProperties;
	}

	public void setLpcomSecProperties(List<LpcomSecProperty> lpcomSecProperties) {
		this.lpcomSecProperties = lpcomSecProperties;
	}

	public LpcomSecProperty addLpcomSecProperty(LpcomSecProperty lpcomSecProperty) {
		getLpcomSecProperties().add(lpcomSecProperty);
		lpcomSecProperty.setLpcomSecurity(this);

		return lpcomSecProperty;
	}

	public LpcomSecProperty removeLpcomSecProperty(LpcomSecProperty lpcomSecProperty) {
		getLpcomSecProperties().remove(lpcomSecProperty);
		lpcomSecProperty.setLpcomSecurity(null);

		return lpcomSecProperty;
	}

	public List<LpcomSecVehicleDet> getLpcomSecVehicleDets() {
		return this.lpcomSecVehicleDets;
	}

	public void setLpcomSecVehicleDets(List<LpcomSecVehicleDet> lpcomSecVehicleDets) {
		this.lpcomSecVehicleDets = lpcomSecVehicleDets;
	}

	public LpcomSecVehicleDet addLpcomSecVehicleDet(LpcomSecVehicleDet lpcomSecVehicleDet) {
		getLpcomSecVehicleDets().add(lpcomSecVehicleDet);
		lpcomSecVehicleDet.setLpcomSecurity(this);

		return lpcomSecVehicleDet;
	}

	public LpcomSecVehicleDet removeLpcomSecVehicleDet(LpcomSecVehicleDet lpcomSecVehicleDet) {
		getLpcomSecVehicleDets().remove(lpcomSecVehicleDet);
		lpcomSecVehicleDet.setLpcomSecurity(null);

		return lpcomSecVehicleDet;
	}

	public List<LpcomSecFacMapping> getLpcomSecFacMappings() {
		return this.lpcomSecFacMappings;
	}

	public void setLpcomSecFacMappings(List<LpcomSecFacMapping> lpcomSecFacMappings) {
		this.lpcomSecFacMappings = lpcomSecFacMappings;
	}

	public LpcomSecFacMapping addLpcomSecFacMapping(LpcomSecFacMapping lpcomSecFacMapping) {
		getLpcomSecFacMappings().add(lpcomSecFacMapping);
		lpcomSecFacMapping.setLpcomSecurity(this);

		return lpcomSecFacMapping;
	}

	public LpcomSecFacMapping removeLpcomSecFacMapping(LpcomSecFacMapping lpcomSecFacMapping) {
		getLpcomSecFacMappings().remove(lpcomSecFacMapping);
		lpcomSecFacMapping.setLpcomSecurity(null);

		return lpcomSecFacMapping;
	}

	public boolean equals(Object obj) {
		if (obj instanceof LpcomSecurity) {
			LpcomSecurity lpcomSecurity = (LpcomSecurity) obj;
			return (lpcomSecurity.lsSecId == this.lsSecId);
		} else {
			return false;
		}
	}

	@Override
	public String toString() {
		return "LpcomSecurity [lsSecId=" + lsSecId + ", lsAlreadyCharged=" + lsAlreadyCharged + ", lsChargedAmt=" + lsChargedAmt + ", lsChargedInstitution=" + lsChargedInstitution + ", lsCreatedBy=" + lsCreatedBy + ", lsCreatedOn=" + lsCreatedOn + ", lsInsuranceCompany=" + lsInsuranceCompany
				+ ", lsInsuredAmt=" + lsInsuredAmt + ", lsModifiedBy=" + lsModifiedBy + ", lsModifiedOn=" + lsModifiedOn + ", lsNatureOfCharge=" + lsNatureOfCharge + ", lsNetSecValue=" + lsNetSecValue + ", lsResRiskFlag=" + lsResRiskFlag + ", lsSecClassification=" + lsSecClassification
				+ ", lsSecCreatedOn=" + lsSecCreatedOn + ", lsSecDesc=" + lsSecDesc + ", lsSecType=" + lsSecType + ", lsTotalSecurityVal=" + lsTotalSecurityVal + ", lsTypeOfCharge=" + lsTypeOfCharge + ", lpcomSecBankDeposits=" + lpcomSecBankDeposits + ", lpcomSecFindocNtrades="
				+ lpcomSecFindocNtrades + ", lpcomSecFindocTrades=" + lpcomSecFindocTrades + ", lpcomSecFurnFixDets=" + lpcomSecFurnFixDets + ", lpcomSecGoodsDets=" + lpcomSecGoodsDets + ", lpcomSecJewelDets=" + lpcomSecJewelDets + ", lpcomSecOwners=" + lpcomSecOwners + ", lpcomSecPlntMcnries="
				+ lpcomSecPlntMcnries + ", lpcomSecProperties=" + lpcomSecProperties + ", lpcomSecVehicleDets=" + lpcomSecVehicleDets + "]";
	}

}