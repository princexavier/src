package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SEC_FAC_MAPPING database table.
 * 
 */
@Entity
@Table(name="LPCOM_SEC_FAC_MAPPING")
@NamedQuery(name="LpcomSecFacMapping.findAll", query="SELECT l FROM LpcomSecFacMapping l")
public class LpcomSecFacMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LFSM_ATTACHED_AS")
	private String lfsmAttachedAs;
	
	@Column(name="LSFM_CREATED_BY")
	private String lsfmCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFM_CREATED_ON")
	private Date lsfmCreatedOn;

	@Column(name="LSFM_FAC_NO")
	private BigDecimal lsfmFacNo;

	@Column(name="LSFM_MODIFIED_BY")
	private String lsfmModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFM_MODIFIED_ON")
	private Date lsfmModifiedOn;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LSFM_ROW_ID",columnDefinition = "NUMERIC(19,0)")
	private BigDecimal lsfmRowId;

	@Column(name="LSFM_SEC_CHARGED_AMT")
	private BigDecimal lsfmSecChargedAmt;

	@Column(name="LSFM_SEC_CLASSIFICATION")
	private BigDecimal lsfmSecClassification;

	@Column(name="LSFM_SEC_GROSS_VAL")
	private BigDecimal lsfmSecGrossVal;

	@Column(name="LSFM_SEC_NET_VAL")
	private BigDecimal lsfmSecNetVal;

	@Column(name="LSFM_SEC_TYPE")
	private BigDecimal lsfmSecType;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LSFM_PROP_NO")
	private LpcomProposal lpcomProposal;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LSFM_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomSecFacMapping() {
	}

	public String getLfsmAttachedAs() {
		return this.lfsmAttachedAs;
	}

	public void setLfsmAttachedAs(String lfsmAttachedAs) {
		this.lfsmAttachedAs = lfsmAttachedAs;
	}
	
	public String getLsfmCreatedBy() {
		return this.lsfmCreatedBy;
	}

	public void setLsfmCreatedBy(String lsfmCreatedBy) {
		this.lsfmCreatedBy = lsfmCreatedBy;
	}

	public Date getLsfmCreatedOn() {
		return this.lsfmCreatedOn;
	}

	public void setLsfmCreatedOn(Date lsfmCreatedOn) {
		this.lsfmCreatedOn = lsfmCreatedOn;
	}

	public BigDecimal getLsfmFacNo() {
		return this.lsfmFacNo;
	}

	public void setLsfmFacNo(BigDecimal lsfmFacNo) {
		this.lsfmFacNo = lsfmFacNo;
	}

	public String getLsfmModifiedBy() {
		return this.lsfmModifiedBy;
	}

	public void setLsfmModifiedBy(String lsfmModifiedBy) {
		this.lsfmModifiedBy = lsfmModifiedBy;
	}

	public Date getLsfmModifiedOn() {
		return this.lsfmModifiedOn;
	}

	public void setLsfmModifiedOn(Date lsfmModifiedOn) {
		this.lsfmModifiedOn = lsfmModifiedOn;
	}

	public BigDecimal getLsfmRowId() {
		return this.lsfmRowId;
	}

	public void setLsfmRowId(BigDecimal lsfmRowId) {
		this.lsfmRowId = lsfmRowId;
	}

	public BigDecimal getLsfmSecChargedAmt() {
		return this.lsfmSecChargedAmt;
	}

	public void setLsfmSecChargedAmt(BigDecimal lsfmSecChargedAmt) {
		this.lsfmSecChargedAmt = lsfmSecChargedAmt;
	}

	public BigDecimal getLsfmSecClassification() {
		return this.lsfmSecClassification;
	}

	public void setLsfmSecClassification(BigDecimal lsfmSecClassification) {
		this.lsfmSecClassification = lsfmSecClassification;
	}

	public BigDecimal getLsfmSecGrossVal() {
		return this.lsfmSecGrossVal;
	}

	public void setLsfmSecGrossVal(BigDecimal lsfmSecGrossVal) {
		this.lsfmSecGrossVal = lsfmSecGrossVal;
	}

	public BigDecimal getLsfmSecNetVal() {
		return this.lsfmSecNetVal;
	}

	public void setLsfmSecNetVal(BigDecimal lsfmSecNetVal) {
		this.lsfmSecNetVal = lsfmSecNetVal;
	}

	public BigDecimal getLsfmSecType() {
		return this.lsfmSecType;
	}

	public void setLsfmSecType(BigDecimal lsfmSecType) {
		this.lsfmSecType = lsfmSecType;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

	@Override
	public String toString() {
		return "LpcomSecFacMapping [lfsmAttachedAs=" + lfsmAttachedAs + ", lsfmCreatedBy=" + lsfmCreatedBy
				+ ", lsfmCreatedOn=" + lsfmCreatedOn + ", lsfmFacNo=" + lsfmFacNo + ", lsfmModifiedBy=" + lsfmModifiedBy
				+ ", lsfmModifiedOn=" + lsfmModifiedOn + ", lsfmRowId=" + lsfmRowId + ", lsfmSecChargedAmt="
				+ lsfmSecChargedAmt + ", lsfmSecClassification=" + lsfmSecClassification + ", lsfmSecGrossVal="
				+ lsfmSecGrossVal + ", lsfmSecNetVal=" + lsfmSecNetVal + ", lsfmSecType=" + lsfmSecType
				+ ", lpcomProposal=" + lpcomProposal + ", lpcomSecurity=" + lpcomSecurity + "]";
	}

}