package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_TAKEOVER_CHKLIST database table.
 * 
 */
@Entity
@Table(name="LPCOM_TAKEOVER_CHKLIST")
@NamedQuery(name="LpcomTakeoverChklist.findAll", query="SELECT l FROM LpcomTakeoverChklist l")
public class LpcomTakeoverChklist implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LTC_CHKLIST_ITEM")
	private String ltcChklistItem;

	@Column(name="LTC_CHKLIST_REMARK")
	private String ltcChklistRemark;

	@Column(name="LTC_CREATED_BY")
	private String ltcCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LTC_CREATED_ON")
	private Date ltcCreatedOn;

	@Column(name="LTC_MODIFIED_BY")
	private String ltcModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LTC_MODIFIED_ON")
	private Date ltcModifiedOn;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LTC_ROW_ID")
	private BigDecimal ltcRowId;

	@Column(name="LTC_ACTIVE")
	private String ltcActive;

	public String getLtcActive() {
		return ltcActive;
	}

	public void setLtcActive(String ltcActive) {
		this.ltcActive = ltcActive;
	}

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LTC_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomTakeoverChklist() {
	}

	public String getLtcChklistItem() {
		return this.ltcChklistItem;
	}

	public void setLtcChklistItem(String ltcChklistItem) {
		this.ltcChklistItem = ltcChklistItem;
	}

	public String getLtcChklistRemark() {
		return this.ltcChklistRemark;
	}

	public void setLtcChklistRemark(String ltcChklistRemark) {
		this.ltcChklistRemark = ltcChklistRemark;
	}

	public String getLtcCreatedBy() {
		return this.ltcCreatedBy;
	}

	public void setLtcCreatedBy(String ltcCreatedBy) {
		this.ltcCreatedBy = ltcCreatedBy;
	}

	public Date getLtcCreatedOn() {
		return this.ltcCreatedOn;
	}

	public void setLtcCreatedOn(Date ltcCreatedOn) {
		this.ltcCreatedOn = ltcCreatedOn;
	}

	public String getLtcModifiedBy() {
		return this.ltcModifiedBy;
	}

	public void setLtcModifiedBy(String ltcModifiedBy) {
		this.ltcModifiedBy = ltcModifiedBy;
	}

	public Date getLtcModifiedOn() {
		return this.ltcModifiedOn;
	}

	public void setLtcModifiedOn(Date ltcModifiedOn) {
		this.ltcModifiedOn = ltcModifiedOn;
	}

	public BigDecimal getLtcRowId() {
		return this.ltcRowId;
	}

	public void setLtcRowId(BigDecimal ltcRowId) {
		this.ltcRowId = ltcRowId;
	}

	

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}