package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_RCU_APPROVAL database table.
 * 
 */
@Entity
@Table(name="LPCOM_RCU_APPROVAL")
@NamedQuery(name="LpcomRcuApproval.findAll", query="SELECT l FROM LpcomRcuApproval l")
public class LpcomRcuApproval implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LRA_APPROVAL_STATUS")
	private String lraApprovalStatus;

	@Column(name="LRA_APPROVED_BY")
	private String lraApprovedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LRA_APPROVED_ON")
	private Date lraApprovedOn;

	@Column(name="LRA_ATTACHMENT_ID")
	private BigDecimal lraAttachmentId;

	@Column(name="LRA_CREATED_BY")
	private String lraCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LRA_CREATED_ON")
	private Date lraCreatedOn;

	@Column(name="LRA_MODIFIED_BY")
	private String lraModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LRA_MODIFIED_ON")
	private Date lraModifiedOn;

	@Column(name="LRA_OVERALL_REJ_CODE")
	private String lraOverallRejCode;

	@Column(name="LRA_OVERALL_STATUS")
	private String lraOverallStatus;

	@Column(name="LRA_REMARKS")
	private String lraRemarks;

	@Id
	@GeneratedValue
	@Column(name="LRA_ROW_ID")
	private BigDecimal lraRowId;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LRA_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomRcuApproval() {
	}

	public String getLraApprovalStatus() {
		return this.lraApprovalStatus;
	}

	public void setLraApprovalStatus(String lraApprovalStatus) {
		this.lraApprovalStatus = lraApprovalStatus;
	}

	public String getLraApprovedBy() {
		return this.lraApprovedBy;
	}

	public void setLraApprovedBy(String lraApprovedBy) {
		this.lraApprovedBy = lraApprovedBy;
	}

	public Date getLraApprovedOn() {
		return this.lraApprovedOn;
	}

	public void setLraApprovedOn(Date lraApprovedOn) {
		this.lraApprovedOn = lraApprovedOn;
	}

	public BigDecimal getLraAttachmentId() {
		return this.lraAttachmentId;
	}

	public void setLraAttachmentId(BigDecimal lraAttachmentId) {
		this.lraAttachmentId = lraAttachmentId;
	}

	public String getLraCreatedBy() {
		return this.lraCreatedBy;
	}

	public void setLraCreatedBy(String lraCreatedBy) {
		this.lraCreatedBy = lraCreatedBy;
	}

	public Date getLraCreatedOn() {
		return this.lraCreatedOn;
	}

	public void setLraCreatedOn(Date lraCreatedOn) {
		this.lraCreatedOn = lraCreatedOn;
	}

	public String getLraModifiedBy() {
		return this.lraModifiedBy;
	}

	public void setLraModifiedBy(String lraModifiedBy) {
		this.lraModifiedBy = lraModifiedBy;
	}

	public Date getLraModifiedOn() {
		return this.lraModifiedOn;
	}

	public void setLraModifiedOn(Date lraModifiedOn) {
		this.lraModifiedOn = lraModifiedOn;
	}

	public String getLraOverallRejCode() {
		return this.lraOverallRejCode;
	}

	public void setLraOverallRejCode(String lraOverallRejCode) {
		this.lraOverallRejCode = lraOverallRejCode;
	}

	public String getLraOverallStatus() {
		return this.lraOverallStatus;
	}

	public void setLraOverallStatus(String lraOverallStatus) {
		this.lraOverallStatus = lraOverallStatus;
	}

	public String getLraRemarks() {
		return this.lraRemarks;
	}

	public void setLraRemarks(String lraRemarks) {
		this.lraRemarks = lraRemarks;
	}

	public BigDecimal getLraRowId() {
		return this.lraRowId;
	}

	public void setLraRowId(BigDecimal lraRowId) {
		this.lraRowId = lraRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}