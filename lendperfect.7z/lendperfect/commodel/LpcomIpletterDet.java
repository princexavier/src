package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_IPLETTER_DET database table.
 * 
 */
@Entity
@Table(name="LPCOM_IPLETTER_DET")
@NamedQuery(name="LpcomIpletterDet.findAll", query="SELECT l FROM LpcomIpletterDet l")
public class LpcomIpletterDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LID_AA_COMMENTS")
	private String lidAaComments;

	@Temporal(TemporalType.DATE)
	@Column(name="LID_ACCEPT_DATE")
	private Date lidAcceptDate;

	@Column(name="LID_APP_STATUS")
	private String lidAppStatus;

	@Column(name="LID_CREATED_BY")
	private String lidCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LID_CREATED_ON")
	private Date lidCreatedOn;

	@Column(name="LID_CUST_ID")
	private BigDecimal lidCustId;

	@Column(name="LID_IP_ACCEPTED")
	private String lidIpAccepted;

	@Column(name="LID_IP_DOC_LOC")
	private String lidIpDocLoc;

	@Column(name="LID_IP_DOC_NAME")
	private String lidIpDocName;

	@Column(name="LID_MODIFIED_BY")
	private String lidModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LID_MODIFIED_ON")
	private Date lidModifiedOn;

	@Column(name="LID_REMARKS")
	private String lidRemarks;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LID_ROW_ID")
	private BigDecimal lidRowId;

	@Column(name="LID_SET_ID")
	private BigDecimal lidSetId;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LID_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomIpletterDet() {
	}

	public String getLidAaComments() {
		return this.lidAaComments;
	}

	public void setLidAaComments(String lidAaComments) {
		this.lidAaComments = lidAaComments;
	}

	public Date getLidAcceptDate() {
		return this.lidAcceptDate;
	}

	public void setLidAcceptDate(Date lidAcceptDate) {
		this.lidAcceptDate = lidAcceptDate;
	}

	public String getLidAppStatus() {
		return this.lidAppStatus;
	}

	public void setLidAppStatus(String lidAppStatus) {
		this.lidAppStatus = lidAppStatus;
	}

	public String getLidCreatedBy() {
		return this.lidCreatedBy;
	}

	public void setLidCreatedBy(String lidCreatedBy) {
		this.lidCreatedBy = lidCreatedBy;
	}

	public Date getLidCreatedOn() {
		return this.lidCreatedOn;
	}

	public void setLidCreatedOn(Date lidCreatedOn) {
		this.lidCreatedOn = lidCreatedOn;
	}

	public BigDecimal getLidCustId() {
		return this.lidCustId;
	}

	public void setLidCustId(BigDecimal lidCustId) {
		this.lidCustId = lidCustId;
	}

	public String getLidIpAccepted() {
		return this.lidIpAccepted;
	}

	public void setLidIpAccepted(String lidIpAccepted) {
		this.lidIpAccepted = lidIpAccepted;
	}

	public String getLidIpDocLoc() {
		return this.lidIpDocLoc;
	}

	public void setLidIpDocLoc(String lidIpDocLoc) {
		this.lidIpDocLoc = lidIpDocLoc;
	}

	public String getLidIpDocName() {
		return this.lidIpDocName;
	}

	public void setLidIpDocName(String lidIpDocName) {
		this.lidIpDocName = lidIpDocName;
	}

	public String getLidModifiedBy() {
		return this.lidModifiedBy;
	}

	public void setLidModifiedBy(String lidModifiedBy) {
		this.lidModifiedBy = lidModifiedBy;
	}

	public Date getLidModifiedOn() {
		return this.lidModifiedOn;
	}

	public void setLidModifiedOn(Date lidModifiedOn) {
		this.lidModifiedOn = lidModifiedOn;
	}

	public String getLidRemarks() {
		return this.lidRemarks;
	}

	public void setLidRemarks(String lidRemarks) {
		this.lidRemarks = lidRemarks;
	}

	public BigDecimal getLidRowId() {
		return this.lidRowId;
	}

	public void setLidRowId(BigDecimal lidRowId) {
		this.lidRowId = lidRowId;
	}

	public BigDecimal getLidSetId() {
		return this.lidSetId;
	}

	public void setLidSetId(BigDecimal lidSetId) {
		this.lidSetId = lidSetId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}