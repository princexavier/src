package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_CUST_CONTCT_DET database table.
 * 
 */
@Entity
@Table(name="LPCOM_CUST_CONTCT_DET")
@NamedQuery(name="LpcomCustContctDet.findAll", query="SELECT l FROM LpcomCustContctDet l")
public class LpcomCustContctDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LCD_CNCT_TYPE")
	private String lcdCnctType;

	@Column(name="LCD_CREATED_BY")
	private String lcdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCD_CREATED_ON")
	private Date lcdCreatedOn;

	@Column(name="LCD_DESC")
	private String lcdDesc;

	@Column(name="LCD_MODIFIED_BY")
	private String lcdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCD_MODIFIED_ON")
	private Date lcdModifiedOn;

	@Column(name="LCD_NUMBER")
	private String lcdNumber;

	@Column(name="LCD_ORDER_NO")
	private BigDecimal lcdOrderNo;

	@Column(name="LCD_PREF_ORDER")
	private BigDecimal lcdPrefOrder;

	@Id
	@Column(name="LCD_ROW_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private BigDecimal lcdRowId;

	//bi-directional many-to-one association to LpcomCustInfo
	@ManyToOne
	@JoinColumn(name="LCD_NEW_ID")
	private LpcomCustInfo lpcomCustInfo;

	public LpcomCustContctDet() {
	}

	public String getLcdCnctType() {
		return this.lcdCnctType;
	}

	public void setLcdCnctType(String lcdCnctType) {
		this.lcdCnctType = lcdCnctType;
	}

	public String getLcdCreatedBy() {
		return this.lcdCreatedBy;
	}

	public void setLcdCreatedBy(String lcdCreatedBy) {
		this.lcdCreatedBy = lcdCreatedBy;
	}

	public Date getLcdCreatedOn() {
		return this.lcdCreatedOn;
	}

	public void setLcdCreatedOn(Date lcdCreatedOn) {
		this.lcdCreatedOn = lcdCreatedOn;
	}

	public String getLcdDesc() {
		return this.lcdDesc;
	}

	public void setLcdDesc(String lcdDesc) {
		this.lcdDesc = lcdDesc;
	}

	public String getLcdModifiedBy() {
		return this.lcdModifiedBy;
	}

	public void setLcdModifiedBy(String lcdModifiedBy) {
		this.lcdModifiedBy = lcdModifiedBy;
	}

	public Date getLcdModifiedOn() {
		return this.lcdModifiedOn;
	}

	public void setLcdModifiedOn(Date lcdModifiedOn) {
		this.lcdModifiedOn = lcdModifiedOn;
	}

	public String getLcdNumber() {
		return this.lcdNumber;
	}

	public void setLcdNumber(String lcdNumber) {
		this.lcdNumber = lcdNumber;
	}

	public BigDecimal getLcdOrderNo() {
		return this.lcdOrderNo;
	}

	public void setLcdOrderNo(BigDecimal lcdOrderNo) {
		this.lcdOrderNo = lcdOrderNo;
	}

	public BigDecimal getLcdPrefOrder() {
		return this.lcdPrefOrder;
	}

	public void setLcdPrefOrder(BigDecimal lcdPrefOrder) {
		this.lcdPrefOrder = lcdPrefOrder;
	}

	public BigDecimal getLcdRowId() {
		return this.lcdRowId;
	}

	public void setLcdRowId(BigDecimal lcdRowId) {
		this.lcdRowId = lcdRowId;
	}

	public LpcomCustInfo getLpcomCustInfo() {
		return this.lpcomCustInfo;
	}

	public void setLpcomCustInfo(LpcomCustInfo lpcomCustInfo) {
		this.lpcomCustInfo = lpcomCustInfo;
	}

}