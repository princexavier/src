package com.sai.lendperfect.commodel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * The persistent class for the LPCOM_LEGAL_DOC_DETAILS database table.
 * 
 */
@Entity
@Table(name="LPCOM_LEGAL_DOC_DETAILS")
@NamedQuery(name="LpcomLegalDocDetail.findAll", query="SELECT l FROM LpcomLegalDocDetail l")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LpcomLegalDocDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LLDD_ROW_ID")
	private long llddRowId;

	@Column(name="LLDD_CREATED_BY")
	private String llddCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LLDD_CREATED_ON")
	private Date llddCreatedOn;

	@Column(name="LLDD_DOC_AFTER_DISB")
	private String llddDocAfterDisb;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LLDD_DOC_DATE")
	private Date llddDocDate;

	@Column(name="LLDD_DOC_NO")
	private BigDecimal llddDocNo;

	@Column(name="LLDD_DOC_NO_OF_PAGES")
	private String llddDocNoOfPages;

	@Column(name="LLDD_DOC_SUB_STATUS")
	private String llddDocSubStatus;

	@Column(name="LLDD_DOC_SUB_TYPE")
	private String llddDocSubType;

	@Column(name="LLDD_DOC_TYPE")
	private String llddDocType;

	@Column(name="LLDD_MODIFIED_BY")
	private String llddModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LLDD_MODIFIED_ON")
	private Date llddModifiedOn;

	@Column(name="LLDD_SEQ_NO")
	private BigDecimal llddSeqNo;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LLDD_PROP_NO")
	private LpcomProposal lpcomProposal;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LLDD_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomLegalDocDetail() {
	}

	public long getLlddRowId() {
		return this.llddRowId;
	}

	public void setLlddRowId(long llddRowId) {
		this.llddRowId = llddRowId;
	}

	public String getLlddCreatedBy() {
		return this.llddCreatedBy;
	}

	public void setLlddCreatedBy(String llddCreatedBy) {
		this.llddCreatedBy = llddCreatedBy;
	}

	public Date getLlddCreatedOn() {
		return this.llddCreatedOn;
	}

	public void setLlddCreatedOn(Date llddCreatedOn) {
		this.llddCreatedOn = llddCreatedOn;
	}

	public String getLlddDocAfterDisb() {
		return this.llddDocAfterDisb;
	}

	public void setLlddDocAfterDisb(String llddDocAfterDisb) {
		this.llddDocAfterDisb = llddDocAfterDisb;
	}

	public Date getLlddDocDate() {
		return this.llddDocDate;
	}

	public void setLlddDocDate(Date llddDocDate) {
		this.llddDocDate = llddDocDate;
	}

	public BigDecimal getLlddDocNo() {
		return this.llddDocNo;
	}

	public void setLlddDocNo(BigDecimal llddDocNo) {
		this.llddDocNo = llddDocNo;
	}

	public String getLlddDocNoOfPages() {
		return this.llddDocNoOfPages;
	}

	public void setLlddDocNoOfPages(String llddDocNoOfPages) {
		this.llddDocNoOfPages = llddDocNoOfPages;
	}

	public String getLlddDocSubStatus() {
		return this.llddDocSubStatus;
	}

	public void setLlddDocSubStatus(String llddDocSubStatus) {
		this.llddDocSubStatus = llddDocSubStatus;
	}

	public String getLlddDocSubType() {
		return this.llddDocSubType;
	}

	public void setLlddDocSubType(String llddDocSubType) {
		this.llddDocSubType = llddDocSubType;
	}

	public String getLlddDocType() {
		return this.llddDocType;
	}

	public void setLlddDocType(String llddDocType) {
		this.llddDocType = llddDocType;
	}

	public String getLlddModifiedBy() {
		return this.llddModifiedBy;
	}

	public void setLlddModifiedBy(String llddModifiedBy) {
		this.llddModifiedBy = llddModifiedBy;
	}

	public Date getLlddModifiedOn() {
		return this.llddModifiedOn;
	}

	public void setLlddModifiedOn(Date llddModifiedOn) {
		this.llddModifiedOn = llddModifiedOn;
	}

	public BigDecimal getLlddSeqNo() {
		return this.llddSeqNo;
	}

	public void setLlddSeqNo(BigDecimal llddSeqNo) {
		this.llddSeqNo = llddSeqNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

}
