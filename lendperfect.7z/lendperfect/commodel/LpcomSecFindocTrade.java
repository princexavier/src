package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SEC_FINDOC_TRADE database table.
 * 
 */
@Entity
@Table(name="LPCOM_SEC_FINDOC_TRADE")
@NamedQuery(name="LpcomSecFindocTrade.findAll", query="SELECT l FROM LpcomSecFindocTrade l")
public class LpcomSecFindocTrade implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LSFT_CREATED_BY")
	private String lsftCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFT_CREATED_ON")
	private Date lsftCreatedOn;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFT_MATURITY_DATE")
	private Date lsftMaturityDate;

	@Column(name="LSFT_MATURITY_VALUE")
	private BigDecimal lsftMaturityValue;

	@Column(name="LSFT_MODIFIED_BY")
	private String lsftModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFT_MODIFIED_ON")
	private Date lsftModifiedOn;

	@Column(name="LSFT_NO_OF_UNITS")
	private BigDecimal lsftNoOfUnits;

	@Column(name="LSFT_QUOTED_RATE")
	private BigDecimal lsftQuotedRate;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LSFT_ROW_ID",columnDefinition = "NUMERIC(19,0)")
	private BigDecimal lsftRowId;

	@Column(name="LSFT_SEC_EXCHG_CODE")
	private String lsftSecExchgCode;

	@Column(name="LSFT_TOT_VAL_OF_SEC")
	private BigDecimal lsftTotValOfSec;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LSFT_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomSecFindocTrade() {
	}

	public String getLsftCreatedBy() {
		return this.lsftCreatedBy;
	}

	public void setLsftCreatedBy(String lsftCreatedBy) {
		this.lsftCreatedBy = lsftCreatedBy;
	}

	public Date getLsftCreatedOn() {
		return this.lsftCreatedOn;
	}

	public void setLsftCreatedOn(Date lsftCreatedOn) {
		this.lsftCreatedOn = lsftCreatedOn;
	}

	public Date getLsftMaturityDate() {
		return this.lsftMaturityDate;
	}

	public void setLsftMaturityDate(Date lsftMaturityDate) {
		this.lsftMaturityDate = lsftMaturityDate;
	}

	public BigDecimal getLsftMaturityValue() {
		return this.lsftMaturityValue;
	}

	public void setLsftMaturityValue(BigDecimal lsftMaturityValue) {
		this.lsftMaturityValue = lsftMaturityValue;
	}

	public String getLsftModifiedBy() {
		return this.lsftModifiedBy;
	}

	public void setLsftModifiedBy(String lsftModifiedBy) {
		this.lsftModifiedBy = lsftModifiedBy;
	}

	public Date getLsftModifiedOn() {
		return this.lsftModifiedOn;
	}

	public void setLsftModifiedOn(Date lsftModifiedOn) {
		this.lsftModifiedOn = lsftModifiedOn;
	}

	public BigDecimal getLsftNoOfUnits() {
		return this.lsftNoOfUnits;
	}

	public void setLsftNoOfUnits(BigDecimal lsftNoOfUnits) {
		this.lsftNoOfUnits = lsftNoOfUnits;
	}

	public BigDecimal getLsftQuotedRate() {
		return this.lsftQuotedRate;
	}

	public void setLsftQuotedRate(BigDecimal lsftQuotedRate) {
		this.lsftQuotedRate = lsftQuotedRate;
	}

	public BigDecimal getLsftRowId() {
		return this.lsftRowId;
	}

	public void setLsftRowId(BigDecimal lsftRowId) {
		this.lsftRowId = lsftRowId;
	}

	public String getLsftSecExchgCode() {
		return this.lsftSecExchgCode;
	}

	public void setLsftSecExchgCode(String lsftSecExchgCode) {
		this.lsftSecExchgCode = lsftSecExchgCode;
	}

	public BigDecimal getLsftTotValOfSec() {
		return this.lsftTotValOfSec;
	}

	public void setLsftTotValOfSec(BigDecimal lsftTotValOfSec) {
		this.lsftTotValOfSec = lsftTotValOfSec;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

	@Override
	public String toString() {
		return "LpcomSecFindocTrade [lsftCreatedBy=" + lsftCreatedBy + ", lsftCreatedOn=" + lsftCreatedOn
				+ ", lsftMaturityDate=" + lsftMaturityDate + ", lsftMaturityValue=" + lsftMaturityValue
				+ ", lsftModifiedBy=" + lsftModifiedBy + ", lsftModifiedOn=" + lsftModifiedOn + ", lsftNoOfUnits="
				+ lsftNoOfUnits + ", lsftQuotedRate=" + lsftQuotedRate + ", lsftRowId=" + lsftRowId
				+ ", lsftSecExchgCode=" + lsftSecExchgCode + ", lsftTotValOfSec=" + lsftTotValOfSec + ", lpcomSecurity="
				+ lpcomSecurity + "]";
	}

}