package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_BUSS_APPROVALS database table.
 * 
 */
@Entity
@Table(name="LPCOM_BUSS_APPROVALS")
@NamedQuery(name="LpcomBussApproval.findAll", query="SELECT l FROM LpcomBussApproval l")
public class LpcomBussApproval implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LBA_APPROVAL_AUTHORITY")
	private String lbaApprovalAuthority;

	@Column(name="LBA_APPROVED_BY")
	private String lbaApprovedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBA_APPROVED_ON")
	private Date lbaApprovedOn;

	@Column(name="LBA_CHARGE_TYPE")
	private String lbaChargeType;

	@Column(name="LBA_CREATED_BY")
	private String lbaCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBA_CREATED_ON")
	private Date lbaCreatedOn;

	@Column(name="LBA_CUST_ID")
	private BigDecimal lbaCustId;

	@Column(name="LBA_FAC_ID")
	private BigDecimal lbaFacId;

	@Column(name="LBA_FACSET_ID")
	private BigDecimal lbaFacsetId;

	@Column(name="LBA_MODIFIED_BY")
	private String lbaModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBA_MODIFIED_ON")
	private Date lbaModifiedOn;

	@Column(name="LBA_PRD_DEFINED")
	private BigDecimal lbaPrdDefined;

	@Column(name="LBA_RECMD_VALUE")
	private BigDecimal lbaRecmdValue;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LBA_ROW_ID")
	private BigDecimal lbaRowId;

	@Column(name="LBA_STATUS")
	private String lbaStatus;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LBA_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomBussApproval() {
	}

	public String getLbaApprovalAuthority() {
		return this.lbaApprovalAuthority;
	}

	public void setLbaApprovalAuthority(String lbaApprovalAuthority) {
		this.lbaApprovalAuthority = lbaApprovalAuthority;
	}

	public String getLbaApprovedBy() {
		return this.lbaApprovedBy;
	}

	public void setLbaApprovedBy(String lbaApprovedBy) {
		this.lbaApprovedBy = lbaApprovedBy;
	}

	public Date getLbaApprovedOn() {
		return this.lbaApprovedOn;
	}

	public void setLbaApprovedOn(Date lbaApprovedOn) {
		this.lbaApprovedOn = lbaApprovedOn;
	}

	public String getLbaChargeType() {
		return this.lbaChargeType;
	}

	public void setLbaChargeType(String lbaChargeType) {
		this.lbaChargeType = lbaChargeType;
	}

	public String getLbaCreatedBy() {
		return this.lbaCreatedBy;
	}

	public void setLbaCreatedBy(String lbaCreatedBy) {
		this.lbaCreatedBy = lbaCreatedBy;
	}

	public Date getLbaCreatedOn() {
		return this.lbaCreatedOn;
	}

	public void setLbaCreatedOn(Date lbaCreatedOn) {
		this.lbaCreatedOn = lbaCreatedOn;
	}

	public BigDecimal getLbaCustId() {
		return this.lbaCustId;
	}

	public void setLbaCustId(BigDecimal lbaCustId) {
		this.lbaCustId = lbaCustId;
	}

	public BigDecimal getLbaFacId() {
		return this.lbaFacId;
	}

	public void setLbaFacId(BigDecimal lbaFacId) {
		this.lbaFacId = lbaFacId;
	}

	public BigDecimal getLbaFacsetId() {
		return this.lbaFacsetId;
	}

	public void setLbaFacsetId(BigDecimal lbaFacsetId) {
		this.lbaFacsetId = lbaFacsetId;
	}

	public String getLbaModifiedBy() {
		return this.lbaModifiedBy;
	}

	public void setLbaModifiedBy(String lbaModifiedBy) {
		this.lbaModifiedBy = lbaModifiedBy;
	}

	public Date getLbaModifiedOn() {
		return this.lbaModifiedOn;
	}

	public void setLbaModifiedOn(Date lbaModifiedOn) {
		this.lbaModifiedOn = lbaModifiedOn;
	}

	public BigDecimal getLbaPrdDefined() {
		return this.lbaPrdDefined;
	}

	public void setLbaPrdDefined(BigDecimal lbaPrdDefined) {
		this.lbaPrdDefined = lbaPrdDefined;
	}

	public BigDecimal getLbaRecmdValue() {
		return this.lbaRecmdValue;
	}

	public void setLbaRecmdValue(BigDecimal lbaRecmdValue) {
		this.lbaRecmdValue = lbaRecmdValue;
	}

	public BigDecimal getLbaRowId() {
		return this.lbaRowId;
	}

	public void setLbaRowId(BigDecimal lbaRowId) {
		this.lbaRowId = lbaRowId;
	}

	public String getLbaStatus() {
		return this.lbaStatus;
	}

	public void setLbaStatus(String lbaStatus) {
		this.lbaStatus = lbaStatus;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}