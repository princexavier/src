package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SEC_PLNT_MCNRY database table.
 * 
 */
@Entity
@Table(name="LPCOM_SEC_PLNT_MCNRY")
@NamedQuery(name="LpcomSecPlntMcnry.findAll", query="SELECT l FROM LpcomSecPlntMcnry l")
public class LpcomSecPlntMcnry implements Serializable {
	private static final long serialVersionUID = 1L;
    
	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LSPMD_BAL_SHEET_DATE")
	private Date lspmdBalSheetDate;

	@Column(name="LSPMD_BAL_SHEET_VALUE")
	private BigDecimal lspmdBalSheetValue;

	@Column(name="LSPMD_BOOK_VALUE")
	private BigDecimal lspmdBookValue;

	@Column(name="LSPMD_CREATED_BY")
	private String lspmdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSPMD_CREATED_ON")
	private Date lspmdCreatedOn;

	@Column(name="LSPMD_MANF_COMP")
	private String lspmdManfComp;

	@Column(name="LSPMD_MODEL_NO")
	private String lspmdModelNo;

	@Column(name="LSPMD_MODIFIED_BY")
	private String lspmdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSPMD_MODIFIED_ON")
	private Date lspmdModifiedOn;

	@Column(name="LSPMD_PUR_PRICE")
	private BigDecimal lspmdPurPrice;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LSPMD_ROW_ID",columnDefinition = "NUMERIC(19,0)")
	private BigDecimal lspmdRowId;

	@Column(name="LSPMD_SALE_VALUE")
	private BigDecimal lspmdSaleValue;

	@Column(name="LSPMD_TYPE")
	private String lspmdType;

	@Column(name="LSPMD_VALUE")
	private BigDecimal lspmdValue;

	@Column(name="LSPMD_WORK_COND")
	private String lspmdWorkCond;

	@Column(name="LSPMD_YEAR_OF_MANF")
	private BigDecimal lspmdYearOfManf;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LSPMD_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomSecPlntMcnry() {
	}

	public Date getLspmdBalSheetDate() {
		return this.lspmdBalSheetDate;
	}

	public void setLspmdBalSheetDate(Date lspmdBalSheetDate) {
		this.lspmdBalSheetDate = lspmdBalSheetDate;
	}

	public BigDecimal getLspmdBalSheetValue() {
		return this.lspmdBalSheetValue;
	}

	public void setLspmdBalSheetValue(BigDecimal lspmdBalSheetValue) {
		this.lspmdBalSheetValue = lspmdBalSheetValue;
	}

	public BigDecimal getLspmdBookValue() {
		return this.lspmdBookValue;
	}

	public void setLspmdBookValue(BigDecimal lspmdBookValue) {
		this.lspmdBookValue = lspmdBookValue;
	}

	public String getLspmdCreatedBy() {
		return this.lspmdCreatedBy;
	}

	public void setLspmdCreatedBy(String lspmdCreatedBy) {
		this.lspmdCreatedBy = lspmdCreatedBy;
	}

	public Date getLspmdCreatedOn() {
		return this.lspmdCreatedOn;
	}

	public void setLspmdCreatedOn(Date lspmdCreatedOn) {
		this.lspmdCreatedOn = lspmdCreatedOn;
	}

	public String getLspmdManfComp() {
		return this.lspmdManfComp;
	}

	public void setLspmdManfComp(String lspmdManfComp) {
		this.lspmdManfComp = lspmdManfComp;
	}

	public String getLspmdModelNo() {
		return this.lspmdModelNo;
	}

	public void setLspmdModelNo(String lspmdModelNo) {
		this.lspmdModelNo = lspmdModelNo;
	}

	public String getLspmdModifiedBy() {
		return this.lspmdModifiedBy;
	}

	public void setLspmdModifiedBy(String lspmdModifiedBy) {
		this.lspmdModifiedBy = lspmdModifiedBy;
	}

	public Date getLspmdModifiedOn() {
		return this.lspmdModifiedOn;
	}

	public void setLspmdModifiedOn(Date lspmdModifiedOn) {
		this.lspmdModifiedOn = lspmdModifiedOn;
	}

	public BigDecimal getLspmdPurPrice() {
		return this.lspmdPurPrice;
	}

	public void setLspmdPurPrice(BigDecimal lspmdPurPrice) {
		this.lspmdPurPrice = lspmdPurPrice;
	}

	public BigDecimal getLspmdRowId() {
		return this.lspmdRowId;
	}

	public void setLspmdRowId(BigDecimal lspmdRowId) {
		this.lspmdRowId = lspmdRowId;
	}

	public BigDecimal getLspmdSaleValue() {
		return this.lspmdSaleValue;
	}

	public void setLspmdSaleValue(BigDecimal lspmdSaleValue) {
		this.lspmdSaleValue = lspmdSaleValue;
	}

	public String getLspmdType() {
		return this.lspmdType;
	}

	public void setLspmdType(String lspmdType) {
		this.lspmdType = lspmdType;
	}

	public BigDecimal getLspmdValue() {
		return this.lspmdValue;
	}

	public void setLspmdValue(BigDecimal lspmdValue) {
		this.lspmdValue = lspmdValue;
	}

	public String getLspmdWorkCond() {
		return this.lspmdWorkCond;
	}

	public void setLspmdWorkCond(String lspmdWorkCond) {
		this.lspmdWorkCond = lspmdWorkCond;
	}

	public BigDecimal getLspmdYearOfManf() {
		return this.lspmdYearOfManf;
	}

	public void setLspmdYearOfManf(BigDecimal lspmdYearOfManf) {
		this.lspmdYearOfManf = lspmdYearOfManf;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

	@Override
	public String toString() {
		return "LpcomSecPlntMcnry [lspmdBalSheetDate=" + lspmdBalSheetDate + ", lspmdBalSheetValue="
				+ lspmdBalSheetValue + ", lspmdBookValue=" + lspmdBookValue + ", lspmdCreatedBy=" + lspmdCreatedBy
				+ ", lspmdCreatedOn=" + lspmdCreatedOn + ", lspmdManfComp=" + lspmdManfComp + ", lspmdModelNo="
				+ lspmdModelNo + ", lspmdModifiedBy=" + lspmdModifiedBy + ", lspmdModifiedOn=" + lspmdModifiedOn
				+ ", lspmdPurPrice=" + lspmdPurPrice + ", lspmdRowId=" + lspmdRowId + ", lspmdSaleValue="
				+ lspmdSaleValue + ", lspmdType=" + lspmdType + ", lspmdValue=" + lspmdValue + ", lspmdWorkCond="
				+ lspmdWorkCond + ", lspmdYearOfManf=" + lspmdYearOfManf + ", lpcomSecurity=" + lpcomSecurity + "]";
	}

}