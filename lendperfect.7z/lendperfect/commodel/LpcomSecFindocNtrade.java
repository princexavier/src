package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SEC_FINDOC_NTRADE database table.
 * 
 */
@Entity
@Table(name="LPCOM_SEC_FINDOC_NTRADE")
@NamedQuery(name="LpcomSecFindocNtrade.findAll", query="SELECT l FROM LpcomSecFindocNtrade l")
public class LpcomSecFindocNtrade implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LSFN_BOOK_VALUE")
	private BigDecimal lsfnBookValue;

	@Column(name="LSFN_CREATED_BY")
	private String lsfnCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFN_CREATED_ON")
	private Date lsfnCreatedOn;

	@Column(name="LSFN_CURR_TYPE")
	private String lsfnCurrType;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFN_DATE")
	private Date lsfnDate;

	@Column(name="LSFN_FACE_VALUE")
	private BigDecimal lsfnFaceValue;

	@Column(name="LSFN_INSTRUMENT")
	private String lsfnInstrument;

	@Column(name="LSFN_ISSUED_BY")
	private String lsfnIssuedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFN_MATURITY_DATE")
	private Date lsfnMaturityDate;

	@Column(name="LSFN_MATURITY_VALUE")
	private BigDecimal lsfnMaturityValue;

	@Column(name="LSFN_MODIFIED_BY")
	private String lsfnModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSFN_MODIFIED_ON")
	private Date lsfnModifiedOn;

	@Column(name="LSFN_POLICY_NO")
	private String lsfnPolicyNo;

	@Column(name="LSFN_RATING_AGENCY")
	private String lsfnRatingAgency;

	@Column(name="LSFN_RATING_SYMBOL")
	private String lsfnRatingSymbol;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LSFN_ROW_ID")
	private BigDecimal lsfnRowId;

	//bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LSFN_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomSecFindocNtrade() {
	}

	public BigDecimal getLsfnBookValue() {
		return this.lsfnBookValue;
	}

	public void setLsfnBookValue(BigDecimal lsfnBookValue) {
		this.lsfnBookValue = lsfnBookValue;
	}

	public String getLsfnCreatedBy() {
		return this.lsfnCreatedBy;
	}

	public void setLsfnCreatedBy(String lsfnCreatedBy) {
		this.lsfnCreatedBy = lsfnCreatedBy;
	}

	public Date getLsfnCreatedOn() {
		return this.lsfnCreatedOn;
	}

	public void setLsfnCreatedOn(Date lsfnCreatedOn) {
		this.lsfnCreatedOn = lsfnCreatedOn;
	}

	public String getLsfnCurrType() {
		return this.lsfnCurrType;
	}

	public void setLsfnCurrType(String lsfnCurrType) {
		this.lsfnCurrType = lsfnCurrType;
	}

	public Date getLsfnDate() {
		return this.lsfnDate;
	}

	public void setLsfnDate(Date lsfnDate) {
		this.lsfnDate = lsfnDate;
	}

	public BigDecimal getLsfnFaceValue() {
		return this.lsfnFaceValue;
	}

	public void setLsfnFaceValue(BigDecimal lsfnFaceValue) {
		this.lsfnFaceValue = lsfnFaceValue;
	}

	public String getLsfnInstrument() {
		return this.lsfnInstrument;
	}

	public void setLsfnInstrument(String lsfnInstrument) {
		this.lsfnInstrument = lsfnInstrument;
	}

	public String getLsfnIssuedBy() {
		return this.lsfnIssuedBy;
	}

	public void setLsfnIssuedBy(String lsfnIssuedBy) {
		this.lsfnIssuedBy = lsfnIssuedBy;
	}

	public Date getLsfnMaturityDate() {
		return this.lsfnMaturityDate;
	}

	public void setLsfnMaturityDate(Date lsfnMaturityDate) {
		this.lsfnMaturityDate = lsfnMaturityDate;
	}

	public BigDecimal getLsfnMaturityValue() {
		return this.lsfnMaturityValue;
	}

	public void setLsfnMaturityValue(BigDecimal lsfnMaturityValue) {
		this.lsfnMaturityValue = lsfnMaturityValue;
	}

	public String getLsfnModifiedBy() {
		return this.lsfnModifiedBy;
	}

	public void setLsfnModifiedBy(String lsfnModifiedBy) {
		this.lsfnModifiedBy = lsfnModifiedBy;
	}

	public Date getLsfnModifiedOn() {
		return this.lsfnModifiedOn;
	}

	public void setLsfnModifiedOn(Date lsfnModifiedOn) {
		this.lsfnModifiedOn = lsfnModifiedOn;
	}

	public String getLsfnPolicyNo() {
		return this.lsfnPolicyNo;
	}

	public void setLsfnPolicyNo(String lsfnPolicyNo) {
		this.lsfnPolicyNo = lsfnPolicyNo;
	}

	public String getLsfnRatingAgency() {
		return this.lsfnRatingAgency;
	}

	public void setLsfnRatingAgency(String lsfnRatingAgency) {
		this.lsfnRatingAgency = lsfnRatingAgency;
	}

	public String getLsfnRatingSymbol() {
		return this.lsfnRatingSymbol;
	}

	public void setLsfnRatingSymbol(String lsfnRatingSymbol) {
		this.lsfnRatingSymbol = lsfnRatingSymbol;
	}

	public BigDecimal getLsfnRowId() {
		return this.lsfnRowId;
	}

	public void setLsfnRowId(BigDecimal lsfnRowId) {
		this.lsfnRowId = lsfnRowId;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

	@Override
	public String toString() {
		return "LpcomSecFindocNtrade [lsfnBookValue=" + lsfnBookValue + ", lsfnCreatedBy=" + lsfnCreatedBy
				+ ", lsfnCreatedOn=" + lsfnCreatedOn + ", lsfnCurrType=" + lsfnCurrType + ", lsfnDate=" + lsfnDate
				+ ", lsfnFaceValue=" + lsfnFaceValue + ", lsfnInstrument=" + lsfnInstrument + ", lsfnIssuedBy="
				+ lsfnIssuedBy + ", lsfnMaturityDate=" + lsfnMaturityDate + ", lsfnMaturityValue=" + lsfnMaturityValue
				+ ", lsfnModifiedBy=" + lsfnModifiedBy + ", lsfnModifiedOn=" + lsfnModifiedOn + ", lsfnPolicyNo="
				+ lsfnPolicyNo + ", lsfnRatingAgency=" + lsfnRatingAgency + ", lsfnRatingSymbol=" + lsfnRatingSymbol
				+ ", lsfnRowId=" + lsfnRowId + ", lpcomSecurity=" + lpcomSecurity + "]";
	}

}