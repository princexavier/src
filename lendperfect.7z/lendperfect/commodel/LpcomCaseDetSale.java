package com.sai.lendperfect.commodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.setupmodel.LpstpScheme;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_CASE_DET_SALES database table.
 * 
 */
@Entity
@Table(name="LPCOM_CASE_DET_SALES")
@NamedQuery(name="LpcomCaseDetSale.findAll", query="SELECT l FROM LpcomCaseDetSale l")
public class LpcomCaseDetSale implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LP_CREATED_BY")
	private String lpCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LP_CREATED_ON")
	private Date lpCreatedOn;

	@Column(name="LP_MODIFIED_BY")
	private String lpModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LP_MODIFIED_ON")
	private Date lpModifiedOn;

	@Column(name="LPCDS_BANK_ARGMT")
	private String lpcdsBankArgmt;

	@Column(name="LPCDS_CASE_TYPE")
	private String lpcdsCaseType;

	@Column(name="LPCDS_DEALER_NAME")
	private String lpcdsDealerName;

	@Column(name="LPCDS_FILLER_FOUR")
	private String lpcdsFillerFour;

	@Column(name="LPCDS_FILLER_ONE")
	private String lpcdsFillerOne;

	@Column(name="LPCDS_FILLER_THREE")
	private String lpcdsFillerThree;

	@Column(name="LPCDS_FILLER_TWO")
	private String lpcdsFillerTwo;

	@Column(name="LPCDS_GRP_ID")
	private String lpcdsGrpId;

	@Column(name="LPCDS_GRP_NAME")
	private String lpcdsGrpName;

	@Column(name="LPCDS_LOAN_PURPOSE")
	private String lpcdsLoanPurpose;

	@Column(name="LPCDS_MANUFACTURER")
	private String lpcdsManufacturer;

	@Column(name="LPCDS_PROCESS_FEE")
	private BigDecimal lpcdsProcessFee;

	@Temporal(TemporalType.DATE)
	@Column(name="LPCDS_RECVD_DATE")
	private Date lpcdsRecvdDate;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LPCDS_ROW_ID")
	private BigDecimal lpcdsRowId;

	@Column(name="LPCDS_TAKEOVER")
	private String lpcdsTakeover;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LPCDS_PROP_NO")
	private LpcomProposal lpcomProposal;
	
	@Transient
	private String lsSchemeId;

	
	//bi-directional many-to-one association to LpstpScheme
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LPCDS_SCHEME_ID")
	private LpstpScheme lpstpScheme;

	public LpcomCaseDetSale() {
	}

	public String getLpCreatedBy() {
		return this.lpCreatedBy;
	}

	public void setLpCreatedBy(String lpCreatedBy) {
		this.lpCreatedBy = lpCreatedBy;
	}

	public Date getLpCreatedOn() {
		return this.lpCreatedOn;
	}

	public void setLpCreatedOn(Date lpCreatedOn) {
		this.lpCreatedOn = lpCreatedOn;
	}

	public String getLpModifiedBy() {
		return this.lpModifiedBy;
	}

	public void setLpModifiedBy(String lpModifiedBy) {
		this.lpModifiedBy = lpModifiedBy;
	}

	public Date getLpModifiedOn() {
		return this.lpModifiedOn;
	}

	public void setLpModifiedOn(Date lpModifiedOn) {
		this.lpModifiedOn = lpModifiedOn;
	}

	public String getLpcdsBankArgmt() {
		return this.lpcdsBankArgmt;
	}

	public void setLpcdsBankArgmt(String lpcdsBankArgmt) {
		this.lpcdsBankArgmt = lpcdsBankArgmt;
	}

	public String getLpcdsCaseType() {
		return this.lpcdsCaseType;
	}

	public void setLpcdsCaseType(String lpcdsCaseType) {
		this.lpcdsCaseType = lpcdsCaseType;
	}

	public String getLpcdsDealerName() {
		return this.lpcdsDealerName;
	}

	public void setLpcdsDealerName(String lpcdsDealerName) {
		this.lpcdsDealerName = lpcdsDealerName;
	}

	public String getLpcdsFillerFour() {
		return this.lpcdsFillerFour;
	}

	public void setLpcdsFillerFour(String lpcdsFillerFour) {
		this.lpcdsFillerFour = lpcdsFillerFour;
	}

	public String getLpcdsFillerOne() {
		return this.lpcdsFillerOne;
	}

	public void setLpcdsFillerOne(String lpcdsFillerOne) {
		this.lpcdsFillerOne = lpcdsFillerOne;
	}

	public String getLpcdsFillerThree() {
		return this.lpcdsFillerThree;
	}

	public void setLpcdsFillerThree(String lpcdsFillerThree) {
		this.lpcdsFillerThree = lpcdsFillerThree;
	}

	public String getLpcdsFillerTwo() {
		return this.lpcdsFillerTwo;
	}

	public void setLpcdsFillerTwo(String lpcdsFillerTwo) {
		this.lpcdsFillerTwo = lpcdsFillerTwo;
	}

	public String getLpcdsGrpId() {
		return this.lpcdsGrpId;
	}

	public void setLpcdsGrpId(String lpcdsGrpId) {
		this.lpcdsGrpId = lpcdsGrpId;
	}

	public String getLpcdsGrpName() {
		return this.lpcdsGrpName;
	}

	public void setLpcdsGrpName(String lpcdsGrpName) {
		this.lpcdsGrpName = lpcdsGrpName;
	}

	public String getLpcdsLoanPurpose() {
		return this.lpcdsLoanPurpose;
	}

	public void setLpcdsLoanPurpose(String lpcdsLoanPurpose) {
		this.lpcdsLoanPurpose = lpcdsLoanPurpose;
	}

	public String getLpcdsManufacturer() {
		return this.lpcdsManufacturer;
	}

	public void setLpcdsManufacturer(String lpcdsManufacturer) {
		this.lpcdsManufacturer = lpcdsManufacturer;
	}

	public BigDecimal getLpcdsProcessFee() {
		return this.lpcdsProcessFee;
	}

	public void setLpcdsProcessFee(BigDecimal lpcdsProcessFee) {
		this.lpcdsProcessFee = lpcdsProcessFee;
	}

	public Date getLpcdsRecvdDate() {
		return this.lpcdsRecvdDate;
	}

	public void setLpcdsRecvdDate(Date lpcdsRecvdDate) {
		this.lpcdsRecvdDate = lpcdsRecvdDate;
	}

	public BigDecimal getLpcdsRowId() {
		return this.lpcdsRowId;
	}

	public void setLpcdsRowId(BigDecimal lpcdsRowId) {
		this.lpcdsRowId = lpcdsRowId;
	}

	public String getLpcdsTakeover() {
		return this.lpcdsTakeover;
	}

	public void setLpcdsTakeover(String lpcdsTakeover) {
		this.lpcdsTakeover = lpcdsTakeover;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpstpScheme getLpstpScheme() {
		return this.lpstpScheme;
	}

	public void setLpstpScheme(LpstpScheme lpstpScheme) {
		this.lpstpScheme = lpstpScheme;
	}


	public String getLsSchemeId() {
		return lsSchemeId;
	}

	public void setLsSchemeId(String lsSchemeId) {
		this.lsSchemeId = lsSchemeId;
	}

}