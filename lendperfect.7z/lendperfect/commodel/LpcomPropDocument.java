  package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import  com.sai.lendperfect.commodel.LpcomProposal;

//import model.Column;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_PROP_DOCUMENTS database table.
 * 
 */
@Entity
@Table(name="LPCOM_PROP_DOCUMENTS")
@NamedQuery(name="LpcomPropDocument.findAll", query="SELECT l FROM LpcomPropDocument l")
public class LpcomPropDocument implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPD_AGENCY_ACTION")
	private String lpdAgencyAction;

	@Column(name="LPD_AGENCY_REJ_CODE")
	private String lpdAgencyRejCode;

	@Column(name="LPD_AGENCY_REMARKS")
	private String lpdAgencyRemarks;

	@Column(name="LPD_CREATED_BY")
	private String lpdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPD_CREATED_ON")
	private Date lpdCreatedOn;

	@Column(name="LPD_DOC_ACTION")
	private String lpdDocAction;

	@Column(name="LPD_DOC_DESC")
	private String lpdDocDesc;

	@Column(name="LPD_DOC_FOR")
	private String lpdDocFor;

	@Column(name="LPD_DOC_ID")
	private BigDecimal lpdDocId;

	@Column(name="LPD_DOC_STATUS")
	private String lpdDocStatus;

	@Column(name="LPD_DOC_TYPE")
	private String lpdDocType;

	@Column(name="LPD_INITIATOR_REMARKS")
	private String lpdInitiatorRemarks;

	@Column(name="LPD_LOCAL_OGL")
	private String lpdLocalOgl;

	@Column(name="LPD_MODIFIED_BY")
	private String lpdModifiedBy;
     
	@Temporal(TemporalType.DATE)
	@Column(name="LPD_MODIFIED_ON")
	private Date lpdModifiedOn;

	@Column(name="LPD_ORDER_NO")
	private BigDecimal lpdOrderNo;

	@Column(name="LPD_PARTY_ID")
	private BigDecimal lpdPartyId;

	@Column(name="LPD_PARTY_TYPE")
	private String lpdPartyType;

	@Column(name="LPD_PROVIDED")
	private String lpdProvided;

	@Column(name="LPD_RCU_ACTION")
	private String lpdRcuAction;

	@Column(name="LPD_RCU_AGENCY_ID")
	private String lpdRcuAgencyId;
    
	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LPD_RECVD_ON")
	private Date lpdRecvdOn;

	@Column(name="LPD_REMARKS")
	private String lpdRemarks;

	@Column(name="LPD_REVIEWED")
	private String lpdReviewed;
	
	@Column(name="LPD_DOC_HOLDER")
	private String lpdDocHolder;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LPD_ROW_ID")
	private BigDecimal lpdRowId;

	//bi-directional many-to-one association to LpcomProposal
	
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LPD_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomPropDocument() {
	}

	public String getLpdAgencyAction() {
		return this.lpdAgencyAction;
	}

	public void setLpdAgencyAction(String lpdAgencyAction) {
		this.lpdAgencyAction = lpdAgencyAction;
	}

	public String getLpdAgencyRejCode() {
		return this.lpdAgencyRejCode;
	}

	public void setLpdAgencyRejCode(String lpdAgencyRejCode) {
		this.lpdAgencyRejCode = lpdAgencyRejCode;
	}

	public String getLpdAgencyRemarks() {
		return this.lpdAgencyRemarks;
	}

	public void setLpdAgencyRemarks(String lpdAgencyRemarks) {
		this.lpdAgencyRemarks = lpdAgencyRemarks;
	}

	


	public void setLpdCreatedBy(String lpdCreatedBy) {
		this.lpdCreatedBy = lpdCreatedBy;
	}

	public Date getLpdCreatedOn() {
		return this.lpdCreatedOn;
	}

	public void setLpdCreatedOn(Date lpdCreatedOn) {
		this.lpdCreatedOn = lpdCreatedOn;
	}

	public String getLpdDocAction() {
		return this.lpdDocAction;
	}

	public void setLpdDocAction(String lpdDocAction) {
		this.lpdDocAction = lpdDocAction;
	}

	public String getLpdDocDesc() {
		return this.lpdDocDesc;
	}

	public void setLpdDocDesc(String lpdDocDesc) {
		this.lpdDocDesc = lpdDocDesc;
	}

	public String getLpdDocFor() {
		return this.lpdDocFor;
	}

	public void setLpdDocFor(String lpdDocFor) {
		this.lpdDocFor = lpdDocFor;
	}

	public BigDecimal getLpdDocId() {
		return this.lpdDocId;
	}

	public void setLpdDocId(BigDecimal lpdDocId) {
		this.lpdDocId = lpdDocId;
	}

	public String getLpdDocStatus() {
		return this.lpdDocStatus;
	}

	public void setLpdDocStatus(String lpdDocStatus) {
		this.lpdDocStatus = lpdDocStatus;
	}

	public String getLpdDocType() {
		return this.lpdDocType;
	}

	public void setLpdDocType(String lpdDocType) {
		this.lpdDocType = lpdDocType;
	}

	public String getLpdInitiatorRemarks() {
		return this.lpdInitiatorRemarks;
	}

	public void setLpdInitiatorRemarks(String lpdInitiatorRemarks) {
		this.lpdInitiatorRemarks = lpdInitiatorRemarks;
	}

	public String getLpdLocalOgl() {
		return this.lpdLocalOgl;
	}

	public void setLpdLocalOgl(String lpdLocalOgl) {
		this.lpdLocalOgl = lpdLocalOgl;
	}

	public String getLpdModifiedBy() {
		return this.lpdModifiedBy;
	}

	public void setLpdModifiedBy(String lpdModifiedBy) {
		this.lpdModifiedBy = lpdModifiedBy;
	}

	public Date getLpdModifiedOn() {
		return this.lpdModifiedOn;
	}

	public void setLpdModifiedOn(Date lpdModifiedOn) {
		this.lpdModifiedOn = lpdModifiedOn;
	}

	public BigDecimal getLpdOrderNo() {
		return this.lpdOrderNo;
	}

	public void setLpdOrderNo(BigDecimal lpdOrderNo) {
		this.lpdOrderNo = lpdOrderNo;
	}

	public BigDecimal getLpdPartyId() {
		return this.lpdPartyId;
	}

	public void setLpdPartyId(BigDecimal lpdPartyId) {
		this.lpdPartyId = lpdPartyId;
	}

	public String getLpdPartyType() {
		return this.lpdPartyType;
	}

	public void setLpdPartyType(String lpdPartyType) {
		this.lpdPartyType = lpdPartyType;
	}


	public String getLpdProvided() {
		return this.lpdProvided;
	}

	public void setLpdProvided(String lpdProvided) {
		this.lpdProvided = lpdProvided;
	}

	public String getLpdRcuAction() {
		return this.lpdRcuAction;
	}

	public void setLpdRcuAction(String lpdRcuAction) {
		this.lpdRcuAction = lpdRcuAction;
	}

	public String getLpdRcuAgencyId() {
		return this.lpdRcuAgencyId;
	}

	public void setLpdRcuAgencyId(String lpdRcuAgencyId) {
		this.lpdRcuAgencyId = lpdRcuAgencyId;
	}

	public Date getLpdRecvdOn() {
		return this.lpdRecvdOn;
	}

	public void setLpdRecvdOn(Date lpdRecvdOn) {
		this.lpdRecvdOn = lpdRecvdOn;
	}

	public String getLpdRemarks() {
		return this.lpdRemarks;
	}

	public void setLpdRemarks(String lpdRemarks) {
		this.lpdRemarks = lpdRemarks;
	}

	public String getLpdReviewed() {
		return this.lpdReviewed;
	}

	public void setLpdReviewed(String lpdReviewed) {
		this.lpdReviewed = lpdReviewed;
	}

	public BigDecimal getLpdRowId() {
		return this.lpdRowId;
	}

	public void setLpdRowId(BigDecimal lpdRowId) {
		this.lpdRowId = lpdRowId;
	}
	
	public String getLpdDocHolder() {
		return this.lpdDocHolder;
	}

	public void setLpdDocHolder(String lpdDocHolder) {
		this.lpdDocHolder = lpdDocHolder;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public String getLpdCreatedBy() {
		return lpdCreatedBy;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}