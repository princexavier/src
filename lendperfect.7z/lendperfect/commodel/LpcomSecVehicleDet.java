package com.sai.lendperfect.commodel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * The persistent class for the LPCOM_SEC_VEHICLE_DET database table.
 * 
 */
@Entity
@Table(name = "LPCOM_SEC_VEHICLE_DET")
@NamedQuery(name = "LpcomSecVehicleDet.findAll", query = "SELECT l FROM LpcomSecVehicleDet l")
public class LpcomSecVehicleDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "LSVD_AGE")
	private BigDecimal lsvdAge;

	@Column(name = "LSVD_BOOK_VALUE")
	private BigDecimal lsvdBookValue;

	@Column(name = "LSVD_CATEGORY")
	private String lsvdCategory;

	@Column(name = "LSVD_COMPANY")
	private BigDecimal lsvdCompany;

	@Column(name = "LSVD_CREATED_BY")
	private String lsvdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LSVD_CREATED_ON")
	private Date lsvdCreatedOn;

	@Column(name = "LSVD_ENGINE_NO")
	private BigDecimal lsvdEngineNo;

	@Column(name = "LSVD_MAKE")
	private BigDecimal lsvdMake;

	@Column(name = "LSVD_MODEL")
	private BigDecimal lsvdModel;

	@Column(name = "LSVD_MODIFIED_BY")
	private String lsvdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LSVD_MODIFIED_ON")
	private Date lsvdModifiedOn;

	@Column(name = "LSVD_PRICE")
	private BigDecimal lsvdPrice;

	@Column(name = "LSVD_REG_NO")
	private BigDecimal lsvdRegNo;

	@Column(name = "LSVD_BRANDNAME")
	private String lsvdBrandNo;

	@Column(name = "LSVD_PURCHASE")
	private BigDecimal lsvdPurchase;

	@Column(name = "LSVD_COSTOFVEHICLE")
	private BigDecimal lsvdCostofvehicle;

	@Column(name = "LSVD_ACCESSORIESPRICE")
	private BigDecimal lsvdAccessoriesprice;

	@Column(name = "LSVD_TAX")
	private BigDecimal lsvdTax;

	@Column(name = "LSVD_INSURANCE")
	private BigDecimal lsvdInsurance;

	@Column(name = "LVSD_OTHERCHARGE")
	private BigDecimal lsvdOthercharge;

	@Column(name = "LVSD_TOTALCOST")
	private BigDecimal lsvdTotalcost;

	@Column(name = "LVSD_ESTABLISHMENTYEAR")
	private BigDecimal lsvdEstablishmentyear;

	@Column(name = "LVSD_SECURITYDET_REMARK")
	private String lsvdSecuritydetRemark;

	@Column(name = "LVSD_CHASIS_NO")
	private BigDecimal lvsdChasisNo;

	@Column(name = "LVSD_OWNER_NAME")
	private String lsvdOwnerName;

	@Column(name = "LVSD_VEHICLEOWNED")
	private BigDecimal lvsdVehicleowned;

	@Column(name = "LSVD_VEHICLE_VALUATION")
	private BigDecimal lsvdVehicleValuation;

	@Column(name = "LSVD_ACTUAL_CONSIDERATION")
	private BigDecimal lsvdActualConsideration;

	@Column(name = "LVSD_SUPPLIERNAME")
	private String lvsdSuppliername;

	@Column(name = "LVSD_ADDRESS")
	private String lsvdAddress;

	@Column(name = "LVSD_STATE")
	private String lvsdstate;

	@Column(name = "LSVD_PINCODE")
	private BigDecimal lvsdPincode;

	@Column(name = "LVSD_PHN_NO")
	private BigDecimal lvsdPhnNo;

	@Column(name = "LVSD_AUTH_DEALER")
	private String lvsdAuthDealer;

	@Column(name = "LVSD_DEALER_SINCE")
	private BigDecimal lvsdDealerSince;

	@Column(name = "LVSD_CITY")
	private String lbsdCity;

	@Column(name = "LVSD_ENGINE_NO")
	private BigDecimal lvsdEngineNo;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LSVD_ROW_ID", columnDefinition = "NUMERIC(19,0)")
	private BigDecimal lsvdRowId;

	@Column(name = "LSVD_TYPE")
	private String lsvdType;

	// bi-directional many-to-one association to LpcomSecurity
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "LSVD_SEC_ID")
	private LpcomSecurity lpcomSecurity;

	public LpcomSecVehicleDet() {
	}

	public BigDecimal getLsvdAge() {
		return this.lsvdAge;
	}

	public void setLsvdAge(BigDecimal lsvdAge) {
		this.lsvdAge = lsvdAge;
	}

	public BigDecimal getLsvdBookValue() {
		return this.lsvdBookValue;
	}

	public void setLsvdBookValue(BigDecimal lsvdBookValue) {
		this.lsvdBookValue = lsvdBookValue;
	}

	public BigDecimal getLsvdVehicleValuation() {
		return lsvdVehicleValuation;
	}

	public void setLsvdVehicleValuation(BigDecimal lsvdVehicleValuation) {
		this.lsvdVehicleValuation = lsvdVehicleValuation;
	}

	public BigDecimal getLsvdActualConsideration() {
		return lsvdActualConsideration;
	}

	public void setLsvdActualConsideration(BigDecimal lsvdActualConsideration) {
		this.lsvdActualConsideration = lsvdActualConsideration;
	}

	public String getLsvdCategory() {
		return this.lsvdCategory;
	}

	public void setLsvdCategory(String lsvdCategory) {
		this.lsvdCategory = lsvdCategory;
	}

	public BigDecimal getLsvdCompany() {
		return this.lsvdCompany;
	}

	public void setLsvdCompany(BigDecimal lsvdCompany) {
		this.lsvdCompany = lsvdCompany;
	}

	public String getLsvdCreatedBy() {
		return this.lsvdCreatedBy;
	}

	public void setLsvdCreatedBy(String lsvdCreatedBy) {
		this.lsvdCreatedBy = lsvdCreatedBy;
	}

	public Date getLsvdCreatedOn() {
		return this.lsvdCreatedOn;
	}

	public void setLsvdCreatedOn(Date lsvdCreatedOn) {
		this.lsvdCreatedOn = lsvdCreatedOn;
	}

	public BigDecimal getLsvdEngineNo() {
		return this.lsvdEngineNo;
	}

	public void setLsvdEngineNo(BigDecimal lsvdEngineNo) {
		this.lsvdEngineNo = lsvdEngineNo;
	}

	public BigDecimal getLsvdMake() {
		return this.lsvdMake;
	}

	public void setLsvdMake(BigDecimal lsvdMake) {
		this.lsvdMake = lsvdMake;
	}

	public BigDecimal getLsvdModel() {
		return this.lsvdModel;
	}

	public void setLsvdModel(BigDecimal lsvdModel) {
		this.lsvdModel = lsvdModel;
	}

	public String getLsvdModifiedBy() {
		return this.lsvdModifiedBy;
	}

	public void setLsvdModifiedBy(String lsvdModifiedBy) {
		this.lsvdModifiedBy = lsvdModifiedBy;
	}

	public Date getLsvdModifiedOn() {
		return this.lsvdModifiedOn;
	}

	public void setLsvdModifiedOn(Date lsvdModifiedOn) {
		this.lsvdModifiedOn = lsvdModifiedOn;
	}

	public BigDecimal getLsvdPrice() {
		return this.lsvdPrice;
	}

	public void setLsvdPrice(BigDecimal lsvdPrice) {
		this.lsvdPrice = lsvdPrice;
	}

	public BigDecimal getLsvdRegNo() {
		return this.lsvdRegNo;
	}

	public void setLsvdRegNo(BigDecimal lsvdRegNo) {
		this.lsvdRegNo = lsvdRegNo;
	}

	public BigDecimal getLsvdRowId() {
		return this.lsvdRowId;
	}

	public void setLsvdRowId(BigDecimal lsvdRowId) {
		this.lsvdRowId = lsvdRowId;
	}

	public String getLsvdType() {
		return this.lsvdType;
	}

	public void setLsvdType(String lsvdType) {
		this.lsvdType = lsvdType;
	}

	public LpcomSecurity getLpcomSecurity() {
		return this.lpcomSecurity;
	}

	public void setLpcomSecurity(LpcomSecurity lpcomSecurity) {
		this.lpcomSecurity = lpcomSecurity;
	}

	public String getLsvdBrandNo() {
		return lsvdBrandNo;
	}

	public void setLsvdBrandNo(String lsvdBrandNo) {
		this.lsvdBrandNo = lsvdBrandNo;
	}

	public BigDecimal getLsvdPurchase() {
		return lsvdPurchase;
	}

	public void setLsvdPurchase(BigDecimal lsvdPurchase) {
		this.lsvdPurchase = lsvdPurchase;
	}

	public BigDecimal getLsvdCostofvehicle() {
		return lsvdCostofvehicle;
	}

	public void setLsvdCostofvehicle(BigDecimal lsvdCostofvehicle) {
		this.lsvdCostofvehicle = lsvdCostofvehicle;
	}

	public BigDecimal getLsvdAccessoriesprice() {
		return lsvdAccessoriesprice;
	}

	public void setLsvdAccessoriesprice(BigDecimal lsvdAccessoriesprice) {
		this.lsvdAccessoriesprice = lsvdAccessoriesprice;
	}

	public BigDecimal getLsvdTax() {
		return lsvdTax;
	}

	public void setLsvdTax(BigDecimal lsvdTax) {
		this.lsvdTax = lsvdTax;
	}

	public BigDecimal getLsvdInsurance() {
		return lsvdInsurance;
	}

	public void setLsvdInsurance(BigDecimal lsvdInsurance) {
		this.lsvdInsurance = lsvdInsurance;
	}

	public BigDecimal getLsvdOthercharge() {
		return lsvdOthercharge;
	}

	public void setLsvdOthercharge(BigDecimal lsvdOthercharge) {
		this.lsvdOthercharge = lsvdOthercharge;
	}

	public BigDecimal getLsvdTotalcost() {
		return lsvdTotalcost;
	}

	public void setLsvdTotalcost(BigDecimal lsvdTotalcost) {
		this.lsvdTotalcost = lsvdTotalcost;
	}

	public BigDecimal getLsvdEstablishmentyear() {
		return lsvdEstablishmentyear;
	}

	public void setLsvdEstablishmentyear(BigDecimal lsvdEstablishmentyear) {
		this.lsvdEstablishmentyear = lsvdEstablishmentyear;
	}

	public String getLsvdSecuritydetRemark() {
		return lsvdSecuritydetRemark;
	}

	public void setLsvdSecuritydetRemark(String lsvdSecuritydetRemark) {
		this.lsvdSecuritydetRemark = lsvdSecuritydetRemark;
	}

	public BigDecimal getLvsdChasisNo() {
		return lvsdChasisNo;
	}

	public void setLvsdChasisNo(BigDecimal lvsdChasisNo) {
		this.lvsdChasisNo = lvsdChasisNo;
	}

	public String getLsvdOwnerName() {
		return lsvdOwnerName;
	}

	public void setLsvdOwnerName(String lsvdOwnerName) {
		this.lsvdOwnerName = lsvdOwnerName;
	}

	public BigDecimal getLvsdVehicleowned() {
		return lvsdVehicleowned;
	}

	public void setLvsdVehicleowned(BigDecimal lvsdVehicleowned) {
		this.lvsdVehicleowned = lvsdVehicleowned;
	}

	public String getLvsdSuppliername() {
		return lvsdSuppliername;
	}

	public void setLvsdSuppliername(String lvsdSuppliername) {
		this.lvsdSuppliername = lvsdSuppliername;
	}

	public String getLsvdAddress() {
		return lsvdAddress;
	}

	public void setLsvdAddress(String lsvdAddress) {
		this.lsvdAddress = lsvdAddress;
	}

	public String getLvsdstate() {
		return lvsdstate;
	}

	public void setLvsdstate(String lvsdstate) {
		this.lvsdstate = lvsdstate;
	}

	public BigDecimal getLvsdPincode() {
		return lvsdPincode;
	}

	public void setLvsdPincode(BigDecimal lvsdPincode) {
		this.lvsdPincode = lvsdPincode;
	}

	public BigDecimal getLvsdPhnNo() {
		return lvsdPhnNo;
	}

	public void setLvsdPhnNo(BigDecimal lvsdPhnNo) {
		this.lvsdPhnNo = lvsdPhnNo;
	}

	public String getLvsdAuthDealer() {
		return lvsdAuthDealer;
	}

	public void setLvsdAuthDealer(String lvsdAuthDealer) {
		this.lvsdAuthDealer = lvsdAuthDealer;
	}

	public BigDecimal getLvsdDealerSince() {
		return lvsdDealerSince;
	}

	public void setLvsdDealerSince(BigDecimal lvsdDealerSince) {
		this.lvsdDealerSince = lvsdDealerSince;
	}

	public String getLbsdCity() {
		return lbsdCity;
	}

	public void setLbsdCity(String lbsdCity) {
		this.lbsdCity = lbsdCity;
	}

	public BigDecimal getLvsdEngineNo() {
		return lvsdEngineNo;
	}

	public void setLvsdEngineNo(BigDecimal lvsdEngineNo) {
		this.lvsdEngineNo = lvsdEngineNo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "LpcomSecVehicleDet [lsvdAge=" + lsvdAge + ", lsvdBookValue=" + lsvdBookValue + ", lsvdCategory=" + lsvdCategory + ", lsvdCompany=" + lsvdCompany + ", lsvdCreatedBy=" + lsvdCreatedBy + ", lsvdCreatedOn=" + lsvdCreatedOn + ", lsvdEngineNo=" + lsvdEngineNo + ", lsvdMake=" + lsvdMake
				+ ", lsvdModel=" + lsvdModel + ", lsvdModifiedBy=" + lsvdModifiedBy + ", lsvdModifiedOn=" + lsvdModifiedOn + ", lsvdPrice=" + lsvdPrice + ", lsvdRegNo=" + lsvdRegNo + ", lsvdBrandNo=" + lsvdBrandNo + ", lsvdPurchase=" + lsvdPurchase + ", lsvdCostofvehicle=" + lsvdCostofvehicle
				+ ", lsvdAccessoriesprice=" + lsvdAccessoriesprice + ", lsvdTax=" + lsvdTax + ", lsvdInsurance=" + lsvdInsurance + ", lsvdOthercharge=" + lsvdOthercharge + ", lsvdTotalcost=" + lsvdTotalcost + ", lsvdEstablishmentyear=" + lsvdEstablishmentyear + ", lsvdSecuritydetRemark="
				+ lsvdSecuritydetRemark + ", lvsdChasisNo=" + lvsdChasisNo + ", lsvdOwnerName=" + lsvdOwnerName + ", lvsdVehicleowned=" + lvsdVehicleowned + ", lvsdSuppliername=" + lvsdSuppliername + ", lsvdAddress=" + lsvdAddress + ", lvsdstate=" + lvsdstate + ", lvsdPincode=" + lvsdPincode
				+ ", lvsdPhnNo=" + lvsdPhnNo + ", lvsdAuthDealer=" + lvsdAuthDealer + ", lvsdDealerSince=" + lvsdDealerSince + ", lbsdCity=" + lbsdCity + ", lvsdEngineNo=" + lvsdEngineNo + ", lsvdRowId=" + lsvdRowId + ", lsvdType=" + lsvdType + ", lpcomSecurity=" + lpcomSecurity + "]";
	}

}