package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_QUERY_MGMT database table.
 * 
 */
@Entity
@Table(name="LPCOM_QUERY_MGMT")
@NamedNativeQueries({
@NamedNativeQuery(name="LpcomQueryMgmt.findQueryCount", query="select count(distinct lqm_query_id) from lpcom_query_mgmt where lqm_prop_no=:propId")
})
public class LpcomQueryMgmt implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LQM_CLOSED")
	private String lqmClosed;

	@Temporal(TemporalType.DATE)
	@Column(name="LQM_CLOSED_ON")
	private Date lqmClosedOn;

	@Column(name="LQM_CRAN_REQ")
	private String lqmCranReq;

	@Column(name="LQM_CREATED_BY")
	private String lqmCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LQM_CREATED_ON")
	private Date lqmCreatedOn;

	@Column(name="LQM_HIGH_PRIORITY")
	private String lqmHighPriority;

	@Column(name="LQM_MODIFIED_BY")
	private String lqmModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LQM_MODIFIED_ON")
	private Date lqmModifiedOn;

	@Column(name="LQM_QUERY")
	private String lqmQuery;

	@Column(name="LQM_QUERY_ID")
	private String lqmQueryId;

	@Column(name="LQM_QUERY_SUBJ")
	private String lqmQuerySubj;

	@Column(name="LQM_QUERY_TYPE")
	private String lqmQueryType;

	@Column(name="LQM_RECENT")
	private String lqmRecent;

	@Column(name="LQM_RECIPIENT")
	private String lqmRecipient;

	@Column(name="LQM_RESPONSE")
	private String lqmResponse;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LQM_ROW_ID")
	private BigDecimal lqmRowId;

	@Column(name="LQM_SENDER")
	private String lqmSender;

	@Column(name="LQM_TO_CC")
	private String lqmToCc;

	@Column(name="LQM_VERSION")
	private BigDecimal lqmVersion;
	
	@Column(name="LQM_TAT")
	private BigDecimal lqmTat;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LQM_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomQueryMgmt() {
	}

	public String getLqmClosed() {
		return this.lqmClosed;
	}

	public void setLqmClosed(String lqmClosed) {
		this.lqmClosed = lqmClosed;
	}

	public Date getLqmClosedOn() {
		return this.lqmClosedOn;
	}

	public void setLqmClosedOn(Date lqmClosedOn) {
		this.lqmClosedOn = lqmClosedOn;
	}

	public String getLqmCranReq() {
		return this.lqmCranReq;
	}

	public void setLqmCranReq(String lqmCranReq) {
		this.lqmCranReq = lqmCranReq;
	}

	public String getLqmCreatedBy() {
		return this.lqmCreatedBy;
	}

	public void setLqmCreatedBy(String lqmCreatedBy) {
		this.lqmCreatedBy = lqmCreatedBy;
	}

	public Date getLqmCreatedOn() {
		return this.lqmCreatedOn;
	}

	public void setLqmCreatedOn(Date lqmCreatedOn) {
		this.lqmCreatedOn = lqmCreatedOn;
	}

	public String getLqmHighPriority() {
		return this.lqmHighPriority;
	}

	public void setLqmHighPriority(String lqmHighPriority) {
		this.lqmHighPriority = lqmHighPriority;
	}

	public String getLqmModifiedBy() {
		return this.lqmModifiedBy;
	}

	public void setLqmModifiedBy(String lqmModifiedBy) {
		this.lqmModifiedBy = lqmModifiedBy;
	}

	public Date getLqmModifiedOn() {
		return this.lqmModifiedOn;
	}

	public void setLqmModifiedOn(Date lqmModifiedOn) {
		this.lqmModifiedOn = lqmModifiedOn;
	}

	public String getLqmQuery() {
		return this.lqmQuery;
	}

	public void setLqmQuery(String lqmQuery) {
		this.lqmQuery = lqmQuery;
	}

	public String getLqmQueryId() {
		return this.lqmQueryId;
	}

	public void setLqmQueryId(String lqmQueryId) {
		this.lqmQueryId = lqmQueryId;
	}

	public String getLqmQuerySubj() {
		return this.lqmQuerySubj;
	}

	public void setLqmQuerySubj(String lqmQuerySubj) {
		this.lqmQuerySubj = lqmQuerySubj;
	}

	public String getLqmQueryType() {
		return this.lqmQueryType;
	}

	public void setLqmQueryType(String lqmQueryType) {
		this.lqmQueryType = lqmQueryType;
	}

	public String getLqmRecent() {
		return this.lqmRecent;
	}

	public void setLqmRecent(String lqmRecent) {
		this.lqmRecent = lqmRecent;
	}

	public String getLqmRecipient() {
		return this.lqmRecipient;
	}

	public void setLqmRecipient(String lqmRecipient) {
		this.lqmRecipient = lqmRecipient;
	}

	public String getLqmResponse() {
		return this.lqmResponse;
	}

	public void setLqmResponse(String lqmResponse) {
		this.lqmResponse = lqmResponse;
	}

	public BigDecimal getLqmRowId() {
		return this.lqmRowId;
	}

	public void setLqmRowId(BigDecimal lqmRowId) {
		this.lqmRowId = lqmRowId;
	}

	public String getLqmSender() {
		return this.lqmSender;
	}

	public void setLqmSender(String lqmSender) {
		this.lqmSender = lqmSender;
	}

	public String getLqmToCc() {
		return this.lqmToCc;
	}

	public void setLqmToCc(String lqmToCc) {
		this.lqmToCc = lqmToCc;
	}

	public BigDecimal getLqmVersion() {
		return this.lqmVersion;
	}

	public void setLqmVersion(BigDecimal lqmVersion) {
		this.lqmVersion = lqmVersion;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public BigDecimal getLqmTat() {
		return lqmTat;
	}

	public void setLqmTat(BigDecimal lqmTat) {
		this.lqmTat = lqmTat;
	}	

}