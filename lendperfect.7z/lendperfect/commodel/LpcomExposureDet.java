package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_EXPOSURE_DET database table.
 * 
 */
@Entity
@Table(name="LPCOM_EXPOSURE_DET")
@NamedQuery(name="LpcomExposureDet.findAll", query="SELECT l FROM LpcomExposureDet l")
public class LpcomExposureDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LED_AMOUNT")
	private BigDecimal ledAmount;

	@Column(name="LED_BCIF_NO")
	private String ledBcifNo;

	@Column(name="LED_CONSIDER_APPRVE")
	private String ledConsiderApprve;

	@Column(name="LED_CREATED_BY")
	private String ledCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LED_CREATED_ON")
	private Date ledCreatedOn;

	@Column(name="LED_CUST_ID")
	private BigDecimal ledCustId;

	@Column(name="LED_DIVISION")
	private String ledDivision;

	@Column(name="LED_DRAW_POWER")
	private BigDecimal ledDrawPower;

	@Column(name="LED_EXPOSURE")
	private BigDecimal ledExposure;

	@Column(name="LED_FAC_TYPE")
	private String ledFacType;

	@Column(name="LED_IRREGULARITIES")
	private String ledIrregularities;

	@Column(name="LED_KOTAK_GRP_NAME")
	private String ledKotakGrpName;

	@Temporal(TemporalType.DATE)
	@Column(name="LED_LIMIT_LOAD_DATE")
	private Date ledLimitLoadDate;

	@Column(name="LED_LIMIT_LOADED")
	private BigDecimal ledLimitLoaded;

	@Temporal(TemporalType.DATE)
	@Column(name="LED_MATURITY_DATE")
	private Date ledMaturityDate;

	@Column(name="LED_MODIFIED_BY")
	private String ledModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LED_MODIFIED_ON")
	private Date ledModifiedOn;

	@Column(name="LED_ORDER_NO")
	private BigDecimal ledOrderNo;

	@Temporal(TemporalType.DATE)
	@Column(name="LED_OS_DATE")
	private Date ledOsDate;

	@Column(name="LED_PRODUCT")
	private String ledProduct;

	@Column(name="LED_REMARKS")
	private String ledRemarks;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LED_ROW_ID")
	private BigDecimal ledRowId;

	@Column(name="LED_SANC_LIMIT")
	private BigDecimal ledSancLimit;

	@Column(name="LED_SEC_DET")
	private String ledSecDet;

	@Column(name="LED_SOURCE")
	private String ledSource;
	
	@Column(name="LED_APAC_NO")
	private String  ledApacNo; 
	
	@Column(name="LED_OS_AMT")
	private BigDecimal  ledOsAmt;
	
//	@Column(name="LED_MANUAL_ENTRY")
//	private String  ledManualEntry;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LED_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomExposureDet() {
	}

	public BigDecimal getLedAmount() {
		return this.ledAmount;
	}

	public void setLedAmount(BigDecimal ledAmount) {
		this.ledAmount = ledAmount;
	}

	public String getLedBcifNo() {
		return this.ledBcifNo;
	}

	public void setLedBcifNo(String ledBcifNo) {
		this.ledBcifNo = ledBcifNo;
	}

	public String getLedConsiderApprve() {
		return this.ledConsiderApprve;
	}

	public void setLedConsiderApprve(String ledConsiderApprve) {
		this.ledConsiderApprve = ledConsiderApprve;
	}

	public String getLedCreatedBy() {
		return this.ledCreatedBy;
	}

	public void setLedCreatedBy(String ledCreatedBy) {
		this.ledCreatedBy = ledCreatedBy;
	}

	public Date getLedCreatedOn() {
		return this.ledCreatedOn;
	}

	public void setLedCreatedOn(Date ledCreatedOn) {
		this.ledCreatedOn = ledCreatedOn;
	}

	public BigDecimal getLedCustId() {
		return this.ledCustId;
	}

	public void setLedCustId(BigDecimal ledCustId) {
		this.ledCustId = ledCustId;
	}

	public String getLedDivision() {
		return this.ledDivision;
	}

	public void setLedDivision(String ledDivision) {
		this.ledDivision = ledDivision;
	}

	public BigDecimal getLedDrawPower() {
		return this.ledDrawPower;
	}

	public void setLedDrawPower(BigDecimal ledDrawPower) {
		this.ledDrawPower = ledDrawPower;
	}

	public BigDecimal getLedExposure() {
		return this.ledExposure;
	}

	public void setLedExposure(BigDecimal ledExposure) {
		this.ledExposure = ledExposure;
	}

	public String getLedFacType() {
		return this.ledFacType;
	}

	public void setLedFacType(String ledFacType) {
		this.ledFacType = ledFacType;
	}

	public String getLedIrregularities() {
		return this.ledIrregularities;
	}

	public void setLedIrregularities(String ledIrregularities) {
		this.ledIrregularities = ledIrregularities;
	}

	public String getLedKotakGrpName() {
		return this.ledKotakGrpName;
	}

	public void setLedKotakGrpName(String ledKotakGrpName) {
		this.ledKotakGrpName = ledKotakGrpName;
	}

	public Date getLedLimitLoadDate() {
		return this.ledLimitLoadDate;
	}

	public void setLedLimitLoadDate(Date ledLimitLoadDate) {
		this.ledLimitLoadDate = ledLimitLoadDate;
	}

	public BigDecimal getLedLimitLoaded() {
		return this.ledLimitLoaded;
	}

	public void setLedLimitLoaded(BigDecimal ledLimitLoaded) {
		this.ledLimitLoaded = ledLimitLoaded;
	}

	public Date getLedMaturityDate() {
		return this.ledMaturityDate;
	}

	public void setLedMaturityDate(Date ledMaturityDate) {
		this.ledMaturityDate = ledMaturityDate;
	}

	public String getLedModifiedBy() {
		return this.ledModifiedBy;
	}

	public void setLedModifiedBy(String ledModifiedBy) {
		this.ledModifiedBy = ledModifiedBy;
	}

	public Date getLedModifiedOn() {
		return this.ledModifiedOn;
	}

	public void setLedModifiedOn(Date ledModifiedOn) {
		this.ledModifiedOn = ledModifiedOn;
	}

	public BigDecimal getLedOrderNo() {
		return this.ledOrderNo;
	}

	public void setLedOrderNo(BigDecimal ledOrderNo) {
		this.ledOrderNo = ledOrderNo;
	}

	public Date getLedOsDate() {
		return this.ledOsDate;
	}

	public void setLedOsDate(Date ledOsDate) {
		this.ledOsDate = ledOsDate;
	}

	public String getLedProduct() {
		return this.ledProduct;
	}

	public void setLedProduct(String ledProduct) {
		this.ledProduct = ledProduct;
	}

	public String getLedRemarks() {
		return this.ledRemarks;
	}

	public void setLedRemarks(String ledRemarks) {
		this.ledRemarks = ledRemarks;
	}

	public BigDecimal getLedRowId() {
		return this.ledRowId;
	}

	public void setLedRowId(BigDecimal ledRowId) {
		this.ledRowId = ledRowId;
	}

	public BigDecimal getLedSancLimit() {
		return this.ledSancLimit;
	}

	public void setLedSancLimit(BigDecimal ledSancLimit) {
		this.ledSancLimit = ledSancLimit;
	}

	public String getLedSecDet() {
		return this.ledSecDet;
	}

	public void setLedSecDet(String ledSecDet) {
		this.ledSecDet = ledSecDet;
	}

	public String getLedSource() {
		return this.ledSource;
	}

	public void setLedSource(String ledSource) {
		this.ledSource = ledSource;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}
	public String getLedApacNo() {
		return ledApacNo;
	}

	public void setLedApacNo(String ledApacNo) {
		this.ledApacNo = ledApacNo;
	}

	public BigDecimal getLedOsAmt() {
		return ledOsAmt;
	}

	public void setLedOsAmt(BigDecimal ledOsAmt) {
		this.ledOsAmt = ledOsAmt;
	}
	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}
	
//	public String getLedManualEntry() {
//		return ledManualEntry;
//	}
//
//	public void setLedManualEntry(String ledManualEntry) {
//		this.ledManualEntry = ledManualEntry;
//	}
}