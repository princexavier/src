package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_LIABILITIES database table.
 * 
 */
@Entity
@Table(name="LPCOM_LIABILITIES")
@NamedQuery(name="LpcomLiability.findAll", query="SELECT l FROM LpcomLiability l")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LpcomLiability implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LL_SNO")
	private long llSno;

	@Column(name="LL_ACCOUNTNO")
	private String llAccountno;

	@Column(name="LL_BALANCE")
	private BigDecimal llBalance;

	@Column(name="LL_BANK")
	private String llBank;

	@Column(name="LL_CRDLIMIT")
	private BigDecimal llCrdlimit;

	@Column(name="LL_CREATED_BY")
	private String llCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LL_CREATED_ON")
	private Date llCreatedOn;

	@Column(name="LL_LIABTYPE")
	private String llLiabtype;

	@Column(name="LL_MODIFIED_BY")
	private String llModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LL_MODIFIED_ON")
	private Date llModifiedOn;

	@Column(name="LL_OURBANK")
	private String llOurbank;

	@Column(name="LL_EMI")
	private BigDecimal llEmi;
	
	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LL_SANCDATE")
	private Date llSancdate;

	//bi-directional many-to-one association to LpcustApplicantData
	@ManyToOne
	@JsonIgnore
	@Fetch(FetchMode.SELECT)
	@JoinColumn(name="LL_APPID")
	private LpcustApplicantData lpcustApplicantData;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@Fetch(FetchMode.SELECT)
	@JoinColumn(name="LL_APPNO")
	private LpcomProposal lpcomProposal;

	public LpcomLiability() {
	}

	public long getLlSno() {
		return this.llSno;
	}

	public void setLlSno(long llSno) {
		this.llSno = llSno;
	}

	public String getLlAccountno() {
		return this.llAccountno;
	}

	public void setLlAccountno(String llAccountno) {
		this.llAccountno = llAccountno;
	}

	public BigDecimal getLlBalance() {
		return this.llBalance;
	}

	public void setLlBalance(BigDecimal llBalance) {
		this.llBalance = llBalance;
	}

	public String getLlBank() {
		return this.llBank;
	}

	public void setLlBank(String llBank) {
		this.llBank = llBank;
	}

	public BigDecimal getLlCrdlimit() {
		return this.llCrdlimit;
	}

	public void setLlCrdlimit(BigDecimal llCrdlimit) {
		this.llCrdlimit = llCrdlimit;
	}

	public String getLlCreatedBy() {
		return this.llCreatedBy;
	}

	public void setLlCreatedBy(String llCreatedBy) {
		this.llCreatedBy = llCreatedBy;
	}

	public Date getLlCreatedOn() {
		return this.llCreatedOn;
	}

	public void setLlCreatedOn(Date llCreatedOn) {
		this.llCreatedOn = llCreatedOn;
	}

	public String getLlLiabtype() {
		return this.llLiabtype;
	}

	public void setLlLiabtype(String llLiabtype) {
		this.llLiabtype = llLiabtype;
	}

	public String getLlModifiedBy() {
		return this.llModifiedBy;
	}

	public void setLlModifiedBy(String llModifiedBy) {
		this.llModifiedBy = llModifiedBy;
	}

	public Date getLlModifiedOn() {
		return this.llModifiedOn;
	}

	public void setLlModifiedOn(Date llModifiedOn) {
		this.llModifiedOn = llModifiedOn;
	}

	public String getLlOurbank() {
		return this.llOurbank;
	}

	public void setLlOurbank(String llOurbank) {
		this.llOurbank = llOurbank;
	}

	
	public Date getLlSancdate() {
		return this.llSancdate;
	}

	public void setLlSancdate(Date llSancdate) {
		this.llSancdate = llSancdate;
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return this.lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}
	

	public BigDecimal getLlEmi() {
		return llEmi;
	}

	public void setLlEmi(BigDecimal llEmi) {
		this.llEmi = llEmi;
	}

}