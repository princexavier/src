package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_OTHER_ASSETS_LIABILITY database table.
 * 
 */
@Entity
@Table(name="LPCOM_OTHER_ASSETS_LIABILITY")
@NamedQuery(name="LpcomOtherAssetsLiability.findAll", query="SELECT l FROM LpcomOtherAssetsLiability l")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LpcomOtherAssetsLiability implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LOAL_SNO")
	private long loalSno;

	@Column(name="LOAL_AMOUNT")
	private BigDecimal loalAmount;

	@Column(name="LOAL_CREATED_BY")
	private String loalCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LOAL_CREATED_ON")
	private Date loalCreatedOn;

	@Column(name="LOAL_DESC")
	private String loalDesc;

	@Column(name="LOAL_MODIFIED_BY")
	private String loalModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LOAL_MODIFIED_ON")
	private Date loalModifiedOn;

	@Column(name="LOAL_TYPE")
	private String loalType;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LOAL_PROP_NO")
	private LpcomProposal lpcomProposal;

	//bi-directional many-to-one association to LpcustApplicantData
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LOAL_APPID")
	private LpcustApplicantData lpcustApplicantData;

	public LpcomOtherAssetsLiability() {
	}

	public long getLoalSno() {
		return this.loalSno;
	}

	public void setLoalSno(long loalSno) {
		this.loalSno = loalSno;
	}

	public BigDecimal getLoalAmount() {
		return this.loalAmount;
	}

	public void setLoalAmount(BigDecimal loalAmount) {
		this.loalAmount = loalAmount;
	}

	public String getLoalCreatedBy() {
		return this.loalCreatedBy;
	}

	public void setLoalCreatedBy(String loalCreatedBy) {
		this.loalCreatedBy = loalCreatedBy;
	}

	public Date getLoalCreatedOn() {
		return this.loalCreatedOn;
	}

	public void setLoalCreatedOn(Date loalCreatedOn) {
		this.loalCreatedOn = loalCreatedOn;
	}

	public String getLoalDesc() {
		return this.loalDesc;
	}

	public void setLoalDesc(String loalDesc) {
		this.loalDesc = loalDesc;
	}

	public String getLoalModifiedBy() {
		return this.loalModifiedBy;
	}

	public void setLoalModifiedBy(String loalModifiedBy) {
		this.loalModifiedBy = loalModifiedBy;
	}

	public Date getLoalModifiedOn() {
		return this.loalModifiedOn;
	}

	public void setLoalModifiedOn(Date loalModifiedOn) {
		this.loalModifiedOn = loalModifiedOn;
	}

	public String getLoalType() {
		return this.loalType;
	}

	public void setLoalType(String loalType) {
		this.loalType = loalType;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return this.lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}

}