package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_PREV_SANCTION database table.
 * 
 */
@Entity
@Table(name="LPCOM_PREV_SANCTION")
@NamedQuery(name="LpcomPrevSanction.findAll", query="SELECT l FROM LpcomPrevSanction l")
public class LpcomPrevSanction implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPS_APP_AUTH_LEVEL")
	private String lpsAppAuthLevel;

	@Column(name="LPS_CREATED_BY")
	private String lpsCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPS_CREATED_ON")
	private Date lpsCreatedOn;

	@Temporal(TemporalType.DATE)
	@Column(name="LPS_DATE_OF_SANCTION")
	private Date lpsDateOfSanction;

	@Column(name="LPS_MODIFIED_BY")
	private String lpsModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPS_MODIFIED_ON")
	private Date lpsModifiedOn;

	@Column(name="LPS_NATURE_OF_PROP")
	private String lpsNatureOfProp;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPS_ROW_ID")
	private BigDecimal lpsRowId;

	@Column(name="LPS_TOT_AMT")
	private BigDecimal lpsTotAmt;
	
	@Column(name="LPS_ORDER_NO")
	private BigDecimal lpsOrderNo;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LPS_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomPrevSanction() {
	}

	public String getLpsAppAuthLevel() {
		return this.lpsAppAuthLevel;
	}

	public void setLpsAppAuthLevel(String lpsAppAuthLevel) {
		this.lpsAppAuthLevel = lpsAppAuthLevel;
	}

	public String getLpsCreatedBy() {
		return this.lpsCreatedBy;
	}

	public void setLpsCreatedBy(String lpsCreatedBy) {
		this.lpsCreatedBy = lpsCreatedBy;
	}

	public Date getLpsCreatedOn() {
		return this.lpsCreatedOn;
	}

	public void setLpsCreatedOn(Date lpsCreatedOn) {
		this.lpsCreatedOn = lpsCreatedOn;
	}

	public Date getLpsDateOfSanction() {
		return this.lpsDateOfSanction;
	}

	public void setLpsDateOfSanction(Date lpsDateOfSanction) {
		this.lpsDateOfSanction = lpsDateOfSanction;
	}

	public String getLpsModifiedBy() {
		return this.lpsModifiedBy;
	}

	public void setLpsModifiedBy(String lpsModifiedBy) {
		this.lpsModifiedBy = lpsModifiedBy;
	}

	public Date getLpsModifiedOn() {
		return this.lpsModifiedOn;
	}

	public void setLpsModifiedOn(Date lpsModifiedOn) {
		this.lpsModifiedOn = lpsModifiedOn;
	}

	public String getLpsNatureOfProp() {
		return this.lpsNatureOfProp;
	}

	public void setLpsNatureOfProp(String lpsNatureOfProp) {
		this.lpsNatureOfProp = lpsNatureOfProp;
	}

	public BigDecimal getLpsRowId() {
		return this.lpsRowId;
	}

	public void setLpsRowId(BigDecimal lpsRowId) {
		this.lpsRowId = lpsRowId;
	}

	public BigDecimal getLpsTotAmt() {
		return this.lpsTotAmt;
	}

	public void setLpsTotAmt(BigDecimal lpsTotAmt) {
		this.lpsTotAmt = lpsTotAmt;
	}
	

	public BigDecimal getLpsOrderNo() {
		return this.lpsOrderNo;
	}

	public void setLpsOrderNo(BigDecimal lpsOrderNo) {
		this.lpsOrderNo = lpsOrderNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}