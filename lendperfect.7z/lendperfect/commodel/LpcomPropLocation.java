package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_PROP_LOCATION database table.
 * 
 */
@Entity
@Table(name="LPCOM_PROP_LOCATION")
@NamedQuery(name="LpcomPropLocation.findAll", query="SELECT l FROM LpcomPropLocation l")
public class LpcomPropLocation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPL_CREATED_BY")
	private String lplCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPL_CREATED_ON")
	private Date lplCreatedOn;

	@Column(name="LPL_DEPARTMENT")
	private String lplDepartment;

	@Column(name="LPL_LEVEL_1")
	private BigDecimal lplLevel1;

	@Column(name="LPL_LEVEL_2")
	private BigDecimal lplLevel2;

	@Column(name="LPL_LEVEL_3")
	private BigDecimal lplLevel3;

	@Column(name="LPL_LEVEL_4")
	private BigDecimal lplLevel4;

	@Column(name="LPL_LEVEL_5")
	private BigDecimal lplLevel5;

	@Column(name="LPL_LEVEL_6")
	private BigDecimal lplLevel6;

	@Column(name="LPL_LEVEL_7")
	private BigDecimal lplLevel7;

	@Column(name="LPL_LEVEL_8")
	private BigDecimal lplLevel8;

	@Column(name="LPL_MODIFIED_BY")
	private String lplModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPL_MODIFIED_ON")
	private Date lplModifiedOn;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPL_ROW_ID")
	private BigDecimal lplRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LPL_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomPropLocation() {
	}

	public String getLplCreatedBy() {
		return this.lplCreatedBy;
	}

	public void setLplCreatedBy(String lplCreatedBy) {
		this.lplCreatedBy = lplCreatedBy;
	}

	public Date getLplCreatedOn() {
		return this.lplCreatedOn;
	}

	public void setLplCreatedOn(Date lplCreatedOn) {
		this.lplCreatedOn = lplCreatedOn;
	}

	public String getLplDepartment() {
		return this.lplDepartment;
	}

	public void setLplDepartment(String lplDepartment) {
		this.lplDepartment = lplDepartment;
	}

	public BigDecimal getLplLevel1() {
		return this.lplLevel1;
	}

	public void setLplLevel1(BigDecimal lplLevel1) {
		this.lplLevel1 = lplLevel1;
	}

	public BigDecimal getLplLevel2() {
		return this.lplLevel2;
	}

	public void setLplLevel2(BigDecimal lplLevel2) {
		this.lplLevel2 = lplLevel2;
	}

	public BigDecimal getLplLevel3() {
		return this.lplLevel3;
	}

	public void setLplLevel3(BigDecimal lplLevel3) {
		this.lplLevel3 = lplLevel3;
	}

	public BigDecimal getLplLevel4() {
		return this.lplLevel4;
	}

	public void setLplLevel4(BigDecimal lplLevel4) {
		this.lplLevel4 = lplLevel4;
	}

	public BigDecimal getLplLevel5() {
		return this.lplLevel5;
	}

	public void setLplLevel5(BigDecimal lplLevel5) {
		this.lplLevel5 = lplLevel5;
	}

	public BigDecimal getLplLevel6() {
		return this.lplLevel6;
	}

	public void setLplLevel6(BigDecimal lplLevel6) {
		this.lplLevel6 = lplLevel6;
	}

	public BigDecimal getLplLevel7() {
		return this.lplLevel7;
	}

	public void setLplLevel7(BigDecimal lplLevel7) {
		this.lplLevel7 = lplLevel7;
	}

	public BigDecimal getLplLevel8() {
		return this.lplLevel8;
	}

	public void setLplLevel8(BigDecimal lplLevel8) {
		this.lplLevel8 = lplLevel8;
	}

	public String getLplModifiedBy() {
		return this.lplModifiedBy;
	}

	public void setLplModifiedBy(String lplModifiedBy) {
		this.lplModifiedBy = lplModifiedBy;
	}

	public Date getLplModifiedOn() {
		return this.lplModifiedOn;
	}

	public void setLplModifiedOn(Date lplModifiedOn) {
		this.lplModifiedOn = lplModifiedOn;
	}

	public BigDecimal getLplRowId() {
		return this.lplRowId;
	}

	public void setLplRowId(BigDecimal lplRowId) {
		this.lplRowId = lplRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}