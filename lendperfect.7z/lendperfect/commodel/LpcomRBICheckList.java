package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_RBI_CHECKLIST database table.
 * 
 */
@Entity
@Table(name="LPCOM_RBI_CHECKLIST")
@NamedQuery(name="LpcomRBICheckList.findAll", query="SELECT l FROM LpcomRBICheckList l")
public class LpcomRBICheckList implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LRC_CHKLIST_DESC")
	private String lrcChklistDesc;

	@Column(name="LRC_CHKLIST_ID")
	private BigDecimal lrcChklistId;

	@Column(name="LRC_COMPLIANCE")
	private String lrcCompliance;

	@Column(name="LRC_CREATED_BY")
	private String lrcCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LRC_CREATED_ON")
	private Date lrcCreatedOn;

	@Column(name="LRC_MODIFIED_BY")
	private String lrcModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LRC_MODIFIED_ON")
	private Date lrcModifiedOn;

	@Column(name="LRC_ORDER_NO")
	private BigDecimal lrcOrderNo;

	@Column(name="LRC_PARENT_ID")
	private BigDecimal lrcParentId;

	@Column(name="LRC_REMARKS")
	private String lrcRemarks;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LRC_ROW_ID")
	private BigDecimal lrcRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LRC_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomRBICheckList() {
	}

	public String getLrcChklistDesc() {
		return this.lrcChklistDesc;
	}

	public void setLrcChklistDesc(String lrcChklistDesc) {
		this.lrcChklistDesc = lrcChklistDesc;
	}

	public BigDecimal getLrcChklistId() {
		return this.lrcChklistId;
	}

	public void setLrcChklistId(BigDecimal lrcChklistId) {
		this.lrcChklistId = lrcChklistId;
	}

	public String getLrcCompliance() {
		return this.lrcCompliance;
	}

	public void setLrcCompliance(String lrcCompliance) {
		this.lrcCompliance = lrcCompliance;
	}

	public String getLrcCreatedBy() {
		return this.lrcCreatedBy;
	}

	public void setLrcCreatedBy(String lrcCreatedBy) {
		this.lrcCreatedBy = lrcCreatedBy;
	}

	public Date getLrcCreatedOn() {
		return this.lrcCreatedOn;
	}

	public void setLrcCreatedOn(Date lrcCreatedOn) {
		this.lrcCreatedOn = lrcCreatedOn;
	}

	public String getLrcModifiedBy() {
		return this.lrcModifiedBy;
	}

	public void setLrcModifiedBy(String lrcModifiedBy) {
		this.lrcModifiedBy = lrcModifiedBy;
	}

	public Date getLrcModifiedOn() {
		return this.lrcModifiedOn;
	}

	public void setLrcModifiedOn(Date lrcModifiedOn) {
		this.lrcModifiedOn = lrcModifiedOn;
	}

	public BigDecimal getLrcOrderNo() {
		return this.lrcOrderNo;
	}

	public void setLrcOrderNo(BigDecimal lrcOrderNo) {
		this.lrcOrderNo = lrcOrderNo;
	}

	public BigDecimal getLrcParentId() {
		return this.lrcParentId;
	}

	public void setLrcParentId(BigDecimal lrcParentId) {
		this.lrcParentId = lrcParentId;
	}

	public String getLrcRemarks() {
		return this.lrcRemarks;
	}

	public void setLrcRemarks(String lrcRemarks) {
		this.lrcRemarks = lrcRemarks;
	}

	public BigDecimal getLrcRowId() {
		return this.lrcRowId;
	}

	public void setLrcRowId(BigDecimal lrcRowId) {
		this.lrcRowId = lrcRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}