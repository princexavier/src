package com.sai.lendperfect.commodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_PARTIES_RELATIONSHIP database table.
 * 
 */
@Entity
@Table(name="LPCOM_PARTIES_RELATIONSHIP")
@NamedQuery(name="LpcomPartiesRelationship.findAll", query="SELECT l FROM LpcomPartiesRelationship l")
public class LpcomPartiesRelationship implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPR_CREATED_BY")
	private String lprCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPR_CREATED_ON")
	private Date lprCreatedOn;

	@Column(name="LPR_CUST_ID")
	private BigDecimal lprCustId;

	@Column(name="LPR_MODIFIED_BY")
	private String lprModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPR_MODIFIED_ON")
	private Date lprModifiedOn;

	@Column(name="LPR_REL_CUST_ID")
	private BigDecimal lprRelCustId;

	@Column(name="LPR_REL_TYPE")
	private String lprRelType;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPR_ROW_ID")
	private BigDecimal lprRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LPR_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomPartiesRelationship() {
	}

	public String getLprCreatedBy() {
		return this.lprCreatedBy;
	}

	public void setLprCreatedBy(String lprCreatedBy) {
		this.lprCreatedBy = lprCreatedBy;
	}

	public Date getLprCreatedOn() {
		return this.lprCreatedOn;
	}

	public void setLprCreatedOn(Date lprCreatedOn) {
		this.lprCreatedOn = lprCreatedOn;
	}

	public BigDecimal getLprCustId() {
		return this.lprCustId;
	}

	public void setLprCustId(BigDecimal lprCustId) {
		this.lprCustId = lprCustId;
	}

	public String getLprModifiedBy() {
		return this.lprModifiedBy;
	}

	public void setLprModifiedBy(String lprModifiedBy) {
		this.lprModifiedBy = lprModifiedBy;
	}

	public Date getLprModifiedOn() {
		return this.lprModifiedOn;
	}

	public void setLprModifiedOn(Date lprModifiedOn) {
		this.lprModifiedOn = lprModifiedOn;
	}

	public BigDecimal getLprRelCustId() {
		return this.lprRelCustId;
	}

	public void setLprRelCustId(BigDecimal lprRelCustId) {
		this.lprRelCustId = lprRelCustId;
	}

	public String getLprRelType() {
		return this.lprRelType;
	}

	public void setLprRelType(String lprRelType) {
		this.lprRelType = lprRelType;
	}

	public BigDecimal getLprRowId() {
		return this.lprRowId;
	}

	public void setLprRowId(BigDecimal lprRowId) {
		this.lprRowId = lprRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}