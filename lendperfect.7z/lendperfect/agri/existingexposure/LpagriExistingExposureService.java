package com.sai.lendperfect.agri.existingexposure;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.agrimodel.LpagriExistingExposure;

public interface LpagriExistingExposureService {
	List<LpagriExistingExposure> saveLpagriExistingExposure(List<LpagriExistingExposure> LpagriExistingExposure);
	List<LpagriExistingExposure> findAll();
	void deleteLpagriExistingExposure(LpagriExistingExposure LpagriExistingExposure);
	LpagriExistingExposure findByLpexRowId(BigDecimal afdRowId);
	LpagriExistingExposure updateLpagriExistingExposure(LpagriExistingExposure LpagriExistingExposure);
	void deleteAllByLpexPropNoAndLpexLoanFor(BigDecimal lpexPropNo,String LpexLoanFor);
	List<LpagriExistingExposure> findByLpexLoanFor(String lpexLoanFor);
	LpagriExistingExposure findByLpexLoanForAndLpexPropNoAndLpexSeqNum(String lpexLoanFor, BigDecimal lpexPropNo,BigDecimal lpexSeqNum);
	List<LpagriExistingExposure> findByLpexPropNo(BigDecimal lpexPropNo);
	
	
	
}
