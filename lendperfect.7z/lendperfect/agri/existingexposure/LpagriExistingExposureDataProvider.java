package com.sai.lendperfect.agri.existingexposure;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.agrimodel.LpagriExistingExposure;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomCustInfo;
import com.sai.lendperfect.commodel.LpcomSetBorrMap;



public class LpagriExistingExposureDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
				
		try {
			
			
			if (dpMethod.equals("saveExistingExposure")) {
				try {
					
					String tableName= "LPCOM_EXISTING_EXPOSURE";
					String seqId = "LPEX_SEQ_NUM";
					String propId = "LPEX_PROP_NO";
					//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
					BigDecimal proposalNo=new BigDecimal(20);
					BigDecimal seq=serviceProvider.getSequenceNoService().findMax(tableName, seqId, propId, proposalNo);
					
					List<LpagriExistingExposure> LpagriExistingExposureList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriExistingExposure>>() {});
					Iterator LpagriExistingExposureListItr = LpagriExistingExposureList.iterator();
					while(LpagriExistingExposureListItr.hasNext())
					{
						LpagriExistingExposure LpagriExistingExposure = (LpagriExistingExposure) LpagriExistingExposureListItr.next();
						if(LpagriExistingExposure.getLpexSeqNum() == null)
						{
							seq=seq.add(new BigDecimal(1));
							LpagriExistingExposure.setLpexSeqNum(seq);	
							LpagriExistingExposure.setLpexPropNo(proposalNo);
							LpagriExistingExposure.setLpexOurBank("Y");
							LpagriExistingExposure.setLpCreatedBy("sai");
							LpagriExistingExposure.setLpCreatedOn(Helper.getSystemDate());
							LpagriExistingExposure.setLpModifiedBy("sai");
							LpagriExistingExposure.setLpModifiedOn(Helper.getSystemDate());
										
						}
						else{
							LpagriExistingExposure.setLpModifiedBy("Nive");
							LpagriExistingExposure.setLpModifiedOn(Helper.getSystemDate());
						}
					}
					serviceProvider.getLpagriExistingExposureService().saveLpagriExistingExposure(LpagriExistingExposureList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", LpagriExistingExposureList);

				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} 
			
			
			else if (dpMethod.equals("getExistingExposure")) {
				try {
					
				//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());lpexPropNo
					BigDecimal lpexPropNo=new BigDecimal(20);
					
					List<Map<String,Object>> LpagriExistingExposureMapList=new ArrayList<Map<String,Object>>();
					Map<String,Object> LpagriExistingExposureMap=new HashMap<String,Object>();
					List<LpcomSetBorrMap> LpcomSetBorrMapListBorw=new ArrayList<LpcomSetBorrMap>();
					List<LpagriExistingExposure> LpagriExistingExposureList=serviceProvider.getLpagriExistingExposureService().findByLpexPropNo(lpexPropNo);
									 
			 LpcomSetBorrMapListBorw=serviceProvider.getListOfValuesService().getPrimaryApplicant("B", lpexPropNo);
			 if(!LpcomSetBorrMapListBorw.isEmpty())
					   {	
						Iterator LpcomSetBorrMapItr=LpcomSetBorrMapListBorw.iterator();
						while(LpcomSetBorrMapItr.hasNext())
						{   
							LpcomSetBorrMap LpcomSetBorrMap=(LpcomSetBorrMap) LpcomSetBorrMapItr.next();
							LpcomCustInfo LpcomCustInfo=serviceProvider.getLpcomCustInfoService().findByLciCustIdAndLciRecent(LpcomSetBorrMap.getLfbmCustId(), "Y");//Recent flag  Y
							   if(LpcomCustInfo!=null)
							    {   							    	
							    	LpagriExistingExposureMap=new HashMap<String,Object>();
							    	LpagriExistingExposureMap.put("custName", LpcomCustInfo.getLciCustName());
							    	LpagriExistingExposureMap.put("custId",LpcomCustInfo.getLciCustId());
							    	LpagriExistingExposureMapList.add(LpagriExistingExposureMap);
							    }
						}
					}
						
			LpcomSetBorrMapListBorw=serviceProvider.getListOfValuesService().getPrimaryApplicant("C", lpexPropNo);
			 if(!LpcomSetBorrMapListBorw.isEmpty())
			   {	
				Iterator LpcomSetBorrMapItr=LpcomSetBorrMapListBorw.iterator();
				while(LpcomSetBorrMapItr.hasNext())
				{   
					LpcomSetBorrMap LpcomSetBorrMap=(LpcomSetBorrMap) LpcomSetBorrMapItr.next();
					LpcomCustInfo LpcomCustInfo=serviceProvider.getLpcomCustInfoService().findByLciCustIdAndLciRecent(LpcomSetBorrMap.getLfbmCustId(), "Y");//Recent flag  Y
					   if(LpcomCustInfo!=null)
					    {   							    	
					    	LpagriExistingExposureMap=new HashMap<String,Object>();
					    	LpagriExistingExposureMap.put("custName", LpcomCustInfo.getLciCustName());
					    	LpagriExistingExposureMap.put("custId",LpcomCustInfo.getLciCustId());
					    	LpagriExistingExposureMapList.add(LpagriExistingExposureMap);
					    }
				}
			}
									
					LpcomSetBorrMapListBorw=serviceProvider.getListOfValuesService().getPrimaryApplicant("G", lpexPropNo);
					 if(!LpcomSetBorrMapListBorw.isEmpty())
					   {	
						Iterator LpcomSetBorrMapItr=LpcomSetBorrMapListBorw.iterator();
						while(LpcomSetBorrMapItr.hasNext())
						{   
							LpcomSetBorrMap LpcomSetBorrMap=(LpcomSetBorrMap) LpcomSetBorrMapItr.next();
							LpcomCustInfo LpcomCustInfo=serviceProvider.getLpcomCustInfoService().findByLciCustIdAndLciRecent(LpcomSetBorrMap.getLfbmCustId(), "Y");//Recent flag  Y
							   if(LpcomCustInfo!=null)
							    {   							    	
							    	LpagriExistingExposureMap=new HashMap<String,Object>();
							    	LpagriExistingExposureMap.put("custName", LpcomCustInfo.getLciCustName());
							    	LpagriExistingExposureMap.put("custId",LpcomCustInfo.getLciCustId());
							    	LpagriExistingExposureMapList.add(LpagriExistingExposureMap);
							    }
						}
					}						
				
									
					responseHashMap.put("existingExposureList",LpagriExistingExposureList);
					responseHashMap.put("loanAvailableBy",LpagriExistingExposureMapList);
					responseHashMap.put("success", true);
					
					
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			
			
			else if (dpMethod.equals("deleteExistingExposure")) {
				try {
					LpagriExistingExposure LpagriExistingExposure=null;
					final LpagriExistingExposure LpagriExistingExposure2 = new ObjectMapper().convertValue(allRequestParams.get("requestData"), LpagriExistingExposure.class);
					LpagriExistingExposure=serviceProvider.getLpagriExistingExposureService().findByLpexLoanForAndLpexPropNoAndLpexSeqNum(LpagriExistingExposure2.getLpexLoanFor(),LpagriExistingExposure2.getLpexPropNo(),LpagriExistingExposure2.getLpexSeqNum());
					serviceProvider.getLpagriExistingExposureService().deleteLpagriExistingExposure(LpagriExistingExposure);
					responseHashMap.put("success", true);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			
			
			else if (dpMethod.equals("deleteAllExistingExposure")) {
				try {
					LpagriExistingExposure LpagriExistingExposure=	null;
					List<LpagriExistingExposure> LpagriExistingExposureList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriExistingExposure>>() {});
					Iterator LpagriExistingExposureListItr=LpagriExistingExposureList.iterator();
					if(LpagriExistingExposureListItr.hasNext())
						 LpagriExistingExposure=(LpagriExistingExposure)LpagriExistingExposureListItr.next();
					BigDecimal LpexPropNo=LpagriExistingExposure.getLpexPropNo(); 
					String lpexLoanFor=String.valueOf(allRequestParams.get("id"));
				serviceProvider.getLpagriExistingExposureService().deleteAllByLpexPropNoAndLpexLoanFor(LpexPropNo,lpexLoanFor);
					responseHashMap.put("success", true);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			
			else {
				dataHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
			
		}
		
		catch (Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}
		return responseHashMap;
	}
}
