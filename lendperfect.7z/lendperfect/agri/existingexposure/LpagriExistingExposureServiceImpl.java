package com.sai.lendperfect.agri.existingexposure;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.agrimodel.LpagriExistingExposure;
import com.sai.lendperfect.agrirepo.LpagriExistingExposureRepo;

@Service("lpagriExistingExposureService")
@Transactional
public class LpagriExistingExposureServiceImpl implements LpagriExistingExposureService{
	
	@Autowired
	private LpagriExistingExposureRepo  lpagriExistingExposureRepo;
	
	public List<LpagriExistingExposure> saveLpagriExistingExposure(List<LpagriExistingExposure> LpagriExistingExposure) {
		return lpagriExistingExposureRepo.save(LpagriExistingExposure);
	}

	public List<LpagriExistingExposure> findAll() {
		return lpagriExistingExposureRepo.findAll();
	}

	public void deleteLpagriExistingExposure(LpagriExistingExposure LpagriExistingExposure) {
		lpagriExistingExposureRepo.delete(LpagriExistingExposure);
	}
	
	public LpagriExistingExposure findByLpexRowId(BigDecimal lpexRowId) {
		return lpagriExistingExposureRepo.findOne(lpexRowId);
	}

	public LpagriExistingExposure updateLpagriExistingExposure(LpagriExistingExposure LpagriExistingExposure) {
		return lpagriExistingExposureRepo.save(LpagriExistingExposure);
	}

	public LpagriExistingExposure findByLpexLoanForAndLpexPropNoAndLpexSeqNum(String lpexLoanFor,BigDecimal lpexPropNo, BigDecimal lpexSeqNum) {
		return lpagriExistingExposureRepo.findByLpexLoanForAndLpexPropNoAndLpexSeqNum(lpexLoanFor, lpexPropNo, lpexSeqNum);
	}

	public void deleteAll() {
		lpagriExistingExposureRepo.deleteAll();
	}

	public List<LpagriExistingExposure> findByLpexLoanFor(String lpexLoanFor) {
		return lpagriExistingExposureRepo.findByLpexLoanFor(lpexLoanFor);
	}

	@Override
	public List<LpagriExistingExposure> findByLpexPropNo(BigDecimal lpexPropNo) {
		
		return (List<LpagriExistingExposure>) lpagriExistingExposureRepo.findByLpexPropNo(lpexPropNo);
	}

	@Override
	public void deleteAllByLpexPropNoAndLpexLoanFor(BigDecimal lpexPropNo, String LpexLoanFor) {
		lpagriExistingExposureRepo.deleteAllByLpexPropNoAndLpexLoanFor(lpexPropNo, LpexLoanFor);
		
	}
}
