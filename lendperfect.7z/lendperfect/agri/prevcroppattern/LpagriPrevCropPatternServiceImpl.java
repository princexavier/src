package com.sai.lendperfect.agri.prevcroppattern;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.agrimodel.LpagriPrevCropPattern;
import com.sai.lendperfect.agrirepo.LpagriPrevCropPatternRepo;

@Service("lpagriPrevCropPatternService")
@Transactional
public class LpagriPrevCropPatternServiceImpl implements  LpagriPrevCropPatternService {
	
	@Autowired
	LpagriPrevCropPatternRepo lpagriPrevCropPatternRepo;
	
	public List<LpagriPrevCropPattern> findAll() {
		return lpagriPrevCropPatternRepo.findAll();
	}
	

	public List<LpagriPrevCropPattern> saveLpagriPrevCropPattern(List<LpagriPrevCropPattern> prevCropPatternList) {
		 return lpagriPrevCropPatternRepo.save(prevCropPatternList);
	}

	public LpagriPrevCropPattern findBylpcpRowId(BigDecimal lpcpRowId) {
		return lpagriPrevCropPatternRepo.findBylpcpRowId(lpcpRowId);
		
	}

	public void deleteLpagriPrevCropPattern(LpagriPrevCropPattern lpagriPrevCropPattern) {
		 lpagriPrevCropPatternRepo.delete(lpagriPrevCropPattern);
		
	}
	
	public LpagriPrevCropPattern saveLpagriPrevCropPatternTest(LpagriPrevCropPattern list) {
		 return lpagriPrevCropPatternRepo.save(list);
	}


	@Override
	public LpagriPrevCropPattern findByLpcpOrderNoAndLpcpPropNo(BigDecimal lpcpOrderNo, BigDecimal lpcpPropNo) {
	
		return lpagriPrevCropPatternRepo.findByLpcpOrderNoAndLpcpPropNo(lpcpOrderNo,lpcpPropNo);
	}


	@Override
	public List<LpagriPrevCropPattern> findByLpcpPropNo(BigDecimal lpcpPropNo) {
		
		return (List<LpagriPrevCropPattern>)lpagriPrevCropPatternRepo.findByLpcpPropNo(lpcpPropNo);
	}


	@Override
	public void deleteAllByLpcpPropNo(BigDecimal lpcpPropNo) {
		lpagriPrevCropPatternRepo.deleteAllByLpcpPropNo(lpcpPropNo);
		
	}


}
