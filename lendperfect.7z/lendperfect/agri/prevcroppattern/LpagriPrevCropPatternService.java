package com.sai.lendperfect.agri.prevcroppattern;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.agrimodel.LpagriPrevCropPattern;

public interface LpagriPrevCropPatternService {

List <LpagriPrevCropPattern> findAll();

List  <LpagriPrevCropPattern> saveLpagriPrevCropPattern(List<LpagriPrevCropPattern> prevCropPatternList);

LpagriPrevCropPattern findBylpcpRowId(BigDecimal lpcpRowId);

void deleteLpagriPrevCropPattern(LpagriPrevCropPattern lpagriPrevCropPattern);

void deleteAllByLpcpPropNo(BigDecimal lpcpPropNo);

LpagriPrevCropPattern saveLpagriPrevCropPatternTest(LpagriPrevCropPattern list);

LpagriPrevCropPattern findByLpcpOrderNoAndLpcpPropNo(BigDecimal lpcpOrderNo, BigDecimal lpcpPropNo);

List<LpagriPrevCropPattern> findByLpcpPropNo(BigDecimal lpcpPropNo);


}
