package com.sai.lendperfect.agri.prevcroppattern;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.agrimodel.LpagriExistingExposure;
import com.sai.lendperfect.agrimodel.LpagriPrevCropPattern;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;

public class PrevCropPatternProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map <String,Object> responseHashMap=new HashMap<String,Object>();
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		
		
		try
		{
		if(dpMethod.equals("savePrevCropPattern"))
		{
						
			String tablename="LPAGRI_PREV_CROP_PATTERN";
			String seqid="LPCP_ORDER_NO";
			String propid="LPCP_PROP_NO";
			//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
			BigDecimal proposalNo=new BigDecimal(29);
			BigDecimal seqId=serviceProvider.getSequenceNoService().findMax(tablename, seqid, propid, proposalNo);
			List<LpagriPrevCropPattern> prevCropPatternList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriPrevCropPattern>>() { });
			Iterator prevCropPatternListItr=prevCropPatternList.iterator();
			
			while(prevCropPatternListItr.hasNext())
			{
				LpagriPrevCropPattern lpagriPrevCropPattern1=(LpagriPrevCropPattern) prevCropPatternListItr.next();
				if(lpagriPrevCropPattern1.getLpcpOrderNo()==null)
				{
				 seqId=seqId.add(new BigDecimal(1));
				lpagriPrevCropPattern1.setLpcpOrderNo(seqId);
				lpagriPrevCropPattern1.setLpcpPropNo(proposalNo);
				lpagriPrevCropPattern1.setLpCreatedBy("Sai");
				lpagriPrevCropPattern1.setLpCreatedOn(Helper.getSystemDate());
				lpagriPrevCropPattern1.setLpModifiedBy("Sai");
				lpagriPrevCropPattern1.setLpModifiedOn(Helper.getSystemDate());
				}
				else
				{
					lpagriPrevCropPattern1.setLpModifiedBy("Nive");
					lpagriPrevCropPattern1.setLpModifiedOn(Helper.getSystemDate());
				}
				
				
			}
			serviceProvider.getLpagriPrevCropPatternService().saveLpagriPrevCropPattern(prevCropPatternList);	
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", prevCropPatternList);
		}
		
		
		else if(dpMethod.equals("getPrevCropPattern")){
			//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
			BigDecimal proposalNo=new BigDecimal(29);
			List<LpagriPrevCropPattern> lpagriPrevCropPattern=serviceProvider.getLpagriPrevCropPatternService().findByLpcpPropNo(proposalNo);
			dataHashMap.put("reqDueDataList",lpagriPrevCropPattern);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
			
		}
		
		
		else if(dpMethod.equals("deletePrevCropPattern")){
			LpagriPrevCropPattern lpagriPrevCropPatternobj=new LpagriPrevCropPattern();
			lpagriPrevCropPatternobj=new ObjectMapper().convertValue(allRequestParams.get("requestData"), LpagriPrevCropPattern.class);
			LpagriPrevCropPattern lpagriPrevCropPattern=serviceProvider.getLpagriPrevCropPatternService().findByLpcpOrderNoAndLpcpPropNo(lpagriPrevCropPatternobj.getLpcpOrderNo(),lpagriPrevCropPatternobj.getLpcpPropNo());
			serviceProvider.getLpagriPrevCropPatternService().deleteLpagriPrevCropPattern(lpagriPrevCropPattern);
			responseHashMap.put("success", true);
		}
		
		
		else if(dpMethod.equals("deleteAllExistingcroppattern")){
			
			LpagriPrevCropPattern LpagriPrevCropPattern=null;
			List<LpagriPrevCropPattern> LpagriPrevCropPatternList= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriPrevCropPattern>>() {});
			Iterator LpagriPrevCropPatternItr=LpagriPrevCropPatternList.iterator();
			if(LpagriPrevCropPatternItr.hasNext())
			LpagriPrevCropPattern=(LpagriPrevCropPattern)LpagriPrevCropPatternItr.next();
			serviceProvider.getLpagriPrevCropPatternService().deleteAllByLpcpPropNo(LpagriPrevCropPattern.getLpcpPropNo());
			responseHashMap.put("success", true);
		}
		
		
		else
		{
			
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		}
		
		catch (Exception ex) {
			dataHashMap.put("errorData", ex.getLocalizedMessage());
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		
	}
		return responseHashMap;
	}
	
}


