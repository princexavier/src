package com.sai.lendperfect.agri.curryearcroppattern;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.agrimodel.LpagriCurrCropPattern;


public interface LpagriCurrCropPatternService {
	List<LpagriCurrCropPattern> saveLpagriCurrCropPattern(List<LpagriCurrCropPattern> lpagriCurrCropPattern);
	List<LpagriCurrCropPattern> findAll();
	LpagriCurrCropPattern findByLpcpPropNoAndLpcpOrderNo(BigDecimal lpcpPropNo,BigDecimal LpcpOrderNo);
	void deleteLpagriCurrCropPattern(LpagriCurrCropPattern lpagriCurrCropPattern);
	void deleteAll();
	List<LpagriCurrCropPattern> findByLpcpPropNo(BigDecimal lpcpPropNo);
	void deleteAllByLpcpPropNo(BigDecimal lpcpPropNo);
}
