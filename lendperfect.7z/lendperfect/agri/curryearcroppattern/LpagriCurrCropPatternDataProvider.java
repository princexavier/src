package com.sai.lendperfect.agri.curryearcroppattern;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.agrimodel.LpagriCurrCropPattern;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

public class LpagriCurrCropPatternDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
	
		try {
			
			
			if (dpMethod.equals("saveAgriCurYearCropPattern")) {
				try {
					
					String tableName= "LPAGRI_CURR_CROP_PATTERN";
					String seqId = "LPCP_ORDER_NO";
					String propId = "LPCP_PROP_NO";
					
					//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
					BigDecimal proposalNo=new BigDecimal("12345000004");
					BigDecimal seq=serviceProvider.getSequenceNoService().findMax(tableName, seqId, propId, proposalNo);
										
					List<LpagriCurrCropPattern> currCropPatternList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriCurrCropPattern>>() {});
					Iterator currCropPatternListItr = currCropPatternList.iterator();
					while(currCropPatternListItr.hasNext())
					{
						LpagriCurrCropPattern lpagriCurrCropPattern = (LpagriCurrCropPattern) currCropPatternListItr.next();
						if(lpagriCurrCropPattern.getLpcpOrderNo() == null)
						{
							seq=seq.add(new BigDecimal(1));
							lpagriCurrCropPattern.setLpcpOrderNo(seq);
							lpagriCurrCropPattern.setLpcpPropNo(proposalNo);
							lpagriCurrCropPattern.setLpCreatedBy("Sai");
							lpagriCurrCropPattern.setLpCreatedOn(Helper.getSystemDate());
							lpagriCurrCropPattern.setLpModifiedBy("Sai");
							lpagriCurrCropPattern.setLpModifiedOn(Helper.getSystemDate());
						}
						
						else
						{
							lpagriCurrCropPattern.setLpModifiedBy("Nive");
							lpagriCurrCropPattern.setLpModifiedOn(Helper.getSystemDate());
							
						}
					}
					
					serviceProvider.getLpagriCurrCropPatternService().saveLpagriCurrCropPattern(currCropPatternList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", currCropPatternList);

				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			
			
			else if (dpMethod.equals("getAgriCurYearCropPattern")) {
				try {
					
					//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
					BigDecimal proposalNo=new BigDecimal("12345000004");
					responseHashMap.put("lpagriCurrCropPatternList",serviceProvider.getLpagriCurrCropPatternService().findByLpcpPropNo(proposalNo));
					responseHashMap.put("success", true);
					
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("deleteAgriCurYearCropPattern")) {
				try {
					LpagriCurrCropPattern lpagriCurrCropPattern=null;
					final LpagriCurrCropPattern lpagriCurrCropPattern2 = new ObjectMapper().convertValue(allRequestParams.get("requestData"), LpagriCurrCropPattern.class);
					lpagriCurrCropPattern=serviceProvider.getLpagriCurrCropPatternService().findByLpcpPropNoAndLpcpOrderNo(lpagriCurrCropPattern2.getLpcpPropNo(),lpagriCurrCropPattern2.getLpcpOrderNo());
					serviceProvider.getLpagriCurrCropPatternService().deleteLpagriCurrCropPattern(lpagriCurrCropPattern);
					responseHashMap.put("success", true);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("deleteAllAgriCurYearCropPattern")) {
				try {
										
					List<LpagriCurrCropPattern> LpagriCurrCropPatternList=null;LpagriCurrCropPattern LpagriCurrCropPattern=null;
					LpagriCurrCropPatternList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriCurrCropPattern>>() {});
					Iterator LpagriCurrCropPatternItr=LpagriCurrCropPatternList.iterator();
					if(LpagriCurrCropPatternItr.hasNext())
					
						LpagriCurrCropPattern=(LpagriCurrCropPattern)LpagriCurrCropPatternItr.next();
					serviceProvider.getLpagriCurrCropPatternService().deleteAllByLpcpPropNo(LpagriCurrCropPattern.getLpcpPropNo());
					responseHashMap.put("success", true);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}

			else {
				dataHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
			return responseHashMap;

		} catch (Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}

		return responseHashMap;

	}

}
