package com.sai.lendperfect.agri.curryearcroppattern;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.agrimodel.LpagriCurrCropPattern;
import com.sai.lendperfect.agrirepo.LpagriCurrCropPatternRepo;


@Service("lpagriCurrCropPatternService")
@Transactional
public class LpagriCurrCropPatternServiceImpl implements LpagriCurrCropPatternService {

	@Autowired
	private LpagriCurrCropPatternRepo  lpagriCurrCropPatternRepo;

	
	public List<LpagriCurrCropPattern> saveLpagriCurrCropPattern(List<LpagriCurrCropPattern> lpagriCurrCropPattern) {
		return lpagriCurrCropPatternRepo.save(lpagriCurrCropPattern);
	}
	
	public List<LpagriCurrCropPattern> findAll() {
		return lpagriCurrCropPatternRepo.findAll();
	}

	public void deleteLpagriCurrCropPattern(LpagriCurrCropPattern lpagriCurrCropPattern) {
		lpagriCurrCropPatternRepo.delete(lpagriCurrCropPattern);
	}

	

	public LpagriCurrCropPattern findByLpcpPropNoAndLpcpOrderNo(BigDecimal lpcpPropNo, BigDecimal lpcpOrderNo) {
		return lpagriCurrCropPatternRepo.findByLpcpPropNoAndLpcpOrderNo(lpcpPropNo, lpcpOrderNo);
	}

	@Override
	public List<LpagriCurrCropPattern> findByLpcpPropNo(BigDecimal lpcpPropNo) {
		return ( List<LpagriCurrCropPattern>)lpagriCurrCropPatternRepo.findByLpcpPropNo(lpcpPropNo);
	}

	@Override
	public void deleteAllByLpcpPropNo(BigDecimal lpcpPropNo) {
		lpagriCurrCropPatternRepo.deleteAllByLpcpPropNo(lpcpPropNo);
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	
}
