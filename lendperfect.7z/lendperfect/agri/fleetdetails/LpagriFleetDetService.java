package com.sai.lendperfect.agri.fleetdetails;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.agrimodel.LpagriFleetDet;

public interface LpagriFleetDetService {
	List<LpagriFleetDet> saveLpagriFleetDet(List<LpagriFleetDet> lpagriFleetDet);
	List<LpagriFleetDet> findAll();
	void deleteLpagriFleetDet(LpagriFleetDet lpagriFleetDet);
	LpagriFleetDet findByAfdRowId(BigDecimal afdRowId);
	LpagriFleetDet updateLpagriFleetDet(LpagriFleetDet lpagriFleetDet);
	LpagriFleetDet findByAfdPropNoAndAfdOrderNo(BigDecimal afdPropNo,BigDecimal afdOrderNo);
	void deleteAllByAfdPropNo(BigDecimal afdPropNo);
	List<LpagriFleetDet> findByAfdPropNo(BigDecimal afdPropNo);
}
