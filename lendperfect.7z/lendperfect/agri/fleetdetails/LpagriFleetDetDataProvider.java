package com.sai.lendperfect.agri.fleetdetails;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.agrimodel.LpagriCurrCropPattern;
import com.sai.lendperfect.agrimodel.LpagriExistingExposure;
import com.sai.lendperfect.agrimodel.LpagriFleetDet;
import com.sai.lendperfect.agrimodel.LpagriPrevCropPattern;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomPropParty;
import com.sai.lendperfect.commodel.LpcomSetBorrMap;
import com.sai.lendperfect.logging.Logging;

public class LpagriFleetDetDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		
		try {
			
			if (dpMethod.equals("saveLpagriFleetDet")) {
				
				try {
					String tableName= "LPAGRI_FLEET_DET";
					String seqId = "AFD_ORDER_NO";
					String propId = "AFD_PROP_No";
					//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
					BigDecimal proposalNo=new BigDecimal(20);
					BigDecimal seq=serviceProvider.getSequenceNoService().findMax(tableName, seqId, propId, proposalNo);
					List<LpagriFleetDet> lpagriFleetDetList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriFleetDet>>() {});
					Iterator lpagriFleetDetListItr = lpagriFleetDetList.iterator();
					while(lpagriFleetDetListItr.hasNext())
					{
						LpagriFleetDet LpagriFleetDet = (LpagriFleetDet) lpagriFleetDetListItr.next();
						if(LpagriFleetDet.getAfdOrderNo() == null)
						{
							seq=seq.add(new BigDecimal(1));
							LpagriFleetDet.setAfdOrderNo(seq);	
							LpagriFleetDet.setAfdPropNo(proposalNo);
							
							LpagriFleetDet.setLpCreatedBy("sai");
							LpagriFleetDet.setLpCreatedOn(Helper.getSystemDate());
							LpagriFleetDet.setLpModifiedBy("sai");
							LpagriFleetDet.setLpModifiedOn(Helper.getSystemDate());
										
						}
						else{
							LpagriFleetDet.setLpModifiedBy("Nive");
							LpagriFleetDet.setLpModifiedOn(Helper.getSystemDate());
						}
					}
				
					serviceProvider.getLpagriFleetDetService().saveLpagriFleetDet(lpagriFleetDetList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", lpagriFleetDetList);

				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
						
					}
				}
			}
			
			
			
			else if (dpMethod.equals("getAgriFleetDetails")) {
				
				try {
					
					//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
					BigDecimal proposalNo=new BigDecimal(20);
								
			        responseHashMap.put("ownerNameList",serviceProvider.getLpagriLandDetailService().getCustomerNameAndId(proposalNo));	
					responseHashMap.put("lpagriFleetDetList",serviceProvider.getLpagriFleetDetService().findByAfdPropNo(proposalNo));		
				    responseHashMap.put("success", true);		
					
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} 
			
			
			else if (dpMethod.equals("deleteAgriFleetDetails")) {
				 
				try {
					LpagriFleetDet lpagriFleetDet=null;
					final LpagriFleetDet lpagriFleetDet2 = new ObjectMapper().convertValue(allRequestParams.get("requestData"), LpagriFleetDet.class);
					lpagriFleetDet=serviceProvider.getLpagriFleetDetService().findByAfdPropNoAndAfdOrderNo(lpagriFleetDet2.getAfdPropNo(),lpagriFleetDet2.getAfdOrderNo());
					serviceProvider.getLpagriFleetDetService().deleteLpagriFleetDet(lpagriFleetDet);
					responseHashMap.put("success", true);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} 
			
			
			else if (dpMethod.equals("deleteAllAgriFleetDetails")) {
				
				try {									
					LpagriFleetDet LpagriFleetDet=null;
					List<LpagriFleetDet> LpagriFleetDetList= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriFleetDet>>() {});
					Iterator LpagriFleetDetItr=LpagriFleetDetList.iterator();
					if(LpagriFleetDetItr.hasNext())
					LpagriFleetDet=(LpagriFleetDet)LpagriFleetDetItr.next();
					serviceProvider.getLpagriFleetDetService().deleteAllByAfdPropNo(LpagriFleetDet.getAfdPropNo());
					responseHashMap.put("success", true);
						
					
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			
		else {
				dataHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
			return responseHashMap;
		}
		
		
		catch (Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}
			
		return responseHashMap;

	}

	
	
	}
