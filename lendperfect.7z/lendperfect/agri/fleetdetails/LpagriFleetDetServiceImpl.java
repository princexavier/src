package com.sai.lendperfect.agri.fleetdetails;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.agrimodel.LpagriFleetDet;
import com.sai.lendperfect.agrirepo.LpagriFleetDetRepo;
//import com.sai.lendperfect.model.SetStaticData;

@Service("lpagriFleetDetService")
@Transactional

public class LpagriFleetDetServiceImpl implements LpagriFleetDetService {

	@Autowired
	private LpagriFleetDetRepo  lpagriFleetDetRepo;

	public List<LpagriFleetDet> saveLpagriFleetDet(List<LpagriFleetDet> lpagriFleetDet) {
		return lpagriFleetDetRepo.save(lpagriFleetDet);
	}

	public List<LpagriFleetDet> findAll() {
		return lpagriFleetDetRepo.findAll();
	}

	public void deleteLpagriFleetDet(LpagriFleetDet lpagriFleetDet) {
		lpagriFleetDetRepo.delete(lpagriFleetDet);
	}
	
	public LpagriFleetDet findByAfdRowId(BigDecimal afdRowId) {
		return lpagriFleetDetRepo.findOne(afdRowId);
	}

	public LpagriFleetDet updateLpagriFleetDet(LpagriFleetDet lpagriFleetDet) {
		return lpagriFleetDetRepo.save(lpagriFleetDet);
	}

	public LpagriFleetDet findByAfdPropNoAndAfdOrderNo(BigDecimal afdPropNo, BigDecimal afdOrderNo) {
		return lpagriFleetDetRepo.findByAfdPropNoAndAfdOrderNo(afdPropNo, afdOrderNo);
	}

	

	@Override
	public List<LpagriFleetDet> findByAfdPropNo(BigDecimal afdPropNo) {
		return ( List<LpagriFleetDet>)lpagriFleetDetRepo.findByAfdPropNo(afdPropNo);
		
	}

	@Override
	public void deleteAllByAfdPropNo(BigDecimal afdPropNo) {
		lpagriFleetDetRepo.deleteAllByAfdPropNo(afdPropNo);
		
	}

}
