package com.sai.lendperfect.agri.landdetails;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.agrimodel.LpagriLandDetail;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;

public class LpagriLandDetailProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map <String,Object> responseHashMap=new HashMap<String,Object>();
		
		try{
			
		if(dpMethod.equals("saveLandDetail"))
		{
			String tablename="LPAGRI_LAND_DETAILS";
			String seqid="ALD_SEQ_ID";
			String propid="ALD_PROP_ID";
			//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
			BigDecimal proposalNo=new BigDecimal("123450000000001");
			BigDecimal seqId=serviceProvider.getSequenceNoService().findMax(tablename, seqid, propid, proposalNo);
			List<LpagriLandDetail> LpagriLandDetailList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriLandDetail>>() { });
			Iterator LpagriLandDetailListItr=LpagriLandDetailList.iterator();
			while(LpagriLandDetailListItr.hasNext())
			{ 
				LpagriLandDetail lpagriLandDetail=(LpagriLandDetail) LpagriLandDetailListItr.next();
				if(lpagriLandDetail.getAldOrderNo()==null){
				 seqId=seqId.add(new BigDecimal(1));
				 lpagriLandDetail.setAldOrderNo(seqId);
				 lpagriLandDetail.setAldPropNo(proposalNo);
				 lpagriLandDetail.setLpCreatedBy("sai");
				 lpagriLandDetail.setLpCreatedOn(Helper.getSystemDate());
				 lpagriLandDetail.setLpModifiedBy("sai");
				 lpagriLandDetail.setLpModifiedOn(Helper.getSystemDate());
				}else
				{
					lpagriLandDetail.setLpModifiedBy("nive");
					lpagriLandDetail.setLpModifiedOn(Helper.getSystemDate());
					
				}
			
			}
			serviceProvider.getLpagriLandDetailService().saveLpagriLandDetail(LpagriLandDetailList);	
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", LpagriLandDetailList);
		}
		
	
	else if(dpMethod.equals("getLpagriLandDetail")){
		//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
		BigDecimal proposalNo=new BigDecimal("123450000000001");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		List<LpagriLandDetail> lpagriLandDetail=serviceProvider.getLpagriLandDetailService().findByAldPropNo(proposalNo);
		List<Map<String,Object>> LpagriLandDetailMapList=new ArrayList<Map<String,Object>>();
		LpagriLandDetailMapList=serviceProvider.getLpagriLandDetailService().getCustomerNameAndId(proposalNo);
		
		dataHashMap.put("reqDueDataList",lpagriLandDetail);
		responseHashMap.put("success", true);
		responseHashMap.put("ownerName", LpagriLandDetailMapList);	
		responseHashMap.put("responseData", dataHashMap);	
	}
		
	else if(dpMethod.equals("deleteLandDetails")){
		LpagriLandDetail lpagriLandDetailobj;
		 lpagriLandDetailobj=new ObjectMapper().convertValue(allRequestParams.get("requestData"), LpagriLandDetail.class);
		LpagriLandDetail lpagriLandDetail=serviceProvider.getLpagriLandDetailService().findByAldOrderNoAndAldPropNo(lpagriLandDetailobj.getAldOrderNo(),lpagriLandDetailobj.getAldPropNo());
		serviceProvider.getLpagriLandDetailService().deletelpagriLandDetail(lpagriLandDetail);
		responseHashMap.put("success", true);
	}
		
	else if(dpMethod.equals("deleteAllLandDetails")){
		
		
		LpagriLandDetail LpagriLandDetail=null;
		List<LpagriLandDetail> LpagriLandDetailList= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpagriLandDetail>>() {});
	Iterator LpagriLandDetailListItr=LpagriLandDetailList.iterator();
	if(LpagriLandDetailListItr.hasNext())
		LpagriLandDetail=(LpagriLandDetail)LpagriLandDetailListItr.next();
	   serviceProvider.getLpagriLandDetailService().deleteAllByAldPropNo(LpagriLandDetail.getAldPropNo());
		responseHashMap.put("success", true);
	
	}
		
	else {
		responseHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
		responseHashMap.put("success", false);
		
	}
	
}
		
		catch (Exception ex) {
			Map <String,Object> dataHashMap=new HashMap<String,Object>();
			
			dataHashMap.put("errorData", ex.getLocalizedMessage());
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		}
		
	
	return responseHashMap;
	}
}

