package com.sai.lendperfect.agri.landdetails;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.sai.lendperfect.agrimodel.LpagriLandDetail;

public interface LpagriLandDetailService {

	void saveLpagriLandDetail(List<LpagriLandDetail> lpagriLandDetailList);

	List<LpagriLandDetail> findAll();


	void deletelpagriLandDetail(LpagriLandDetail lpagriLandDetail);

	LpagriLandDetail findByAldOrderNoAndAldPropNo(BigDecimal aldOrderNo, BigDecimal aldPropNo);

	void deleteAllByAldPropNo(BigDecimal aldPropNo);
	
	List<LpagriLandDetail> findByAldPropNo(BigDecimal aldPropNo);
	
	List<Map<String,Object>> getCustomerNameAndId(BigDecimal aldPropNo);

}
