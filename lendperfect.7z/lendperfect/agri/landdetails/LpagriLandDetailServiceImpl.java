package com.sai.lendperfect.agri.landdetails;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.agrimodel.LpagriLandDetail;
import com.sai.lendperfect.agrirepo.LpagriLandDetailRepo;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomCustInfo;
import com.sai.lendperfect.commodel.LpcomPropParty;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSetBorrMap;

@Service("lpagriLandDetailService")
@Transactional
public class LpagriLandDetailServiceImpl implements LpagriLandDetailService{

	@Autowired
	private LpagriLandDetailRepo lpagriLandDetailRepo;
	
	@Autowired
	private ServiceProvider serviceProvider;
	


	
	public void saveLpagriLandDetail(List<LpagriLandDetail> lpagriLandDetailList) {
		lpagriLandDetailRepo.save(lpagriLandDetailList);
		
	}
	public List<LpagriLandDetail> findAll() {
		return lpagriLandDetailRepo.findAll();
	}

	public void deletelpagriLandDetail(LpagriLandDetail lpagriLandDetail) {
		
		lpagriLandDetailRepo.delete(lpagriLandDetail);
	}

	public LpagriLandDetail findByAldOrderNoAndAldPropNo(BigDecimal aldSeqId, BigDecimal aldPropNo) {
		
		return lpagriLandDetailRepo.findByAldOrderNoAndAldPropNo(aldSeqId,aldPropNo);
	}

	
	@Override
	public List<LpagriLandDetail> findByAldPropNo(BigDecimal aldPropNo) {
		
		return (List<LpagriLandDetail>)lpagriLandDetailRepo.findByAldPropNo(aldPropNo);
	}
	
	public void deleteAllByAldPropNo(BigDecimal aldPropNo) {
	
		lpagriLandDetailRepo.deleteAllByAldPropNo(aldPropNo);
	}
	
	
	@Override
	public List<Map<String, Object>> getCustomerNameAndId(BigDecimal aldPropNo) {		
		List<Map<String,Object>> LpCustomerInfoMapList=new ArrayList<Map<String,Object>>();
		Map<String,Object> LpCustomerInfoMap=new HashMap<String,Object>();
	
		LpcomProposal LpcomProposal=serviceProvider.getLpcomProposalService().findByLpPropNo(aldPropNo);
		
		List<LpcomPropParty> LpcomPropPartyList =LpcomProposal.getLpcomPropParty();
		
		List<LpcomSetBorrMap> LpcomSetBorrMapList=LpcomProposal.getLpcomSetBorrMaps();
		
		Iterator<LpcomPropParty> LpcomPropPartyListItr=LpcomPropPartyList.iterator();
		Iterator<LpcomSetBorrMap> LpcomSetBorrMapListItr=LpcomSetBorrMapList.iterator();
		
		while(LpcomPropPartyListItr.hasNext())
		{
			LpcomPropParty LpcomPropParty=(LpcomPropParty)LpcomPropPartyListItr.next();
			
			while(LpcomSetBorrMapListItr.hasNext())
			{
				LpcomSetBorrMap LpcomSetBorrMap=LpcomSetBorrMapListItr.next();
				if(LpcomPropParty.getLpcomProposal().equals(LpcomSetBorrMap.getLpcomProposal()))
				{
					LpcomCustInfo LpcomCustInfo=serviceProvider.getLpcomCustInfoService().findByLciCustIdAndLciRecent(LpcomSetBorrMap.getLfbmCustId(), "Y");//Recent flag  Y
					   if(LpcomCustInfo!=null)
					    {   							    	
						   LpCustomerInfoMap=new HashMap<String,Object>();
						   LpCustomerInfoMap.put("custName", LpcomCustInfo.getLciCustName());
						   LpCustomerInfoMap.put("custId",LpcomCustInfo.getLciCustId());
						   LpCustomerInfoMapList.add(LpCustomerInfoMap);
						   
					    }
					  
				}
				
			}
			
			
		
	}

		return LpCustomerInfoMapList;
		
	}
		
}

