package com.sai.lendperfect.agri.agriReferenceDet;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.agrimodel.LpagriReferenceDet;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;


public class LpAgriReferenceDataProvider {
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpAgriReferenceDataProvider.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		try{
			
			
			if(dpMethod.equals("getreferencedetails"))
			{
				
			try {
				
				//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
				BigDecimal proposalNo=new BigDecimal(29);
					dataHashMap.put("referencedetails",serviceProvider.getLaAgriReferenceService().findByproposal(proposalNo));
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}
			catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			
			
			else if(dpMethod.equals("saveLpAgriReferenceData")){	
				try {
					
					String tableName= "LPAGRI_REFERENCE_DET";
					String seqId = "LRD_SEQ_NO";
					String propId = "LRD_PROP_NO";
					
					//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
					BigDecimal proposalNo=new BigDecimal(29);
					BigDecimal seq=serviceProvider.getSequenceNoService().findMax(tableName, seqId, propId, proposalNo);
										
					List<LpagriReferenceDet> lpagriReferenceDetList=new ObjectMapper()
							.convertValue(requestHashMap.get("optionsFieldArray"),new TypeReference<List<LpagriReferenceDet>>() {});
					
					Iterator<LpagriReferenceDet> lpagriReferenceDetListItr= lpagriReferenceDetList.iterator();
					while(lpagriReferenceDetListItr.hasNext())
					{
						LpagriReferenceDet lpagriReferenceDet=lpagriReferenceDetListItr.next();
						if(lpagriReferenceDet.getLrdSeqNo() == null)
						{
						seq=seq.add(new BigDecimal(1));
						lpagriReferenceDet.setLrdSeqNo(seq);
						lpagriReferenceDet.setLrdPropNo(proposalNo);
						lpagriReferenceDet.setLrdCreatedBy("sai");
						lpagriReferenceDet.setLrdModifiedBy("sai");
						lpagriReferenceDet.setLrdCreatedOn(Helper.getSystemDate());
						lpagriReferenceDet.setLrdModifiedOn(Helper.getSystemDate());
						}
						else
						{
							lpagriReferenceDet.setLrdModifiedBy("nive");
							lpagriReferenceDet.setLrdModifiedOn(Helper.getSystemDate());
						}
					}
					serviceProvider.getLaAgriReferenceService().saveLpagriReferenceDetList(lpagriReferenceDetList);
					dataHashMap.put("optionsFieldArray",lpagriReferenceDetList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}
				catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			
		
			
			 if(dpMethod.equals("deletereferencedetails")){	
					try {
						
						LpagriReferenceDet LpagriReferenceDet=null;
						List<LpagriReferenceDet> LpagriReferenceDetList= new ObjectMapper().convertValue(requestHashMap.get("optionsFieldArray"), new TypeReference<List<LpagriReferenceDet>>() {});
					   Iterator LpagriReferenceDetListItr=LpagriReferenceDetList.iterator();
				    	if(LpagriReferenceDetListItr.hasNext())
					 	LpagriReferenceDet=(LpagriReferenceDet)LpagriReferenceDetListItr.next();
					    serviceProvider.getLaAgriReferenceService().deleteAllByLrdPropNo(LpagriReferenceDet.getLrdPropNo());
						responseHashMap.put("success", true);
														
						
					}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
			 
			 
			 
			 if(dpMethod.equals("deleteresingleferencedet")){	
					try {
						
						//BigDecimal proposalNo=new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
						BigDecimal proposalNo=new BigDecimal(29);
						Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
						LpagriReferenceDet lpagriReferenceDetList=new LpagriReferenceDet();
						BigDecimal  lprefSeqNo=BigDecimal.valueOf(Long.valueOf((String)requestHashMapnew.get("SeqId").toString()));
						BigDecimal  lprefPropNo=proposalNo;
						serviceProvider.getLaAgriReferenceService().deleteAllByLrdPropNoAndLrdSeqNo(lprefPropNo, lprefSeqNo);
						dataHashMap.put("referencedetails",responseHashMap.put("referencedetails", serviceProvider.getLaAgriReferenceService().findByproposal(lprefPropNo)));
						responseHashMap.put("responseData", dataHashMap);
					}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
			 
		} 
		
		catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		
	return responseHashMap;
	}
}

