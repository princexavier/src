package com.sai.lendperfect.agri.agriReferenceDet;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.agrimodel.LpagriReferenceDet;




public interface LpAgriReferenceService {
		
		List<LpagriReferenceDet> findAll();
		LpagriReferenceDet findById(BigDecimal  LprefRowId);
		LpagriReferenceDet saveLpAgriReferenceData(LpagriReferenceDet lpagrireferencedet);
		List<LpagriReferenceDet> saveLpagriReferenceDetList(List<LpagriReferenceDet> lpagriReferenceDetList);
		void deletereferencedetails(List<LpagriReferenceDet> lpagriReferenceDetList);
		void deletesinglereferencedet(LpagriReferenceDet lpagriReferenceDetList);
		void deletesinglereferencedet(BigDecimal LrdRowId);
		List<LpagriReferenceDet> findByproposal(BigDecimal lrdPropNo);
		void deleteAllByLrdPropNoAndLrdSeqNo(BigDecimal lrdPropNo,BigDecimal lrdSeqNo);
		void deleteAllByLrdPropNo(BigDecimal lrdPropNo);
		void deleteAll();
}
