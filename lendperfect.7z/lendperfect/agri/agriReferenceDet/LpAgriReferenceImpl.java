package com.sai.lendperfect.agri.agriReferenceDet;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.agrimodel.LpagriReferenceDet;
import com.sai.lendperfect.agrirepo.LpAgriReferenceRepo;

@Service("LpAgriReferenceService")
@Transactional
public class LpAgriReferenceImpl  implements LpAgriReferenceService{

	@Autowired
	LpAgriReferenceRepo   lpagriReferenceRepo;
	
	public List<LpagriReferenceDet> findAll() {
		// TODO Auto-generated method stub
		return lpagriReferenceRepo.findAll();
	}
	
	@Override
	public LpagriReferenceDet saveLpAgriReferenceData(LpagriReferenceDet reference) {
		return  lpagriReferenceRepo.save(reference);
	}
	

	
	@Override
	public LpagriReferenceDet findById(BigDecimal LprefRowId) {
		// TODO Auto-generated method stub
		return lpagriReferenceRepo.findOne(LprefRowId);
	}


	@Override
	public List<LpagriReferenceDet> saveLpagriReferenceDetList(List<LpagriReferenceDet> lpagriReferenceDetList) {
		// TODO Auto-generated method stub
		return lpagriReferenceRepo.save(lpagriReferenceDetList);
	}
	@Override
	public void deletereferencedetails(List<LpagriReferenceDet> lpagriReferenceDetList) {
		// TODO Auto-generated method stub
		lpagriReferenceRepo.delete(lpagriReferenceDetList);
		
	}

	@Override
	public void deletesinglereferencedet(BigDecimal LprefRowId) {
		// TODO Auto-generated method stub
		lpagriReferenceRepo.delete(LprefRowId);
	}

	@Override
	public void deletesinglereferencedet(LpagriReferenceDet lpagriReferenceDetList) {
		// TODO Auto-generated method stub
		lpagriReferenceRepo.delete(lpagriReferenceDetList);
		
	}

	@Override
	public List<LpagriReferenceDet> findByproposal(BigDecimal lrdPropNo) {
		// TODO Auto-generated method stub
		return lpagriReferenceRepo.findAllByLrdPropNo(lrdPropNo);
	}

	@Override
	public void deleteAllByLrdPropNo(BigDecimal lrdPropNo) {
		// TODO Auto-generated method stub
		lpagriReferenceRepo.deleteAllByLrdPropNo(lrdPropNo);
		
	}

	@Override
	public void deleteAllByLrdPropNoAndLrdSeqNo(BigDecimal lrdPropNo, BigDecimal lrdSeqNo) {
		// TODO Auto-generated method stub
		lpagriReferenceRepo.deleteAllByLrdPropNoAndLrdSeqNo(lrdPropNo, lrdSeqNo);
		
	}
	
	public void deleteAll() {
		
		lpagriReferenceRepo.deleteAll();
	}


}
