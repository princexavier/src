package com.sai.lendperfect.application.taxdetails;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantTaxDetail;
import com.sai.lendperfect.application.repo.LpcustApplicantTaxDetailRepo;

@Service("lpcustApplicantTaxDetailService")
@Transactional
public class LpcustApplicantTaxDetailServiceImpl implements LpcustApplicantTaxDetailService {
	
	@Autowired
	LpcustApplicantTaxDetailRepo lpcustApplicantTaxDetailRepo;

	@Override
	public LpcustApplicantTaxDetail findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {		
		return lpcustApplicantTaxDetailRepo.findByLpcustApplicantData(lpcustApplicantData);
	}

	@Override
	public LpcustApplicantTaxDetail saveLpcustApplicantTaxDetail(LpcustApplicantTaxDetail lpcustApplicantTaxDetail) {
		return lpcustApplicantTaxDetailRepo.save(lpcustApplicantTaxDetail);
	}

}
