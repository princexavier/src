package com.sai.lendperfect.application.taxdetails;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantTaxDetail;

public interface LpcustApplicantTaxDetailService {
	
	LpcustApplicantTaxDetail findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
	LpcustApplicantTaxDetail saveLpcustApplicantTaxDetail(LpcustApplicantTaxDetail lpcustApplicantTaxDetail);

}
