package com.sai.lendperfect.application.taxdetails;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustApplicantTaxDetail;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomLiability;
import com.sai.lendperfect.logging.Logging;

public class TaxDetailDataProvider {

	@SuppressWarnings("unchecked")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {

		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();

		try {
			if (dpMethod.equals("getTaxDetail")) {		
				Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");
				LpcustApplicantTaxDetail lpcustApplicantTaxDetail = serviceProvider.getLpcustApplicantTaxDetailService().findByLpcustApplicantData(serviceProvider.getCustomerDetailsService().findByLadId(Long.parseLong(requestMap.get("latpAppId").toString())));
				dataHashMap.put("lpcustApplicantTaxDetail", lpcustApplicantTaxDetail);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
			if (dpMethod.equals("saveTaxDetail")) {
				Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");
				LpcustApplicantTaxDetail lpcustApplicantTaxDetail = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpcustApplicantTaxDetail>() {});
				if (lpcustApplicantTaxDetail.getLatpSno() == 0) {
					lpcustApplicantTaxDetail.setLatpCreatedBy(session.getAttribute("userid").toString());
					lpcustApplicantTaxDetail.setLatpCreatedOn(new Date(System.currentTimeMillis()));
				}
				lpcustApplicantTaxDetail.setLatpModifiedBy(session.getAttribute("userid").toString());
				lpcustApplicantTaxDetail.setLatpModifiedOn(new Date(System.currentTimeMillis()));
				lpcustApplicantTaxDetail.setLpcustApplicantData(serviceProvider.getCustomerDetailsService().findByLadId(Long.parseLong(requestMap.get("latpAppId").toString())));
				lpcustApplicantTaxDetail = serviceProvider.getLpcustApplicantTaxDetailService().saveLpcustApplicantTaxDetail(lpcustApplicantTaxDetail);
				dataHashMap.put("lpcustApplicantTaxDetail", lpcustApplicantTaxDetail);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
		} catch (Exception ex) {

			ex.printStackTrace();
			dataHashMap.put("errorData", ex.getLocalizedMessage());
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);

		}
		return responseHashMap;
	}
}
