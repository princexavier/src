package com.sai.lendperfect.application.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.common.ipletterdet.FiledownloadDataProvider;
import com.sai.lendperfect.common.ipletterdet.FileuploadDataProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mobileapp.customercreation.MobileFileDownloadDataProvider;

public class Filedownload {
	public Map<String, ?> process(String dpClass,String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging,String dataDirectory
			)		{  
		Map<String, ?> dpMap=null; 

		switch(dpClass)

			{
			  case "FiledownloadDataProvider":
			    	
				    FiledownloadDataProvider filedownloadDataProvider=new FiledownloadDataProvider();
			    	dpMap=filedownloadDataProvider.getData(dpMethod, session, allRequestParams,masterData, serviceProvider, logging,dataDirectory);
			    break;
			  case "MobileFileDownloadDataProvider":
				  MobileFileDownloadDataProvider mobileFileDownloadDataProvider=new MobileFileDownloadDataProvider();
				  dpMap=mobileFileDownloadDataProvider.getData(dpMethod, session, allRequestParams,masterData, serviceProvider, logging,dataDirectory);
				  break;
			} 
		

		return dpMap; 
		} 

}
