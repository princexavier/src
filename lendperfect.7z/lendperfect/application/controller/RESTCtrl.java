package com.sai.lendperfect.application.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.DataProcessor;
import com.sai.lendperfect.application.util.EmailManager;
import com.sai.lendperfect.application.util.DocumentManager;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Fileupload;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.audittrail.AuditTrialProvider;
import com.sai.lendperfect.commodel.LpcomSourcingDet;
import com.sai.lendperfect.corpmodel.LpcorpFacility;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasProperty;
/*import com.sai.lendperfect.model.SetStaticData;*/
import com.sai.lendperfect.webservice.leadservice.ErrorDetail;
import com.sai.lendperfect.webservice.leadservice.LeadRequest;
import com.sai.lendperfect.webservice.leadservice.LeadResponse;
import com.sai.lendperfect.webservice.leadservicestatus.LeadStatusCheckRequest;
import com.sai.lendperfect.webservice.leadservicestatus.LeadStatusCheckResponse;

@Component
@RestController
@CrossOrigin(origins = "*")
public class RESTCtrl implements ApplicationListener<ApplicationReadyEvent> {

	@Autowired
	private ServiceProvider serviceProvider;

	@Autowired
	private Environment environment;

	private DataProcessor dataProcessor = new DataProcessor();

	private List<?> masterDataList = new ArrayList();

	private Logging logging = new Logging();

	private Fileupload fileupload = new Fileupload();

	private Filedownload filedownload = new Filedownload();

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/api", method = RequestMethod.POST)
	public ResponseEntity<?> api(@RequestBody HashMap allRequestParams, HttpSession session) throws Exception {

		if (allRequestParams.get("dataProvider") != null && allRequestParams.get("method") != null) {
			if (Helper.correctNullMap(allRequestParams.get("auditTrailRequest")) != null) {
				Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("auditTrailRequest");
				if (requestMap.get("actionType").equals("insert") || requestMap.get("actionType").equals("update")) {
					AuditTrialProvider.insertAudit(allRequestParams, session, serviceProvider, environment);
				} else if (requestMap.get("actionType").equals("delete")) {
					AuditTrialProvider.deleteAudit(allRequestParams, session, serviceProvider, environment);
				}
			}
			Map<String, ?> resultHashMap = dataProcessor.process((String) allRequestParams.get("dataProvider"),
					(String) allRequestParams.get("method"), session, allRequestParams, masterDataList, serviceProvider,
					logging);
			if (resultHashMap.containsKey("masterData")) {
				// masterDataList=(List<SetStaticData>)
				// resultHashMap.get("masterData");
			}
			return new ResponseEntity(resultHashMap, HttpStatus.OK);
		} else {
			Map<String, CustomErr> resultHashMap = new HashMap<String, CustomErr>();
			resultHashMap.put("errorData", new CustomErr(ErrConstants.dataProviderNotFoundErrCode,
					ErrConstants.dataProviderNotFoundErrMessage));
			return new ResponseEntity(resultHashMap, HttpStatus.BAD_REQUEST);
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/apifile", headers = ("content-type=multipart/*"), method = RequestMethod.POST) // multi
																												// header
																												// using
																												// find
																												// current
																												// location
																												// by
																												// dhanam
	public ResponseEntity<?> apifile(@RequestParam("file") MultipartFile uploadedFile,
			@RequestParam("dataProvider") String dataProvider, @RequestParam("method") String method,
			@RequestParam("requestData") String requestData, HttpSession session, HttpServletRequest request) { // append
																												// and
																												// get
																												// all
																												// request
																												// parameter
																												// in
																												// formdata
																												// and
																												// single
																												// file
																												// path
																												// covert
																												// to
																												// multi
																												// part
																												// path
																												// by
																												// dhanam
		Map allRequestParams;
		Map<String, ?> resultHashMap = null;
		try {
			String dataDirectory = request.getServletContext().getRealPath("//Document//");
			allRequestParams = new ObjectMapper().readValue(requestData, Map.class);
			resultHashMap = fileupload.process(dataProvider, method, session, allRequestParams, masterDataList,
					serviceProvider, logging, uploadedFile, dataDirectory); // append
																			// mutltipart
																			// file

		} catch (IOException e) {

			e.printStackTrace();
		}

		return new ResponseEntity(resultHashMap, HttpStatus.OK);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/apifiledownload", method = RequestMethod.POST)
	public ResponseEntity<?> apifiledownload(@RequestBody HashMap allRequestParams, HttpSession session,
			HttpServletRequest request) {

		if (allRequestParams.get("dataProvider") != null && allRequestParams.get("method") != null) {
			String dataDirectory = request.getServletContext().getRealPath("/kotak-md.png");
			Map<String, ?> resultHashMap = filedownload.process((String) allRequestParams.get("dataProvider"),
					(String) allRequestParams.get("method"), session, allRequestParams, masterDataList, serviceProvider,
					logging, dataDirectory);
			return new ResponseEntity(resultHashMap, HttpStatus.OK);
		} else {
			Map<String, CustomErr> resultHashMap = new HashMap<String, CustomErr>();
			resultHashMap.put("errorData", new CustomErr(ErrConstants.dataProviderNotFoundErrCode,
					ErrConstants.dataProviderNotFoundErrMessage));
			return new ResponseEntity(resultHashMap, HttpStatus.BAD_REQUEST);
		}

	}

	public void onApplicationEvent(ApplicationReadyEvent arg0) {
		this.loadMasterData();
	}

	/**************
	 * Service Provider For Processing Lead from External Source
	 *****************************/
	@PostMapping(value = "/api/KleadServices", consumes = {
			MediaType.APPLICATION_XML_VALUE }, produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<?> LeadService(@RequestBody LeadRequest requestObj) {
		System.out.println("****************** leadServices Called ****************** ");
		ArrayList<ErrorDetail> errorDetailList = new ArrayList();
		ErrorDetail errorDetail = new ErrorDetail();
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		LeadResponse respObj = new LeadResponse();

		try {
			/**************
			 * Validation Against Request Object
			 *****************************/
			System.out.println("****************** Validating Request ****************** ");
			errorDetailList = Helper.fieldValidation(requestObj, errorDetailList, validator);

			if (errorDetailList.isEmpty()) {
				System.out.println("****************** Inside the Error Detail Empty Block ******************** ");

				HashMap allRequestParams = new HashMap();
				allRequestParams.put("dataProvider", "LeadServiceDataProvider");
				allRequestParams.put("method", "InvokeLeadService");
				allRequestParams.put("requestObj", requestObj);
				System.out.println("****************** Addressing DataProcessor  ******************** ");
				Map<String, ?> resultHashMap = dataProcessor.process((String) allRequestParams.get("dataProvider"),
						(String) allRequestParams.get("method"), null, allRequestParams, masterDataList,
						serviceProvider, logging);

				respObj.setBuss_portfolio((String) requestObj.getBuss_portfolio());
				respObj.setLead_ID((String) requestObj.getLead_ID());
				respObj.setSubmit_status((String) resultHashMap.get("Status"));

			} else {
				System.out.println(
						"****************** Validation Failed,Inside the Error Detail  Block ******************** ");
				respObj.setSubmit_status("LP002");
				respObj.setErrorDetail(errorDetailList);
			}

		} catch (Exception e) {
			System.out.println("****************** Inside the Catch Block ******************** ");
			e.printStackTrace();
			respObj.setBuss_portfolio((String) requestObj.getBuss_portfolio());
			respObj.setLead_ID((String) requestObj.getLead_ID());
			respObj.setSubmit_status("LP001");

		}
		System.out.println("****************** leadServices Ended ****************** ");
		return new ResponseEntity<Object>(respObj, HttpStatus.OK);

	}

	/**************
	 * Service Provider For Processing LeadStatus Check
	 *****************************/
	@PostMapping(value = "/api/KleadServicesStatusCheck", consumes = {
			MediaType.APPLICATION_XML_VALUE }, produces = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<?> LeadServiceStatusCheck(@RequestBody LeadStatusCheckRequest requestObj) {
		System.out.println("KleadServicesStatusCheck Service Called");

		ErrorDetail errorDetail = new ErrorDetail();
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		Validator validator = factory.getValidator();
		LeadStatusCheckResponse respObj = new LeadStatusCheckResponse();
		ArrayList<ErrorDetail> errorDetailList = new ArrayList();
		try {

			/**************
			 * Validation Against Request Object
			 *****************************/
			System.out.println("****************** Validating Request ****************** ");
			errorDetailList = Helper.fieldValidation(requestObj, errorDetailList, validator);

			if (errorDetailList.isEmpty()) {
				System.out.println("****************** Inside the Error Detail Empty Block ******************** ");
				System.out.println("****************** Fetching Query for lpComSourcingDet ******************** ");
				LpcomSourcingDet lpComSouringDet = serviceProvider.getLeadStatusCheckService()
						.findByLsdKleadId(requestObj.getLead_ID());
				if (lpComSouringDet != null) {
					System.out.println(
							"****************** Inside the lpComSourcingDet  Record Block ******************** ");
					respObj.setBuss_portfolio(lpComSouringDet.getLpcomProposal().getLpBizVertical());
					respObj.setLead_ID(lpComSouringDet.getLpcomProposal().getLpLeadNo());
					respObj.setProp_created_status("Y");
					respObj.setProp_no(String.valueOf(lpComSouringDet.getLpcomProposal().getLpPropNo()));
					ArrayList arrList = new ArrayList<>();

					lpComSouringDet.getLpcomProposal().getLpcorpFacilities().forEach(corpFacilities -> {
						arrList.add(corpFacilities.getLfFacStatus());
					});

					if (arrList.contains("OP")) {
						respObj.setProp_status("Proposal is on Process");
					} else if (arrList.contains("PA")) {
						respObj.setProp_status("Proposal Approved");
					} else if (arrList.contains("PR")) {
						respObj.setProp_status("Proposal Rejected");
					}

					respObj.setProp_holder(lpComSouringDet.getLpcomProposal().getLpPropHolder());
					respObj.setHolder_level("");
					respObj.setStatus("LP000");// Need to get it from DB
				} else {
					System.out.println("****************** Query Output is Null ******************** ");
					respObj.setProp_created_status("N");
					respObj.setStatus("LP003");// Need to get it from DB
				}
			} else {
				System.out.println(
						"****************** Validation Failed,Inside the Error Detail  Block ******************** ");
				respObj.setStatus("LP002");// Need to get it from DB
				respObj.setErrorDetail(errorDetailList);
			}
		} catch (Exception e) {
			System.out.println("****************** Inside the Catch Block ******************** ");
			e.printStackTrace();
			respObj.setStatus("LP001");
		}

		System.out.println("KleadServicesStatusCheck Service Ended");
		return new ResponseEntity<Object>(respObj, HttpStatus.OK);

	}

	private void loadMasterData() {
		// masterDataList=serviceProvider.getSetStaticDataService().findAll();
	}

}
