package com.sai.lendperfect.application.searchcriteria;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.cbsmodel.Custdetails;

public interface CbsService {
	List<Custdetails> dedupe(StringBuilder queryStr,List<LpcustApplicantData> LpcustApplicantData);
	
	Custdetails findByCifId(String cifId);
	List<Custdetails> getDedupeFirstResult(String aadhar,String phone,String email,List<LpcustApplicantData> lpcustApplicantDataList);
	List<Custdetails> getDedupeSecondResult(String aadhar,String phone,String email,String panNo,List<LpcustApplicantData> lpcustApplicantDataList);
	List<Custdetails> getDedupeThirdResult(String aadhar,String phone,String email,String ladPassport,List<LpcustApplicantData> lpcustApplicantDataList);
	List<Custdetails> getDedupeFourthResult(String aadhar,String phone,String email,String ladPassport,String panNo,List<LpcustApplicantData> lpcustApplicantDataList);
	List<Custdetails> getDedupeFifthResult(String aadhar,String phone,String email,String cbsId,List<LpcustApplicantData> losCustApplicantData);
	List<Custdetails> getDedupeSixthResult(String aadhar,String phone,String email,String ladPassport,String panNo,String cbsId,List<LpcustApplicantData> losCustApplicantData);
	List<Custdetails> getDedupeSeventhResult(String aadhar,String phone,String email,String ladPassport,String cbsId,List<LpcustApplicantData> losCustApplicantData);
	List<Custdetails> getDedupeEigthResult(String aadhar,String phone,String email,String cbsId,String panNo,List<LpcustApplicantData> losCustApplicantData);
}
