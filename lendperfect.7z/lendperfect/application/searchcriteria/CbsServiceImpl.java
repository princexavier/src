package com.sai.lendperfect.application.searchcriteria;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.application.model.LpcustApplicantData;

import com.sai.lendperfect.cbsmodel.Custdetails;
import com.sai.lendperfect.cbsrepo.CustDetailsRepo;

@Service("CbsService")
@Transactional("cbsTransactionManager")
public class CbsServiceImpl implements CbsService {
	
	@Autowired
	CustDetailsRepo custDetailsRepo;
	
	@PersistenceContext(unitName="cbs")
	private EntityManager entityManager;	
	
	
	
	public List<Custdetails> dedupe(StringBuilder queryStr,List<LpcustApplicantData> lpcustApplicantDataList)
	{
		List<Custdetails> custDetailsDedupeList=new ArrayList<>();
		@SuppressWarnings("unchecked")
		List<Custdetails> query = entityManager.createQuery(queryStr.toString()).getResultList();
		if(!query.isEmpty() || lpcustApplicantDataList.isEmpty()){
			for(Custdetails custDetailsList :query){
			custDetailsDedupeList.add(custDetailsList);
		}
		}
		else if(!query.isEmpty() && !lpcustApplicantDataList.isEmpty()){
		for(LpcustApplicantData applicantList :lpcustApplicantDataList){
			for(Custdetails custDetailsList :query){
				if(applicantList.getLadCbsid().equals(custDetailsList.getCifId())){
					custDetailsDedupeList.clear();
				}else{
					custDetailsDedupeList.add(custDetailsList);
				}
			}
		
		}
		}
		  return custDetailsDedupeList;
	}
	
	public List<Custdetails> comparelosApplicant(List<Custdetails> custdetails,List<LpcustApplicantData> lpcustApplicantDataList){
		List<Custdetails> custDetailsDedupeList=new ArrayList<>();
		if(!custdetails.isEmpty() || lpcustApplicantDataList.isEmpty()){
			for(Custdetails custDetailsList :custdetails){
			custDetailsDedupeList.add(custDetailsList);
		}
		}
		else if(!custdetails.isEmpty() && !lpcustApplicantDataList.isEmpty()){
		for(LpcustApplicantData applicantList :lpcustApplicantDataList){
			for(Custdetails custDetailsList :custdetails){
				if(applicantList.getLadCbsid().equals(custDetailsList.getCifId())){
					custDetailsDedupeList.clear();
				}else{
					custDetailsDedupeList.add(custDetailsList);
				}
			}
		
		}
		}
		  return custDetailsDedupeList;
	}
	public Custdetails findByCifId(String cifId){
		return custDetailsRepo.findByCifId(cifId);
		
	}
	
	public List<Custdetails> getDedupeFirstResult(String aadhar,String phone,String email,List<LpcustApplicantData> lpcustApplicantDataList){
		List<Custdetails> custdetails=custDetailsRepo.getDedupeFirstResult(aadhar,phone,email);
		List<Custdetails> details=comparelosApplicant(custdetails,lpcustApplicantDataList);
		return details;
	}
	
	public List<Custdetails> getDedupeSecondResult(String aadhar,String phone,String email,String panNo,List<LpcustApplicantData> lpcustApplicantDataList){
		List<Custdetails> custdetails=custDetailsRepo.getDedupeSecondResult(aadhar,phone,email,panNo);
		List<Custdetails> details=comparelosApplicant(custdetails,lpcustApplicantDataList);
		return details;
	}
	
	public List<Custdetails> getDedupeThirdResult(String aadhar,String phone,String email,String ladPassport,List<LpcustApplicantData> lpcustApplicantDataList){
		List<Custdetails> custdetails= custDetailsRepo.getDedupeThirdResult(aadhar,phone,email,ladPassport);
		 List<Custdetails> details=comparelosApplicant(custdetails,lpcustApplicantDataList);
			return details;
	}
	
	public List<Custdetails> getDedupeFourthResult(String aadhar,String phone,String email,String ladPassport,String panNo,List<LpcustApplicantData> lpcustApplicantDataList){
		List<Custdetails> custdetails=custDetailsRepo.getDedupeFourthResult(aadhar,phone,email,ladPassport,panNo);
		 List<Custdetails> details=comparelosApplicant(custdetails,lpcustApplicantDataList);
			return details;
	}
	
	public List<Custdetails> getDedupeFifthResult(String aadhar,String phone,String email,String cbsId,List<LpcustApplicantData> losCustApplicantData){
		List<Custdetails> custdetails=custDetailsRepo.getDedupeFifthResult(aadhar,phone,email,cbsId);
		 List<Custdetails> details=comparelosApplicant(custdetails,losCustApplicantData);
			return details;
	}
	
	public List<Custdetails> getDedupeSixthResult(String aadhar,String phone,String email,String ladPassport,String panNo,String cbsId,List<LpcustApplicantData> losCustApplicantData){
		List<Custdetails> custdetails=custDetailsRepo.getDedupeSixthResult(aadhar,phone,email,ladPassport,panNo,cbsId);
		 List<Custdetails> details=comparelosApplicant(custdetails,losCustApplicantData);
			return details;
	}
	
	public List<Custdetails> getDedupeSeventhResult(String aadhar,String phone,String email,String ladPassport,String cbsId,List<LpcustApplicantData> losCustApplicantData){
		List<Custdetails> custdetails=custDetailsRepo.getDedupeSeventhResult(aadhar,phone,email,ladPassport,cbsId);
		 List<Custdetails> details=comparelosApplicant(custdetails,losCustApplicantData);
			return details;
	}
	
	public List<Custdetails> getDedupeEigthResult(String aadhar,String phone,String email,String cbsId,String panNo,List<LpcustApplicantData> losCustApplicantData){
		List<Custdetails> custdetails=custDetailsRepo.getDedupeEigthResult(aadhar,phone,email,cbsId,panNo);
		 List<Custdetails> details=comparelosApplicant(custdetails,losCustApplicantData);
			return details;
	}
}
