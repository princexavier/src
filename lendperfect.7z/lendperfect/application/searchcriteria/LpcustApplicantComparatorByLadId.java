package com.sai.lendperfect.application.searchcriteria;

import java.util.Comparator;

import com.sai.lendperfect.application.model.LpcustApplicantData;

public class LpcustApplicantComparatorByLadId implements Comparator<LpcustApplicantData>{

	@Override
	public int compare(LpcustApplicantData o1, LpcustApplicantData o2) {
		if(o1.getLadId() == o2.getLadId())
		   return 0;
		else if(o1.getLadId() < o2.getLadId())
			return 1;
		else
			return -1;
	}	

}
