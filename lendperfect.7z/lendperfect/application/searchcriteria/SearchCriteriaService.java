package com.sai.lendperfect.application.searchcriteria;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.sai.lendperfect.application.model.LpcustApplicantData;


public interface SearchCriteriaService {	
	List<LpcustApplicantData> dedupe(StringBuilder queryStr);
}
