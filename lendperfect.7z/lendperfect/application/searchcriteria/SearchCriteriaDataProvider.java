package com.sai.lendperfect.application.searchcriteria;

import java.math.BigDecimal;
import java.util.*;


import javax.servlet.http.HttpSession;

import com.sai.lendperfect.app.customerdetails.CustomerDetailsProvider;
import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.cbsmodel.Custdetails;
//import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.common.businessapproval.LpcomBussApprovalDataProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;

public class SearchCriteriaDataProvider {
	@SuppressWarnings("unchecked")
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpcomBussApprovalDataProvider.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		
		try {
			if(dpMethod.equals("getProofsList")) {
				String header="Dedupe KYC";                      // LLVHEADER
				String header1="Search Criteria Condition";						
				List<LpmasListofvalue> lpmasListofvalueList;
				List<LpmasListofvalue> lpmasListofvalueList1;
				lpmasListofvalueList=serviceProvider.getLpmasListofvalueService().findByLlvHeaderOrderByLlvRowId(header);
				lpmasListofvalueList1=serviceProvider.getLpmasListofvalueService().findByLlvHeaderOrderByLlvRowId(header1);				
				dataHashMap.put("proofList",lpmasListofvalueList);
				dataHashMap.put("operatorList",lpmasListofvalueList1);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			} else  if(dpMethod.equals("getResultBySearchQuery")) {
                HashMap<String,StringBuilder> queries=queryMaker(requestHashMap);
                StringBuilder losQuery = queries.get("losQuery");
                StringBuilder cbsQuery = queries.get("cbsQuery");
                List<LpcustApplicantData> losCustApplicantData=null;
                List lpcustAppcustRelationList=new ArrayList<>();
                List<Custdetails>  cbsCustApplicantData=null;
                List<Custdetails> query=null;
                if(losQuery != null && losQuery.length()!=0) {
                	losCustApplicantData=serviceProvider.getSearchCriteriaService().dedupe(losQuery);
                	LinkedHashMap <BigDecimal,TreeSet<LpcustApplicantData>> sortedMap=new LinkedHashMap <>();
                	if(!losCustApplicantData.isEmpty()) {
                		for(LpcustApplicantData lp : losCustApplicantData) {
                			if(sortedMap.containsKey(lp.getLadOldid())) {
                				sortedMap.get(lp.getLadOldid()).add(lp);
                			} else  {
                				sortedMap.put(lp.getLadOldid(),new TreeSet<>(new LpcustApplicantComparatorByLadId()));
                				sortedMap.get(lp.getLadOldid()).add(lp);
                			}
                		}
                	}
                	
                	losCustApplicantData.clear();
                	for(BigDecimal b: sortedMap.keySet()) {
                		losCustApplicantData.add(sortedMap.get(b).first());
                	}                	
                }
                
                String aadhar=requestHashMap.get("ladaadhar").toString();
                String phone=requestHashMap.get("ladPhone").toString();
//                String dob = requestHashMap.get("ladDob").toString();
                String email=requestHashMap.get("ladEmail").toString();
//                String fname=requestHashMap.get("ladFname").toString();
//                String fname=name.concat("%");
             
                if(requestHashMap.get("ladaadhar")!=null && requestHashMap.get("ladPhone")!=null 
                		&& requestHashMap.get("ladEmail")!=null 
                		&& requestHashMap.get("ladPanno")==null && requestHashMap.get("ladPassport")==null && losCustApplicantData!=null && requestHashMap.get("ladCbsid")==null){
//                if(cbsQuery != null && cbsQuery.length()!=0 && losCustApplicantData!=null) {
                	cbsCustApplicantData=serviceProvider.getCbsService().getDedupeFirstResult(aadhar,phone,email,losCustApplicantData);
                	}
                
                else if(requestHashMap.get("ladaadhar")!=null && requestHashMap.get("ladPhone")!=null 
                		&& requestHashMap.get("ladEmail")!=null 
                		&& requestHashMap.get("ladPanno" )!=null && requestHashMap.get("ladPassport")==null 
                		&& requestHashMap.get("ladCbsid")==null && losCustApplicantData!=null){
                	String panNo=requestHashMap.get("ladPanno").toString();
                	cbsCustApplicantData=serviceProvider.getCbsService().getDedupeSecondResult(aadhar,phone,email,panNo,losCustApplicantData);
                }
                
                else  if(requestHashMap.get("ladaadhar")!=null && requestHashMap.get("ladPhone")!=null 
                		&& requestHashMap.get("ladEmail")!=null  && 
                		requestHashMap.get("ladPassport")!=null && losCustApplicantData!=null && requestHashMap.get("ladCbsid")==null && requestHashMap.get("ladPanno" )==null){
                	   String passport = requestHashMap.get("ladPassport").toString();
                	   cbsCustApplicantData=serviceProvider.getCbsService().getDedupeThirdResult(aadhar,phone,email,passport,losCustApplicantData);
                }
                
                else  if(requestHashMap.get("ladaadhar")!=null && requestHashMap.get("ladPhone")!=null 
                		&& requestHashMap.get("ladEmail")!=null &&
                		requestHashMap.get("ladPassport")!=null && requestHashMap.get("ladPanno")!=null && losCustApplicantData!=null && requestHashMap.get("ladCbsid")==null){
                	String panNo=requestHashMap.get("ladPanno").toString();
                	   String passport = requestHashMap.get("ladPassport").toString();
                	   cbsCustApplicantData=serviceProvider.getCbsService().getDedupeFourthResult(aadhar,phone,email,passport,panNo,losCustApplicantData);
                }
                
                else  if(requestHashMap.get("ladaadhar")!=null && requestHashMap.get("ladPhone")!=null 
                		&& requestHashMap.get("ladEmail")!=null && 
                		requestHashMap.get("ladCbsid")!=null && losCustApplicantData!=null && requestHashMap.get("ladPanno" )==null && requestHashMap.get("ladPassport")==null){
              	   String ladCbsid = requestHashMap.get("ladCbsid").toString();
              	 cbsCustApplicantData=serviceProvider.getCbsService().getDedupeFifthResult(aadhar,phone,email,ladCbsid,losCustApplicantData);
                 }
                
                else  if(requestHashMap.get("ladaadhar")!=null && requestHashMap.get("ladPhone")!=null 
                		&& requestHashMap.get("ladEmail")!=null 
                		&& requestHashMap.get("ladPassport")!=null && requestHashMap.get("ladPanno")!=null &&requestHashMap.get("ladCbsid")!=null 
                		&& losCustApplicantData!=null){
                	   String panNo=requestHashMap.get("ladPanno").toString();
                	   String passport = requestHashMap.get("ladPassport").toString();
                	   String ladCbsid = requestHashMap.get("ladCbsid").toString();
                	   cbsCustApplicantData=serviceProvider.getCbsService().getDedupeSixthResult(aadhar,phone,email,passport,panNo,ladCbsid,losCustApplicantData);
                }
                
                else if(requestHashMap.get("ladaadhar")!=null && requestHashMap.get("ladPhone")!=null 
                		&& requestHashMap.get("ladEmail")!=null &&
                		requestHashMap.get("ladPassport")!=null &&requestHashMap.get("ladCbsid")!=null  && losCustApplicantData!=null && requestHashMap.get("ladPanno")==null){
             	   String passport = requestHashMap.get("ladPassport").toString();
             	   String ladCbsid = requestHashMap.get("ladCbsid").toString();
             	  cbsCustApplicantData=serviceProvider.getCbsService().getDedupeSeventhResult(aadhar,phone,email,passport,ladCbsid,losCustApplicantData);
             }
                
                else  if(requestHashMap.get("ladaadhar")!=null && requestHashMap.get("ladPhone")!=null 
                		&& requestHashMap.get("ladEmail")!=null  && 
                		requestHashMap.get("ladPanno")!=null &&requestHashMap.get("ladCbsid")!=null  && losCustApplicantData!=null && requestHashMap.get("ladPassport")==null){
             	   String panNo=requestHashMap.get("ladPanno").toString();
             	   String ladCbsid = requestHashMap.get("ladCbsid").toString();
             	  cbsCustApplicantData=serviceProvider.getCbsService().getDedupeEigthResult(aadhar,phone,email,panNo,ladCbsid,losCustApplicantData);
             }
                
                dataHashMap.put("matchedUsersInLOS",losCustApplicantData);
                dataHashMap.put("matchedUsersInCBS",cbsCustApplicantData);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
			else if(dpMethod.equals("newApplicant")){
				BigDecimal propno=new BigDecimal(0);
				session.setAttribute("LP_COM_PROP_NO",propno);
				CustomerDetailsProvider CustomerDetailsProvider = new CustomerDetailsProvider();
				CustomerDetailsProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
				responseHashMap.put("success", true);
			}
		} catch(Exception e) {
			e.printStackTrace();
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
			responseHashMap.put("Message", e.toString());
		}
		
		return responseHashMap;
		
	}	
	
	private HashMap<String,StringBuilder> queryMaker(Map<String,?> map) {
		//Column mapping in LPCUST_APPLICANT_DATA
		String losCustIdCol="l.ladCbsid";
		String losCustNameCol="l.ladFname";
		String losPassportCol="l.ladPassport";
		String losPanCol="l.ladPanno";
		String losAadharCol="l.ladaadhar";
		String losVoterIdCol="l.ladVoterId";
		String losDrivingLicenseCol="l.ladDrivingLicenseNo";
		String losRationCardCol="l.ladRationNo";
		String losMobileNoCol="l.ladPhone";
		String losEmailCol="l.ladEmail";
		String losDobCol = "to_char(l.ladDob,'dd/mm/yyyy')";
		String losLadLnameCol="l.ladLname";
		String losLadMnameCol="l.ladMname";
//		String losCustNameConCol = map.get("ladFname").toString()+ " " +map.get("ladMname").toString()+ " " +map.get("ladLname").toString();
		
		//Column mapping in CUSTDETAILS
		String cbsCustIdCol="c.CIF_ID";
		String cbsCustNameCol="c.NAME";
		String cbsAadharCol="c.AADHAR_NUM";
		String cbsPanCol="c.PAN_GIR_NUM";
		String cbsPassportCol="c.PSPRT_NUM";
		String cbsMobileCol="c.MAILING_PHONENO";
		String cbsEmailCol="c.MAILING_EMAIL";
		String cbsCustDobCol = "to_char(c.CUST_DOB,'dd/mm/yyyy')";
		
		
		StringBuilder losQueryString=new StringBuilder("");
		StringBuilder cbsQueryString=new StringBuilder("");
		if(map.get("ladCbsid") != null && !map.get("ladCbsid").toString().isEmpty()) {
		losQueryString.append(losCustIdCol + "='" +map.get("ladCbsid")  +"' ");
		cbsQueryString.append("SELECT c FROM Custdetails c  WHERE "+cbsCustIdCol + "='" +map.get("ladCbsid")  +"' ");
	}
		
		if(map.get("ladaadhar") != null && !map.get("ladaadhar").toString().isEmpty()) {
			if(losQueryString.length()!=0) {
			    	losQueryString.append(" OR " + losAadharCol + "='" + map.get("ladaadhar") + "' ");
			    }
			 else {
				losQueryString.append(losAadharCol + "='" + map.get("ladaadhar") + "' ");
			}
//			if(cbsQueryString.length()!=0) {
//			    	cbsQueryString.append(" UNION SELECT c FROM Custdetails c  WHERE " + cbsAadharCol + "='" + map.get("ladaadhar") + "' ");
//			    
//			} else {
//				cbsQueryString.append("SELECT c FROM Custdetails c  WHERE " +cbsAadharCol + "='" + map.get("ladaadhar") + "' ");
//			}								
		}
		
		if(map.get("ladPanno") != null && !map.get("ladPanno").toString().isEmpty()) {
			if(losQueryString.length()!=0) {
			    	losQueryString.append(" OR " + losPanCol + "='" + map.get("ladPanno") + "' ");
			    }
			 else {
				losQueryString.append(losPanCol + "='" + map.get("ladPanno") + "' ");
			}
//			if(cbsQueryString.length()!=0) {
//			    	cbsQueryString.append(" UNION SELECT c FROM Custdetails c  WHERE " + cbsPanCol + "='" + map.get("ladPanno") + "' ");
//			    }
//			 else {
//				cbsQueryString.append("SELECT c FROM Custdetails c  WHERE " +cbsPanCol + "='" + map.get("ladPanno") + "' ");
//			}
		}	
		
		if(map.get("ladPassport") != null && !map.get("ladPassport").toString().isEmpty()) {
			if(losQueryString.length()!=0) {
			    	losQueryString.append("OR " + losPassportCol + "='" + map.get("ladPassport") + "' ");
			    }
			 else {
				losQueryString.append(losPassportCol + "='" + map.get("ladPassport") + "' ");
			}
//			if(cbsQueryString.length()!=0) {
//			    	cbsQueryString.append(" UNION SELECT c FROM Custdetails c  WHERE " + cbsPassportCol + "='" + map.get("ladPassport") + "' ");
//			    }
//			 else {
//				cbsQueryString.append("SELECT c FROM Custdetails c  WHERE " +cbsPassportCol + "='" + map.get("ladPassport") + "' ");
//			}
		}	
		
		if(map.get("ladPhone") != null && !map.get("ladPhone").toString().isEmpty()) {
			if(losQueryString.length()!=0) { 
			    	losQueryString.append(" OR " + losMobileNoCol + "='" + map.get("ladPhone") + "' ");
			} else {
				losQueryString.append(losMobileNoCol + "='" + map.get("ladPhone") + "' ");
			}
//			if(cbsQueryString.length()!=0) {
//			    	cbsQueryString.append(" UNION SELECT c FROM Custdetails c  WHERE " + cbsMobileCol + "='" + map.get("ladPhone") + "' ");
//			} else {
//				cbsQueryString.append("SELECT c FROM Custdetails c  WHERE " +cbsMobileCol + "='" + map.get("ladPhone") + "' ");
//			}
		}	
		
		if(map.get("ladEmail") != null && !map.get("ladEmail").toString().isEmpty()) {
			if(losQueryString.length()!=0) { 
			    	losQueryString.append(" OR " + losEmailCol + "='" + map.get("ladEmail") + "' ");
			    
			} else {
				losQueryString.append(losEmailCol + "='" + map.get("ladEmail") + "' ");
			}
//			if(cbsQueryString.length()!=0) {
//			    	cbsQueryString.append(" UNION SELECT c FROM Custdetails c  WHERE " + cbsEmailCol + "='" + map.get("ladEmail") + "' ");
//			    }
//			 else {
//				cbsQueryString.append("SELECT c FROM Custdetails c  WHERE  " +cbsEmailCol + "='" + map.get("ladEmail") + "' ");
//			}
		}	
		
		
//		if(map.get("ladFname") != null && !map.get("ladFname").toString().isEmpty()){
//			if(losQueryString.length()!=0){
//				losQueryString.append(" OR ( "+losCustNameCol + " LIKE "+"'"+map.get("ladFname")+"%"+"'");		
//			} else {
//				losQueryString.append("  (" + losCustNameCol + " LIKE "+"'"+map.get("ladFname")+"%"+"'");	
//			}
//		}
		
//		if(map.get("ladMname") != null && !map.get("ladMname").toString().isEmpty()){
//			if(losQueryString.length()!=0)
//				losQueryString.append(" AND "+losLadMnameCol + " LIKE "+"'"+map.get("ladMname")+"%"+"'");
//		}
//		
//		if(map.get("ladLname") != null && !map.get("ladLname").toString().isEmpty()){
//			if(losQueryString.length()!=0)
//				losQueryString.append(" AND "+losLadLnameCol + " LIKE "+"'"+map.get("ladLname")+"%"+"'");
//		}
		
//		if(map.get("ladFname") != null){
//			if(cbsQueryString.length()!=0){
//				cbsQueryString.append(" UNION (SELECT c FROM Custdetails c  WHERE "+cbsCustNameCol + " LIKE "+"'"+map.get("ladFname")+"%"+"'" );
//			}
//			else{
//				cbsQueryString.append("  (SELECT c FROM Custdetails c  WHERE " + cbsCustNameCol + " LIKE "+"'"+map.get("ladFname")+"%"+"'");
//			}
//		}
		
		
//		if(map.get("ladDob") != null && !map.get("ladDob").toString().isEmpty()){
//			if(losQueryString.length()!=0) { 
//			    	losQueryString.append(" AND " + losDobCol + "='" + map.get("ladDob") + "') ");
//			    }
//			 else {
//				losQueryString.append(" AND " +losDobCol + "='" + map.get("ladDob") + "')");
//			}
	
		
			
//			if(cbsQueryString.length()!=0) {
//			    	cbsQueryString.append(" AND  " + cbsCustDobCol + "='" + map.get("ladDob") + "') ");
//			    }
//			 else {
//				cbsQueryString.append(" AND " +cbsCustDobCol + "='" + map.get("ladDob") + "') ");
//			}
		
		
		HashMap<String,StringBuilder> resultMap=new HashMap<>();
		resultMap.put("losQuery", losQueryString);
		resultMap.put("cbsQuery", cbsQueryString);
		
		return resultMap;
	}	
}
