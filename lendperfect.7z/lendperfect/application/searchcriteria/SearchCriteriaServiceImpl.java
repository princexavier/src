package com.sai.lendperfect.application.searchcriteria;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.application.model.LpcustApplicantData;



@Service("searchCriteriaService")
@Transactional
public class SearchCriteriaServiceImpl implements SearchCriteriaService{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	
	public List<LpcustApplicantData> dedupe(StringBuilder queryStr)
	{
		@SuppressWarnings("unchecked")
		List<LpcustApplicantData> query = entityManager.createQuery("SELECT l from LpcustApplicantData l  WHERE "+queryStr.toString()).getResultList();
		  return query;
	}
  
}
