package com.sai.lendperfect.application.config;

import java.util.Properties;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;



@Configuration
@EnableJpaRepositories(basePackages = {"com.sai.lendperfect.corprepo","com.sai.lendperfect.comrepo",
										"com.sai.lendperfect.setuprepo","com.sai.lendperfect.masterrepo","com.sai.lendperfect.application.repo","com.sai.lendperfect.agrirepo","com.sai.lendperfect.webservice.webservicesrepo"},
		entityManagerFactoryRef = "entityManagerFactory",
		transactionManagerRef = "transactionManager")
@EnableTransactionManagement
public class JPA {

	@Autowired
	private Environment environment;

	
	@Bean
	@Primary	
	public DataSourceProperties dataSourceProperties(){
		
		DataSourceProperties dataSourceProperties=new DataSourceProperties();
		dataSourceProperties.setDriverClassName(environment.getRequiredProperty("lendperfect.datasource.driverClassName"));
		dataSourceProperties.setUrl(environment.getRequiredProperty("lendperfect.datasource.url"));
		dataSourceProperties.setPassword(environment.getRequiredProperty("lendperfect.datasource.password"));
		dataSourceProperties.setUsername(environment.getRequiredProperty("lendperfect.datasource.username"));
		return dataSourceProperties ;
	}

	@Bean
	@Primary	
	public DataSource dataSource() {
	
		DataSource dataSource=null;
		if(environment.getRequiredProperty("spring.datasource.name").equalsIgnoreCase("dev"))
		{
			DataSourceProperties dataSourceProperties = dataSourceProperties();
			 dataSource =  DataSourceBuilder
						.create(dataSourceProperties.getClassLoader())
						.driverClassName(dataSourceProperties.getDriverClassName())
						.url(dataSourceProperties.getUrl())
						.username(dataSourceProperties.getUsername())
						.password(dataSourceProperties.getPassword())
						.build();
			 
		}else if(environment.getRequiredProperty("spring.datasource.name").equalsIgnoreCase("prod"))
		{
			 JndiDataSourceLookup jndiDataSourceLookup = new JndiDataSourceLookup();
		     jndiDataSourceLookup.setResourceRef(true);
		     dataSource =jndiDataSourceLookup.getDataSource(environment.getRequiredProperty("spring.datasource.jndi-name"));
		     
		}else if(environment.getRequiredProperty("spring.datasource.name").equalsIgnoreCase("test"))
		{
			 JndiDataSourceLookup jndiDataSourceLookup = new JndiDataSourceLookup();
		     jndiDataSourceLookup.setResourceRef(true);
		     dataSource= jndiDataSourceLookup.getDataSource(environment.getRequiredProperty("spring.datasource.jndi-name"));
		}
		return dataSource;
	}

	/*
	 * Entity Manager Factory setup.
	 */
	@Bean
	@Primary	
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() throws NamingException {
		LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
		factoryBean.setDataSource(dataSource());
		factoryBean.setPackagesToScan(new String[] {"com.sai.lendperfect.agrimodel","com.sai.lendperfect.corpmodel","com.sai.lendperfect.commodel","com.sai.lendperfect.mastermodel","com.sai.lendperfect.setupmodel","com.sai.lendperfect.application.model"});
		factoryBean.setJpaVendorAdapter(jpaVendorAdapter());
		factoryBean.setJpaProperties(jpaProperties());
		return factoryBean;
	}

	/*
	 * Provider specific adapter.
	 */
	@Bean
	public JpaVendorAdapter jpaVendorAdapter() {
		HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
		return hibernateJpaVendorAdapter;
	}

	/*
	 * Here you can specify any provider specific properties.
	 */
	private Properties jpaProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.dialect", environment.getRequiredProperty("lendperfect.datasource.hibernate.dialect"));
		properties.put("hibernate.hbm2ddl.auto", environment.getRequiredProperty("lendperfect.datasource.hibernate.hbm2ddl.method"));
		properties.put("hibernate.show_sql", environment.getRequiredProperty("lendperfect.datasource.hibernate.show_sql"));
		properties.put("hibernate.format_sql", environment.getRequiredProperty("lendperfect.datasource.hibernate.format_sql"));				
		return properties;
	}

	@Bean
	@Autowired
	@Primary
	public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
		JpaTransactionManager txManager = new JpaTransactionManager();
		txManager.setEntityManagerFactory(emf);
		return txManager;
	}

}
