package com.sai.lendperfect.application.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;



@Configuration
@EnableJpaRepositories(
    basePackages = {"com.sai.lendperfect.cbsrepo"}, 
    entityManagerFactoryRef = "cbsEntityManager", 
    transactionManagerRef = "cbsTransactionManager"
)
public class CbsJPA {
	
    @Autowired
    private Environment env;
     
    @Bean    
    public LocalContainerEntityManagerFactoryBean cbsEntityManager() {
        LocalContainerEntityManagerFactoryBean em
          = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource( cbsDataSource());
        em.setPackagesToScan(
        		new String[] {"com.sai.lendperfect.cbsmodel"});
        HibernateJpaVendorAdapter vendorAdapter
          = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        Map<String, Object> properties = new HashMap<String, Object>();
  	  properties.put("hibernate.show_sql", "true");
  	  properties.put("hibernate.format_sql", "true");
        em.setJpaPropertyMap(properties);
        em.setPersistenceUnitName("cbs");
        return em;
    }
 
    
    @Bean
    @ConfigurationProperties(prefix = "cbsdb.datasource")
    public DataSource cbsDataSource() {
      return DataSourceBuilder.create().build();
    }
 
    
    @Bean
    public PlatformTransactionManager cbsTransactionManager() {
  
        JpaTransactionManager transactionManager
          = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(
        		cbsEntityManager().getObject());
        return transactionManager;
    }
}