package com.sai.lendperfect.application.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sai.lendperfect.application.util.ServiceProvider;


@Configuration
public class AppConfig {	
	
	@Bean
	public ServiceProvider getServiceProvider()
	{
		return new ServiceProvider();
	}
		
}
