package com.sai.lendperfect.application.repo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustLoanDetail;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface LoanDetailsRepo extends JpaRepository<LpcustLoanDetail, BigDecimal>{

	LpcustLoanDetail findByLpcomProposal(LpcomProposal lpcomProposal);
	LpcustLoanDetail findByLldSno(long lldSno);
	LpcustLoanDetail findByLldId(long lldid);
	LpcustLoanDetail findByLpcomProposalAndLldSno(LpcomProposal lpcomProposal,long lldSno);
	List<LpcustLoanDetail> findBylpcomProposal(LpcomProposal lpcomProposal);
	LpcustLoanDetail findByLpcomProposalAndLldPrdcode(LpcomProposal lpcomProposal, Long lfaFacNo);
	
	List<LpcustLoanDetail> findBylpcomProposalOrderByLldSno(LpcomProposal lpcomProposal);
}
