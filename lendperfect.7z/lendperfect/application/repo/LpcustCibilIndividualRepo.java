package com.sai.lendperfect.application.repo;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustCibilIndividual;


public interface LpcustCibilIndividualRepo extends JpaRepository<LpcustCibilIndividual, Serializable>{
	LpcustCibilIndividual findByCiRefnumber(String refNo);
}
