package com.sai.lendperfect.application.repo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sai.lendperfect.application.model.LpcustApplicantData;

public interface LpApplicationDataRepo extends JpaRepository<LpcustApplicantData, Serializable>{

	
	LpcustApplicantData findByladId(BigDecimal ladId);
	LpcustApplicantData findByladId(long ladId);
	LpcustApplicantData findByLadaadhar(String ladaadhar);
	List<LpcustApplicantData> findByLadOldid(BigDecimal ladOldid);
	LpcustApplicantData findByLadMobile(String ladMobile);
	LpcustApplicantData findByLadEmail(String ladEmail);
	List<LpcustApplicantData> findByLadFnameIgnoreCaseContaining(String ladFname);
	LpcustApplicantData findByLadCbsid(String ladCbsid);
	List<LpcustApplicantData> findByLadPannoOrLadMobileOrLadaadharOrLadFnameIgnoreCaseContainingOrLadEmailOrLadCbsid(String ladPanno,
			String ladMobile,String ladaadhar,String ladEmail,String ladFname,String ladCbsid);
	//LpcustApplicantData findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
}
