package com.sai.lendperfect.application.repo;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.application.model.AuditTrial;


@Repository
public interface AuditTrialRepo extends JpaRepository<AuditTrial, Serializable>{
	
}
