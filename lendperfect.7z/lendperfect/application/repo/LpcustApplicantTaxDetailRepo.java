package com.sai.lendperfect.application.repo;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantTaxDetail;

public interface LpcustApplicantTaxDetailRepo extends JpaRepository<LpcustApplicantTaxDetail, Serializable> {
	
	LpcustApplicantTaxDetail findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);

}
