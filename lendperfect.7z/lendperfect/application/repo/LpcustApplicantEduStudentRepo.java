package com.sai.lendperfect.application.repo;

import java.io.Serializable;
import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustApplicantEduStudent;
import com.sai.lendperfect.commodel.LpcomProposal;


public interface LpcustApplicantEduStudentRepo extends JpaRepository<LpcustApplicantEduStudent, Serializable>{

	LpcustApplicantEduStudent findBylpcomProposal(LpcomProposal lpcomProposal);

}
