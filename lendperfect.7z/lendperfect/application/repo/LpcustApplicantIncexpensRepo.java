package com.sai.lendperfect.application.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantIncexpens;

import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcustApplicantIncexpensRepo extends JpaRepository<LpcustApplicantIncexpens, Long>{


	LpcustApplicantIncexpens findByLaieId(Long id);
	LpcustApplicantIncexpens findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
}
