package com.sai.lendperfect.application.repo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpApplicationRelationRepo extends JpaRepository<LpcustAppcustRelation, Serializable> {

	List<LpcustAppcustRelation> findByLpcomProposal(LpcomProposal lpcomProposal);

	LpcustAppcustRelation findBylarId(Long larId);

	LpcustAppcustRelation findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);

	LpcustAppcustRelation findByLpcomProposalAndLarType(LpcomProposal lpcomProposal, String larType);

	LpcustAppcustRelation findByLpcustApplicantDataAndLarType(LpcustApplicantData lpcustApplicantData, String larType);

	List<LpcustAppcustRelation> findByLpcomProposalOrderByLpcustApplicantData(LpcomProposal lpcomProposal);

	List<LpcustAppcustRelation> findByLpcomProposalOrderByLarId(LpcomProposal lpcomProposal);

	void deleteByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
	List<LpcustAppcustRelation> findByLpcomProposalAndLarTypeOrderByLarId(LpcomProposal lpcomProposal,String larType);
	LpcustAppcustRelation findByLpcomProposalAndLpcustApplicantData(LpcomProposal lpcomProposal,LpcustApplicantData lpcustApplicantData);

}
