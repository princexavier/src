package com.sai.lendperfect.application.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantIncexpens;
import com.sai.lendperfect.application.model.LpcustApplicantOblicat;
import com.sai.lendperfect.application.model.LpcustApplicantOtherexp;

import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcustApplicantOtherexpRepo extends JpaRepository<LpcustApplicantOtherexp, Long>{

	//List<LpcustOtherIncome> findByLadId(LpcustApplicantData lpcustApplicantData);
	//List<LpcustApplicantOtherexp> findByLaoeId(Long id);
	LpcustApplicantOtherexp findByLaoeId(Long id);
	List<LpcustApplicantOtherexp> findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
	
}
