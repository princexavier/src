package com.sai.lendperfect.application.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;

import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcustApplicantOtherIncomeRepo extends JpaRepository<LpcustApplicantOtherIncome, Long>{

	List<LpcustApplicantOtherIncome> findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
	LpcustApplicantOtherIncome findByLaoiId(Long id);
	
}
