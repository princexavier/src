package com.sai.lendperfect.application.repo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustApplicantEduDetail;
import com.sai.lendperfect.application.model.LpcustApplicantEduScholar;
import com.sai.lendperfect.commodel.LpcomProposal;



public interface LpcustApplicantEduScholarRepo extends JpaRepository<LpcustApplicantEduScholar, Serializable>{

	List<LpcustApplicantEduScholar> findByLpcomProposal(LpcomProposal lpcomProposal);
	LpcustApplicantEduScholar findByLaescEduScholarId(Long id);

}
