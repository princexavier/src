package com.sai.lendperfect.application.repo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantEduCourseExp;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpCourseExpenseRepo extends JpaRepository <LpcustApplicantEduCourseExp,Serializable>  {
	List<LpcustApplicantEduCourseExp> findByLpcomProposal(LpcomProposal lpcomProposal);
	List<LpcustApplicantEduCourseExp>findAllByLpcomProposal(LpcomProposal lpcomProposal);
}
