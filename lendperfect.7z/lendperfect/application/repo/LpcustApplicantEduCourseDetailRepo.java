package com.sai.lendperfect.application.repo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEduCourseDetail;
import com.sai.lendperfect.application.model.LpcustApplicantEduStudent;
import com.sai.lendperfect.application.model.LpcustApplicantEmployer;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.setupmodel.LpstpDelegatedPower;

public interface LpcustApplicantEduCourseDetailRepo extends JpaRepository<LpcustApplicantEduCourseDetail, Serializable>{

	LpcustApplicantEduCourseDetail findBylpcomProposal(LpcomProposal lpcomProposal);

}
