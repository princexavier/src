package com.sai.lendperfect.application.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.URL;

import org.springframework.core.io.ClassPathResource;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.html.HtmlTags;
import com.itextpdf.text.html.simpleparser.HTMLWorker;
import com.itextpdf.text.html.simpleparser.StyleSheet;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class PdfGenerator {
	
	public static boolean createPdfDoument(String htmlText,String filePath,String imageDirectory)
	{
		boolean returnFlag = false;
		try{
			returnFlag=true;
			OutputStream file = new FileOutputStream(new File(filePath));
		    Document document = new Document(PageSize.A4,20,20,80, 20);
			document.setMargins(30, 35, 40, 40);
			
			
		    PdfWriter writer = PdfWriter.getInstance(document, file);
		    document.open();
		  
		   PdfPTable table=null;
			PdfPCell cell=null;
			table=new PdfPTable(2);
			table.setWidthPercentage(100.0f);
			int[] widthterm = {50,50};
			table.setWidths(widthterm);
//			
//			
//			cell=new PdfPCell();
		
//		   Image imgCheck = Image.getInstance(imageDirectory);
//			//Image imgCheck = Image.getInstance("/lendperfect-war/src/main/webapp/PMCBLogo.png");
//			imgCheck.scalePercent(100);
//			imgCheck.setWidthPercentage(100);
//			imgCheck.scaleToFit(190,100);
//			imgCheck.setAlignment(imgCheck.ALIGN_RIGHT);
//			//cell.addElement(new Chunk(imgCheck, 0,-1, true));
//			cell=new PdfPCell(imgCheck,false);
//			cell.setBorder(0);
			
//			cell.setHorizontalAlignment(cell.ALIGN_RIGHT);
			//table.addCell(cell);
			
			Paragraph para = new Paragraph("PMC BANK",FontFactory.getFont(FontFactory.TIMES_ROMAN,20,Font.BOLD,new BaseColor(0,64,128)));
			cell=new PdfPCell(para);
			cell.setBorder(0);
			cell.setFixedHeight(50);
			cell.setPaddingTop(20);
			cell.setVerticalAlignment(cell.ALIGN_CENTER);
			cell.setHorizontalAlignment(cell.ALIGN_CENTER);
			table.addCell(cell);
			
			document.add(table);
		    
		    HTMLWorker htmlWorker = new HTMLWorker(document);
		    htmlWorker.setStyleSheet(GenerateStyleSheet());
		    htmlWorker.parse(new StringReader(htmlText));
		    document.close();
		    file.close();	
		}catch (Exception e) {
			returnFlag=false;
			e.printStackTrace();
		}
		return returnFlag;
	}
	
	 private static StyleSheet GenerateStyleSheet()
     {
         StyleSheet css = new StyleSheet();
         css.loadTagStyle(HtmlTags.TH, HtmlTags.FONTSIZE, "5");
         css.loadTagStyle(HtmlTags.TH, HtmlTags.FONTFAMILY, "TIMES_ROMAN");
         css.loadTagStyle(HtmlTags.TH, HtmlTags.BGCOLOR, "#f4f4f4");
         css.loadTagStyle(HtmlTags.TH, HtmlTags.ALIGN, "CENTER");
         css.loadTagStyle("th", "style", "font-weight: bold;font-size: 10px;word-wrap:nowrap;");
         
         css.loadTagStyle("td", "style", "padding-left:4px !important;font-weight: 300;font-size: 10px;word-wrap:nowrap;");
         css.loadTagStyle(HtmlTags.TD, HtmlTags.FONTSIZE, "10");
         css.loadTagStyle(HtmlTags.TD, HtmlTags.FONTFAMILY, "TIMES_ROMAN");
         return css;
     }
}
