package com.sai.lendperfect.application.util;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSetBorrMap;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.masterrepo.LpmasListofvalueRepo;



@Service("listOfValuesService")
@Transactional
public class ListOfValuesServiceImpl implements ListOfValuesService{

	@Autowired
	private ServiceProvider serviceProvider;
	
	@Autowired
	private LpmasListofvalueRepo lpmasListofvalueRepo;
	
	
	
	public List<LpcomSetBorrMap> getPrimaryApplicant(String borrowerType,BigDecimal proposalNo) {
		List<LpcomSetBorrMap> lpcomFacBorrMapList,borrowList=new ArrayList<LpcomSetBorrMap>();
		
		LpcomProposal LpcomProposal=serviceProvider.getLpcomProposalService().findByLpPropNo(proposalNo);
		lpcomFacBorrMapList=LpcomProposal.getLpcomSetBorrMaps();
		
		if(borrowerType.equalsIgnoreCase("B"))
		{	lpcomFacBorrMapList.forEach(BorrowerMap->{
				if(BorrowerMap.getLfbmBorrType().equalsIgnoreCase(borrowerType))
				{
					borrowList.add(BorrowerMap);
				}
	    	});
			
			
		}
		
		else if(borrowerType.equalsIgnoreCase("C"))
		{
			lpcomFacBorrMapList.forEach(BorrowerMap->{
				if(BorrowerMap.getLfbmBorrType().equalsIgnoreCase(borrowerType))
				{
					borrowList.add(BorrowerMap);
				}
	    	});	
			
		}
		
		else if(borrowerType.equalsIgnoreCase("G"))
		{
			lpcomFacBorrMapList.forEach(BorrowerMap->{
				if(BorrowerMap.getLfbmBorrType().equalsIgnoreCase(borrowerType))
				{
					borrowList.add(BorrowerMap);
				}
	    	});	
			
		}
		return borrowList;
		
	}

	public List<LpmasListofvalue> getOptionList(String llvHeader, String active) {
		List<LpmasListofvalue> lpmasListofvalue=null;
		if(active.equalsIgnoreCase("Y")|| active.equalsIgnoreCase("N")){
			lpmasListofvalue=lpmasListofvalueRepo.findByLlvHeaderAndLlvActive(llvHeader,active);
		}
		else
		lpmasListofvalue=lpmasListofvalueRepo.findByLlvHeader(llvHeader);
		return lpmasListofvalue;
	}

	@Override
	public List<Object> getCustomerName(BigDecimal lppLpCustId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LpmasListofvalue findByLlvOptionVal(String lprRelType) {
		return lpmasListofvalueRepo.findByLlvOptionVal(lprRelType);
	}

//	public List<Object> getCustomerName(BigDecimal lppLpCustId) {
//		List<Object> customerList=lpcomCustDataIndRepo.findByl(lppLpCustId);
//		return null;
//	}

		
}
