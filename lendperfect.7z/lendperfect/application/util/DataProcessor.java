package com.sai.lendperfect.application.util;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.sai.lendperfect.agri.agriReferenceDet.LpAgriReferenceDataProvider;
import com.sai.lendperfect.agri.curryearcroppattern.LpagriCurrCropPatternDataProvider;
import com.sai.lendperfect.agri.existingexposure.LpagriExistingExposureDataProvider;
import com.sai.lendperfect.agri.fleetdetails.LpagriFleetDetDataProvider;
import com.sai.lendperfect.agri.landdetails.LpagriLandDetailProvider;
import com.sai.lendperfect.agri.prevcroppattern.PrevCropPatternProvider;
import com.sai.lendperfect.app.applicantemployertype.LpcustApplicantEmployerProvider;
import com.sai.lendperfect.app.applicantlist.LpcomApplicantListDataProvider;
import com.sai.lendperfect.app.application.ApplicationProvider;
import com.sai.lendperfect.app.customerdetails.CustomerDetailsProvider;
import com.sai.lendperfect.app.educationcoursedetails.LpcustApplicantEduCourseDetailProvider;
import com.sai.lendperfect.app.educationloan.LpcustApplicantEduDetailProvider;
import com.sai.lendperfect.app.educationparticularsofstudent.LpcustApplicantEduStudentProvider;
import com.sai.lendperfect.app.eduscholarshipdetails.LpcustApplicantEduScholarProvider;
import com.sai.lendperfect.app.incexpenses.LpcustApplicantIncexpensProvider;
import com.sai.lendperfect.app.loandetails.LoanDetailsProvider;
import com.sai.lendperfect.app.oblirepay.LpcustApplicantOblicatProvider;
import com.sai.lendperfect.app.relation.ApplicationRelationProvider;
import com.sai.lendperfect.application.courseexpense.LpcomCourseExpenseDataProvider;
import com.sai.lendperfect.application.searchcriteria.SearchCriteriaDataProvider;
import com.sai.lendperfect.application.taxdetails.TaxDetailDataProvider;
import com.sai.lendperfect.cbs.cbsliabpulling.CbsLiabPullingDataProvider;
import com.sai.lendperfect.com.proposalcopmof.LpcomProposalCopmofDataProvider;
import com.sai.lendperfect.common.LpcomPropTermsCond.LpcomPropTermsCondDataProvider;
import com.sai.lendperfect.common.PropDocument.LpcomPropDocumentDataProvider;
import com.sai.lendperfect.common.PropRecommend.LpcomPropRecommendDataProvider;
import com.sai.lendperfect.common.Search.SearchDataProvider;
import com.sai.lendperfect.common.Search.StateCitySearchDataProvider;
import com.sai.lendperfect.common.additionalinfo.LpcomPropAdditionalInfoProvider;
import com.sai.lendperfect.common.bankingarrangement.BankingArrangementDataProvider;
import com.sai.lendperfect.common.borrowerrelationship.LpcomBorrowerRelationshipDataProvider;
import com.sai.lendperfect.common.businessapproval.LpcomBussApprovalDataProvider;
import com.sai.lendperfect.common.bybankdocument.ByBankDocumentProvider;
import com.sai.lendperfect.common.bybankdocument.BybankDocumentSearchProvider;
import com.sai.lendperfect.common.casecredit.LpcomCaseDetCreditProvider;
import com.sai.lendperfect.common.casesale.LpcomCaseDetSaleProvider;
import com.sai.lendperfect.common.chartreport.LpcomChartReportDataProvider;
import com.sai.lendperfect.common.combooffer.ComboOfferDataProvider;
import com.sai.lendperfect.common.cranformat.CranFormatDataProvider;
import com.sai.lendperfect.common.deviation.DeviationTrackingDataProvider;
import com.sai.lendperfect.common.exposuredet.LpcomExposureDetDataProvider;
import com.sai.lendperfect.common.externalvaluation.LpcomExternalValuationDataProvider;
import com.sai.lendperfect.common.facilityassessment.LpcomFacAssessmentDataProvider;
import com.sai.lendperfect.common.facilityborrowermapping.LpcomFacBorrMapDataProvider;
import com.sai.lendperfect.common.facilityrecommend.LpcomFacilityRecommendDataProvider;
import com.sai.lendperfect.common.internalvaluation.LpcomInternalValuationDataProvider;
import com.sai.lendperfect.common.ipletterdet.LpcomIpletterDetDataProvider;
import com.sai.lendperfect.common.legalverification.ExternalLegalReportDataProvider;
import com.sai.lendperfect.common.legalverification.LpcomLegalVerifcationDataProvider;
import com.sai.lendperfect.common.liabilities.LpcomLiabilitiesDataProvider;
import com.sai.lendperfect.common.login.LoginDataProvider;
import com.sai.lendperfect.common.mailbox.MailboxDataProvider;
import com.sai.lendperfect.common.otherassetsliability.LpcomOtherAssetsLiabilityDataProvider;
import com.sai.lendperfect.common.pagecomments.PageCommentsDataProvider;
import com.sai.lendperfect.common.prev3sanction.LpcomPrev3SanctionDataProvider;
import com.sai.lendperfect.common.proposal.NewProposalDataProvider;
import com.sai.lendperfect.common.proposalsearch.ExistingProposalSearchDataProvider;
import com.sai.lendperfect.common.proposalsecurities.ProposalSecuritiesDataProvider;
import com.sai.lendperfect.common.pslclassification.PSLClassificationDataProvider;
import com.sai.lendperfect.common.query.LpcomQueryMgmtDataProvider;
import com.sai.lendperfect.common.query.LpcomQueryRecipientDataProvider;
import com.sai.lendperfect.common.query.QueriesReceivedDataProvider;
import com.sai.lendperfect.common.query.QueryHistoryDataProvider;
import com.sai.lendperfect.common.query.ResponseReceivedDataProvider;
import com.sai.lendperfect.common.rbichecklist.RBICheckListDataProvider;
import com.sai.lendperfect.common.reallowcation.LpcomReallowcationDataProvider;
import com.sai.lendperfect.common.secbankdeposit.LpcomSecBankDepositDataProvider;
import com.sai.lendperfect.common.secfindocntrade.LpcomSecFindocNtradeDataProvider;
import com.sai.lendperfect.common.secfindoctrade.LpcomSecFindocTradeDataProvider;
import com.sai.lendperfect.common.secfurniture.LpcomSecFurnFixDetDataProvider;

import com.sai.lendperfect.common.secgoodsdetails.LpcomSecGoodsDetailDataProvider;
import com.sai.lendperfect.common.secjeweldetails.LpcomSecJewelDetDataProvider;
import com.sai.lendperfect.common.secplntmchnrydetail.LpcomSecPlntMchnryDetailDataProvider;
import com.sai.lendperfect.common.secproperty.LpcomSecPropertyDataProvider;
import com.sai.lendperfect.common.security.LpcomSecurityDataProvider;
import com.sai.lendperfect.common.securitycoverage.SecurityCoverageDataProvider;
import com.sai.lendperfect.common.secvehicledetail.LpcomSecVehicleDetailDataProvider;
import com.sai.lendperfect.common.shareholding.LpcomShareHoldingProvider;
import com.sai.lendperfect.common.sourcingdetails.SourcingDetailProvider;
import com.sai.lendperfect.common.takeoverchecklist.LpcomTakeoverChklistDataProvider;
import com.sai.lendperfect.common.tat.LpcomTatDataProvider;
import com.sai.lendperfect.common.technicalinbox.TechnicalInboxDataProvider;
import com.sai.lendperfect.common.technicalrequestform.TechnicalRequestFormDataProvider;
import com.sai.lendperfect.common.workflow.WorkflowDataProvider;
import com.sai.lendperfect.corporate.AccCondAnalysis2.LpcorpAccCondAnalysis2DataProvider;
import com.sai.lendperfect.corporate.DebtorsSale.LpcorpDebtorsSaleDataProvider;
import com.sai.lendperfect.corporate.acccondcmtannex.LpcorpAccCondCmtAnnexDataProvider;
import com.sai.lendperfect.corporate.bcacannex.LpcorpBcacAnnexDataProvider;
import com.sai.lendperfect.corporate.buyerseller.LpcorpBuyerSupplierDataProvider;
import com.sai.lendperfect.corporate.cirannex.LpcorpCirAnnexDataProvider;
import com.sai.lendperfect.corporate.compcpannex.LpcorpCompCpAnnexDataProvider;
import com.sai.lendperfect.corporate.compsheetannex.LpcorpCompSheetAnnexDataProvider;
import com.sai.lendperfect.corporate.corp26asGst.Lpcorp26asGstDataProvider;
import com.sai.lendperfect.corporate.corpModelSale.LpcorpModelSaleDataProvider;
import com.sai.lendperfect.corporate.cropdetails.LpcorpCropDetDataProvider;
import com.sai.lendperfect.corporate.customerdetails.PartyDetailsProvider;
//import com.sai.lendperfect.corporate.dynmassessmnt.LpcorpDynamicAssessmentDataProvider;
import com.sai.lendperfect.corporate.dynmassessmnt.LpcorpDynamicAssessmentDataProvider;
import com.sai.lendperfect.corporate.existingexposure.LpcorpExistingExposureDataProvider;
import com.sai.lendperfect.corporate.exposuredetails.LpcorpExposureDetailsDataProvider;
import com.sai.lendperfect.corporate.externalrating.LpcorpExtRatingDataProvider;
import com.sai.lendperfect.corporate.forexexpo.LpcorpForexExpoDataProvider;
import com.sai.lendperfect.corporate.guaranteedetails.LpcorpGuarnteeDetDataProvider;
import com.sai.lendperfect.corporate.landdetails.LpcorpLandDetailDataProvider;
import com.sai.lendperfect.corporate.partyotherinfo.PartyOtherInfoDataProvider;
import com.sai.lendperfect.corporate.rbipslclause.LpcorpRbiPslClauseDataProvider;
import com.sai.lendperfect.corporate.scorecalc.LpcomScorecardCalcDataProvider;
import com.sai.lendperfect.corporate.taprojectedsales.LpcorpTaProjectedSalesDataProvider;
import com.sai.lendperfect.corporate.taretail.LpcorpTaRetailDataProvider;
import com.sai.lendperfect.corporate.tasales.LpcorpTaSalesDataProvider;
import com.sai.lendperfect.corporate.wcanalysis.LpcorpWcAnalysisDataProvider;
import com.sai.lendperfect.corporate.wcchruncashflow.LpcorpChrunCfdetDataprovider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.master.YieldMaster.LpagriYieldMasterDataProvider;
import com.sai.lendperfect.master.listofvalues.ListValueMasterDataProvider;
import com.sai.lendperfect.master.lpmasProperty.LpmasPropertyDataProvider;
import com.sai.lendperfect.master.lpmasinterfacelink.LpmasInterfaceLinkDataProvider;
import com.sai.lendperfect.master.lpmasinterrcodes.LpmasIntErrCodeDataProvider;
import com.sai.lendperfect.master.psllov.PslLovDataProvider;
import com.sai.lendperfect.master.sof.LpmasSofDataProvider;
import com.sai.lendperfect.mobileapp.customercreation.CustomerCreationProvider;
import com.sai.lendperfect.setup.Document.LpstpDocumentDataProvider;
import com.sai.lendperfect.setup.PrdDocument.LpstpPrdDocDataProvider;
import com.sai.lendperfect.setup.PrdTermsCond.LpstpPrdTermsCondDataProvider;
import com.sai.lendperfect.setup.TermsCondtn.LpstpTermsCondtnDataProvider;
import com.sai.lendperfect.setup.annexuremaster.LpstpAnnexMasterDataProvider;
import com.sai.lendperfect.setup.assessmentengine.LpstpAssessmentDataProvider;
import com.sai.lendperfect.setup.bulletin.LpstpBulletInfoDataProvider;
import com.sai.lendperfect.setup.comboconfiguration.LpstpComboMasterDataProvider;
import com.sai.lendperfect.setup.concession.LpstpPrdConcessionDataProvider;
import com.sai.lendperfect.setup.cranformat.CranMasterDataProvider;
import com.sai.lendperfect.setup.delegatedpowers.LpstpDelegatedPowersDataProvider;
import com.sai.lendperfect.setup.deviation.LpstpDeviationDataProvider;
import com.sai.lendperfect.setup.documentfee.LpstpPrdDocFeeDataProvider;
import com.sai.lendperfect.setup.documenttemplate.LpstpDocumentTemplateProvider;
import com.sai.lendperfect.setup.facilitymaster.LpstpFacilityDataProvider;
import com.sai.lendperfect.setup.financialmaster.FinancialMasterDataprovider;
import com.sai.lendperfect.setup.finformula.CMAFormulaDataProvider;
import com.sai.lendperfect.setup.finmaster.FinMasterDataProvider;
import com.sai.lendperfect.setup.interestrate.LpstpPrdIntRateDataProvider;
import com.sai.lendperfect.setup.lpstpdelegationrepo.LpstpDelegationDataProvider;
import com.sai.lendperfect.setup.lpstpprdcoapguacount.LpstpPrdCoapguarcountProvider;
import com.sai.lendperfect.setup.mailtemplate.LpstpMailTemplateProvider;
import com.sai.lendperfect.setup.margin.LpstpPrdMarginDataProvider;
import com.sai.lendperfect.setup.organisation.OrganisationDataProvider;
import com.sai.lendperfect.setup.organisation_lpstp.LpstpOrganisationDataProvider;
import com.sai.lendperfect.setup.organization.SetOrganisationDataProvider;
import com.sai.lendperfect.setup.organizationlevel.OrganizationLevelDataProvider;
import com.sai.lendperfect.setup.orgmapping.LpstpOrgMappingDataProvider;
import com.sai.lendperfect.setup.prdannexure.ProductAnnexureProvider;
import com.sai.lendperfect.setup.prdassessment.LpstpPrdAssmentDataProvider;
import com.sai.lendperfect.setup.processingfee.LpstpPrdProFeeDataProvider;
import com.sai.lendperfect.setup.productdetails.LpstpProductDataProvider;
import com.sai.lendperfect.setup.productsearch.LpstpProductSearchDataProvider;
import com.sai.lendperfect.setup.pslmaster.PSLMasterDataProvider;
import com.sai.lendperfect.setup.qualitativemaster.QualitativeMasterDataprovider;
import com.sai.lendperfect.setup.repaymentcapacity.LpstpPrdRepaymentCapacityDataProvider;
import com.sai.lendperfect.setup.schememaster.LpstpSchemeDataProvider;
import com.sai.lendperfect.setup.scorecardbusinessrule.ScoreCardBusinessRuleDataProvider;
/*import com.sai.lendperfect.setup.rbichecklist.RbiCheckListDataProvider;
*/
import com.sai.lendperfect.setup.scorecardmaster.ScorecardMasterDataProvider;
import com.sai.lendperfect.setup.securitymaster.LpstpSecurityDataProvider;
import com.sai.lendperfect.setup.stgeographymaster.StGeographyMasterDataProvider;
import com.sai.lendperfect.setup.takeoverchecklist.LpstpTakeoverChklistDataProvider;
import com.sai.lendperfect.setup.usersgroup.UserGroupDataProvider;
import com.sai.lendperfect.master.quicklinks.LpmasQuickLinkDataProvider;
import com.sai.lendperfect.setup.user.LpstpUserDataProvider;
import com.sai.lendperfect.setup.userclass.UserClassDataProvider;
import com.sai.lendperfect.setup.workflowmaster.LpstpWorkflowDataProvider;
import com.sai.lendperfect.webservice.bcifcreation.BcifCreationDataProvider;
import com.sai.lendperfect.webservice.cibilservice.CibilServiceDataProvider;
import com.sai.lendperfect.webservice.leadservice.LeadServiceDataProvider;
import com.sai.lendperfect.webservice.leadservicestatus.LeadStatusCheckDataProvider;
import com.sai.lendperfect.webservice.ncifcreation.NcifDataProvider;

public class DataProcessor {

	public Map<String, ?> process(String dpClass, String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData, ServiceProvider serviceProvider, Logging logging) throws ParseException {

		Map<String, ?> dpMap = null;

		switch (dpClass)

		{

		case "LpcustApplicantIncexpensProvider":
			LpcustApplicantIncexpensProvider lpcustApplicantIncexpensProvider = new LpcustApplicantIncexpensProvider();
			dpMap = lpcustApplicantIncexpensProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcustApplicantOblicatProvider":
			LpcustApplicantOblicatProvider lpcustApplicantOblicatProvider = new LpcustApplicantOblicatProvider();
			dpMap = lpcustApplicantOblicatProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcustApplicantEduScholarProvider":

			LpcustApplicantEduScholarProvider lpcustApplicantEduScholarProvider = new LpcustApplicantEduScholarProvider();

			dpMap = lpcustApplicantEduScholarProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcustApplicantEduDetailProvider":

			LpcustApplicantEduDetailProvider lpcustApplicantEduDetailProvider = new LpcustApplicantEduDetailProvider();
			dpMap = lpcustApplicantEduDetailProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "ExistingProposalSearchDataProvider":

			ExistingProposalSearchDataProvider existingProposalSearchDataProvider = new ExistingProposalSearchDataProvider();
			dpMap = existingProposalSearchDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "UserGroupDataProvider":

			UserGroupDataProvider userGroupDataProvider = new UserGroupDataProvider();

			dpMap = userGroupDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "BybankDocumentSearchProvider":
			BybankDocumentSearchProvider bybankDocumentSearchProvider = new BybankDocumentSearchProvider();
			dpMap = bybankDocumentSearchProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "FinMasterDataProvider":

			FinMasterDataProvider finMasterDataProvider = new FinMasterDataProvider();

			dpMap = finMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "OrganizationLevelDataProvider":

			OrganizationLevelDataProvider organizationLevelDataProvider = new OrganizationLevelDataProvider();

			dpMap = organizationLevelDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "SetOrganisationDataProvider":

			SetOrganisationDataProvider setOrganisationDataProvider = new SetOrganisationDataProvider();

			dpMap = setOrganisationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "ScorecardMasterDataProvider":

			ScorecardMasterDataProvider scorecardMasterDataProvider = new ScorecardMasterDataProvider();

			dpMap = scorecardMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "QualitativeMasterDataprovider":

			QualitativeMasterDataprovider qualitativeMasterDataprovider = new QualitativeMasterDataprovider();

			dpMap = qualitativeMasterDataprovider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LoginDataProvider":

			LoginDataProvider loginDataProvider = new LoginDataProvider();

			dpMap = loginDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "LpcomCourseExpenseDataProvider":

			LpcomCourseExpenseDataProvider lpcomCourseExpenseDataProvider = new LpcomCourseExpenseDataProvider();

			dpMap = lpcomCourseExpenseDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "PrevCropPatternProvider":

			PrevCropPatternProvider prevCropPatternProvider = new PrevCropPatternProvider();

			dpMap = prevCropPatternProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpagriLandDetailProvider":

			LpagriLandDetailProvider lpagriLandDetailProvider = new LpagriLandDetailProvider();

			dpMap = lpagriLandDetailProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpWcAnalysisDataProvider":

			LpcorpWcAnalysisDataProvider lpcorpWcAnalysisDataProvider = new LpcorpWcAnalysisDataProvider();

			dpMap = lpcorpWcAnalysisDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "LpcorpChrunCfdetDataprovider":

			LpcorpChrunCfdetDataprovider lpcorpChrunCfdetDataprovider = new LpcorpChrunCfdetDataprovider();

			dpMap = lpcorpChrunCfdetDataprovider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "LpcorpExtRatingDataProvider":

			LpcorpExtRatingDataProvider lpcorpExtRatingDataProvider = new LpcorpExtRatingDataProvider();

			dpMap = lpcorpExtRatingDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpagriCurrCropPatternDataProvider":

			LpagriCurrCropPatternDataProvider lpagriCurrCropPatternDataProvider = new LpagriCurrCropPatternDataProvider();

			dpMap = lpagriCurrCropPatternDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomProposalCopmofDataProvider":

			LpcomProposalCopmofDataProvider lpcomProposalCopmofDataProvider = new LpcomProposalCopmofDataProvider();

			dpMap = lpcomProposalCopmofDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "StGeographyMasterDataProvider":

			StGeographyMasterDataProvider stGeographyMasterDataProvider = new StGeographyMasterDataProvider();

			dpMap = stGeographyMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "SourcingDetailProvider":

			SourcingDetailProvider sourcingDetailProvider = new SourcingDetailProvider();

			dpMap = sourcingDetailProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpagriFleetDetDataProvider":

			LpagriFleetDetDataProvider lpagriFleetDetDataProvider = new LpagriFleetDetDataProvider();

			dpMap = lpagriFleetDetDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpAgriReferenceDataProvider":

			LpAgriReferenceDataProvider LpAgriReferenceDataProvider = new LpAgriReferenceDataProvider();

			dpMap = LpAgriReferenceDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpagriYieldMasterDataProvider":

			LpagriYieldMasterDataProvider LpagriYieldMasterDataProvider = new LpagriYieldMasterDataProvider();
			dpMap = LpagriYieldMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "HomeDataProvider":

			HomeDataProvider homeDataProvider = new HomeDataProvider();

			dpMap = homeDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpModelSaleDataProvider":

			LpcorpModelSaleDataProvider LpcorpModelSaleDataProvider = new LpcorpModelSaleDataProvider();

			dpMap = LpcorpModelSaleDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpDebtorsSaleDataProvider":

			LpcorpDebtorsSaleDataProvider LpcorpDebtorsSaleDataProvider = new LpcorpDebtorsSaleDataProvider();

			dpMap = LpcorpDebtorsSaleDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpTermsCondtnDataProvider":

			LpstpTermsCondtnDataProvider LpstpTermsCondtnDataProvider = new LpstpTermsCondtnDataProvider();

			dpMap = LpstpTermsCondtnDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "MailTemplateProvider":

			LpstpMailTemplateProvider mailTemplateProvider = new LpstpMailTemplateProvider();

			dpMap = mailTemplateProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpagriExistingExposureDataProvider":

			LpagriExistingExposureDataProvider lpagriExistingExposureDataProvider = new LpagriExistingExposureDataProvider();

			dpMap = lpagriExistingExposureDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomCaseDetSaleProvider":

			LpcomCaseDetSaleProvider lpcomCaseDetSaleProvider = new LpcomCaseDetSaleProvider();

			dpMap = lpcomCaseDetSaleProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomCaseDetCreditProvider":

			LpcomCaseDetCreditProvider lpcomCaseDetCreditProvider = new LpcomCaseDetCreditProvider();

			dpMap = lpcomCaseDetCreditProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomShareHoldingProvider":

			LpcomShareHoldingProvider lpcomShareHoldingProvider = new LpcomShareHoldingProvider();

			dpMap = lpcomShareHoldingProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpFacilityDataProvider":

			LpstpFacilityDataProvider lpstpFacilityDataProvider = new LpstpFacilityDataProvider();

			dpMap = lpstpFacilityDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpLandDetailDataProvider":
			LpcorpLandDetailDataProvider lpcorpLandDetailDataProvider = new LpcorpLandDetailDataProvider();

			dpMap = lpcorpLandDetailDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpCropDetDataProvider":

			LpcorpCropDetDataProvider lpcorpCropDetDataProvider = new LpcorpCropDetDataProvider();

			dpMap = lpcorpCropDetDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpGuarnteeDetDataProvider":

			LpcorpGuarnteeDetDataProvider lpcorpGuarnteeDetDataProvider = new LpcorpGuarnteeDetDataProvider();

			dpMap = lpcorpGuarnteeDetDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpTakeoverChklistDataProvider":

			LpstpTakeoverChklistDataProvider lpstpTakeoverChklistDataProvider = new LpstpTakeoverChklistDataProvider();

			dpMap = lpstpTakeoverChklistDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomTakeoverChklistDataProvider":

			LpcomTakeoverChklistDataProvider lpcomTakeoverChklistDataProvider = new LpcomTakeoverChklistDataProvider();

			dpMap = lpcomTakeoverChklistDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpExistingExposureDataProvider":

			LpcorpExistingExposureDataProvider lpcorpExistingExposureDataProvider = new LpcorpExistingExposureDataProvider();

			dpMap = lpcorpExistingExposureDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "PartyDetailsProvider":

			PartyDetailsProvider PartyDetailsProvider = new PartyDetailsProvider();

			dpMap = PartyDetailsProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecurityDataProvider":

			LpcomSecurityDataProvider lpcomSecurityDataProvider = new LpcomSecurityDataProvider();

			dpMap = lpcomSecurityDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecPropertyDataProvider":

			LpcomSecPropertyDataProvider lpcomSecPropertyDataProvider = new LpcomSecPropertyDataProvider();

			dpMap = lpcomSecPropertyDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecFindocTradeDataProvider":

			LpcomSecFindocTradeDataProvider lpcomSecFindocTradeDataProvider = new LpcomSecFindocTradeDataProvider();

			dpMap = lpcomSecFindocTradeDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecFindocNtradeDataProvider":

			LpcomSecFindocNtradeDataProvider lpcomSecFindocNtradeDataProvider = new LpcomSecFindocNtradeDataProvider();

			dpMap = lpcomSecFindocNtradeDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecBankDepositDataProvider":

			LpcomSecBankDepositDataProvider lpcomSecBankDepositDataProvider = new LpcomSecBankDepositDataProvider();

			dpMap = lpcomSecBankDepositDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecFurnFixDetDataProvider":

			LpcomSecFurnFixDetDataProvider lpcomSecFurnFixDetDataProvider = new LpcomSecFurnFixDetDataProvider();

			dpMap = lpcomSecFurnFixDetDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomVehicleDetailDataProvider":

			LpcomSecVehicleDetailDataProvider lpcomVehicleDetailDataProvider = new LpcomSecVehicleDetailDataProvider();

			dpMap = lpcomVehicleDetailDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecJewelDetDataProvider":

			LpcomSecJewelDetDataProvider lpcomSecJewelDetDataProvider = new LpcomSecJewelDetDataProvider();

			dpMap = lpcomSecJewelDetDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpAccCondAnalysis2DataProvider":

			LpcorpAccCondAnalysis2DataProvider LpcorpAccCondAnalysis2DataProvider = new LpcorpAccCondAnalysis2DataProvider();

			dpMap = LpcorpAccCondAnalysis2DataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecPlntMchnryDetailDataProvider":
			LpcomSecPlntMchnryDetailDataProvider lpcomSecPlntMchnryDetailDataProvider = new LpcomSecPlntMchnryDetailDataProvider();

			dpMap = lpcomSecPlntMchnryDetailDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomSecGoodsDetailDataProvider":

			LpcomSecGoodsDetailDataProvider lpcomSecGoodsDetailDataProvider = new LpcomSecGoodsDetailDataProvider();

			dpMap = lpcomSecGoodsDetailDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "SearchDataProvider":

			SearchDataProvider SearchDataProvider = new SearchDataProvider();

			dpMap = SearchDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpDocumentDataProvider":

			LpstpDocumentDataProvider LpstpDocumentDataProvider = new LpstpDocumentDataProvider();

			dpMap = LpstpDocumentDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomPropDocumentDataProvider":

			LpcomPropDocumentDataProvider LpcomPropDocumentDataProvider = new LpcomPropDocumentDataProvider();

			dpMap = LpcomPropDocumentDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpBuyerSupplierDataProvider":

			LpcorpBuyerSupplierDataProvider lpcorpBuyerSupplierDataProvider = new LpcorpBuyerSupplierDataProvider();

			dpMap = lpcorpBuyerSupplierDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpForexExpoDataProvider":

			LpcorpForexExpoDataProvider lpcorpForexExpoDataProvider = new LpcorpForexExpoDataProvider();

			dpMap = lpcorpForexExpoDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpProductDataProvider":

			LpstpProductDataProvider lpstpProductDataProvider = new LpstpProductDataProvider();

			dpMap = lpstpProductDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpPrdIntRateDataProvider":

			LpstpPrdIntRateDataProvider lpstpPrdIntRateDataProvider = new LpstpPrdIntRateDataProvider();

			dpMap = lpstpPrdIntRateDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpAnnexMasterDataProvider":

			LpstpAnnexMasterDataProvider lpstpAnnexMasterDataProvider = new LpstpAnnexMasterDataProvider();

			dpMap = lpstpAnnexMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "LpcorpExposureDetailsDataProvider":

			LpcorpExposureDetailsDataProvider lpcorpExposureDetailsDataProvider = new LpcorpExposureDetailsDataProvider();

			dpMap = lpcorpExposureDetailsDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "Lpcorp26asGstDataProvider":

			Lpcorp26asGstDataProvider Lpcorp26asGstDataProvider = new Lpcorp26asGstDataProvider();

			dpMap = Lpcorp26asGstDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "BankingArrangementDataProvider":

			BankingArrangementDataProvider bankingArrangementDataProvider = new BankingArrangementDataProvider();

			dpMap = bankingArrangementDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpPrdTermsCondDataProvider":

			LpstpPrdTermsCondDataProvider LpstpPrdTermsCondDataProvider = new LpstpPrdTermsCondDataProvider();

			dpMap = LpstpPrdTermsCondDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpCirAnnexDataProvider":

			LpcorpCirAnnexDataProvider lpcorpCirAnnexDataProvider = new LpcorpCirAnnexDataProvider();

			dpMap = lpcorpCirAnnexDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpCompSheetAnnexDataProvider":

			LpcorpCompSheetAnnexDataProvider lpcorpCompSheetAnnexDataProvider = new LpcorpCompSheetAnnexDataProvider();

			dpMap = lpcorpCompSheetAnnexDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpBcacAnnexDataProvider":

			LpcorpBcacAnnexDataProvider lpcorpBcacAnnexDataProvider = new LpcorpBcacAnnexDataProvider();
			dpMap = lpcorpBcacAnnexDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpCompCpAnnexDataProvider":

			LpcorpCompCpAnnexDataProvider lpcorpCompCpAnnexDataProvider = new LpcorpCompCpAnnexDataProvider();

			dpMap = lpcorpCompCpAnnexDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpAccCondCmtAnnexDataProvider":

			LpcorpAccCondCmtAnnexDataProvider lpcorpAccCondCmtAnnexDataProvider = new LpcorpAccCondCmtAnnexDataProvider();

			dpMap = lpcorpAccCondCmtAnnexDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpSecurityDataProvider":

			LpstpSecurityDataProvider lpstpSecurityDataProvider = new LpstpSecurityDataProvider();

			dpMap = lpstpSecurityDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpPrdDocDataProvider":

			LpstpPrdDocDataProvider LpstpPrdDocDataProvider = new LpstpPrdDocDataProvider();

			dpMap = LpstpPrdDocDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "LpcomFacBorrMapDataProvider":

			LpcomFacBorrMapDataProvider LpcomFacBorrMapDataProvider = new LpcomFacBorrMapDataProvider();

			dpMap = LpcomFacBorrMapDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "PartyOtherInfoDataProvider":

			PartyOtherInfoDataProvider partyOtherInfoDataProvider = new PartyOtherInfoDataProvider();

			dpMap = partyOtherInfoDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcorpDynamicAssessmentDataProvider":

			LpcorpDynamicAssessmentDataProvider lpcorpDynamicAssessmentDataProvider = new LpcorpDynamicAssessmentDataProvider();

			dpMap = lpcorpDynamicAssessmentDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpUserDataProvider":

			LpstpUserDataProvider LpstpUserDataProvider = new LpstpUserDataProvider();

			dpMap = LpstpUserDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "FinancialMasterDataprovider":

			FinancialMasterDataprovider financialMasterDataprovider = new FinancialMasterDataprovider();

			dpMap = financialMasterDataprovider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "CMAFormulaDataProvider":

			CMAFormulaDataProvider cMAFormulaDataProvider = new CMAFormulaDataProvider();

			dpMap = cMAFormulaDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpWorkflowDataProvider":

			LpstpWorkflowDataProvider LpstpWorkflowDataProvider = new LpstpWorkflowDataProvider();
			dpMap = LpstpWorkflowDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "NewProposalDataProvider":

			NewProposalDataProvider newProposalDataProvider = new NewProposalDataProvider();
			dpMap = newProposalDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomPropRecommendDataProvider":

			LpcomPropRecommendDataProvider lpcomPropRecommendDataProvider = new LpcomPropRecommendDataProvider();
			dpMap = lpcomPropRecommendDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomPropAdditionalInfoProvider":

			LpcomPropAdditionalInfoProvider LpcomPropAdditionalInfoProvider = new LpcomPropAdditionalInfoProvider();

			dpMap = LpcomPropAdditionalInfoProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "CranFormatDataProvider":

			CranFormatDataProvider cranFormatDataProvider = new CranFormatDataProvider();

			dpMap = cranFormatDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomFacilityRecommendDataProvider":

			LpcomFacilityRecommendDataProvider LpcomFacilityRecommendDataProvider = new LpcomFacilityRecommendDataProvider();

			dpMap = LpcomFacilityRecommendDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpSchemeDataProvider":

			LpstpSchemeDataProvider LpstpSchemeDataProvider = new LpstpSchemeDataProvider();
			dpMap = LpstpSchemeDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "ListValueMasterDataProvider":

			ListValueMasterDataProvider listValueMasterDataProvider = new ListValueMasterDataProvider();
			dpMap = listValueMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomQueryDataProvider":

			// LpcomQueryDataProvider lpcomQueryDataProvider=new
			// LpcomQueryDataProvider();
			// dpMap=lpcomQueryDataProvider.getData(dpMethod, session,
			// allRequestParams,masterData, serviceProvider, logging);

			break;

		case "MailboxDataProvider":

			MailboxDataProvider mailboxDataProvider = new MailboxDataProvider();
			dpMap = mailboxDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpDelegationDataProvider":

			LpstpDelegationDataProvider lpstpDelegationDataProvider = new LpstpDelegationDataProvider();

			dpMap = lpstpDelegationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomQueryRecipientDataProvider":

			LpcomQueryRecipientDataProvider lpcomQueryRecipientDataProvider = new LpcomQueryRecipientDataProvider();

			dpMap = lpcomQueryRecipientDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "ProposalSecuritiesDataProvider":

			ProposalSecuritiesDataProvider proposalSecuritiesDataProvider = new ProposalSecuritiesDataProvider();

			dpMap = proposalSecuritiesDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "CranMasterDataProvider":

			CranMasterDataProvider cranMasterDataProvider = new CranMasterDataProvider();
			dpMap = cranMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "PageCommentsDataProvider":

			PageCommentsDataProvider PageCommentsDataProvider = new PageCommentsDataProvider();
			dpMap = PageCommentsDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpAssessmentDataProvider":

			LpstpAssessmentDataProvider lpstpAssessmentDataProvider = new LpstpAssessmentDataProvider();
			dpMap = lpstpAssessmentDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "QueryHistoryDataProvider":

			QueryHistoryDataProvider queryHistoryDataProvider = new QueryHistoryDataProvider();
			dpMap = queryHistoryDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpPrdAssmentDataProvider":
			LpstpPrdAssmentDataProvider lpstpPrdAssmentDataProvider = new LpstpPrdAssmentDataProvider();
			dpMap = lpstpPrdAssmentDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcomFacAssessmentDataProvider":
			LpcomFacAssessmentDataProvider lpcomFacAssessmentDataProvider = new LpcomFacAssessmentDataProvider();
			dpMap = lpcomFacAssessmentDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpstpDeviationDataProvider":

			LpstpDeviationDataProvider lpstpDeviationDataProvider = new LpstpDeviationDataProvider();
			dpMap = lpstpDeviationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "DeviationTrackingDataProvider":

			DeviationTrackingDataProvider deviationTrackingDataProvider = new DeviationTrackingDataProvider();
			dpMap = deviationTrackingDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "HeaderPageNavigationDataProvider":

			HeaderPageNavigationDataProvider headerPageNavigationDataProvider = new HeaderPageNavigationDataProvider();
			dpMap = headerPageNavigationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "LpcomIpletterDetDataProvider":

			LpcomIpletterDetDataProvider lpcomIpletterDetDataProvider = new LpcomIpletterDetDataProvider();
			dpMap = lpcomIpletterDetDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcorpRbiPslClauseDataProvider":

			LpcorpRbiPslClauseDataProvider lpcorpRbiPslClauseDataProvider = new LpcorpRbiPslClauseDataProvider();
			dpMap = lpcorpRbiPslClauseDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpcomQueryMgmtDataProvider":

			LpcomQueryMgmtDataProvider lpcomQueryMgmtDataProvider = new LpcomQueryMgmtDataProvider();
			dpMap = lpcomQueryMgmtDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "ResponseReceivedDataProvider":

			ResponseReceivedDataProvider responseReceivedDataProvider = new ResponseReceivedDataProvider();
			dpMap = responseReceivedDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "QueriesReceivedDataProvider":

			QueriesReceivedDataProvider queriesReceivedDataProvider = new QueriesReceivedDataProvider();
			dpMap = queriesReceivedDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpstpOrgMappingDataProvider":
			LpstpOrgMappingDataProvider lpstpOrgMappingDataProvider = new LpstpOrgMappingDataProvider();
			dpMap = lpstpOrgMappingDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpmasInterfaceLinkDataProvider":
			LpmasInterfaceLinkDataProvider LpmasInterfaceLinkDataProvider = new LpmasInterfaceLinkDataProvider();
			dpMap = LpmasInterfaceLinkDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "PslLovDataProvider":
			PslLovDataProvider pslLovDataProvider = new PslLovDataProvider();
			dpMap = pslLovDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcomBorrowerRelationshipDataProvider":

			LpcomBorrowerRelationshipDataProvider lpcomBorrowerRelationshipDataProvider = new LpcomBorrowerRelationshipDataProvider();
			dpMap = lpcomBorrowerRelationshipDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "PSLMasterDataProvider":
			PSLMasterDataProvider pSLMasterDataProvider = new PSLMasterDataProvider();
			dpMap = pSLMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpstpOrganisationDataProvider":
			LpstpOrganisationDataProvider lpstpOrganisationDataProvider = new LpstpOrganisationDataProvider();
			dpMap = lpstpOrganisationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "SecurityCoverageDataProvider":
			SecurityCoverageDataProvider securityCoverageDataProvider = new SecurityCoverageDataProvider();
			dpMap = securityCoverageDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "PSLClassificationDataProvider":
			PSLClassificationDataProvider pSLClassificationDataProvider = new PSLClassificationDataProvider();
			dpMap = pSLClassificationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcomPrev3SanctionDataProvider":
			LpcomPrev3SanctionDataProvider lpcomPrev3SanctionDataProvider = new LpcomPrev3SanctionDataProvider();
			dpMap = lpcomPrev3SanctionDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "UserClassDataProvider":
			UserClassDataProvider userClassDataProvider = new UserClassDataProvider();
			dpMap = userClassDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcomExposureDetDataProvider":
			LpcomExposureDetDataProvider lpcomExposureDetDataProvider = new LpcomExposureDetDataProvider();
			dpMap = lpcomExposureDetDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpstpProductSearchDataProvider":
			LpstpProductSearchDataProvider lpstpProductSearchDataProvider = new LpstpProductSearchDataProvider();
			dpMap = lpstpProductSearchDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcorpTaSalesDataProvider":
			LpcorpTaSalesDataProvider lpcorpTaSalesDataProvider = new LpcorpTaSalesDataProvider();
			dpMap = lpcorpTaSalesDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcorpTaRetailDataProvider":
			LpcorpTaRetailDataProvider lpcorpTaRetailDataProvider = new LpcorpTaRetailDataProvider();
			dpMap = lpcorpTaRetailDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcorpTaProjectedSalesDataProvider":
			LpcorpTaProjectedSalesDataProvider lpcorpTaProjectedSalesDataProvider = new LpcorpTaProjectedSalesDataProvider();
			dpMap = lpcorpTaProjectedSalesDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "RBICheckListDataProvider":
			RBICheckListDataProvider rbidataObj = new RBICheckListDataProvider();
			dpMap = rbidataObj.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "WorkflowDataProvider":

			WorkflowDataProvider workflowDataProvider = new WorkflowDataProvider();

			dpMap = workflowDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "NcifDataProvider":
			System.out.println("****************** Addressing Ncif_DataProvider  ******************** ");
			NcifDataProvider ncifProvider = new NcifDataProvider();
			dpMap = ncifProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "BcifCreationDataProvider":
			System.out.println("****************** Addressing BcifCreationDataProvider  ******************** ");
			BcifCreationDataProvider bcifDataProvider = new BcifCreationDataProvider();
			dpMap = bcifDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LeadServiceDataProvider":
			System.out.println("****************** Addressing LeadServiceDataProvider  ******************** ");
			LeadServiceDataProvider leadServiceDataProvider = new LeadServiceDataProvider();
			dpMap = leadServiceDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "LeadStatusCheckDataProvider":
			System.out.println("****************** Addressing LeadStatusCheckDataProvider  ******************** ");
			LeadStatusCheckDataProvider leadStatusCheckDataProvider = new LeadStatusCheckDataProvider();
			dpMap = leadStatusCheckDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "CibilServiceDataProvider":
			System.out.println("****************** Addressing CibilIndivualServiceDataProvider  ******************** ");
			CibilServiceDataProvider cibilServiceDataProvider = new CibilServiceDataProvider();
			dpMap = cibilServiceDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpmasPropertyDataProvider":

			LpmasPropertyDataProvider lpmasPropertyDataProvider = new LpmasPropertyDataProvider();

			dpMap = lpmasPropertyDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "LpmasIntErrCodeDataProvider":
			LpmasIntErrCodeDataProvider lpmasIntErrCodeDataProvider = new LpmasIntErrCodeDataProvider();
			dpMap = lpmasIntErrCodeDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpmasSofDataProvider":
			LpmasSofDataProvider lpmasSofDataProvider = new LpmasSofDataProvider();
			dpMap = lpmasSofDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcomBussApprovalDataProvider":

			LpcomBussApprovalDataProvider lpcomBussApprovalDataProvider = new LpcomBussApprovalDataProvider();
			dpMap = lpcomBussApprovalDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;

		case "CustomerDetailsProvider":
			CustomerDetailsProvider customerDetailsProvider = new CustomerDetailsProvider();
			dpMap = customerDetailsProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LoanDetailsProvider":
			LoanDetailsProvider loanDetailsProvider = new LoanDetailsProvider();
			dpMap = loanDetailsProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "ApplicationRelationProvider":
			ApplicationRelationProvider applicationRelationProvider = new ApplicationRelationProvider();
			dpMap = applicationRelationProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "ApplicationProvider":
			ApplicationProvider applicationProvider = new ApplicationProvider();
			dpMap = applicationProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpstpPrdDocFeeDataProvider":
			LpstpPrdDocFeeDataProvider lpstpPrdDocFeeDataProvider = new LpstpPrdDocFeeDataProvider();
			dpMap = lpstpPrdDocFeeDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpstpPrdMarginDataProvider":
			LpstpPrdMarginDataProvider lpstpPrdMarginDataProvider = new LpstpPrdMarginDataProvider();
			dpMap = lpstpPrdMarginDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpstpPrdProFeeDataProvider":

			LpstpPrdProFeeDataProvider lpstpPrdProFeeDataProvider = new LpstpPrdProFeeDataProvider();
			dpMap = lpstpPrdProFeeDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcomLiabilitiesDataProvider":
			LpcomLiabilitiesDataProvider lpcomLiabilitiesDataProvider = new LpcomLiabilitiesDataProvider();
			dpMap = lpcomLiabilitiesDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "LpcomOtherAssetsLiabilityDataProvider":
			LpcomOtherAssetsLiabilityDataProvider lpcomOtherAssetsLiabilityDataProvider = new LpcomOtherAssetsLiabilityDataProvider();
			dpMap = lpcomOtherAssetsLiabilityDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "LpcomApplicantListDataProvider":
			LpcomApplicantListDataProvider lpcomApplicantListDataProvider = new LpcomApplicantListDataProvider();
			dpMap = lpcomApplicantListDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "CbsLiabPullingDataProvider":
			CbsLiabPullingDataProvider cbsLiabPullingDataProvider = new CbsLiabPullingDataProvider();
			dpMap = cbsLiabPullingDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpstpPrdCoapguarcountProvider":
			LpstpPrdCoapguarcountProvider lpstpPrdCoapguarcountProvider = new LpstpPrdCoapguarcountProvider();
			dpMap = lpstpPrdCoapguarcountProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "ByBankDocumentProvider":
			ByBankDocumentProvider byBankDocumentProvider = new ByBankDocumentProvider();
			dpMap = byBankDocumentProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcomPropTermsCondDataProvider":
			LpcomPropTermsCondDataProvider lpcomPropTermsCondDataProvider = new LpcomPropTermsCondDataProvider();
			dpMap = lpcomPropTermsCondDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		
    	case "LpmasQuickLinkDataProvider":  
    		LpmasQuickLinkDataProvider lpmasQuickLinkDataProvider=new LpmasQuickLinkDataProvider(); 
			dpMap=lpmasQuickLinkDataProvider.getData(dpMethod,session,allRequestParams,masterData,serviceProvider,logging);  
		break;
		
    	case "LpcomExternalValuationDataProvider":  
    		LpcomExternalValuationDataProvider lpcomExternalValuationDataProvider=new LpcomExternalValuationDataProvider(); 
			dpMap=lpcomExternalValuationDataProvider.getData(dpMethod,session,allRequestParams,masterData,serviceProvider,logging);  
		break;
		
    	case "TechnicalRequestFormDataProvider":  
    		TechnicalRequestFormDataProvider technicalRequestFormDataProvider=new TechnicalRequestFormDataProvider(); 
			dpMap=technicalRequestFormDataProvider.getData(dpMethod,session,allRequestParams,masterData,serviceProvider,logging);  
		break;
		
    	case "LpcomInternalValuationDataProvider":  
    		LpcomInternalValuationDataProvider lpcomInternalValuationDataProvider=new LpcomInternalValuationDataProvider(); 
			dpMap=lpcomInternalValuationDataProvider.getData(dpMethod,session,allRequestParams,masterData,serviceProvider,logging);  
		break;
		
    	case "TechnicalInboxDataProvider":  
    		TechnicalInboxDataProvider technicalInboxDataProvider=new TechnicalInboxDataProvider(); 
			dpMap=technicalInboxDataProvider.getData(dpMethod,session,allRequestParams,masterData,serviceProvider,logging);  
		break;
		

		
		
		
		
		
		
		
		
		

		case "LpstpDelegatedPowersProvider":
			LpstpDelegatedPowersDataProvider delegatedPowersDataProvider = new LpstpDelegatedPowersDataProvider();
			dpMap = delegatedPowersDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpcustApplicantEmployerProvider":
			LpcustApplicantEmployerProvider lpcustApplicantEmployerProvider = new LpcustApplicantEmployerProvider();
			dpMap = lpcustApplicantEmployerProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "ParticularsOfStudentProvider":
			LpcustApplicantEduStudentProvider lpcustApplicantEduStudentProvider = new LpcustApplicantEduStudentProvider();
			dpMap = lpcustApplicantEduStudentProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "CourseDetailsProvider":
			LpcustApplicantEduCourseDetailProvider lpcustApplicantEduCourseDetailProvider = new LpcustApplicantEduCourseDetailProvider();
			dpMap = lpcustApplicantEduCourseDetailProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "DocumentTemplateProvider":
			LpstpDocumentTemplateProvider documentTemplateProvider = new LpstpDocumentTemplateProvider();
			dpMap = documentTemplateProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "LpstpPrdRepaymentCapacityDataProvider":
			LpstpPrdRepaymentCapacityDataProvider lpstpPrdRepaymentCapacityDataProvider = new LpstpPrdRepaymentCapacityDataProvider();
			dpMap = lpstpPrdRepaymentCapacityDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "LpstpBulletInfoDataProvider":
			LpstpBulletInfoDataProvider lpstpBulletinfoDataProvider = new LpstpBulletInfoDataProvider();
			dpMap = lpstpBulletinfoDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);

			break;
		case "LpstpComboMasterDataProvider":
			LpstpComboMasterDataProvider lpstpComboMasterDataProvider = new LpstpComboMasterDataProvider();
			dpMap = lpstpComboMasterDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "SearchCriteriaDataProvider":
			SearchCriteriaDataProvider searchCriteriaDataProvider = new SearchCriteriaDataProvider();
			dpMap = searchCriteriaDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "LpcomScorecardCalcDataProvider":
			LpcomScorecardCalcDataProvider lpcomScorecardCalcDataProvider = new LpcomScorecardCalcDataProvider();
			dpMap = lpcomScorecardCalcDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
		case "LpcomTatDataProvider":
			LpcomTatDataProvider lpcomTatDataProvider = new LpcomTatDataProvider();
			dpMap = lpcomTatDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "ScoreCardBusinessRuleDataProvider":
			ScoreCardBusinessRuleDataProvider scoreCardBusinessRuleDataProvider = new ScoreCardBusinessRuleDataProvider();
			dpMap = scoreCardBusinessRuleDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "ComboOfferDataProvider":
			ComboOfferDataProvider comboOfferDataProvider = new ComboOfferDataProvider();
			dpMap = comboOfferDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "StateCitySearchDataProvider":
			StateCitySearchDataProvider stateCitySearchDataProvider = new StateCitySearchDataProvider();
			dpMap = stateCitySearchDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "LpstpPrdConcessionDataProvider":
			LpstpPrdConcessionDataProvider lpstpPrdConcessionProvider = new LpstpPrdConcessionDataProvider();
			dpMap = lpstpPrdConcessionProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "TaxDetailDataProvider":
			TaxDetailDataProvider taxDetailDataProvider = new TaxDetailDataProvider();
			dpMap = taxDetailDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		case "ProductAnnexureProvider":
			ProductAnnexureProvider productAnnexureProvider = new ProductAnnexureProvider();
			dpMap = productAnnexureProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
			
		case "LpcomLegalVerifcationDataProvider":
			LpcomLegalVerifcationDataProvider lpcomLegalVerifcationDataProvider = new LpcomLegalVerifcationDataProvider();
			dpMap = lpcomLegalVerifcationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

	 	case "LpcomChartReportDataProvider":  
    		LpcomChartReportDataProvider lpcomChartReportDataProvider=new LpcomChartReportDataProvider(); 
			dpMap=lpcomChartReportDataProvider.getData(dpMethod,session,allRequestParams,masterData,serviceProvider,logging);  
		break;

		case "OrganisationDataProvider":
			OrganisationDataProvider organisationDataProvider = new OrganisationDataProvider();
			dpMap = organisationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;


		case "ExternalLegalReportDataProvider":
			ExternalLegalReportDataProvider externalLegalReportDataProvider = new ExternalLegalReportDataProvider();
			dpMap = externalLegalReportDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;
			
		case "LpcomReallowcationDataProvider":
			LpcomReallowcationDataProvider lpcomReallowcationDataProvider = new LpcomReallowcationDataProvider();
			dpMap = lpcomReallowcationDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
			break;

		 case "CustomerCreationProvider":
				CustomerCreationProvider customerCreationProvider = new CustomerCreationProvider();
				dpMap = customerCreationProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider, logging);
				break;
		default:
			Map<String, Object> responseHashMap = new HashMap<String, Object>();
			Map<String, CustomErr> dataHashMap = new HashMap<String, CustomErr>();
			dataHashMap.put("errorData", new CustomErr(ErrConstants.dataProviderNotFoundErrCode, ErrConstants.dataProviderNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
			dpMap = responseHashMap;
		}

		return dpMap;
	}

}
