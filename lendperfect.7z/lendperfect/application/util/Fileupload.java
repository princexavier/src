package com.sai.lendperfect.application.util;

import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpSession;

import com.sai.lendperfect.common.ipletterdet.FileuploadDataProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mobileapp.customercreation.CustomerCreationProvider;
import com.sai.lendperfect.mobileapp.customercreation.MobileFileUploadDataProvider;

import org.springframework.web.multipart.MultipartFile;

public class Fileupload {
	/**
	 * @param dpClass
	 * @param dpMethod
	 * @param session
	 * @param allRequestParams
	 * @param masterData
	 * @param serviceProvider
	 * @param logging
	 * @param file
	 * @return
	 */
	public Map<String, ?> process(String dpClass,String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging,MultipartFile file,String dataDirectory)		{  

		Map<String, ?> dpMap=null; 

		switch(dpClass)

			{
			  case "FileuploadDataProvider":
			    	
			    	FileuploadDataProvider fileuploadDataProvider=new FileuploadDataProvider();
			    	dpMap=fileuploadDataProvider.getData(dpMethod, session, allRequestParams,masterData, serviceProvider, logging,file,dataDirectory);
			    break;
			  case "MobileFileUploadDataProvider":
				  MobileFileUploadDataProvider mobileFileUploadDataProvider = new MobileFileUploadDataProvider();
					dpMap = mobileFileUploadDataProvider.getData(dpMethod, session, allRequestParams, masterData, serviceProvider,file, logging,dataDirectory);
					break;
					
			} 

		return dpMap; 
		} 
}
