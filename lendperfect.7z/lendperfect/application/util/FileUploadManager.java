package com.sai.lendperfect.application.util;

import static org.hamcrest.CoreMatchers.instanceOf;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service("FileUploadManager")
@Transactional
public class FileUploadManager {
	
		
		public List<Object> fileUpload(File file)
		{
			XSSFWorkbook workbook = null;
			InputStream fileInputStream;
			XSSFSheet sheet = null;
			XSSFRow row = null;
			XSSFCell cell = null;
			String tableName ="";
			List<String> columnNameList=new ArrayList();;
			List<String> columnHeaderList;
			List<String> rowDataList = null;
			HashMap<Integer,String> hspColumnMap = new HashMap();
			HashMap<Integer,ArrayList> hspRowDataMap = new HashMap();
			List<Object> finalList = new ArrayList();
			String filename="";
			HSSFWorkbook workbookXls = null;
			HSSFSheet sheetXls = null;
		
			try
			{
				filename=file.getName();
				fileInputStream= new FileInputStream(file);
				if (filename.endsWith(".xlsx")) {
					workbook = new XSSFWorkbook(fileInputStream);
					sheet=workbook.getSheetAt(0);
					columnNameList=new ArrayList();
					columnHeaderList=new ArrayList();
					int iteartor=1;
					int counter=1;
					int rowNumber=1;
					for(int i=0;i<=sheet.getLastRowNum();i++){
						row = sheet.getRow(i);
					    rowDataList=new ArrayList();
					    rowNumber=row.getLastCellNum();
					    for (int j = 0; j <rowNumber; j++) {
		                	cell =(XSSFCell) row.getCell(j);
		                	if(i==0)
		                	{
		                		 if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
		                			 tableName= cell.getStringCellValue();
		                			 tableName=Helper.removeUnderscores(tableName);
		                			 }
		                	}else if(i==1)
		                	{
		                		 if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
		                			 columnNameList.add("set"+Helper.removeUnderscores(cell.getStringCellValue()));
		                			 hspColumnMap.put(iteartor, "set"+Helper.removeUnderscores(cell.getStringCellValue()));
		                			 iteartor=iteartor+1;
			                     }
		                	}else if(i==2){
		                		 if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
		                			 columnHeaderList.add("set"+Helper.removeUnderscores(cell.getStringCellValue()));
			                     }
		                	}else 
		                	{
		                		if (cell == null) {
		                			rowDataList.add("");
								}else if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
		                			rowDataList.add(cell.getStringCellValue());
			                     }else if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
			                    	 rowDataList.add(String.valueOf(cell.getNumericCellValue()));
			                     }else if(cell.getCellType() == HSSFCell.CELL_TYPE_BLANK)
			                     {
			                    	 rowDataList.add(String.valueOf(""));
			                     }
		                		rowNumber=columnNameList.size();
		                	}
		                }
					    if(!rowDataList.isEmpty())
		                {
		                	hspRowDataMap.put(counter, (ArrayList) rowDataList);
		                	counter=counter+1;
		                }
					    if(!columnNameList.isEmpty())
					    {
					    	rowNumber=columnNameList.size();
					    }
					}
				
				}else if(filename.endsWith(".xls"))
				{
					workbookXls = new HSSFWorkbook(fileInputStream);
					sheetXls = workbookXls.getSheetAt(0);
					columnNameList=new ArrayList();
					columnHeaderList=new ArrayList();
					int iteartor=1;
					int counter=1;
					int rowNumber=1;
					for(int i=0;i<=sheetXls.getLastRowNum();i++){
						row = sheet.getRow(i);
					    rowDataList=new ArrayList();
					    rowNumber=row.getLastCellNum();
					    for (int j = 0; j <rowNumber; j++) {
		                	cell =(XSSFCell) row.getCell(j);
		                	if(i==0)
		                	{
		                		 if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
		                			 tableName= cell.getStringCellValue();
		                			 tableName=Helper.removeUnderscores(tableName);
		                			 }
		                	}else if(i==1)
		                	{
		                		 if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
		                			 columnNameList.add("set"+Helper.removeUnderscores(cell.getStringCellValue()));
		                			 hspColumnMap.put(iteartor, "set"+Helper.removeUnderscores(cell.getStringCellValue()));
		                			 iteartor=iteartor+1;
			                     }
		                	}else if(i==2){
		                		 if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
		                			 columnHeaderList.add("set"+Helper.removeUnderscores(cell.getStringCellValue()));
			                     }
		                	}else 
		                	{
		                		if (cell == null) {
		                			rowDataList.add("");
								}else if (cell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
		                			rowDataList.add(cell.getStringCellValue());
			                     }else if (cell.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) {
			                    	 rowDataList.add(String.valueOf(cell.getNumericCellValue()));
			                     }else if(cell.getCellType() == HSSFCell.CELL_TYPE_BLANK)
			                     {
			                    	 rowDataList.add(String.valueOf(""));
			                     }
		                		rowNumber=columnNameList.size();
		                	}
		                }
					    if(!rowDataList.isEmpty())
		                {
		                	hspRowDataMap.put(counter, (ArrayList) rowDataList);
		                	counter=counter+1;
		                }
					    if(!columnNameList.isEmpty())
					    {
					    	rowNumber=columnNameList.size();
					    }
					}
				}
				
				if (filename.endsWith(".xlsx") || filename.endsWith(".xls")) {
				
					Class className = Class.forName("com.sai.lendperfect.model."+tableName);
		   			Object obj = className.newInstance();
		   			
		   			
		   			Method[] methods = obj.getClass().getMethods();
		   			HashMap hspMap = new HashMap();
		   			
		   			for(int k=0;k<methods.length;k++)
					{
		   				if(methods[k].getName().startsWith("set"))
						{
		   					Class<?>[] paramTypes1 = methods[k].getParameterTypes();
		   					Method method = className.getDeclaredMethod(methods[k].getName(),paramTypes1[0]);
		   					for(int i=0;i<columnNameList.size();i++)
		   					{
		   						if(method.getName().contains(columnNameList.get(i)))
		   						{
		   							hspMap.put(method.getName(),paramTypes1);
		   						}
		   					}
						}
					}
			
					for(Map.Entry<Integer,ArrayList> lableObject:hspRowDataMap.entrySet()){
						obj = className.newInstance();
						for(int j=0;j<columnNameList.size();j++)
						{
							Class<?>[] class1=(Class[]) hspMap.get(columnNameList.get(j));
							Method method = className.getDeclaredMethod(columnNameList.get(j),class1[0]);
							
							if(class1[0].equals(BigDecimal.class))
							{
								method.invoke(obj,new BigDecimal((String) lableObject.getValue().get(j)));
							}else if(class1[0].equals(String.class))
							{
								method.invoke(obj,new String((String) lableObject.getValue().get(j)));
							}else if(class1[0].equals(Float.class))
							{
								method.invoke(obj,new Float((float) lableObject.getValue().get(j)));
							}else if(class1[0].equals(Double.class))
							{
								method.invoke(obj,new Double((double) lableObject.getValue().get(j)));
							}else if(class1[0].equals(Long.class))
							{
								method.invoke(obj,new Long((long) lableObject.getValue().get(j)));
							}else if(class1[0].equals(Integer.class))
							{
								method.invoke(obj,new Integer((int) lableObject.getValue().get(j)));
							}else if(class1[0].equals(Date.class))
							{
								method.invoke(obj,Helper.convertStringToDate((String) lableObject.getValue().get(j)));
							}else if(class1[0].equals(Boolean.class))
							{
								method.invoke(obj,new Boolean((String) lableObject.getValue().get(j)));
							}
						}
						finalList.add(obj);
					}
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
			return finalList;
		}
	

}
