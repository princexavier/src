package com.sai.lendperfect.application.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Iterator;

public class DataProcessorMaker
{
	public static void main(String args[])
	{
		try {
			BufferedReader buffReader=new BufferedReader(new InputStreamReader(new FileInputStream("src/main/resources/application.properties")));
			StringBuilder sb=new StringBuilder();
			HashSet<String> set=new HashSet<String>();  
			sb.append("package com.sai.lendperfect.util;  \n\n");
			sb.append("import javax.servlet.http.HttpSession;  \n\n");
			sb.append("import java.util.Map;  \n\n");
			sb.append("import com.sai.lendperfect.util.dataprovider.IndexDataProvider;  \n\n");
			String line=null;
			while((line=buffReader.readLine())!=null)
			{
			if(line.contains("page.") && !line.contains("IndexDataProvider"))
					{
			    String DPMapper=line.split(":")[1].split("_")[0];
			    set.add(DPMapper);
					}
			}
			
		   Iterator<String> itr=set.iterator();  
			  while(itr.hasNext()){  
				  sb.append("import com.sai.lendperfect.util.dataprovider."+itr.next()+";  \n\n"); 
			  }  
			  sb.append("		public class DataProcessor	{   \n\n");
			  sb.append("		public Map<String, ?> process(String dpClass,String dpMethod,HttpSession session,Object masterData)		{   \n\n");
			  sb.append("		Map<String, ?> dpMap=null;   \n\n");
			  sb.append("		switch(dpClass)\n\n			{  \n\n");
              sb.append("		case \"IndexDataProvider\": \n\n");		    
              sb.append("		IndexDataProvider indexDataProvider=new IndexDataProvider();  \n\n");
              sb.append("		dpMap=indexDataProvider.getData(session, masterData,dpMethod); \n\n		break;\n\n");			    
              sb.append("			}\n\n");
			  sb.append("		return dpMap;\n\n");
			  sb.append("		} \n\n");
              sb.append("		public Map<String, ?> process(String dpClass,String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData)		{  \n\n");
              sb.append("		Map<String, ?> dpMap=null; \n\n");
              sb.append("		switch(dpClass)\n\n			{  \n\n");
              itr=set.iterator();  
			  while(itr.hasNext()){  
			  String DMapperClassName=itr.next();
			  String DMapperObjectName=DMapperClassName.substring(0,1).toLowerCase()+DMapperClassName.substring(1);
              sb.append("		case \""+DMapperClassName+"\":  \n\n");			    	
              sb.append("		"+DMapperClassName+" "+DMapperObjectName+"=new "+DMapperClassName+"(); \n\n");
              sb.append("		dpMap="+DMapperObjectName+".getData(session,allRequestParams, masterData,dpMethod);  \n\n		break; \n\n");
			  }
              sb.append("			} \n\n");
			  sb.append("		return dpMap; \n");
			  sb.append("		} \n\n");
              sb.append("	} \n \n");            
              buffReader.close();				
              FileOutputStream fos = new FileOutputStream(new File("src/main/java/com/sai/lendperfect/util/DataProcessor.java"));
              fos.write(sb.toString().getBytes());
              fos.flush();
              fos.close();
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
}
