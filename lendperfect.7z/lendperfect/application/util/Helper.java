package com.sai.lendperfect.application.util;

import java.io.BufferedReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpSession;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.setupmodel.SetUserGroup;
import com.sai.lendperfect.webservice.leadservice.ErrorDetail;

public class Helper {

	public static String removeUnderscores(final String input) {
		StringBuffer result = new StringBuffer();
		if (input != null) {
			String[] tmp = input.split("_");
			for (int i = 0; i < tmp.length; i++) {
				String fragment;

				fragment = tmp[i];
				fragment = toCamelCase(fragment);
				result.append(fragment);
			}
		}
		return result.toString();
	}

	public static String toCamelCase(final String init) {
		if (init == null)
			return null;

		final StringBuilder ret = new StringBuilder(init.length());

		for (final String word : init.split(" ")) {
			if (!word.isEmpty()) {
				ret.append(word.substring(0, 1).toUpperCase());
				ret.append(word.substring(1).toLowerCase());
			}
			if (!(ret.length() == init.length()))
				ret.append(" ");
		}

		return ret.toString();
	}

	public static Date convertStringToDate(String dateStr) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

		Date date = null;

		if (dateStr == null) {
			return null;
		} else {
			try {
				date = sdf.parse(dateStr);
			} catch (ParseException e) {

			}
		}
		return date;
	}

	public static String correctNull(Object obj) {
		if (obj == null)
			return "";
		return (String) obj;
	}
	
	public static Map correctNullMap(Object obj) {
		if (obj == null)
			return null;
		return (Map) obj;
	}

	public static String correctNullForNum(Object obj) {
		if (obj == null || obj.toString().equalsIgnoreCase("null"))
			return "0.00";
		return obj.toString();
	}

	public static Timestamp getSystemDate() {
		return new Timestamp(System.currentTimeMillis());
	}

	public static long convertLong(Long L) {
		long i = 0l;
		i = (L == null ? i : L.longValue());
		return i;
	}

	public static String decrypt(String key, String encryptedText) {
		// need of JAVA security jar
		String decryptedText = "";
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			byte[] key1 = key.getBytes("UTF-8");
			SecretKeySpec secretKey = new SecretKeySpec(key1, "AES");
			IvParameterSpec ivparameterspec = new IvParameterSpec(key1);
			cipher.init(Cipher.DECRYPT_MODE, secretKey, ivparameterspec);
			Base64.Decoder decoder = Base64.getDecoder();
			byte[] cipherText = decoder.decode(encryptedText.getBytes("UTF8"));
			decryptedText = new String(cipher.doFinal(cipherText), "UTF-8");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return decryptedText;
	}

	public static String encrypt(String key, String value) {
		String encryptedText = "";
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			byte[] key1 = key.getBytes("UTF-8");
			SecretKeySpec secretKey = new SecretKeySpec(key1, "AES");
			IvParameterSpec ivparameterspec = new IvParameterSpec(key1);
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivparameterspec);
			byte[] cipherText = cipher.doFinal(value.getBytes("UTF8"));
			Base64.Encoder encoder = Base64.getEncoder();
			encryptedText = encoder.encodeToString(cipherText);

		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return encryptedText;
	}

	public static String correctNull(String strNull) {
		if (strNull == null || strNull.equalsIgnoreCase("null")) {
			strNull = "";
		}
		return strNull.trim();
	}

	public static String getCurrentTime() throws Exception {
		Calendar cal = Calendar.getInstance();
		String strSysHour = "";
		String strSysMin = "";
		String strSysSec = "";
		String strSysMSec = "";
		String strSysTime = "";
		try {
			strSysHour = String.valueOf(cal.get(Calendar.HOUR));
			strSysMin = String.valueOf(cal.get(Calendar.MINUTE));
			strSysSec = String.valueOf(cal.get(Calendar.SECOND));
			strSysMSec = String.valueOf(cal.get(Calendar.MILLISECOND));
			strSysTime = strSysHour + "." + strSysMin + "." + strSysSec + "." + strSysMSec;
		} catch (Exception e) {
			throw new Exception("*Exception in getCurrentTime **" + e);
		}
		return strSysTime;
	}

	public static String correctBigDecimal(String strNull) {
		if (strNull == null || strNull.equals("")) {
			strNull = "0";
		}
		return strNull;
	}

	public static String pageAccessRights(String type, BigDecimal pageId, BigDecimal propNo, ServiceProvider serviceProvider, HttpSession session) {
		String pageValue = null;
		LpcomProposal lpcomProposal = new LpcomProposal();
		if (type.equals("S")) {
			Long grpId = Long.parseLong(session.getAttribute("groupid").toString());
			SetUserGroup lpstpUserGroup = serviceProvider.getUserGroupService().findById(grpId);
			String grpRights = lpstpUserGroup.getSugGrpRights();
			List<String> grpRightsList = Arrays.asList(grpRights.split("\\s*~\\s*"));
			for (String grp : grpRightsList) {
				pageValue = grp.substring(grp.length() - 1);
				String key = grp.substring(0, grp.length() - 1);
				if ((pageId.toString()).equals(key)) {
					return pageValue;

				}
			}
		} else if (type.equals("P")) {
			boolean flag = false;
			lpcomProposal = serviceProvider.getLpcomProposalService().findBylpPropNoAndlpStatus(propNo, "OP");

			if (lpcomProposal != null) {
				if (lpcomProposal.getLpStatus().equals("OP"))
					flag = true;
				if ((session.getAttribute("userid").toString()).equals(lpcomProposal.getLpPropHolder()) && (flag == true)) {
					String pageAccess = serviceProvider.getLpcomMailboxService().getPageAccess(lpcomProposal.getLpPropNo(), pageId);
					if (pageAccess != null) {
						if (pageAccess.equals("M") || pageAccess.equals("N")) {
							pageValue = "W";
						} else if (pageAccess.equals("R")) {
							pageValue = "R";
						}

					}
				} else
					pageValue = "R";
			} else {
				pageValue = "W";
			}
		}
		return pageValue;

	}

	private static String calculateage(int day1, int month1, int year1) {
		String Age = "";
		Calendar birthCal = new GregorianCalendar(year1, month1, day1);
		Calendar nowCal = new GregorianCalendar();
		int age = nowCal.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR);
		boolean isMonthGreater = birthCal.get(Calendar.MONTH) >= nowCal.get(Calendar.MONTH);
		boolean isMonthSameButDayGreater = birthCal.get(Calendar.MONTH) >= nowCal.get(Calendar.MONTH) && birthCal.get(Calendar.DAY_OF_MONTH) >= nowCal.get(Calendar.DAY_OF_MONTH);
		if (age < 18) {
			Age = String.valueOf(age);
		} else if (isMonthGreater || isMonthSameButDayGreater) {
			Age = String.valueOf(age - 1);
		}
		return Age;
	}

	/* For Validating Fields in Webservice */
	public static ArrayList<ErrorDetail> fieldValidation(Object obj, ArrayList<ErrorDetail> errorDetailList, Validator validator) {
		try {
			ErrorDetail errorDetail = null;
			Set<ConstraintViolation<Object>> constraintViolations = validator.validate(obj);
			for (ConstraintViolation Err : constraintViolations) {
				errorDetail = new ErrorDetail();
				errorDetail.setErrorfield(String.valueOf(Err.getPropertyPath()));
				errorDetail.setErrorfieldValue(String.valueOf(Err.getInvalidValue()));
				errorDetail.setErrorDesc(Err.getMessage());
				errorDetailList.add(errorDetail);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return errorDetailList;
	}

	// Currency Conversion
	// UnitsToActuals
	public static BigDecimal UnitsToActuals(String propDenom, BigDecimal unitValue) {

		BigDecimal value = new BigDecimal(0);

		if (propDenom.equals("L")) {
			value = unitValue.multiply(new BigDecimal(100000));
		}

		else if (propDenom.equals("C")) {
			value = unitValue.multiply(new BigDecimal(10000000));
		}

		else if (propDenom.equals("A")) {
			value = unitValue;
		}

		return value;
	}

	// ActualsToUnits
	public static BigDecimal ActualsToUnits(String propDenom, BigDecimal actualValue) {

		BigDecimal value = new BigDecimal(0);

		if (propDenom.equals("L")) {
			value = actualValue.divide(new BigDecimal(100000));
		}

		else if (propDenom.equals("C")) {
			value = actualValue.divide(new BigDecimal(10000000));
		}

		else if (propDenom.equals("A")) {
			value = actualValue;
		}

		return value;
	}

	/*********** Marshalling(Object to XML) **************/
	public static String convertObjectToXml(Object obj) throws Exception {
		JAXBContext context = JAXBContext.newInstance(obj.getClass());
		Marshaller jaxbMarshaller = context.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
		StringWriter strWriter = new StringWriter();
		jaxbMarshaller.marshal(obj, strWriter);
		return strWriter.toString();
	}

	/*********** UnMarshalling(XML to Object) **************/
	public static Object convertXmlToObject(String strxml, Object obj) throws Exception {
		BufferedReader br = new BufferedReader(new StringReader(strxml));
		JAXBContext jaxbContext = JAXBContext.newInstance(obj.getClass());
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		return jaxbUnmarshaller.unmarshal(br);
	}

	public static String CLOBToString(Clob cl) {
		String strClob = "";
		BufferedReader br = null;
		try {
			if (cl == null)
				return "";
			StringBuffer strOut = new StringBuffer();
			String aux;
			// We access to stream, as this way we don't have to use the
			// CLOB.length() which is slower...
			br = new BufferedReader(cl.getCharacterStream());
			while ((aux = br.readLine()) != null)
				strOut.append(aux).append("\n");
			strClob = strOut.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// br.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return strClob;
	}

	public static String figtoWords(String str1) {

		String[] one = { "One ", "Two ", "Three ", "Four ", "Five ", "Six ", "Seven ", "Eight ", "Nine " };
		String[] ele = { "Eleven ", "Twelve ", "Thirteen ", "Fourteen ", "Fifteen ", "Sixteen ", "Seventeen ", "Eighteen ", "Nineteen " };
		String[] ten = { "Ten ", "Twenty ", "Thirty ", "Forty ", "Fifty ", "Sixty ", "Seventy ", "Eighty ", "Ninety " };

		String str = "";
		int i = 0;
		for (; i < str1.length(); i++) {
			if (str1.charAt(i) == '.') {
				str = str1.substring(0, i);
				break;
			}
		}
		if (i == str1.length()) {
			str = str1;
		}

		int len, k;
		len = str.length();
		k = 10 - len;
		if (len < 10) {
			switch (k) {
			case 1:
				str = "0" + str;
				break;
			case 2:
				str = "00" + str;
				break;
			case 3:
				str = "000" + str;
				break;
			case 4:
				str = "0000" + str;
				break;
			case 5:
				str = "00000" + str;
				break;
			case 6:
				str = "000000" + str;
				break;
			case 7:
				str = "0000000" + str;
				break;
			case 8:
				str = "00000000" + str;
				break;
			case 9:
				str = "000000000" + str;
				break;
			case 10:
				str = "0000000000" + str;
				break;
			}
		}

		int d, d1, d2;
		String word = new String();
		String chdigit = new String();
		chdigit = str.substring(0, 1);
		d = Integer.parseInt(chdigit);
		chdigit = str.substring(1, 2);
		d1 = Integer.parseInt(chdigit);
		chdigit = str.substring(2, 3);
		d2 = Integer.parseInt(chdigit);
		if (d != 0) {
			word = word.concat(one[d - 1]);
			word = word.concat("Hundred ");
		}
		if (d1 == 0 && d2 != 0) {
			word = word.concat(one[d2 - 1]);
			word = word.concat("Crores ");
		}
		if (d1 == 1 && d2 != 0) {
			word = word.concat(ele[d2 - 1]);
			word = word.concat("Crores ");
		}
		if (d1 != 0 && d2 == 0) {
			word = word.concat(ten[d1 - 1]);
			word = word.concat("Crores ");
		}
		if (d1 > 1 && d2 != 0) {
			word = word.concat(ten[d1 - 1]);
			word = word.concat(one[d2 - 1]);
			word = word.concat("Crores ");
		}
		if (d != 0 && d1 == 0 && d2 == 0) {
			word = word.concat("Crores ");
		}
		chdigit = str.substring(3, 4);
		d = Integer.parseInt(chdigit);
		chdigit = str.substring(4, 5);
		d1 = Integer.parseInt(chdigit);
		if (d == 0 && d1 != 0) {
			word = word.concat(one[d1 - 1]);
			word = word.concat("Lakhs ");
		}
		if (d == 1 && d1 != 0) {
			word = word.concat(ele[d1 - 1]);
			word = word.concat("Lakhs ");
		}

		if (d != 0 && d1 == 0) {
			word = word.concat(ten[d - 1]);
			word = word.concat("Lakhs ");
		}
		if (d > 1 && d1 != 0) {
			word = word.concat(ten[d - 1]);
			word = word.concat(one[d1 - 1]);
			word = word.concat("Lakhs ");
		}

		chdigit = str.substring(5, 6);
		d = Integer.parseInt(chdigit);
		chdigit = str.substring(6, 7);
		d1 = Integer.parseInt(chdigit);
		if (d == 0 && d1 != 0) {
			word = word.concat(one[d1 - 1]);
			word = word.concat("Thousand ");
		}
		if (d == 1 && d1 != 0) {
			word = word.concat(ele[d1 - 1]);
			word = word.concat("Thousand ");
		}
		if (d != 0 && d1 == 0) {
			word = word.concat(ten[d - 1]);
			word = word.concat("Thousand ");
		}
		if (d > 1 && d1 != 0) {
			word = word.concat(ten[d - 1]);
			word = word.concat(one[d1 - 1]);
			word = word.concat("Thousand ");
		}
		chdigit = str.substring(7, 8);
		d = Integer.parseInt(chdigit);
		chdigit = str.substring(8, 9);
		d1 = Integer.parseInt(chdigit);
		chdigit = str.substring(9, 10);
		d2 = Integer.parseInt(chdigit);
		if (d != 0) {
			word = word.concat(one[d - 1]);
			word = word.concat("Hundred ");
		}
		if (d1 == 0 && d2 != 0) {
			word = word.concat(one[d2 - 1]);
		}
		if (d1 == 1 && d2 != 0) {
			word = word.concat(ele[d2 - 1]);
		}
		if (d1 != 0 && d2 == 0) {
			word = word.concat(ten[d1 - 1]);
		}
		if (d1 > 1 && d2 != 0) {
			word = word.concat(ten[d1 - 1]);
			word = word.concat(one[d2 - 1]);
		}
		if ("0000000000".equals(str)) {
			word = "Zero Only";
		} else {
			word = word.concat("only");

		}

		return word;
	}

	public static String replaceAll(String str, String pattern, String replace, boolean isCaseSensitive) {
		int s = 0;
		int e = 0;
		StringBuffer result = new StringBuffer();
		if (isCaseSensitive) {
			while ((e = str.indexOf(pattern, s)) >= 0) {
				result.append(str.substring(s, e));
				result.append(replace);
				s = e + pattern.length();
			}
		} else {
			while ((e = str.toUpperCase().indexOf(pattern.toUpperCase(), s)) >= 0) {
				result.append(str.substring(s, e));
				result.append(replace);
				s = e + pattern.length();
			}
		}
		result.append(str.substring(s));
		return result.toString();
	}

	public static String correctInt(String strNull) {
		if (strNull == null || strNull.trim().equals("") || strNull.trim().equals("null")) {
			strNull = "0";
		}
		return strNull.trim();
	}
 
	 public static String correctDouble(String strNull) {
		if (strNull == null || strNull.trim().equals("") || strNull.trim().equals("null")) {
			strNull = "0.0";
		}
		return strNull.trim();
     }
 

}
