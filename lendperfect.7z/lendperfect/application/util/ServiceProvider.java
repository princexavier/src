package com.sai.lendperfect.application.util;

import org.springframework.beans.factory.annotation.Autowired;

import com.sai.lendperfect.agri.agriReferenceDet.LpAgriReferenceService;
import com.sai.lendperfect.agri.curryearcroppattern.LpagriCurrCropPatternService;
import com.sai.lendperfect.agri.existingexposure.LpagriExistingExposureService;
import com.sai.lendperfect.agri.fleetdetails.LpagriFleetDetService;
import com.sai.lendperfect.agri.landdetails.LpagriLandDetailService;
import com.sai.lendperfect.agri.prevcroppattern.LpagriPrevCropPatternService;
import com.sai.lendperfect.app.applicantemployertype.LpcustApplicantEmployerService;
import com.sai.lendperfect.app.application.ApplicationService;
import com.sai.lendperfect.app.customerdetails.CustomerDetailsService;
import com.sai.lendperfect.app.educationcoursedetails.LpcustApplicantEduCourseDetailService;
import com.sai.lendperfect.app.educationloan.LpcustApplicantEduDetailService;
import com.sai.lendperfect.app.educationparticularsofstudent.LpcustApplicantEduStudentService;
import com.sai.lendperfect.app.eduscholarshipdetails.LpcustApplicantEduScholarService;
import com.sai.lendperfect.app.incexpenses.LpcustApplicantIncexpensService;
import com.sai.lendperfect.app.loandetails.LoanDetailsService;
import com.sai.lendperfect.app.oblirepay.LpcustApplicantOblicatService;
import com.sai.lendperfect.app.otherexpenditure.LpcustApplicantOtherexpService;
import com.sai.lendperfect.app.otherincomes.LpcustApplicantOtherIncomeService;
import com.sai.lendperfect.app.relation.ApplicationRelationService;
import com.sai.lendperfect.application.courseexpense.LpcomCourseExpenseService;
import com.sai.lendperfect.application.searchcriteria.CbsService;
import com.sai.lendperfect.application.searchcriteria.SearchCriteriaService;
import com.sai.lendperfect.application.taxdetails.LpcustApplicantTaxDetailService;
import com.sai.lendperfect.audittrail.AuditTrialService;
import com.sai.lendperfect.cbs.cbsliabpulling.CustaccountService;
import com.sai.lendperfect.cibilindividual.LpcustCibilIndividualService;
import com.sai.lendperfect.com.proposalcopmof.LpcomproposalcopmofService;
import com.sai.lendperfect.common.LpcomPropTermsCond.LpcomPropTermsCondService;
import com.sai.lendperfect.common.PropDocument.LpcomProfSamplingService;
import com.sai.lendperfect.common.PropDocument.LpcomPropDocumentService;
import com.sai.lendperfect.common.PropDocument.LpcomRcuApprovalService;
import com.sai.lendperfect.common.PropRecommend.LpcomPropRecommendService;
import com.sai.lendperfect.common.additionalinfo.LpcomPropAdditionalInfoService;
import com.sai.lendperfect.common.assessment.LpcomAssessmentService;
import com.sai.lendperfect.common.borrowerrelationship.LpcomBorrowerRelationshipService;
import com.sai.lendperfect.common.businessapproval.LpcomBussApprovalService;
import com.sai.lendperfect.common.bybankdocument.ByBankDocumentService;
import com.sai.lendperfect.common.casecredit.LpcomCaseDetCreditService;
import com.sai.lendperfect.common.casesale.LpcomCaseDetSaleService;
import com.sai.lendperfect.common.deviation.LpcomDeviationService;
import com.sai.lendperfect.common.exposuredet.LpcomExposureDetService;
import com.sai.lendperfect.common.externalvaluation.LpcomExternalValuationService;
import com.sai.lendperfect.common.facilityassessment.LpcomFacAssessmentService;
import com.sai.lendperfect.common.facilityborrowermapping.LpcomPropPartyService;
import com.sai.lendperfect.common.facilityborrowermapping.LpcomSetBorrMapService;
import com.sai.lendperfect.common.facilityborrowermapping.LpcomSetFacMapService;
import com.sai.lendperfect.common.facilityrecommend.LpcomFacilityRecommendService;
import com.sai.lendperfect.common.globalvariables.LpcomGlobalVariableService;
import com.sai.lendperfect.common.globalvariables.LpstpGlobalVariableService;
import com.sai.lendperfect.common.internalvaluation.LpcomInternalValService;
import com.sai.lendperfect.common.ipletterdet.LpcomDocAttachmentService;
import com.sai.lendperfect.common.ipletterdet.LpcomIpletterDetService;
import com.sai.lendperfect.common.legalverification.LpcomLegalDocDetailService;
import com.sai.lendperfect.common.legalverification.LpcomLegalVerifcationService;
import com.sai.lendperfect.common.liabilities.LpcomLiabilitiesService;
import com.sai.lendperfect.common.login.LoginService;
import com.sai.lendperfect.common.lpcomPropLocation.LpcomPropLocationService;
import com.sai.lendperfect.common.mailbox.LpcomMailboxService;
import com.sai.lendperfect.common.otherassetsliability.LpcomOtherAssetsLiabilityService;
import com.sai.lendperfect.common.pagecomments.LpcomPageCommentService;
import com.sai.lendperfect.common.prev3sanction.LpcomPrev3SanctionService;
import com.sai.lendperfect.common.proposal.LpcomProposalService;
import com.sai.lendperfect.common.pslclassification.LpcomPSLClassificationService;
import com.sai.lendperfect.common.query.LpcomQueryMgmtService;
import com.sai.lendperfect.common.rbichecklist.LpcomRBICheckListService;
import com.sai.lendperfect.common.secbankdeposit.LpcomSecBankDepositService;
import com.sai.lendperfect.common.secfacmapping.LpcomSecFacMappingService;
import com.sai.lendperfect.common.secfindocntrade.LpcomSecFindocNtradeService;
import com.sai.lendperfect.common.secfindoctrade.LpcomSecFindocTradeService;
import com.sai.lendperfect.common.secfurniture.LpcomSecFurnFixDetService;
import com.sai.lendperfect.common.secgoodsdetails.LpcomSecGoodsDetailService;
import com.sai.lendperfect.common.secjeweldetails.LpcomSecJewelDetService;
import com.sai.lendperfect.common.secplntmchnrydetail.LpcomSecPlntMchnryDetailService;
import com.sai.lendperfect.common.secproperty.LpcomSecPropertyService;
import com.sai.lendperfect.common.security.LpcomSecOwnerService;
import com.sai.lendperfect.common.security.LpcomSecurityService;
import com.sai.lendperfect.common.secvehicledetail.LpcomSecVehicleDetailService;
import com.sai.lendperfect.common.shareholding.LpcomShareHoldingService;
import com.sai.lendperfect.common.sourcingdetails.LpcomSourcingDetService;
import com.sai.lendperfect.common.takeoverchecklist.LpcomTakeoverChklistService;
import com.sai.lendperfect.common.userproposal.LpcomUserProposalService;
import com.sai.lendperfect.corporate.AccCondAnalysis2.LpcorpAccCondAnalysis2Service;
import com.sai.lendperfect.corporate.DebtorsSale.LpcorpDebtorsSaleService;
import com.sai.lendperfect.corporate.acccondcmtannex.LpcorpAccCondCmtAnnexService;
import com.sai.lendperfect.corporate.bcacannex.LpcorpBcacAnnexService;
import com.sai.lendperfect.corporate.buyerseller.LpcorpBuyerSupplierService;
import com.sai.lendperfect.corporate.cirannex.LpcorpCirAnnexService;
import com.sai.lendperfect.corporate.compcpannex.LpcorpCompCpAnnexService;
import com.sai.lendperfect.corporate.compsheetannex.LpcorpCompSheetAnnexService;
import com.sai.lendperfect.corporate.corp26asGst.Lpcorp26asGstService;
import com.sai.lendperfect.corporate.corpModelSale.LpcorpModelSaleService;
import com.sai.lendperfect.corporate.cropdetails.LpcorpCropDetService;
import com.sai.lendperfect.corporate.customerdetails.LpcomCustAddrService;
import com.sai.lendperfect.corporate.customerdetails.LpcomCustContctDetService;
import com.sai.lendperfect.corporate.customerdetails.LpcomCustDataIndService;
import com.sai.lendperfect.corporate.customerdetails.LpcomCustDataNindService;
import com.sai.lendperfect.corporate.customerdetails.LpcomCustInfoService;
import com.sai.lendperfect.corporate.dynmassessmnt.LpcorpDynamicAssessmentService;
import com.sai.lendperfect.corporate.dynmassessmnt.LpcorpDynamicAssmntDataService;
import com.sai.lendperfect.corporate.existingexposure.LpcorpExistingExposureService;
import com.sai.lendperfect.corporate.exposuredetails.LpcorpFacilityService;
import com.sai.lendperfect.corporate.externalrating.LpcorpExtRatingService;
import com.sai.lendperfect.corporate.forexexpo.LpcorpForexExpoService;
import com.sai.lendperfect.corporate.guaranteedetails.LpcorpGuarnteeDetService;
import com.sai.lendperfect.corporate.landdetails.LpcorpLandDetailService;
import com.sai.lendperfect.corporate.partyotherinfo.LpcorpMeetingDetService;
import com.sai.lendperfect.corporate.partyotherinfo.LpcorpReferenceDetService;
import com.sai.lendperfect.corporate.partyotherinfo.LpcorpVisitDetService;
import com.sai.lendperfect.corporate.rbipslclause.LpcorpRbiPslClauseService;
import com.sai.lendperfect.corporate.scorecalc.LpcomScorecardService;
import com.sai.lendperfect.corporate.taprojectedsales.LpcorpTaProjectedSalesService;
import com.sai.lendperfect.corporate.taretail.LpcorpTaRetailService;
import com.sai.lendperfect.corporate.tasales.LpcorpTaSalesService;
import com.sai.lendperfect.corporate.wcanalysis.LpcorpWcAnalysisService;
import com.sai.lendperfect.master.YieldMaster.LpagriYieldMasterService;
import com.sai.lendperfect.master.bizvertical.LpmasBizVerticalService;
import com.sai.lendperfect.master.listofvalues.LpmasListofvalueService;
import com.sai.lendperfect.master.listofvalues.LpmasListofvalues1Service;
import com.sai.lendperfect.master.lpcomreqrespdata.LpcomReqRespDataService;
import com.sai.lendperfect.master.lpmasProperty.LpmasPropertyService;
import com.sai.lendperfect.master.lpmasinterfacelink.LpmasInterfaceLinkService;
import com.sai.lendperfect.master.lpmasinterrcodes.LpmasIntErrCodeService;
import com.sai.lendperfect.master.pagemaster.LpmasPageMasterService;
import com.sai.lendperfect.master.psllov.LpMasPslLov1Service;
import com.sai.lendperfect.master.psllov.LpMasPslLovService;
import com.sai.lendperfect.master.quicklinks.LpmasQuickLinkService;
import com.sai.lendperfect.master.sof.LpmasCropSofService;
import com.sai.lendperfect.master.sof.LpmasSofService;
import com.sai.lendperfect.setup.Document.LpstpDocumentService;
import com.sai.lendperfect.setup.PrdDocument.LpstpPrdDocService;
import com.sai.lendperfect.setup.PrdTermsCond.LpstpPrdTermsCondService;
import com.sai.lendperfect.setup.TermsCondtn.LpstpTermsCondtnService;
import com.sai.lendperfect.setup.annexuremaster.LpstpAnnexMasterService;
import com.sai.lendperfect.setup.assessmentengine.LpstpAssessmentService;
import com.sai.lendperfect.setup.bulletin.LpstpBulletInfoService;
import com.sai.lendperfect.setup.cmamaster.LpstpCMAMasterService;
import com.sai.lendperfect.setup.comboconfiguration.LpstpComboMasterService;
import com.sai.lendperfect.setup.concession.LpstpPrdConcessionService;
import com.sai.lendperfect.setup.cranformat.LpstpCranMasterService;
import com.sai.lendperfect.setup.delegatedpowers.LpstpDelegatedPowersService;
import com.sai.lendperfect.setup.deviation.LpstpDeviationService;
import com.sai.lendperfect.setup.documentfee.LpstpPrdDocFeeService;
import com.sai.lendperfect.setup.documenttemplate.LpstpDocumentTemplateService;
import com.sai.lendperfect.setup.facilitymaster.LpstpFacilityService;
import com.sai.lendperfect.setup.financialmaster.FinancialMasterService;
import com.sai.lendperfect.setup.finformula.LpstpFinFormulaService;
import com.sai.lendperfect.setup.finmaster.LpstpFinMasterService;
import com.sai.lendperfect.setup.interestrate.LpstpPrdIntRateService;
import com.sai.lendperfect.setup.lpstpdelegationrepo.LpstpDelegationService;
import com.sai.lendperfect.setup.lpstpprdcoapguacount.LpstpPrdCoapguarcountService;
import com.sai.lendperfect.setup.mailtemplate.LpstpMailTemplateService;
import com.sai.lendperfect.setup.margin.LpstpPrdMarginService;
import com.sai.lendperfect.setup.organisation.OrganisationService;
import com.sai.lendperfect.setup.organisation_lpstp.LpstpOrganisationService;
import com.sai.lendperfect.setup.organization.SetOrganisationService;
import com.sai.lendperfect.setup.organizationlevel.SetOrgLevelService;
import com.sai.lendperfect.setup.orgmapping.LpstpOrgMappingService;
import com.sai.lendperfect.setup.prdannexure.LpstpPrdAnnexureService;
import com.sai.lendperfect.setup.prdassessment.LpstpPrdAssmentService;
import com.sai.lendperfect.setup.processingfee.LpstpPrdProFeeService;
import com.sai.lendperfect.setup.productdetails.LpstpProductDetService;
import com.sai.lendperfect.setup.pslmaster.LpstpPSLMasterService;
import com.sai.lendperfect.setup.qualitativemaster.StQualitativeMasterService;
import com.sai.lendperfect.setup.repaymentcapacity.LpstpPrdRepaymentCapacityService;
import com.sai.lendperfect.setup.schememaster.LpstpSchemeService;
import com.sai.lendperfect.setup.scorecardbusinessrule.LpstpRiskBusinessruleService;
import com.sai.lendperfect.setup.scorecardbusinessrule.LpstpRiskruleCutoffrangeService;
import com.sai.lendperfect.setup.scorecardmaster.LpstpScorecardMasterService;
import com.sai.lendperfect.setup.scorecardmaster.LpstpScorecardOptionMasterService;
import com.sai.lendperfect.setup.scorecardmaster.LpstpScrcrdLapsDefinedService;
/*import com.sai.lendperfect.setup.rbichecklist.SetRbiCheckListService;*/
import com.sai.lendperfect.setup.securitymaster.LpstpSecurityService;
import com.sai.lendperfect.setup.stgeographymaster.StGeographyMasterService;
import com.sai.lendperfect.setup.takeoverchecklist.LpstpTakeoverChklistService;
import com.sai.lendperfect.setup.user.LpstpUserAccessService;
import com.sai.lendperfect.setup.user.LpstpUserLocationService;
import com.sai.lendperfect.setup.user.LpstpUserService;
import com.sai.lendperfect.setup.userclass.LpstpUserClassService;
import com.sai.lendperfect.setup.usersgroup.SetUserGroupService;
import com.sai.lendperfect.setup.workflowmaster.LpstpWfFlowService;
import com.sai.lendperfect.setup.workflowmaster.LpstpWfFlowpointService;
import com.sai.lendperfect.setup.workflowmaster.LpstpWfPagelistService;
import com.sai.lendperfect.setup.workflowmaster.LpstpWorkflowService;
import com.sai.lendperfect.webservice.bcifcreation.BcifCreationService;
import com.sai.lendperfect.webservice.leadservice.LeadService;
import com.sai.lendperfect.webservice.leadservicestatus.LeadStatusCheckService;

public class ServiceProvider {

	@Autowired
	private LpcomproposalcopmofService lpcomproposalcopmofService;
	
	@Autowired
	private LpcomInternalValService lpcomInternalValService;
	@Autowired
	private SetUserGroupService setuserGroupService;
    @Autowired
    private LpcomExternalValuationService lpcomExternalValuationService;
	@Autowired
	private LpcomCourseExpenseService lpcomCourseExpenseService;

	@Autowired
	private LpstpCMAMasterService setCMAMasterService;

	@Autowired
	private LpstpFinMasterService setFinMasterService;

	@Autowired
	private LoginService loginService;
	@Autowired
	private StQualitativeMasterService stQualitativeMasterService;

	@Autowired
	private LpstpScorecardMasterService lpstpScorecardMasterService;

	@Autowired
	private LpstpScrcrdLapsDefinedService lpstpScrcrdLapsDefinedService;

	@Autowired
	private LpstpScorecardOptionMasterService lpstpScorecardOptionMasterService;

	@Autowired
	private LpagriCurrCropPatternService lpagriCurrCropPatternService;

	@Autowired
	private StGeographyMasterService stGeographyMasterService;

	@Autowired
	private LpagriPrevCropPatternService lpagriPrevCropPatternService;

	@Autowired
	private SequenceNoService sequenceNoService;

	@Autowired
	private LpagriLandDetailService lpagriLandDetailService;

	// @Autowired
	// private SetRbiCheckListService setRbiCheckListService;
	//
	@Autowired
	private LpcomCaseDetSaleService lpcomCaseDetSaleService;

	@Autowired
	private LpcomCaseDetCreditService lpcomCaseDetCreditService;

	@Autowired
	private LpcomShareHoldingService lpcomShareHoldingService;

	@Autowired
	private LpcorpLandDetailService lpcorpLandDetailService;

	@Autowired
	private LpcorpCropDetService lpcorpCropDetService;

	@Autowired
	private LpmasBizVerticalService lpmasBizVerticalService;

	@Autowired
	private LpcorpGuarnteeDetService lpcorpGuarnteeDetService;

	@Autowired
	private LpstpFacilityService lpstpFacilityService;

	@Autowired
	private LpstpTakeoverChklistService lpstpTakeoverChklistService;

	@Autowired
	private LpcomTakeoverChklistService lpcomTakeoverChklistService;

	@Autowired
	private LpagriExistingExposureService lpagriExistingExposureService;

	@Autowired
	private LpstpMailTemplateService mailTemplateService;

	@Autowired
	private LpAgriReferenceService LpAgriReferenceService;

	@Autowired
	private LpagriYieldMasterService LpagriYieldMasterService;

	@Autowired
	private LpcorpModelSaleService LpcorpModelSaleService;

	@Autowired
	private LpcorpDebtorsSaleService LpcorpDebtorsSaleService;

	@Autowired
	private LpstpTermsCondtnService LpstpTermsCondtnService;

	@Autowired
	private EmailManager emailManager;

	@Autowired
	private FileUploadManager fileUploadManager;

	@Autowired
	private LpmasPageMasterService lpmasPageMasterService;

	@Autowired
	private LpcorpExtRatingService lpcorpExtRatingService;

	@Autowired
	private LpcorpExistingExposureService lpcorpExistingExposureService;

	@Autowired
	private LpcomSecVehicleDetailService lpcomSecVehicleDetailService;

	@Autowired
	private LpcomSecPlntMchnryDetailService lpcomSecPlntMchnryDetailService;

	@Autowired
	private LpcomSecJewelDetService lpcomSecJewelDetService;

	@Autowired
	private LpcomSecGoodsDetailService lpcomSecGoodsDetailService;

	@Autowired
	private LpcorpAccCondAnalysis2Service LpcorpAccCondAnalysis2Service;

	@Autowired
	private LpmasListofvalueService LpmasListofvalueService;

	@Autowired
	private LpstpDocumentService LpstpDocumentService;

	@Autowired
	private LpcomPropDocumentService LpcomPropDocumentService;

	@Autowired
	private LpcorpRbiPslClauseService lpcorpRbiPslClauseService;

	@Autowired
	private LpstpSecurityService lpstpSecurityService;

	@Autowired
	private LpcomSourcingDetService lpcomSourcingDetService;

	@Autowired
	private LpcomCustDataIndService lpcomCustDataIndService;

	@Autowired
	private LpcomCustDataNindService lpcomCustDataNindService;

	@Autowired
	private LpcomCustAddrService lpcomCustAddrService;

	@Autowired
	private LpcomCustContctDetService LpcomCustContctDetService;

	@Autowired
	private LpcomSecurityService lpcomSecurityService;

	@Autowired
	private LpcomSecBankDepositService lpcomSecBankDepositService;

	@Autowired
	public LpcomSecFurnFixDetService lpcomSecFurnFixDetService;

	@Autowired
	public LpcomSecFindocTradeService lpcomSecFindocTradeService;

	@Autowired
	public LpcomSecFindocNtradeService lpcomSecFindocNtradeService;

	@Autowired
	public LpcorpMeetingDetService lpcorpMeetingDetService;

	@Autowired
	public LpcorpVisitDetService lpcorpVisitDetService;

	@Autowired
	public LpcorpReferenceDetService lpcorpReferenceDetService;

	@Autowired
	public LpcomSecPropertyService lpcomSecPropertyService;

	@Autowired
	private LpagriFleetDetService lpagriFleetDetService;

	@Autowired
	private LpcorpAccCondCmtAnnexService lpcorpAccCondCmtService;

	@Autowired
	private LpcorpFacilityService LpcorpFacilityService;

	@Autowired
	private LpstpProductDetService lpstpProductDetService;

	@Autowired
	private LpstpPrdIntRateService lpstpPrdIntRateService;

	@Autowired
	private LpcorpBuyerSupplierService lpcorpBuyerSupplierService;

	@Autowired
	private LpcorpForexExpoService lpcorpForexExpoService;

	@Autowired
	private LpcorpCirAnnexService lpcorpCirAnnexService;

	@Autowired
	private LpstpAnnexMasterService lpstpAnnexMasterService;

	@Autowired
	private LpstpPrdProFeeService lpstpPrdProFeeService;

	@Autowired
	private LpcorpCompSheetAnnexService lpcorpCompSheetAnnexService;

	@Autowired
	private LpcorpBcacAnnexService lpcorpBcacAnnexService;

	@Autowired
	private LpcorpCompCpAnnexService lpcorpCompCpAnnexService;

	@Autowired
	private LpcorpAccCondCmtAnnexService lpcorpAccCondCmtAnnexService;

	@Autowired
	private ListOfValuesService listOfValuesService;

	@Autowired
	private LpcomPropPartyService lpcomPropPartyService;

	@Autowired
	private LpcomProposalService lpcomProposalService;

	@Autowired
	private Lpcorp26asGstService Lpcorp26asGstService;

	@Autowired
	private LpstpPrdTermsCondService LpstpPrdTermsCondService;

	@Autowired
	private LpstpPrdDocService LpstpPrdDocService;

	@Autowired
	private LpcomSetBorrMapService lpcomSetBorrMapService;

	@Autowired
	private LpcomSetFacMapService LpcomSetFacMapService;

	@Autowired
	private LpcomSecOwnerService lpcomSecOwnerService;

	@Autowired
	private LpcorpDynamicAssessmentService lpcorpDynamicAssessmentService;

	@Autowired
	private LpcorpDynamicAssmntDataService lpcorpDynamicAssmntDataService;

	@Autowired
	private LpstpUserService lpstpUserService;

	@Autowired
	private LpstpWorkflowService LpstpWorkflowService;

	@Autowired
	private LpstpWfFlowService LpstpWfFlowService;

	@Autowired
	private LpstpWfPagelistService LpstpWfPagelistService;

	@Autowired
	private LpstpWfFlowpointService LpstpWfFlowpointService;

	@Autowired
	private PrimaryIdGenerationService primaryIdGenerationService;

	@Autowired
	private LpcomMailboxService lpcomMailboxService;

	@Autowired
	private LpcomPropRecommendService lpcomPropRecommendService;
	@Autowired
	private FinancialMasterService financialMasterService;
	@Autowired
	private LpcomGlobalVariableService lpcomGlobalVariableService;
	@Autowired
	private LpstpFinFormulaService lpstpFinFormulaService;
	@Autowired
	private LpcomPropAdditionalInfoService lpcomPropAdditionalInfoService;

	@Autowired
	private LpstpUserAccessService lpstpUserAccessService;

	@Autowired
	private LpstpSchemeService LpstpSchemeService;
	@Autowired
	private SetOrganisationService setOrganisationService;
	@Autowired
	private SetOrgLevelService setOrganisationlevelService;
	@Autowired
	private LpstpOrganisationService lpstpOrganisationService;

	@Autowired
	private LpcomFacilityRecommendService LpcomFacilityRecommendService;

	@Autowired
	private LpmasListofvalues1Service lpmasListofvalues1Service;

	@Autowired
	private LpstpDelegationService lpstpDelegationService;

	@Autowired
	private LpcorpWcAnalysisService lpcorpWcAnalysisService;

	@Autowired
	private LpstpCranMasterService lpstpCranMasterService;

	@Autowired
	private LpcomCustInfoService lpcomCustInfoService;

	@Autowired
	private LpcomPageCommentService lpcomPageCommentService;
	@Autowired
	private LpcomDeviationService lpcomDeviationService;

	@Autowired
	private LpcomQueryMgmtService lpcomQueryMgmtService;

	@Autowired
	private LpstpOrgMappingService lpstpOrgMappingService;

	@Autowired
	private LpmasInterfaceLinkService LpmasInterfaceLinkService;

	@Autowired
	private LpstpAssessmentService lpstpAssessmentService;

	@Autowired
	private LpstpGlobalVariableService lpstpGlobalVariableService;

	@Autowired
	private LpstpDeviationService lpstpDeviationService;

	@Autowired
	private LpstpPrdAssmentService lpstpPrdAssmentService;

	@Autowired
	private LpcomFacAssessmentService lpcomFacAssessmentService;

	@Autowired
	private LpstpUserLocationService LpstpUserLocationService;

	@Autowired
	private LpcomIpletterDetService lpcomIpletterDetService;

	@Autowired
	private LpMasPslLov1Service lpMasPslLov1Service;

	@Autowired
	private LpMasPslLovService lpMasPslLovService;

	@Autowired
	private LpcomSecFacMappingService lpcomSecFacMappingService;

	@Autowired
	private LpcomBorrowerRelationshipService lpcomBorrowerRelationshipService;

	@Autowired
	private LpstpPSLMasterService lpstpPSLMasterService;

	@Autowired
	private LpcomDocAttachmentService lpcomDocAttachmentService;

	@Autowired
	private LpcomPSLClassificationService lpcomPSLClassificationService;

	@Autowired
	private LpcomPropTermsCondService lpcomPropTermsCondService;

	@Autowired
	private LpcomPrev3SanctionService lpcomPrev3SanctionService;

	@Autowired
	private LpstpUserClassService lpstpUserClassService;

	@Autowired
	private LpcomExposureDetService lpcomExposureDetService;

	@Autowired
	private LpcomPropLocationService lpcomPropLocationService;

	@Autowired
	private LpcorpTaSalesService lpcorpTaSalesService;

	@Autowired
	private LpcorpTaRetailService lpcorpTaRetailService;

	@Autowired
	private LpcorpTaProjectedSalesService lpcorpTaProjectedSalesService;

	@Autowired
	private LpmasPropertyService lpmasPropertyService;

	@Autowired
	private LpcomRBICheckListService lpcomRBICheckListService;

	@Autowired
	private LpcomProfSamplingService lpcomProfSamplingService;

	@Autowired
	private LpcomRcuApprovalService lpcomRcuApprovalService;

	/*
	 * @Autowired private
	 * com.sai.lendperfect.webservice.ncifcreation.Ncif_service Ncif_service;
	 */

	@Autowired
	private BcifCreationService bcifCreationService;

	@Autowired
	private LeadService leadService;

	@Autowired
	private LeadStatusCheckService leadStatusCheckService;

	@Autowired
	private LpcomReqRespDataService lpcomReqRespDataService;

	@Autowired
	private LpmasIntErrCodeService lpmasIntErrCodeService;

	@Autowired
	private LpmasSofService lpmasSofService;

	@Autowired
	private LpmasCropSofService lpmasCropSofService;

	@Autowired
	private LpcomBussApprovalService lpcomBussApprovalService;

	@Autowired
	private LpstpPrdDocFeeService lpstpPrdDocFeeService;

	@Autowired
	private LpstpPrdMarginService lpstpPrdMarginService;

	@Autowired
	private CustomerDetailsService customerDetailsService;

	@Autowired
	private LoanDetailsService loanDetailsService;

	@Autowired
	private ApplicationService applicationService;

	@Autowired
	private ApplicationRelationService applicationRelationService;

	@Autowired
	private LpstpPrdCoapguarcountService lpstpPrdCoapguarcountService;

	@Autowired
	private LpcomLiabilitiesService lpcomLiabilitiesService;

	@Autowired
	private LpcomOtherAssetsLiabilityService lpcomOtherAssetsLiabilityService;

	@Autowired
	private ByBankDocumentService byBankDocumentService;

	@Autowired
	private LpstpDelegatedPowersService lpstpDelegatedPowersService;

	@Autowired
	private LpcustApplicantEmployerService lpcustApplicantEmployerService;

	@Autowired
	private LpcustApplicantEduStudentService lpcustApplicantEduStudentService;

	@Autowired
	private LpcustApplicantEduCourseDetailService lpcustApplicantEduCourseDetailService;

	@Autowired
	private LpstpDocumentTemplateService documentTemplateService;

	@Autowired
	private LpstpPrdRepaymentCapacityService lpstpPrdRepaymentCapacityService;

	@Autowired
	private LpstpBulletInfoService lpstpBulletinfoService;

	/**/
	@Autowired
	private LpcustApplicantEduDetailService lpcustApplicantEduDetailService;

	@Autowired
	private LpcustApplicantIncexpensService lpcustApplicantIncexpensService;

	@Autowired
	private LpcustApplicantOtherIncomeService lpcustApplicantOtherIncomeService;

	@Autowired
	private LpcustApplicantOblicatService lpcustApplicantOblicatService;

	@Autowired
	private LpcustApplicantOtherexpService lpcustApplicantOtherexpService;

	@Autowired
	private LpcustApplicantEduScholarService lpcustApplicantEduScholarService;

	@Autowired
	private LpstpComboMasterService lpstpComboMasterService;

	@Autowired
	private DocumentManager documentManager;

	@Autowired
	private CbsService cbsService;

	@Autowired
	private SearchCriteriaService searchCriteriaService;

	@Autowired
	private LpcomScorecardService lpcomScorecardService;

	@Autowired
	private LpstpRiskBusinessruleService lpstpRiskBusinessruleService;

	@Autowired
	private LpstpRiskruleCutoffrangeService lpstpRiskruleCutoffrangeService;

	@Autowired
	private LpstpPrdConcessionService lpstpPrdConcessionService;

	@Autowired
	private LpcustApplicantTaxDetailService lpcustApplicantTaxDetailService;

	
	@Autowired
	private LpcomUserProposalService lpcomUserProposalService;
	
	
	@Autowired 
	private LpcustCibilIndividualService lpcustCibilIndividualService;
	
	@Autowired
	private AuditTrialService auditTrialService;

	public AuditTrialService getAuditTrialService() {
		return auditTrialService;
	}


	public LpcustCibilIndividualService getLpcustCibilIndividualService() {
		return lpcustCibilIndividualService;
	}

	@Autowired
	private LpstpPrdAnnexureService lpstpPrdAnnexureService;

	public LpstpPrdAnnexureService getLpstpPrdAnnexureService() {
		return lpstpPrdAnnexureService;
	}


	public LpcomproposalcopmofService getLpcomproposalcopmofService() {
		return lpcomproposalcopmofService;
	}

	public LpstpRiskBusinessruleService getLpstpRiskBusinessruleService() {
		return lpstpRiskBusinessruleService;
	}

	public LpstpRiskruleCutoffrangeService getLpstpRiskruleCutoffrangeService() {
		return lpstpRiskruleCutoffrangeService;
	}

	public LpstpPrdConcessionService getLpstpPrdConcessionService() {
		return lpstpPrdConcessionService;
	}

	public LpstpBulletInfoService getLpstpBulletinfoService() {
		return lpstpBulletinfoService;
	}

	public LpcomScorecardService getLpcomScorecardService() {
		return lpcomScorecardService;
	}

	@Autowired
	private CustaccountService custaccountService;

	public LpstpComboMasterService getLpstpComboMasterService() {
		return lpstpComboMasterService;
	}

	@Autowired
	private LpcomAssessmentService LpcomAssessmentService;

	public LpcomAssessmentService getLpcomAssessmentService() {
		return LpcomAssessmentService;
	}

	public void setLpcomAssessmentService(LpcomAssessmentService lpcomAssessmentService) {
		LpcomAssessmentService = lpcomAssessmentService;
	}

	public CbsService getCbsService() {
		return cbsService;
	}

	public LpcustApplicantEduDetailService getLpcustApplicantEduDetailService() {
		return lpcustApplicantEduDetailService;
	}

	public LpcustApplicantEduScholarService getLpcustApplicantEduScholarService() {
		return lpcustApplicantEduScholarService;
	}

	public LpcustApplicantOblicatService getLpcustApplicantOblicatService() {
		return lpcustApplicantOblicatService;
	}

	public LpcustApplicantOtherexpService getLpcustApplicantOtherexpService() {
		return lpcustApplicantOtherexpService;
	}

	public LpcustApplicantIncexpensService getLpcustApplicantIncexpensService() {
		return lpcustApplicantIncexpensService;
	}

	public LpcustApplicantOtherIncomeService getLpcustApplicantOtherIncomeService() {
		return lpcustApplicantOtherIncomeService;
	}

	/**/

	public LpstpBulletInfoService getLpstpBulletInfoService() {
		return lpstpBulletinfoService;
	}

	public LpcustApplicantEduCourseDetailService getLpcustApplicantEduCourseDetailService() {
		return lpcustApplicantEduCourseDetailService;
	}

	public LpstpPrdRepaymentCapacityService getLpstpPrdRepaymentCapacityService() {
		return lpstpPrdRepaymentCapacityService;
	}

	public ByBankDocumentService getByBankDocumentService() {
		return byBankDocumentService;
	}

	public SetUserGroupService getUserGroupService() {
		return setuserGroupService;
	}

	public LpstpFinMasterService getSetFinMasterService() {
		return setFinMasterService;
	}

	public LpstpCMAMasterService getSetCMAMasterService() {
		return setCMAMasterService;
	}

	public SetOrgLevelService getSetOrgLevel() {
		return setOrganisationlevelService;
	}

	public SetOrganisationService getsetOrganisationService() {
		return setOrganisationService;
	}

	public LoginService getLoginService() {
		return loginService;
	}

	public StQualitativeMasterService getStQualitativeMasterService() {
		return stQualitativeMasterService;
	}

	public LpstpPrdProFeeService getLpstpPrdProFeeService() {
		return lpstpPrdProFeeService;
	}

	public LpagriPrevCropPatternService getLpagriPrevCropPatternService() {
		return lpagriPrevCropPatternService;
	}

	public SequenceNoService getSequenceNoService() {
		return sequenceNoService;
	}

	public LpagriLandDetailService getLpagriLandDetailService() {
		return lpagriLandDetailService;
	}

	public LpstpScorecardMasterService getLpstpScorecardMasterService() {
		return lpstpScorecardMasterService;
	}

	public LpstpScorecardOptionMasterService getLpstpScorecardOptionMasterService() {
		return lpstpScorecardOptionMasterService;
	}

	/*
	 * public SetRbiCheckListService getSetRbiCheckListService() { return
	 * setRbiCheckListService; }
	 */

	public LpagriCurrCropPatternService getLpagriCurrCropPatternService() {
		return lpagriCurrCropPatternService;
	}

	public StGeographyMasterService getStGeographyMasterService() {
		return stGeographyMasterService;
	}

	public LpcomSourcingDetService getLpcomSourcingDetService() {
		return lpcomSourcingDetService;
	}

	public LpstpFacilityService getLpstpFacilityService() {
		return lpstpFacilityService;
	}

	public LpcomCaseDetSaleService getLpcomCaseDetSaleService() {
		return lpcomCaseDetSaleService;
	}

	public LpcomCaseDetCreditService getLpcomCaseDetCreditService() {
		return lpcomCaseDetCreditService;
	}

	public LpcomShareHoldingService getLpcomShareHoldingService() {
		return lpcomShareHoldingService;
	}

	public LpcorpLandDetailService getLpcorpLandDetailService() {
		return lpcorpLandDetailService;
	}

	public LpcorpCropDetService getLpcorpCropDetService() {
		return lpcorpCropDetService;
	}

	public LpcorpGuarnteeDetService getLpcorpGuarnteeDetService() {

		return lpcorpGuarnteeDetService;
	}

	public LpmasBizVerticalService getLpmasBizVerticalService() {

		return lpmasBizVerticalService;
	}

	public LpstpTakeoverChklistService getLpstpTakeoverChklistService() {

		return lpstpTakeoverChklistService;
	}

	public LpcomTakeoverChklistService getLpcomTakeoverChklistService() {

		return lpcomTakeoverChklistService;
	}

	public LpstpMailTemplateService getMailTemplateService() {
		return mailTemplateService;
	}

	public LpstpDocumentTemplateService getDocumentTemplateService() {
		return documentTemplateService;
	}

	public LpAgriReferenceService getLaAgriReferenceService() {
		return LpAgriReferenceService;
	}

	public LpagriYieldMasterService getLpagriYieldMasterService() {
		return LpagriYieldMasterService;
	}

	public LpcorpModelSaleService getLpcorpModelSaleService() {
		return LpcorpModelSaleService;
	}

	public LpcorpDebtorsSaleService getLpcorpDebtorsSaleService() {
		return LpcorpDebtorsSaleService;
	}

	public LpstpTermsCondtnService getLpstpTermsCondtnService() {
		return LpstpTermsCondtnService;
	}

	public EmailManager getEmailManager() {
		return emailManager;
	}

	public DocumentManager getDocumentManager() {
		return documentManager;
	}

	public LpcorpExtRatingService getLpcorpExtRatingService() {
		return lpcorpExtRatingService;
	}

	public LpcorpExistingExposureService getLpcorpExistingExposureService() {
		return lpcorpExistingExposureService;
	}

	public FileUploadManager getFileUploadManager() {
		return fileUploadManager;
	}

	public void setFileUploadManager(FileUploadManager fileUploadManager1) {
		this.fileUploadManager = fileUploadManager1;
	}

	public LpmasPageMasterService getLpmasPageMasterService() {
		return lpmasPageMasterService;
	}

	public LpcomSecVehicleDetailService getLpcomSecVehicleDetailService() {
		return lpcomSecVehicleDetailService;
	}

	public LpcomSecurityService getLpcomSecurityService() {
		return lpcomSecurityService;
	}

	public LpcomSecBankDepositService getLpcomSecBankDepositService() {
		return lpcomSecBankDepositService;
	}

	public LpcomSecFurnFixDetService getLpcomSecFurnFixDetService() {
		return lpcomSecFurnFixDetService;
	}

	public LpcomSecFindocTradeService getLpcomSecFindocTradeService() {
		return lpcomSecFindocTradeService;
	}

	public LpcomSecFindocNtradeService getLpcomSecFindocNtradeService() {
		return lpcomSecFindocNtradeService;
	}

	public LpcorpMeetingDetService getLpcorpMeetingDetService() {
		return lpcorpMeetingDetService;
	}

	public LpcorpVisitDetService getLpcorpVisitDetService() {
		return lpcorpVisitDetService;
	}

	public LpcorpReferenceDetService getLpcorpReferenceDetService() {
		return lpcorpReferenceDetService;
	}

	public LpcomSecPropertyService getLpcomSecPropertyService() {
		return lpcomSecPropertyService;
	}

	public LpcomSecPlntMchnryDetailService getSecPlntMchnryDetailService() {
		return lpcomSecPlntMchnryDetailService;
	}

	public LpcomSecJewelDetService getLpcomSecJewelDetService() {
		return lpcomSecJewelDetService;
	}

	public LpcomSecGoodsDetailService getLpcomSecGoodsDetailService() {
		return lpcomSecGoodsDetailService;
	}

	public LpcorpAccCondAnalysis2Service getLpcorpAccCondAnalysis2Service() {
		return LpcorpAccCondAnalysis2Service;
	}

	public LpmasListofvalueService getLpmasListofvalueService() {
		return LpmasListofvalueService;
	}

	public LpstpDocumentService getLpstpDocumentService() {
		return LpstpDocumentService;
	}

	public LpcomPropDocumentService getLpcomPropDocumentService() {
		return LpcomPropDocumentService;
	}

	public LpcorpRbiPslClauseService getLpcorpRbiPslClauseService() {
		return lpcorpRbiPslClauseService;
	}

	public LpstpSecurityService getLpstpSecurityService() {
		return lpstpSecurityService;
	}

	public LpcomCustDataIndService getLpcomCustDataIndService() {
		return lpcomCustDataIndService;
	}

	public LpcomCustContctDetService getLpcomCustContctDetService() {
		return LpcomCustContctDetService;
	}

	public LpcomCustDataNindService getLpcomCustDataNindService() {
		return lpcomCustDataNindService;
	}

	public LpcomCustAddrService getLpcomCustAddrService() {
		return lpcomCustAddrService;
	}

	public LpagriFleetDetService getLpagriFleetDetService() {
		return lpagriFleetDetService;
	}

	public LpagriExistingExposureService getLpagriExistingExposureService() {
		return lpagriExistingExposureService;
	}

	public LpcorpAccCondCmtAnnexService getLpcorpAccCondCmtService() {
		return lpcorpAccCondCmtService;
	}

	public LpcorpFacilityService getLpcorpFacilityService() {
		return LpcorpFacilityService;
	}

	public LpstpProductDetService getLpstpProductDetService() {
		return lpstpProductDetService;
	}

	public LpstpPrdIntRateService getLpstpPrdInterestRateService() {
		return lpstpPrdIntRateService;
	}

	public LpcorpBuyerSupplierService getLpcorpBuyerSupplierService() {
		return lpcorpBuyerSupplierService;
	}

	public LpcorpForexExpoService getLpcorpForexExpoService() {
		return lpcorpForexExpoService;
	}

	public LpcorpCirAnnexService getLpcorpCirAnnexService() {
		return lpcorpCirAnnexService;
	}

	public LpstpAnnexMasterService getLpstpAnnexMasterService() {
		return lpstpAnnexMasterService;
	}

	public LpcorpCompSheetAnnexService getLpcorpCompSheetAnnexService() {
		return lpcorpCompSheetAnnexService;
	}

	public LpcorpBcacAnnexService getLpcorpBcacAnnexService() {
		return lpcorpBcacAnnexService;
	}

	public LpcorpCompCpAnnexService getLpcorpCompCpAnnexService() {
		return lpcorpCompCpAnnexService;
	}

	public LpcorpAccCondCmtAnnexService getLpcorpAccCondCmtAnnexService() {
		return lpcorpAccCondCmtAnnexService;
	}

	public ListOfValuesService getListOfValuesService() {
		return listOfValuesService;
	}

	public LpcomPropPartyService getLpcomPropPartyService() {
		return lpcomPropPartyService;
	}

	public LpcomProposalService getLpcomProposalService() {
		return lpcomProposalService;
	}

	public Lpcorp26asGstService getLpcorp26asGstService() {
		return Lpcorp26asGstService;
	}

	public LpstpPrdTermsCondService getLpstpPrdTermsCondService() {
		return LpstpPrdTermsCondService;
	}

	public LpstpPrdDocService getLpstpPrdDocService() {
		return LpstpPrdDocService;
	}

	public LpcomSetFacMapService getLpcomSetFacMapService() {
		return LpcomSetFacMapService;

	}

	public LpcomSetBorrMapService getLpcomSetBorrMapService() {
		return lpcomSetBorrMapService;
	}

	public LpcomSecOwnerService getLpcomSecOwnerService() {
		return lpcomSecOwnerService;
	}

	public LpcorpDynamicAssessmentService getLpcorpDynamicAssessmentService() {
		return lpcorpDynamicAssessmentService;
	}

	public LpcorpDynamicAssmntDataService getLpcorpDynamicAssmntDataService() {
		return lpcorpDynamicAssmntDataService;
	}

	public PrimaryIdGenerationService getPrimaryIdGenerationService() {
		return primaryIdGenerationService;
	}

	public LpstpUserService getLpstpUserService() {
		return lpstpUserService;
	}

	public FinancialMasterService getFinancialMasterService() {
		return financialMasterService;
	}

	public LpcomGlobalVariableService getLpcomGlobalVariableService() {
		return lpcomGlobalVariableService;
	}

	public LpstpFinFormulaService getLpstpFinFormulaService() {
		return lpstpFinFormulaService;
	}

	public LpstpScrcrdLapsDefinedService getLpstpScrcrdLapsDefinedService() {
		return lpstpScrcrdLapsDefinedService;
	}

	public LpstpWorkflowService getLpstpWorkflowService() {
		return LpstpWorkflowService;
	}

	public LpstpWfFlowService getLpstpWfFlowService() {
		return LpstpWfFlowService;
	}

	public LpstpWfPagelistService getLpstpWfPagelistService() {
		return LpstpWfPagelistService;
	}

	public LpstpWfFlowpointService getLpstpWfFlowpointService() {
		return LpstpWfFlowpointService;
	}

	public LpcomMailboxService getLpcomMailboxService() {
		return lpcomMailboxService;
	}

	public LpcomPropRecommendService getLpcomPropRecommendService() {
		return lpcomPropRecommendService;
	}

	public LpcomPropAdditionalInfoService getLpcomPropAdditionalInfoService() {
		return lpcomPropAdditionalInfoService;
	}

	public LpstpUserAccessService getLpstpUserAccessService() {
		return lpstpUserAccessService;
	}

	public LpstpSchemeService getLpstpSchemeService() {
		return LpstpSchemeService;
	}

	public LpstpOrganisationService getLpstpOrganisationService() {
		return lpstpOrganisationService;
	}

	public LpcomFacilityRecommendService getLpcomFacilityRecommendService() {
		return LpcomFacilityRecommendService;
	}

	public LpmasListofvalues1Service getLpmasListofvalues1Service() {
		return lpmasListofvalues1Service;
	}

	public LpcorpWcAnalysisService getLpcorpWcAnalysisService() {
		return lpcorpWcAnalysisService;
	}

	public LpstpDelegationService getLpstpDelegationService() {
		return lpstpDelegationService;
	}

	public LpstpCranMasterService getLpstpCranMasterService() {
		return lpstpCranMasterService;
	}

	public LpcomCustInfoService getLpcomCustInfoService() {
		return lpcomCustInfoService;
	}

	public void setLpcomCustInfoService(LpcomCustInfoService lpcomCustInfoService) {
		this.lpcomCustInfoService = lpcomCustInfoService;
	}

	public LpstpAssessmentService getLpstpAssessmentService() {
		return lpstpAssessmentService;
	}

	public LpstpPrdAssmentService getLpstpPrdAssmentService() {
		return lpstpPrdAssmentService;
	}

	public LpcomFacAssessmentService getLpcomFacAssessmentService() {
		return lpcomFacAssessmentService;
	}

	public LpstpGlobalVariableService getLpstpGlobalVariableService() {
		return lpstpGlobalVariableService;
	}

	public LpstpDeviationService getLpstpDeviationService() {
		return lpstpDeviationService;
	}

	public LpcomDeviationService getLpcomDeviationService() {
		return lpcomDeviationService;
	}

	public LpcomQueryMgmtService getLpcomQueryMgmtService() {
		return lpcomQueryMgmtService;
	}

	public LpstpUserLocationService getLpstpUserLocationService() {
		return LpstpUserLocationService;
	}

	public void setLpstpUserLocationService(LpstpUserLocationService lpstpUserLocationService) {
		LpstpUserLocationService = lpstpUserLocationService;
	}

	public LpcomIpletterDetService getLpcomIpletterDetService() {
		return lpcomIpletterDetService;
	}

	public LpstpOrgMappingService getLpstpOrgMappingService() {
		return lpstpOrgMappingService;
	}

	public LpmasInterfaceLinkService getLpmasInterfaceLinkService() {
		return LpmasInterfaceLinkService;
	}

	public void setLpmasInterfaceLinkService(LpmasInterfaceLinkService lpmasInterfaceLinkService) {
		LpmasInterfaceLinkService = lpmasInterfaceLinkService;
	}

	/**
	 * @return the lpMasPslLov1Service
	 */
	public LpMasPslLov1Service getLpMasPslLov1Service() {
		return lpMasPslLov1Service;
	}

	/**
	 * @return the lpMasPslLovService
	 */
	public LpMasPslLovService getLpMasPslLovService() {
		return lpMasPslLovService;
	}

	public LpcomSecFacMappingService getLpcomSecFacMappingService() {
		return lpcomSecFacMappingService;
	}

	public LpcomPageCommentService getLpcomPageCommentService() {
		return lpcomPageCommentService;
	}

	public void setLpcomPageCommentService(LpcomPageCommentService lpcomPageCommentService) {
		this.lpcomPageCommentService = lpcomPageCommentService;
	}

	public LpcomBorrowerRelationshipService getLpcomBorrowerRelationshipService() {
		return lpcomBorrowerRelationshipService;
	}

	/**
	 * @return the lpstpPSLMasterService
	 */
	public LpstpPSLMasterService getLpstpPSLMasterService() {
		return lpstpPSLMasterService;
	}

	public LpcomDocAttachmentService getLpcomDocAttachmentService() {
		return lpcomDocAttachmentService;
	}

	/**
	 * @return the lpcomPSLClassificationService
	 */
	public LpcomPSLClassificationService getLpcomPSLClassificationService() {
		return lpcomPSLClassificationService;
	}

	public LpcomPropTermsCondService getLpcomPropTermsCondService() {
		return lpcomPropTermsCondService;
	}

	public LpcomPrev3SanctionService getLpcomPrev3SanctionService() {
		return lpcomPrev3SanctionService;
	}

	/**
	 * @return the lpstpUserClassService
	 */
	public LpstpUserClassService getLpstpUserClassService() {
		return lpstpUserClassService;
	}

	public LpcomExposureDetService getLpcomExposureDetService() {
		return lpcomExposureDetService;
	}

	public LpcomPropLocationService getLpcomPropLocationService() {
		return lpcomPropLocationService;
	}

	public LpcorpTaSalesService getLpcorpTaSalesService() {
		return lpcorpTaSalesService;
	}

	public LpcorpTaRetailService getLpcorpTaRetailService() {
		return lpcorpTaRetailService;
	}

	public LpcorpTaProjectedSalesService getLpcorpTaProjectedSalesService() {
		return lpcorpTaProjectedSalesService;
	}

	public LpmasPropertyService getLpmasPropertyService() {
		return lpmasPropertyService;
	}

	public LpcomRBICheckListService getLpcomRBICheckListService() {
		return lpcomRBICheckListService;
	}

	public LpcomProfSamplingService getLpcomProfSamplingService() {
		return lpcomProfSamplingService;
	}

	public LpcomRcuApprovalService getLpcomRcuApprovalService() {
		return lpcomRcuApprovalService;
	}

	/**
	 * @return the bcifCreationService
	 */
	public BcifCreationService getBcifCreationService() {
		return bcifCreationService;
	}

	/*
	 * public com.sai.lendperfect.webservice.ncifcreation.Ncif_service
	 * getNcif_service() { return Ncif_service; }
	 */

	public LeadStatusCheckService getLeadStatusCheckService() {
		return leadStatusCheckService;
	}

	public LpcomReqRespDataService getLpcomReqRespDataService() {
		return lpcomReqRespDataService;
	}

	public LeadService getLeadService() {
		return leadService;
	}

	public LpmasIntErrCodeService getLpmasIntErrCodeService() {
		return lpmasIntErrCodeService;
	}

	public LpmasSofService getLpmasSofService() {
		return lpmasSofService;
	}

	public LpmasCropSofService getLpmasCropSofService() {
		return lpmasCropSofService;
	}

	public LpcomBussApprovalService getLpcomBussApprovalService() {
		return lpcomBussApprovalService;
	}

	public LpstpPrdDocFeeService getLpstpPrdDocFeeService() {
		return lpstpPrdDocFeeService;
	}

	public LpstpPrdMarginService getLpstpPrdMarginService() {
		return lpstpPrdMarginService;
	}

	public CustomerDetailsService getCustomerDetailsService() {
		return customerDetailsService;
	}

	public LoanDetailsService getLoanDetailsService() {
		return loanDetailsService;
	}

	public ApplicationService getApplication() {
		return applicationService;
	}

	public ApplicationRelationService getApplicationRelation() {
		return applicationRelationService;
	}

	public LpcomLiabilitiesService getLpcomLiabilitiesService() {
		return lpcomLiabilitiesService;
	}

	public LpcomOtherAssetsLiabilityService getLpcomOtherAssetsLiabilityService() {
		return lpcomOtherAssetsLiabilityService;
	}

	public SetUserGroupService getSetuserGroupService() {
		return setuserGroupService;
	}

	public LpAgriReferenceService getLpAgriReferenceService() {
		return LpAgriReferenceService;
	}

	public LpcomSecPlntMchnryDetailService getLpcomSecPlntMchnryDetailService() {
		return lpcomSecPlntMchnryDetailService;
	}

	public SetOrganisationService getSetOrganisationService() {
		return setOrganisationService;
	}

	public SetOrgLevelService getSetOrganisationlevelService() {
		return setOrganisationlevelService;
	}

	public ApplicationService getApplicationService() {
		return applicationService;
	}

	public LpstpPrdCoapguarcountService getLpstpPrdCoapguarcountService() {
		return lpstpPrdCoapguarcountService;
	}

	public ApplicationRelationService getApplicationRelationService() {
		return applicationRelationService;
	}

	public LpcomCourseExpenseService getLpcomCourseExpenseService() {
		return lpcomCourseExpenseService;
	}

	public LpstpDelegatedPowersService getLpstpDelegatedPowersService() {
		return lpstpDelegatedPowersService;
	}

	public LpcustApplicantEmployerService getLpcustApplicantEmployerService() {
		return lpcustApplicantEmployerService;
	}

	public LpstpPrdIntRateService getLpstpPrdIntRateService() {
		return lpstpPrdIntRateService;
	}

	public LpcustApplicantEduStudentService getLpcustApplicantEduStudentService() {
		return lpcustApplicantEduStudentService;
	}

	public SearchCriteriaService getSearchCriteriaService() {
		return searchCriteriaService;
	}

	public LpcomproposalcopmofService getlpcomproposalcopmofService() {
		return lpcomproposalcopmofService;
	}

	public CustaccountService getCustaccountService() {
		return custaccountService;
	}

	public LpcomExternalValuationService getLpcomExternalValuationService() {
		return lpcomExternalValuationService;
	}

	public void setLpcomExternalValuationService(LpcomExternalValuationService lpcomExternalValuationService) {
		this.lpcomExternalValuationService = lpcomExternalValuationService;
	}

	public LpcomInternalValService getLpcomInternalValService() {
		return lpcomInternalValService;
	}

	public void setLpcomInternalValService(LpcomInternalValService lpcomInternalValService) {
		this.lpcomInternalValService = lpcomInternalValService;
	}

	public LpcustApplicantTaxDetailService getLpcustApplicantTaxDetailService() {
		return lpcustApplicantTaxDetailService;
	}
	
	public LpcomUserProposalService getLpcomUserProposalService() {
		return lpcomUserProposalService;
	}
	
	@Autowired
	LpmasQuickLinkService lpmasQuickLinkService;
	
	public LpmasQuickLinkService getLpmasQuickLinkService() {
		return lpmasQuickLinkService;
	}
	
	@Autowired
	LpcomLegalVerifcationService lpcomLegalVerifcationService;
	
	public LpcomLegalVerifcationService getLpcomLegalVerifcationService() {
		return lpcomLegalVerifcationService;
	}
	
	@Autowired
	LpcomLegalDocDetailService lpcomLegalDocDetailService;
	
	public LpcomLegalDocDetailService getLpcomLegalDocDetailService() {
		return lpcomLegalDocDetailService;
	}

	@Autowired
	OrganisationService organisationService;
	
	public OrganisationService getOrganisationService() {
		return organisationService;
	}

}
