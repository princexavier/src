package com.sai.lendperfect.application.util;

import java.math.BigDecimal;

public interface PrimaryIdGenerationService {
BigDecimal getProposalNo(String orgScode);

long getOrgId();

}
