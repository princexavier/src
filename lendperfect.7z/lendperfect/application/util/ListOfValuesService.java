package com.sai.lendperfect.application.util;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.commodel.LpcomSetBorrMap;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;


public interface ListOfValuesService {
 List<LpcomSetBorrMap> getPrimaryApplicant(String borrowerType,BigDecimal proposalNo);
 List<LpmasListofvalue> getOptionList(String llvOptionVal,String active);
 List<Object> getCustomerName(BigDecimal lppLpCustId);
 LpmasListofvalue findByLlvOptionVal(String lprRelType);
}
