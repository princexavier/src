package com.sai.lendperfect.application.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasPageMaster;

public class HeaderPageNavigationDataProvider {
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		logging.setLoggerClass(this.getClass());
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		
		List<LpmasPageMaster> LpmasPageMasterlist=new ArrayList();
		
		if(dpMethod.equals("getParentPageList"))
		{
			try{
				List<LpmasPageMaster> LpmasPagelist=new ArrayList();
				String active="Y";
				String type=(session.getAttribute("LP_COM_PROP_NO")).toString();
				if(type.equals("0")){
					type="S";
				}
				if(type.equalsIgnoreCase("new") || (type!="0" && type!=null && !type.equalsIgnoreCase("S")))
					type="P";
				LpmasPageMasterlist= serviceProvider.getLpmasPageMasterService().findByLpmPageActiveAndLpmPageTypeAndLpmParentLinkOrderByLpmPageId(active,type,new BigDecimal(0));
				LpmasPagelist=serviceProvider.getLpmasPageMasterService().findByLpmPageActiveAndLpmParentLinkGreaterThan("Y",new BigDecimal(0));
				responseHashMap.put("parentList", LpmasPageMasterlist);
				responseHashMap.put("allChildList", LpmasPagelist);
				
			
			}
			catch(Exception e)
			{
			
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
				
	    }
		if(dpMethod.equals("getChildPageList"))
		{
			try{
						
				BigDecimal lpmParentLink=new BigDecimal( allRequestParams.get("requestData").toString());
				LpmasPageMasterlist=serviceProvider.getLpmasPageMasterService().findAllByLpmParentLinkAndLpmPageActiveOrderByLpmPageId(lpmParentLink,"Y");
				responseHashMap.put("childList", LpmasPageMasterlist);
				
			
			}
			catch(Exception e)
			{
			
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
				
	    }
			
	  return responseHashMap;
	}
}
