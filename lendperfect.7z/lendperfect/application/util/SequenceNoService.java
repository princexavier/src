package com.sai.lendperfect.application.util;

import java.math.BigDecimal;


public interface SequenceNoService {
BigDecimal findMax(String tablename,String seqid,String propid,BigDecimal propvalue);
BigDecimal findMaxString(String tablename,String seqid,String userid,String uservalue);
BigDecimal findoverallMax(String tablename,String seqid);
BigDecimal findMaxForTable(String tablename, String seqid);
BigDecimal findMaxForScoreCard(String tablename,String seqid,String propid,BigDecimal propvalue);
BigDecimal findMinForFromValue(String tablename,String seqid,String propid,BigDecimal propvalue);
BigDecimal findMaxForToValue(String tablename,String seqid,String propid,BigDecimal propvalue);
}

