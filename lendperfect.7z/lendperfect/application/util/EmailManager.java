package com.sai.lendperfect.application.util;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.commodel.MailTemplate;
import com.sai.lendperfect.master.lpmasProperty.LpmasPropertyService;
import com.sai.lendperfect.mastermodel.LpmasProperty;

@Service("EmailManager")
public class EmailManager {

	
	private  JavaMailSenderImpl sender;

	@Autowired
	private LpmasPropertyService lpmasPropertyService;
	
	@Autowired
	private ApplicationContext applicationContext;
	
	private void loadEmailConfig()
	{
		List<BigDecimal> bigDecimals =new ArrayList<BigDecimal>(Arrays.asList(new BigDecimal("2"),new BigDecimal("3"),new BigDecimal("4"),new BigDecimal("5"),new BigDecimal("6")));
	
		LpmasPropertyService lpmasPropertyService = applicationContext.getBean(LpmasPropertyService.class);
		
		List<LpmasProperty> lpmasProperties = lpmasPropertyService.findByLpropRowIdInOrderByLpropRowId(bigDecimals);
		String emailPort="";
		String emailHost="";
		String emailId="";
		String emailPass="";
		String emailAvail="N";
		for(LpmasProperty lpmasProperty : lpmasProperties)
		{
			if(lpmasProperty.getLpropRowId().compareTo(new BigDecimal("2")) == 0)
			{
				emailAvail= Helper.correctNull(lpmasProperty.getLpropValue());
			}else if(lpmasProperty.getLpropRowId().compareTo(new BigDecimal("3"))  == 0)
			{
				emailId= Helper.correctNull(lpmasProperty.getLpropValue());
			}else if(lpmasProperty.getLpropRowId().compareTo(new BigDecimal("4"))  == 0)
			{
				emailPass= Helper.correctNull(lpmasProperty.getLpropValue());
			}else if(lpmasProperty.getLpropRowId().compareTo(new BigDecimal("5"))  == 0)
			{
				emailHost= Helper.correctNull(lpmasProperty.getLpropValue());
			}else if(lpmasProperty.getLpropRowId().compareTo(new BigDecimal("6"))  == 0)
			{
				emailPort= Helper.correctNull(lpmasProperty.getLpropValue());
			}
		}
		/*EmailManager emailManager=new EmailManager(emailHost,Integer.parseInt(emailPort),emailId,emailPass,emailAvail);		
		serviceProvider.setEmailManager(emailManager);*/
		
		sender = new JavaMailSenderImpl();
		sender.setHost(emailHost);
		sender.setPort(Integer.parseInt(emailPort));
		sender.setUsername(emailId);
        sender.setPassword(emailPass);
        sender.setProtocol("smtp");
        Properties props = sender.getJavaMailProperties();
        props.put("mail.smtp.auth", true);
        props.put("mail.smtp.starttls.enable",true);
        props.put("mail.debug", false);
        props.put("mail.avail", emailAvail);
	}
	
	public boolean sendEmail(MailTemplate mailtemplate,HashMap hshMap) throws Exception
	{
		try
		{
			
			loadEmailConfig();
			if(Helper.correctNull(sender.getJavaMailProperties().getProperty("mail.avail")).equalsIgnoreCase("Y"))
			{
				MimeMessage message = sender.createMimeMessage();
				 MimeMessageHelper helper = new MimeMessageHelper(message,true);
				 if(!Helper.correctNull(mailtemplate.getMessage()).equalsIgnoreCase(""))
				 {
					
					List<String> arryString = new ArrayList<>();
					 String mess = Helper.correctNull(mailtemplate.getMessage());
					 String messreplaced = Helper.correctNull(mailtemplate.getMessage());
					 Pattern pattern = Pattern.compile("@\\w+");
					 Matcher matcher = pattern.matcher(mess);
					 while(matcher.find())
					 {
						 arryString.add(matcher.group());
					 }
					 for(String str : arryString)
					 {
						 messreplaced=messreplaced.replace(str, Helper.correctNull((String) hshMap.get(str)));
					 }
					 mailtemplate.setMessage(messreplaced);
				 }
				 helper.setFrom(Helper.correctNull(sender.getUsername()));
				 if(mailtemplate.getTo().size()!=0)
				 {
					 if (mailtemplate.getTo().size() > 0) {
						 String[] str =mailtemplate.getTo().toArray(new String[mailtemplate.getTo().size()]);
						 if(str.length>0)
						 {
							 helper.setTo(str);
						 }
					}else
					 {
						 helper.setTo(mailtemplate.getToAsList());
					 }
					 
					 if(!Helper.correctNull(mailtemplate.getMessage()).equalsIgnoreCase(""))
					 {
						 helper.setText(mailtemplate.getMessage(),true);
					 }else
					 {
						 return false;
					 }
					 if(mailtemplate.isFile())
					 {
						 if(mailtemplate.getFile() !=null)
						 {
							 helper.addAttachment(mailtemplate.getFile().getFilename(), mailtemplate.getFile());					 
						 }else
						 {
							 return false;
						 }
					 }
					 if (mailtemplate.getBcc().size() > 0) {
						helper.setBcc(mailtemplate.getBcc().toArray(new String[mailtemplate.getBcc().size()]));
					 }
					 if (mailtemplate.getCc().size() > 0) {
							helper.setCc(mailtemplate.getCc().toArray(new String[mailtemplate.getCc().size()]));
					}
					 if(!Helper.correctNull(mailtemplate.getSubject()).equalsIgnoreCase(""))
					 {
						 helper.setSubject(Helper.correctNull(mailtemplate.getSubject()));
					 }else
					 {
						 return false;
					 }
					 sender.send(message);	
					 return true;
				 }else
				 {
					 return false;
				 }
			}else
			{
				return false;
			}
		}catch(Exception e)
		{
			e.printStackTrace();
			 return false;
		}
		 
	}


}
