package com.sai.lendperfect.application.util;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service("sequenceNoService")
@Transactional
public class SequenceNoServiceImpl implements SequenceNoService {
	@PersistenceContext
	private EntityManager entityManager;
	Logger logger = LoggerFactory.getLogger(this.getClass());
	 List max;
	 BigDecimal b;
	public BigDecimal findMax(String tablename, String seqid, String propid, BigDecimal propvalue) {
		try{
		 Query query = entityManager.createNativeQuery("select nvl(max("+seqid+"),0) from "+tablename+" where "+propid+"="+propvalue+"");  
		  max= query.getResultList();
		  b=new BigDecimal(max.get(0).toString()); 
		}
		catch(Exception e){	
			if(max==null)
			{
				  b=new BigDecimal(0); 
				e.printStackTrace();
			}
			
		}
			
	return b;
	}
	public BigDecimal findMaxString(String tablename, String seqid, String userid, String uservalue) {
		try{
			 Query query = entityManager.createNativeQuery("select nvl(max("+seqid+"),0) from "+tablename+" where "+userid+"='"+uservalue+"'");  
			  max= query.getResultList();
			  b=new BigDecimal(max.get(0).toString()); 
			}
			catch(Exception e){		
				if(max==null)
				{
					  b=new BigDecimal(0); 
					e.printStackTrace();
				}
			}
		return b;
	}

	public BigDecimal findoverallMax(String tablename, String seqid) {  //overall sequence without any proposal no  add by dhanam 
		// TODO Auto-generated method stub
		try{
			 Query query = entityManager.createNativeQuery("select nvl(max("+seqid+"),0) from "+tablename);  
			  max= query.getResultList();
			  b=new BigDecimal(max.get(0).toString()); 
			  if(b.equals(new BigDecimal(0)))
			  {
				b=new BigDecimal(1);  
			  }
			  else
			  { 
				b=b.add(new BigDecimal(1));  
			  }
			}
			catch(Exception e){		
				if(max==null)
				{
					e.printStackTrace();
				}
			}
		return b;
	}
	
	public BigDecimal findMaxForTable(String tablename, String seqid) {  // sequence for customer details add by deepika 
		// TODO Auto-generated method stub
		try{
			 Query query = entityManager.createNativeQuery("select nvl(max("+seqid+"),0) from "+tablename);  
			  max= query.getResultList();
			  b=new BigDecimal(max.get(0).toString()); 
			  if(b.equals(new BigDecimal(0)))
			  {
				b=new BigDecimal(1000000);  
			  }
			  else
			  {
				b=b.add(new BigDecimal(1));  
			  }
			}
			catch(Exception e){		
				if(max==null)
				{
					e.printStackTrace();
				}
			}
		return b;
	}
	public BigDecimal findMaxForScoreCard(String tablename, String seqid, String propid, BigDecimal propvalue) {
		try{
		 Query query = entityManager.createNativeQuery("select nvl(max("+seqid+"),0) from "+tablename+" where "+propid+"="+propvalue+"and (LSOM_DELETED='N' or LSOM_DELETED is null )and LSOM_OPTION_AVAILABLE='Y' ");  
		  max= query.getResultList();
		  b=new BigDecimal(max.get(0).toString()); 
		}
		catch(Exception e){	
			if(max==null)
			{
				  b=new BigDecimal(0); 
				e.printStackTrace();
			}
			
		}
			
	return b;
	}
	public BigDecimal findMinForFromValue(String tablename, String seqid, String propid, BigDecimal propvalue) {
		try{
			 Query query = entityManager.createNativeQuery("select nvl(min("+seqid+"),0) from "+tablename+" where "+propid+"="+propvalue+"and (LSOM_DELETED='N' or LSOM_DELETED is null )and LSOM_OPTION_AVAILABLE='Y' ");  
			  max= query.getResultList();
			  b=new BigDecimal(max.get(0).toString()); 
			}
			catch(Exception e){	
				if(max==null)
				{
					  b=new BigDecimal(0); 
					e.printStackTrace();
				}
				
			}
				
		return b;
	}
	@Override
	public BigDecimal findMaxForToValue(String tablename, String seqid, String propid, BigDecimal propvalue) {
		try{
			 Query query = entityManager.createNativeQuery("select nvl(max("+seqid+"),0) from "+tablename+" where "+propid+"="+propvalue+"and (LSOM_DELETED='N' or LSOM_DELETED is null )and LSOM_OPTION_AVAILABLE='Y' ");  
			  max= query.getResultList();
			  b=new BigDecimal(max.get(0).toString()); 
			}
			catch(Exception e){	
				if(max==null)
				{
					  b=new BigDecimal(0); 
					e.printStackTrace();
				}
				
			}
				
		return b;
	}
}