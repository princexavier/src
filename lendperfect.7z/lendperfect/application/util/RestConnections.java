package com.sai.lendperfect.application.util;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RestConnections {
	
	
	public  static Object PostConnection(Object requestObj,String Url,Object ResponseClass)
	{
		
		Class<?> responseClass =(Class<?>) ResponseClass;
		HttpEntity<Object> httpentity = new HttpEntity<>(requestObj);
		RestTemplate rs = new RestTemplate();

		ResponseEntity<?> respEntity =rs.postForEntity(Url, requestObj,responseClass);
		
		return respEntity;
		
		
	}
	public  static Object PostConnection(Object requestObj,String Url,Object ResponseClass,HttpHeaders httpHeader)
	{
		Class<?> responseClass =(Class<?>) ResponseClass;
		HttpEntity<Object> httpentity = new HttpEntity<>(requestObj,httpHeader);
		RestTemplate rs = new RestTemplate();

		ResponseEntity<?> respEntity =rs.postForEntity(Url, requestObj,responseClass);
		
		return respEntity;
		
	}

}
