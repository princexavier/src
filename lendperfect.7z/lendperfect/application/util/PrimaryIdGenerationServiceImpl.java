package com.sai.lendperfect.application.util;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("primaryIdGenerationService")
@Transactional
public class PrimaryIdGenerationServiceImpl implements PrimaryIdGenerationService{
	@PersistenceContext
	private EntityManager entityManager;
	Logger logger = LoggerFactory.getLogger(this.getClass());
	 List max;
	 BigDecimal b,propno;
	 int digitlen;
	public BigDecimal getProposalNo(String orgScode) {
		StringBuffer sb = new StringBuffer(orgScode);		
		try{			
			 Query query = entityManager.createNativeQuery("select nvl(max(LSD_PROP_NO),0)from LPCOM_SOURCING_DET" );  
			  max= query.getResultList();
			  b=new BigDecimal( max.get(0).toString());	
			  if(b.intValue()==0){
					 digitlen=10-b.toString().length();
					  for(int i=1;i<=digitlen;i++){
						sb.append("0");
					  }
						b=new BigDecimal(sb.append(b.add(new BigDecimal(1))).toString());
				 }	
		
			  else{
				  StringBuffer substr = new StringBuffer(max.get(0).toString());
				String temp=substr.substring(5,15).toString();
				propno=new BigDecimal(temp).add(new BigDecimal(1));
				 digitlen=10-propno.toString().length();
				  for(int i=1;i<=digitlen;i++){
					sb.append("0");
				  }
				  b=new BigDecimal(sb.append(propno).toString());
			  }
			 
		}
	  catch(Exception e){		
	   			e.printStackTrace();
			            }
		return b;
		}
	@Override
	public long getOrgId() {
		long orgId = -1;
		try{

			String orgid="LO_ORG_ID";
			String tablename="LPSTP_ORGANISATIONS";
			 Query query = entityManager.createNativeQuery("select nvl(max("+orgid+"),0) from "+tablename+"");  
			  max= query.getResultList();
			  orgId=Long.parseLong(max.get(0).toString());
			  if(orgId==0){
				  orgId=10000+1;
			  }
			  else
				  orgId=orgId+1;
			}
			catch(Exception e){	
					e.printStackTrace();
				
			}
		
		return orgId;
	}
	}


