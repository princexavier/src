package com.sai.lendperfect.application.util;

import java.math.BigDecimal;
import java.util.List;

public class MenuItems {
	
	
	private String name;
	private String url;
	private String writeble;
	private List<MenuItems> childern;
	private BigDecimal pageId;
	private String icon;
	private BigDecimal lpmparentlink;
	private String pageAccess;
	
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List getChildern() {
		return childern;
	}
	public void setChildern(List childern) {
		this.childern = childern;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getWriteble() {
		return writeble;
	}
	public void setWriteble(String writeble) {
		this.writeble = writeble;
	}
	public BigDecimal getPageId() {
		return pageId;
	}
	public void setPageId(BigDecimal pageId) {
		this.pageId = pageId;
	}
	public BigDecimal getLpmparentlink() {
		return lpmparentlink;
	}
	public void setLpmparentlink(BigDecimal lpmparentlink) {
		this.lpmparentlink = lpmparentlink;
	}
	
	public String getPageAccess() {
		return pageAccess;
	}
	public void setPageAccess(String pageAccess) {
		this.pageAccess = pageAccess;
	}
	
	@Override
	public String toString() {
		return "MenuItems [name=" + name + ", url=" + url + ", writeble=" + writeble + ", childern=" + childern
				+ ", pageId=" + pageId + ", icon=" + icon + ", lpmparentlink=" + lpmparentlink + ", pageAccess="
				+ pageAccess + "]";
	}
	

}
