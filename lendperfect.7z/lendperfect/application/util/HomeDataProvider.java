package com.sai.lendperfect.application.util;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.servlet.http.HttpSession;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustLoanDetail;
import com.sai.lendperfect.commodel.LpcomCaseDetSale;
import com.sai.lendperfect.commodel.LpcomMailbox;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasPageMaster;
import com.sai.lendperfect.setup.mailtemplate.LpstpMailTemplateProvider;
import com.sai.lendperfect.setupmodel.LpstpFacility;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.LpstpWfFlow;
import com.sai.lendperfect.setupmodel.LpstpWfFlowpoint;
import com.sai.lendperfect.setupmodel.SetUserGroup;
import com.sai.lendperfect.setup.workflowmaster.LpstpWorkflowService;


public class HomeDataProvider {
	
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		logging.setLoggerClass(LpstpMailTemplateProvider.class);		
		
if(session.getAttribute("Flow_Type").toString().equalsIgnoreCase("T")|| session.getAttribute("Flow_Type").toString().equalsIgnoreCase("L")){
	   session.setAttribute("Workflow_Id",1);

}


		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		String active="Y";
		String workflowid="";
		String eduLoan = "";
		long prodCode = 0;
		List<LpcustLoanDetail> lpcustLoanDetail = new ArrayList();
		
		List<LpmasPageMaster> lpmasPageMasterlist=new ArrayList();
	   if(dpMethod.equals("getPageMaster"))
		{
		   
			Map <String,Object> dataHashMap=new HashMap<String,Object>();
			Long grpId=Long.parseLong(session.getAttribute("groupid").toString());
			SetUserGroup lpstpUserGroup=serviceProvider.getUserGroupService().findById(grpId);
			String grpRights=lpstpUserGroup.getSugGrpRights();
			String type=(session.getAttribute("LP_COM_PROP_NO")).toString();
			if(type.equals("0")){
				type="S";
			}
			
			List<String> grpRightsList = Arrays.asList(grpRights.split("\\s*~\\s*"));
			HashMap grpMap = new HashMap<>();
			for(String grp : grpRightsList)
			{
				String key = grp.substring(0, grp.length()-1);
				String value  = grp.substring(grp.length() - 1);
				grpMap.put(key, value);
			}
			if(type.equalsIgnoreCase("new") || (type!="0" && type!=null && !type.equalsIgnoreCase("S")))
				if(type.equalsIgnoreCase("new"))
				{					
					
					lpmasPageMasterlist= serviceProvider.getLpmasPageMasterService().findByLpmPageActiveAndLpmPageTypeInOrderByLpmSeqNum(active,"P","C");					
				}

				else if(!(null==session.getAttribute("Workflow_Id")) && !(session.getAttribute("Workflow_Id").toString().equalsIgnoreCase("new")))
				{ 

					LpcomProposal lpcomProposal=(serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(type)));
					if(lpcomProposal!=null)
					{
						
						lpcustLoanDetail = serviceProvider.getLoanDetailsService().findByLpcomProposalList(lpcomProposal);
												
						for(int i=0;i<lpcustLoanDetail.size();i++)
						{
                           	long serialNo  = lpcustLoanDetail.get(i).getLldSno();
                           	if(serialNo == 1)
                           	{
                           		 prodCode = lpcustLoanDetail.get(i).getLldPrdcode();
                           	}
							
						}
												
						LpstpProductDet LpstpProductDet = new LpstpProductDet();
						LpstpProductDet = serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prodCode);
						
						if(LpstpProductDet.getLpdPrdType().equalsIgnoreCase("pE"))
						{
							eduLoan = LpstpProductDet.getLpdPrdType();
						}
						
					}
					Map <String,Object> listMap=new HashMap<String,Object>();
					List<Object> pagelistListNew= null;
					workflowid=(session.getAttribute("Workflow_Id")).toString();
					LpcomMailbox lpcomMailboxobj=new LpcomMailbox();
					List<LpcomMailbox> lpcomMailboxList=serviceProvider.getLpcomMailboxService().findByLpcomProposal(serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString())));
					Iterator<LpcomMailbox> lpcomMailboxListItr=lpcomMailboxList.iterator();
					while(lpcomMailboxListItr.hasNext())
					{
						LpcomMailbox lpcomMailbox=lpcomMailboxListItr.next();
						if(lpcomMailbox.getLmFrwdTime()==null && (lpcomMailbox.getLmType().equalsIgnoreCase(session.getAttribute("Flow_Type").toString())))
						{
							if(session.getAttribute("Flow_Type").toString().equalsIgnoreCase("T")||session.getAttribute("Flow_Type").toString().equalsIgnoreCase("L"))
							{
							if(lpcomMailbox.getLmReferenceId()!=null && ((lpcomMailbox.getLmReferenceId().compareTo(new BigDecimal(session.getAttribute("sec_Id").toString())))==0))
							{
								lpcomMailboxobj=lpcomMailbox;
								LpstpWfFlow lpstpWfFlow=serviceProvider.getLpstpWfFlowService().findByLwfFlowpointId(Long.parseLong(lpcomMailboxobj.getLmFlowId().toString()));
								session.setAttribute("Workflow_Id",lpstpWfFlow.getLwfWorkflowId());
								workflowid=(session.getAttribute("Workflow_Id")).toString();
								break;
							}
							}
							else
							{
							lpcomMailboxobj=lpcomMailbox;
							break;
							}
					}
						
//						if(lpcomMailbox.getLmFrwdTime()==null)
//						lpcomMailboxobj=lpcomMailbox;
					}
					LpstpWfFlow lpstpWfFlow=serviceProvider.getLpstpWfFlowService().findByLwfFlowpointId(lpcomMailboxobj.getLmFlowId());					
					  List<Object[]>verticalpageList=serviceProvider.getLpstpWorkflowService().verticalpagelist(new BigDecimal(lpstpWfFlow.getLwfFlowpointId()));
					  pagelistListNew = new ArrayList<Object>(); 
					  for(Object[] object : verticalpageList)
					  {	if(!object[0].toString().equalsIgnoreCase("1600"))
					  {
						listMap=new HashMap<String,Object>();
						listMap.put("lpmPageId",object[0]);
						listMap.put("lpmPageName",object[1]);
						listMap.put("lpmParentLink",object[2]);
						listMap.put("lpmSeqNum",object[3]);
						listMap.put("lpmPageType",object[4]);
						listMap.put("lpmPageActive",object[5]);
						listMap.put("lpmLinkName",object[6]);
						listMap.put("lpmPageProperty1",object[7]);
						pagelistListNew.add(listMap);
					  }
					  else
					  { 
						  if(eduLoan.equalsIgnoreCase("pE"))
							  {

							listMap=new HashMap<String,Object>();
							listMap.put("lpmPageId",object[0]);
							listMap.put("lpmPageName",object[1]);
							listMap.put("lpmParentLink",object[2]);
							listMap.put("lpmSeqNum",object[3]);
							listMap.put("lpmPageType",object[4]);
							listMap.put("lpmPageActive",object[5]);
							listMap.put("lpmLinkName",object[6]);
							listMap.put("lpmPageProperty1",object[7]);
							pagelistListNew.add(listMap);
							  }
//						  
					  }
					    }
					lpmasPageMasterlist=new ObjectMapper()
							.convertValue(pagelistListNew,new TypeReference<List<LpmasPageMaster>>() {});
			
				}
				else{
					lpmasPageMasterlist= serviceProvider.getLpmasPageMasterService().findByLpmPageActiveAndLpmPageTypeInOrderByLpmSeqNum(active,"P","C");	
					}
			else
			{
				lpmasPageMasterlist= serviceProvider.getLpmasPageMasterService().findByLpmPageActiveAndLpmPageTypeOrderByLpmSeqNum(active,"S");	
				

			}
			//lpmasPageMasterlist= serviceProvider.getLpmasPageMasterService().findByLpmPageActiveAndLpmPageTypeOrderByLpmSeqNum(active,type);	
			//lpmasPageMasterlist.sort((LpmasPageMaster m1, LpmasPageMaster m2)->String.valueOf(m1.getLpmPageId()).compareTo(String.valueOf(m2.getLpmPageId())));
			
			List<LpmasPageMaster> parentList = lpmasPageMasterlist.stream().
					filter(m3->m3.getLpmParentLink().equals(new BigDecimal(0))).collect(Collectors.toList());
			
			HashMap<BigDecimal, List<LpmasPageMaster>> childMap = (HashMap<BigDecimal, List<LpmasPageMaster>>) lpmasPageMasterlist.stream().
					filter(m3->! m3.getLpmParentLink().equals(new BigDecimal(0))).collect(Collectors.groupingBy(LpmasPageMaster::getLpmParentLink)); 
			
			List<MenuItems> MenuItemsList = new ArrayList<>();
			List<MenuItems> childMenuItemsList = new ArrayList<>();
			
			for(int i = 0 ;i<parentList.size();i++)
			{
				LpmasPageMaster lpmasPageMaster=parentList.get(i);
				childMenuItemsList=new ArrayList<>();
				if((Helper.correctNull((String) grpMap.get(String.valueOf(lpmasPageMaster.getLpmPageId())))).equalsIgnoreCase("D"))
				{
					List<LpmasPageMaster> clist=new ArrayList<>();
					clist = childMap.get(lpmasPageMaster.getLpmPageId());
					if(clist==null)
					{
						clist=new ArrayList<>();
					}
					if(!clist.isEmpty()){
						for(LpmasPageMaster lpchild : clist)
						{
							MenuItems menuItems = new MenuItems();
							if(!(Helper.correctNull((String) grpMap.get(String.valueOf(lpchild.getLpmPageId())))).equalsIgnoreCase("D"))
							{
				         		menuItems.setName(Helper.correctNull(lpchild.getLpmPageName()));
								menuItems.setUrl(Helper.correctNull(lpchild.getLpmLinkName()));
								menuItems.setWriteble(Helper.correctNull((String) grpMap.get(String.valueOf(lpchild.getLpmPageId()))));
								menuItems.setIcon(Helper.correctNull(lpchild.getLpmPageProperty1()));
								menuItems.setPageId(new BigDecimal(String.valueOf(lpchild.getLpmPageId())));
								menuItems.setLpmparentlink(new BigDecimal(String.valueOf(lpchild.getLpmParentLink())));
								childMenuItemsList.add(menuItems);
							
							}
						}
						
					}
					
					if(!childMenuItemsList.isEmpty())
					{
						MenuItems menuItems = new MenuItems();
						menuItems.setName(Helper.correctNull(lpmasPageMaster.getLpmPageName()));
						menuItems.setUrl(Helper.correctNull(lpmasPageMaster.getLpmLinkName()));
						menuItems.setWriteble(Helper.correctNull((String) grpMap.get(String.valueOf(lpmasPageMaster.getLpmPageId()))));
						menuItems.setIcon(Helper.correctNull(lpmasPageMaster.getLpmPageProperty1()));
						menuItems.setChildern(childMenuItemsList);
						menuItems.setPageId(new BigDecimal(lpmasPageMaster.getLpmPageId()));
						menuItems.setLpmparentlink(new BigDecimal(String.valueOf(lpmasPageMaster.getLpmParentLink())));
						menuItems.setPageAccess(Helper.correctNull(lpmasPageMaster.getLpmPageType()));
						MenuItemsList.add(menuItems);
					}
				}else
				{					
					MenuItems menuItems = new MenuItems();
					menuItems.setName(Helper.correctNull(lpmasPageMaster.getLpmPageName()));
					menuItems.setUrl(Helper.correctNull(lpmasPageMaster.getLpmLinkName()));
					menuItems.setWriteble(Helper.correctNull((String) grpMap.get(String.valueOf(lpmasPageMaster.getLpmPageId()))));
					menuItems.setIcon(Helper.correctNull(lpmasPageMaster.getLpmPageProperty1()));
					menuItems.setPageId(new BigDecimal(lpmasPageMaster.getLpmPageId()));
					menuItems.setLpmparentlink(new BigDecimal(String.valueOf(lpmasPageMaster.getLpmParentLink())));
					menuItems.setPageAccess(Helper.correctNull(lpmasPageMaster.getLpmPageType()));
					List<LpmasPageMaster> clist=new ArrayList<>();
					clist = childMap.get(new BigDecimal(lpmasPageMaster.getLpmPageId()));
					
					if(clist==null)
					{
						clist=new ArrayList<>();
					}
					if(!clist.isEmpty() ){
						for(LpmasPageMaster lpchild : clist)
						{
							MenuItems menuItems1 = new MenuItems();
							if(!(Helper.correctNull((String) grpMap.get(String.valueOf(lpchild.getLpmPageId())))).equalsIgnoreCase("D"))
							{
								menuItems1.setName(Helper.correctNull(lpchild.getLpmPageName()));
								menuItems1.setUrl(Helper.correctNull(lpchild.getLpmLinkName()));
								menuItems1.setWriteble(Helper.correctNull((String) grpMap.get(String.valueOf(lpchild.getLpmPageId()))));
								menuItems1.setIcon(Helper.correctNull(lpmasPageMaster.getLpmPageProperty1()));
								menuItems1.setPageId(new BigDecimal(String.valueOf(lpchild.getLpmPageId())));
								menuItems1.setLpmparentlink(new BigDecimal(String.valueOf(lpchild.getLpmParentLink())));
								menuItems1.setPageAccess(Helper.correctNull(lpchild.getLpmPageType()));
								childMenuItemsList.add(menuItems1);
							}
						}
					}
					if(!childMenuItemsList.isEmpty())
					{
						menuItems.setChildern(childMenuItemsList);
					}
					MenuItemsList.add(menuItems);
				}
				
			}

			dataHashMap.put("gson",MenuItemsList);
			dataHashMap.put("getPageMasterList",lpmasPageMasterlist);
			responseHashMap.put("userid",StringUtils.capitalize(session.getAttribute("userid").toString()) );
			responseHashMap.put("location", StringUtils.capitalize(session.getAttribute("location").toString()));
			responseHashMap.put("designation",StringUtils.capitalize( session.getAttribute("designation").toString()));
			responseHashMap.put("firstname", StringUtils.capitalize(session.getAttribute("firstname").toString()));
			responseHashMap.put("lastname", StringUtils.capitalize(session.getAttribute("lastname").toString()));
			responseHashMap.put("propNo", session.getAttribute("Workflow_Id"));
			responseHashMap.put("ProcFlag",session.getAttribute("ProcFlag"));
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	   else if(dpMethod.equals("getPageClear"))
		{
		   BigDecimal propno=new BigDecimal(0);
		   session.setAttribute("LP_COM_PROP_NO",propno);
		   session.setAttribute("Workflow_Id",1);
		   session.setAttribute("ProcFlag","S");
		   responseHashMap.put("success", true);
		}
		else
		{
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
		
		
	}

}
