package com.sai.lendperfect.application.util;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.core.env.Environment;
import org.springframework.ejb.access.EjbAccessException;

import com.google.gson.Gson;
import com.sai.lendperfect.gsonauthedicate.JsonObjectResponse;
import com.sai.lendperfect.gsonauthedicate.ResponseStatus;
import com.sai.lendperfect.gsonauthedicate.status;
import com.sai.lendperfect.gsonauthedicate.request.JsonObjectRequest;
import com.sai.lendperfect.gsonauthedicate.request.UserProfileDTO;
import com.sai.lendperfect.gsonauthedicate.request.sessioncontext;
import com.sai.lendperfect.mastermodel.LpmasProperty;

import scala.math.BigDecimal;

public class LDAPAuthentication {
	
	public static boolean authenticate(String username,String password) 
	{
		Boolean  _return =false;
		Environment environment = null;
		try{
			DataSourceProperties dataSourceProperties=new DataSourceProperties();
			
			 DirContext ctx =null;
			 List<String>result = new ArrayList<>();
			 Hashtable<String, String> env =new Hashtable<>();
			 env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			 env.put(Context.PROVIDER_URL, environment.getRequiredProperty("lendperfect.LDAPAuthenticate") );
			 env.put(Context.SECURITY_AUTHENTICATION, "simple");
			 env.put(Context.SECURITY_PRINCIPAL,  username);//192.168.239.33:8080/PMCWebConnect/process
			 env.put(Context.SECURITY_CREDENTIALS, password);
			 env.put(Context.REFERRAL, "follow");	 	
			 ctx = new InitialDirContext(env);
			 if(ctx !=null)
			 {
				 _return =true;
			 }
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				
			} 
			return _return;		
	}
	
	public static boolean AuthendicateUserJsondata(HashMap hshRequestValues,ServiceProvider serviceProvider) throws EjbAccessException
	{

		URL u1=null;
		HttpURLConnection uc1=null;
		Gson gson = new Gson();
		DataInputStream datainput=null;
		StringBuffer sb=null;
		BufferedReader in=null;
		String response1 = "",outputResponse="";
		String urlUserid="" ,urlPassword="";
		boolean ldap = false;
		try{
			
		  DataSourceProperties dataSourceProperties=new DataSourceProperties();
				  
 		  JsonObjectRequest jsonRequest = new JsonObjectRequest();
		  
		  sessioncontext sessreq = new sessioncontext();
		  urlUserid = Helper.correctNull((String)hshRequestValues.get("txtusr_id"));
		  urlPassword = Helper.correctNull((String)hshRequestValues.get("txtusr_password"));
		  sessreq.setUserId(URLEncoder.encode(urlUserid,"UTF-8"));
		  sessreq.setUserPwd(URLEncoder.encode(urlPassword,"UTF-8"));
		  
		  jsonRequest.setSessioncontext(sessreq);
		  
		  UserProfileDTO userreq = new UserProfileDTO();
		  
		  userreq.setUserId(URLEncoder.encode(urlUserid,"UTF-8"));
		  userreq.setUserName("");
		  userreq.setPrimaryPwd(URLEncoder.encode(urlPassword,"UTF-8"));
		  
		  jsonRequest.setUserProfileDTO(userreq);
		  
		  jsonRequest.setApplicationID("PMC");
		  jsonRequest.setService("AuthenticateUser");
		  jsonRequest.setResponseStatus("");
		  
		  System.out.println(new Gson().toJson(jsonRequest));
		  
		  LpmasProperty lpmasProperty=serviceProvider.getLpmasPropertyService().findById(new java.math.BigDecimal(8));// file directory get from property  table
		  String LDAPAuthenticateUrl=Helper.correctNull((String)lpmasProperty.getLpropValue());

	      String APIURL=LDAPAuthenticateUrl+"?request="+(new Gson().toJson(jsonRequest));
		
		   System.out.println("=====APIURL====="+APIURL);
			String rtrnStr="";
			System.out.println("=====Before Create Connenction=====");
			
			u1 = new URL(APIURL); 
			uc1 = (HttpURLConnection)u1.openConnection(); 
			uc1.setDoOutput(true);
			uc1.setRequestProperty("Accept-Charset", "UTF-8");
		
			in = new BufferedReader(new InputStreamReader(
					uc1.getInputStream()));
    
             while ((outputResponse = in.readLine()) != null) 
             {
             System.out.println("outputResponse=======>"+outputResponse);
                 response1+=outputResponse;
                 }
                 in.close();
   
				
			
		       
		    /*   FileReader fr1 = null;
	      
	       String outputResponse1="";
	       BufferedReader br = new BufferedReader(new FileReader("E:\\pmcbAuthedicationSuccess.json"));
			// Simply iterate through XML response and show on console. 
			while ((outputResponse1 = br.readLine()) != null) { 
			 //	System.out.println(output); 
				response1+=outputResponse1; 
			}*/
             
            System.out.println("response1==========before============> :"+response1);
			response1 = response1.trim().replace("[","").replace("]", "").replace("/", "").replace("!", "").replace("-", "").replace("\"{","{").replace("}\"", "}").replace("\\", "");
			System.out.println("response1==========after============> :"+response1);
             
             
			Gson gson2 = new Gson();
			JsonObjectResponse jsonObject = gson2.fromJson(response1,JsonObjectResponse.class);
			 
			 System.out.println(jsonObject.toString());
			
			String strenumValue="",struserId="",struserName="",primaryPwd="",stremployeeID="";
			String txtEmailID="",strsesuserId="",strsesuserPwd="",strerrormessage="";
			boolean strmutable;
			
			ResponseStatus responsestatus = jsonObject.getResponseStatus();
			
			int errorCode=0,branchCode=0,desigCode=0,privilages=0;
			
			status result =jsonObject.getResponseStatus().getStatus();
	        Logger logger = LoggerFactory.getLogger(strerrormessage);
			strmutable=jsonObject.getResponseStatus().getStatus().isMutable();
			logger.info("strmutable===================>"+strmutable);
		    strenumValue=jsonObject.getResponseStatus().getStatus().getEnumValue();
			logger.info("strenumValue===================>"+jsonObject.getResponseStatus());
			errorCode= jsonObject.getResponseStatus().getErrorCode();
			logger.info("errorCode===================>"+errorCode);
			hshRequestValues.put("strenumValue", strenumValue);

			if(strenumValue.equalsIgnoreCase("SUCCESS"))
			{
				com.sai.lendperfect.gsonauthedicate.UserProfileDTO userProfileDTO = jsonObject.getUserProfileDTO();
				struserId=jsonObject.getUserProfileDTO().getUserId();
				logger.info("struserId===================>"+struserId);
				struserName=jsonObject.getUserProfileDTO().getUserName();
				logger.info("struserName===================>"+struserName);
				primaryPwd=jsonObject.getUserProfileDTO().getPrimaryPwd();
				logger.info("primaryPwd===================>"+primaryPwd);
				branchCode=jsonObject.getUserProfileDTO().getBranchCode();
				logger.info("branchCode===================>"+branchCode);
				stremployeeID=jsonObject.getUserProfileDTO().getEmployeeID();
				logger.info("stremployeeID===================>"+stremployeeID);
				hshRequestValues.put("stremployeeID", stremployeeID);
				txtEmailID=jsonObject.getUserProfileDTO().getTxtEmailID();
				logger.info("txtEmailID===================>"+txtEmailID);
				desigCode=jsonObject.getUserProfileDTO().getDesigCode();
				logger.info("desigCode===================>"+desigCode);
				privilages=jsonObject.getUserProfileDTO().getPrivilages();
				logger.info("privilages===================>"+privilages);
				com.sai.lendperfect.gsonauthedicate.sessioncontext sess= jsonObject.getSessioncontext();
				
				strsesuserId=jsonObject.getSessioncontext().getUserId();
				logger.info("strsesuserId===================>"+strsesuserId);
				strsesuserPwd=jsonObject.getSessioncontext().getUserPwd();
				logger.info("strsesuserPwd===================>"+strsesuserPwd);
				ldap = true;
			}
			else
			{
				errorCode= jsonObject.getResponseStatus().getErrorCode();
				logger.info("errorCode===================>"+errorCode);
				strerrormessage=jsonObject.getResponseStatus().getMessage();
				logger.info("strerrormessage===================>"+strerrormessage);
				
                com.sai.lendperfect.gsonauthedicate.sessioncontext sess= jsonObject.getSessioncontext();
				
				strsesuserId=jsonObject.getSessioncontext().getUserId();
				logger.info("strsesuserId===================>"+strsesuserId);
				strsesuserPwd=jsonObject.getSessioncontext().getUserPwd();
				logger.info("strsesuserPwd===================>"+strsesuserPwd);
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception is====>"+e.toString());
		}
		return ldap;
	}
}
