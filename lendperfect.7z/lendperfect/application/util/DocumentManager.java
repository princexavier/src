package com.sai.lendperfect.application.util;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.MailTemplate;
import com.sai.lendperfect.mastermodel.LpmasKeyParameter;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.setup.documenttemplate.LpstpDocumentTemplateService;
import com.sai.lendperfect.setupmodel.LpstpDocumentTemplate;
import com.sai.lendperfect.setupmodel.LpstpGeographyMaster;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.StGeographyMaster;

@Service("DocumentManager")
public class DocumentManager {
	
	@Autowired
	LpstpDocumentTemplateService lpstpDocumentTemplateService;
	
	@Autowired
	ServiceProvider serviceProvider;
	
	public String printDocument(String strdocument,LpcomProposal lpcomProposal,Integer prdcode) throws Exception
	{
		String docureplaced="",docu="",strtowords="";
		Map<String,Object> documentMap=new HashMap<String,Object>();
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		String strCheck="";
	
		try
		{
				 if(!strdocument.equalsIgnoreCase(""))
				 {
					 List<String> findingList = new ArrayList<String>();
					 
					 docu = strdocument;
					 docureplaced = strdocument;
					 Pattern pattern = Pattern.compile("@\\w+");
					 Matcher matcher = pattern.matcher(docu);
					 while(matcher.find())
					 {
						 findingList.add(matcher.group());
					 }
					 documentMap=constructDocumentMap(findingList,lpcomProposal,prdcode);
						 for(String str : findingList)
						 {
							 if(documentMap.containsKey(str))
							 {
								 String str1=String.valueOf( documentMap.get(str));
								 
								if (str1 == null||str1.equalsIgnoreCase("null") || str1 == "")
								{
									docureplaced=docureplaced.replace(str,"");
								}
								else
								{
									if((str.equalsIgnoreCase("@AMOUNTINWORDS"))||(str.equalsIgnoreCase("@EMIINWORDS")))
										{
											strtowords=String.valueOf(documentMap.get(str));
											str1=Helper.figtoWords(strtowords);
										 }else if(str.equalsIgnoreCase("@INTERESTTYPE"))	
											{
												strtowords=String.valueOf(documentMap.get(str));
												strCheck="interesttype";
												str1=listofvalues(strCheck,strtowords);
											}else if(str.equalsIgnoreCase("@BORROWERDESIGNATION")){
													strtowords=String.valueOf(documentMap.get(str));
													strCheck="Designation";
													str1=listofvalues(strCheck,strtowords);
												}
									 docureplaced=docureplaced.replace(str,str1);			
								}						
							 }
							 else
							 {
								 docureplaced=docureplaced.replace(str,"");
							 }
							
						 }
					 responseHashMap.put("docureplaced", docureplaced);
				 }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		 return docureplaced;	 
	}
	

	private String listofvalues(String strheader,String strvalue)
	{
			LpmasListofvalue lpmasListofvalue = new LpmasListofvalue();
			lpmasListofvalue = serviceProvider.getLpmasListofvalueService().findByLlvHeaderAndLlvOptionVal(strheader,strvalue);
				if (lpmasListofvalue != null) {
					strvalue = Helper.correctNull(lpmasListofvalue.getLlvOptionDesc());
				} else {
					strvalue = "";
				}
		return strvalue;		
	}
	
	
	private Map<String,Object> constructDocumentMap(List<String> findingList,LpcomProposal lpcomProposal,Integer prdcode)
	{
		Map<String,Object> 	documentMap=new HashMap<String,Object>();
		Iterator<String> findingListItr=findingList.iterator();
		Map<String,Map<String,Object>> documentMapByTable=new HashMap<String,Map<String,Object>>();
		while(findingListItr.hasNext())
		{
			String lkpKeyValue=findingListItr.next();
			LpmasKeyParameter lpmasKeyParamete=lpstpDocumentTemplateService.findLkpKeyValue(lkpKeyValue);
			Map<String,Object> fieldNameMap;
			if(documentMapByTable.containsKey(lpmasKeyParamete.getLkpTableName()))
				fieldNameMap=documentMapByTable.get(lpmasKeyParamete.getLkpTableName());
			else
				fieldNameMap=new HashMap<String,Object>();
				fieldNameMap.put(lkpKeyValue, lpmasKeyParamete.getLkpFieldName());
				documentMapByTable.put(lpmasKeyParamete.getLkpTableName(), fieldNameMap);	
		}
		Set<String> documentMapByTableKeySet=documentMapByTable.keySet();
		Iterator<String> documentMapByTableKeySetItr=documentMapByTableKeySet.iterator();
		while(documentMapByTableKeySetItr.hasNext())
		{
			String tableName=documentMapByTableKeySetItr.next();
			documentMap.putAll(getDocumentMap(tableName,documentMapByTable.get(tableName),lpcomProposal,prdcode));
		}
		return documentMap;	
	}
	
	
	private Map<String,Object> getDocumentMap(String tableName,Map<String,Object> fieldNameMap,LpcomProposal lpcomProposal,Integer prdcode)
	{
		Map<String,Object> 	documentMap=new HashMap<String,Object>();
		String query=constructQuery(tableName,fieldNameMap,lpcomProposal,prdcode);
		if(fieldNameMap.keySet().size()==1)
		{
		List<Object> objectList=lpstpDocumentTemplateService.findDocumentData(query);
		Iterator<Object> objectListItr=objectList.iterator();
		String delimeter="<br>";
		String key=fieldNameMap.keySet().iterator().next();
		while(objectListItr.hasNext())
		{
			if(!documentMap.containsKey(key))
				documentMap.put(key,objectListItr.next());
			else
				documentMap.put(key,documentMap.get(key).toString()+delimeter+objectListItr.next().toString());
		}
		}
		else
		{
			List<Object[]> objectArrayList=lpstpDocumentTemplateService.findDocumentDataWithMultiCol(query);
			int objectCounter=0;
			Set<String> fieldNameMapKeySet=fieldNameMap.keySet();
			Iterator<String> fieldNameMapKeySetItr=fieldNameMapKeySet.iterator();
			if(objectArrayList.isEmpty())
			{
				
			}
			else{
			while(fieldNameMapKeySetItr.hasNext())
			{ 
				Object[] objectArray=objectArrayList.get(0);
				documentMap.put(fieldNameMapKeySetItr.next(),objectArray[objectCounter++]);
			}
			}
		}
		return documentMap;
	}
	
	

	
	private String constructQuery(String tableName,Map<String,Object> fieldNameMap,LpcomProposal lpcomProposal,Integer prdcode)
	{
		StringBuilder query=new StringBuilder("select");
		Set<String> fieldNameMapKeySet=fieldNameMap.keySet();
			Iterator<String> fieldNameMapKeySetItr=fieldNameMapKeySet.iterator();
			while(fieldNameMapKeySetItr.hasNext())
			{
				if(query.toString().equals("select"))
				query.append(" "+fieldNameMap.get(fieldNameMapKeySetItr.next()));
				else
				query.append(" , "+fieldNameMap.get(fieldNameMapKeySetItr.next()));
			}
			
		switch ( tableName )
		{
		     //Applicant data
		case "LpcustApplicantData a" :
			 query.append(" from "+tableName+",LpcustAppcustRelation r where a.ladId=r.lpcustApplicantData and r.larType='A' and r.lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;		
			 
			 //Coapplicant data
		case "LpcustApplicantData c":
			 query.append(" from "+tableName+",LpcustAppcustRelation r where c.ladId=r.lpcustApplicantData and r.larType='C' and r.lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;	
			 
			//Guarantor data
		case "LpcustApplicantData g":
			 query.append(" from "+tableName+",LpcustAppcustRelation r where g.ladId=r.lpcustApplicantData and r.larType='G' and r.lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;	
			 
			 //External Terms & Conditions-Pre Disbursement
		case "LpcomPropTermsCond d":
			 query.append(" from "+tableName+" where d.lptcIntExt='E' and d.lptcDisbType='PR' and lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;	
			 
			 //External Terms & Conditions-Post Disbursement
		case "LpcomPropTermsCond d1":
			 query.append(" from "+tableName+" where d1.lptcIntExt='E' and d1.lptcDisbType='PO' and lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;		 
			 
			 //Internal Terms & Conditions-Pre Disbursement
		case "LpcomPropTermsCond t":
			 query.append(" from "+tableName+" where t.lptcIntExt='I' and  t.lptcDisbType='PR' and lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;	
			 
			 //Internal Terms & Conditions-Post Disbursement
		case "LpcomPropTermsCond t1":
			 query.append(" from "+tableName+" where t1.lptcIntExt='I' and  t1.lptcDisbType='PO' and lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;
			
			 //Current Date
		case "LpcustLoanDetail u":
			query.append(" from "+tableName+" where u.lldSno='1' and lpcomProposal="+lpcomProposal.getLpPropNo());
			 query.replace(23, 35,"'DD-MM-YYYY'");
			 break;
			 
			 //Current Day
		case "LpcustLoanDetail u1":
			 query.append(" from "+tableName+" where u1.lldSno='1' and lpcomProposal="+lpcomProposal.getLpPropNo());
			 query.replace(23, 27,"'DD'");
			 break;
			 
			 //Current Month
		case "LpcustLoanDetail u2":
			 query.append(" from "+tableName+" where u2.lldSno='1' and lpcomProposal="+lpcomProposal.getLpPropNo());
			 query.replace(23, 30,"'MONTH'");
			 break;
			 
			 //Current Year
		case "LpcustLoanDetail u3":
			 query.append(" from "+tableName+" where u3.lldSno='1' and lpcomProposal="+lpcomProposal.getLpPropNo());
			 query.replace(23, 29,"'YYYY'");
			 break;
			 
			 //Product Description
	   case  "LpstpProductDet p":
			 query.append(" from "+tableName+",LpcustLoanDetail r where p.lpdProdNewId="+prdcode+" and p.lpdProdNewId=r.lldPrdcode and r.lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;
		
			 //Branch Name,Branch Address
	  case  "LpstpOrganisation o":
			 query.append(" from "+tableName+",LpcomProposal r where r.lpOrgCode=o.loOrgId and r.lpPropNo="+lpcomProposal.getLpPropNo());
			 break;
			
			 //Branch City,State Description
	  case  "LpstpGeographyMaster g":
			 query.append(" from "+tableName+",LpcomProposal r,LpstpOrganisation o  where g.lgmCityCode=o.loCity and g.lgmStateCode=o.loState and r.lpOrgCode=o.loOrgId and r.lpPropNo="+lpcomProposal.getLpPropNo());
			 break;
			 
	
			 //Employee City,State Description
	  case  "LpcustApplicantEmployer e1":
			 query.append(" from "+tableName+",LpstpGeographyMaster g,LpcustAppcustRelation r  where g.lgmCityCode=e1.laePerempCity and g.lgmStateCode=e1.laePerempState and e1.ladId=r.lpcustApplicantData and r.larType='A' and r.lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;
		
			 //Employee Designation,Nature of Business,Number,Department,Address
	  case "LpcustApplicantEmployer e":	   
 		     query.append(" from "+tableName+",LpcustAppcustRelation r where e.ladId=r.lpcustApplicantData and r.larType='A' and r.lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;
		
			 //LoanDetails
	  case "LpcustLoanDetail l":
			 query.append(" from "+tableName+" where l.lldPrdcode="+prdcode+ "and lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;
		
			//Security Owner,Address
	  case "LpcomSecProperty s":	   
		 	 query.append(" from "+tableName+",LpcomSecOwner a,LpcustApplicantData b,LpcustAppcustRelation c where a.lsoOwnerId=b.ladId and a.lpcomSecurity=s.lpcomSecurity and c.lpcustApplicantData=b.ladId and c.lpcomProposal="+lpcomProposal.getLpPropNo());
			 break;
					   
			//Security City,State 
	  case "LpcomSecProperty s1":	   
		    query.append(" from "+tableName+",LpcomSecOwner a,LpcustApplicantData b,LpcustAppcustRelation c,LpstpGeographyMaster g where a.lsoOwnerId=b.ladId and a.lpcomSecurity=s1.lpcomSecurity and c.lpcustApplicantData=b.ladId and s1.lspCity=g.lgmCityCode and s1.lspState=g.lgmStateCode and c.lpcomProposal="+lpcomProposal.getLpPropNo());
			break;
		
			//Vechicle Seller name,vechicle name
	  case "LpcomSecVehicleDet s2":	   
		 	  query.append(" from "+tableName+",LpcomSecOwner a,LpcustApplicantData b,LpcustAppcustRelation c where a.lsoOwnerId=b.ladId and a.lpcomSecurity=s2.lpcomSecurity and c.lpcustApplicantData=b.ladId and c.lpcomProposal="+lpcomProposal.getLpPropNo());
			  break;
			
			//Application Approved By,Approved Date,Created By,Created On,Processed By,Processed On
	  case "LpcustLoanDetail q":
		  query.append(" from "+tableName+",LpcomProposal p where q.lpcomProposal=p.lpPropNo and q.lldSno='1' and p.lpPropNo="+lpcomProposal.getLpPropNo());
		  break;
	  		
			  
		default :
				 query.append(" from "+tableName+" where "+tableName.split(" ")[1]+".lpcomProposal="+lpcomProposal.getLpPropNo());	
		}
		return query.toString();
	}	
}
