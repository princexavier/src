package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name="LPCUST_CIBIL_INDIVIDUAL")
@NamedQuery(name="LpcustCibilIndividual.findAll", query="SELECT l FROM LpcustCibilIndividual l")
public class LpcustCibilIndividual implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CI_ROWID")
	private long ciRowId;

	private String appno;

	@Column(name="CI_ACKID")
	private String ciAckid;

	@Column(name="CI_CHMERRDESC")
	private String ciChmerrdesc;

	@Column(name="CI_CHMSCR")
	private String ciChmscr;

	@Column(name="CI_CHMSTATUS")
	private String ciChmstatus;

	@Column(name="CI_CIBILERRDESC")
	private String ciCibilerrdesc;

	@Column(name="CI_CIBILTUSCR")
	private BigDecimal ciCibiltuscr;

	@Column(name="CI_DELFLAG")
	private String ciDelflag;

	@Column(name="CI_ERRORGEN")
	private Timestamp ciErrorgen;

	@Column(name="CI_ERRORMSG")
	private String ciErrormsg;

	@Column(name="CI_FILENUMBER")
	private String ciFilenumber;

	@Column(name="CI_GENERATEDBY")
	private String ciGeneratedby;

	@Column(name="CI_GENERATEDDATE")
	private Date ciGenerateddate;

	@Lob
	@Column(name="CI_PDFREPORT")
	private byte[] ciPdfreport;

	@Column(name="CI_REFNUMBER")
	private String ciRefnumber;

	@Lob
	@Column(name="CI_REPORT")
	private String ciReport;

	@Column(name="CI_REPORTTYPE")
	private String ciReporttype;

	@Column(name="CI_STATUS")
	private String ciStatus;

	public long getCiRowId() {
		return ciRowId;
	}

	public void setCiRowId(long ciRowId) {
		this.ciRowId = ciRowId;
	}
	
	public LpcustCibilIndividual() {
	}

	public String getAppno() {
		return this.appno;
	}

	public void setAppno(String appno) {
		this.appno = appno;
	}

	public String getCiAckid() {
		return this.ciAckid;
	}

	public void setCiAckid(String ciAckid) {
		this.ciAckid = ciAckid;
	}

	public String getCiChmerrdesc() {
		return this.ciChmerrdesc;
	}

	public void setCiChmerrdesc(String ciChmerrdesc) {
		this.ciChmerrdesc = ciChmerrdesc;
	}

	public String getCiChmscr() {
		return this.ciChmscr;
	}

	public void setCiChmscr(String ciChmscr) {
		this.ciChmscr = ciChmscr;
	}

	public String getCiChmstatus() {
		return this.ciChmstatus;
	}

	public void setCiChmstatus(String ciChmstatus) {
		this.ciChmstatus = ciChmstatus;
	}

	public String getCiCibilerrdesc() {
		return this.ciCibilerrdesc;
	}

	public void setCiCibilerrdesc(String ciCibilerrdesc) {
		this.ciCibilerrdesc = ciCibilerrdesc;
	}

	public BigDecimal getCiCibiltuscr() {
		return this.ciCibiltuscr;
	}

	public void setCiCibiltuscr(BigDecimal ciCibiltuscr) {
		this.ciCibiltuscr = ciCibiltuscr;
	}

	public String getCiDelflag() {
		return this.ciDelflag;
	}

	public void setCiDelflag(String ciDelflag) {
		this.ciDelflag = ciDelflag;
	}

	public Timestamp getCiErrorgen() {
		return this.ciErrorgen;
	}

	public void setCiErrorgen(Timestamp ciErrorgen) {
		this.ciErrorgen = ciErrorgen;
	}

	public String getCiErrormsg() {
		return this.ciErrormsg;
	}

	public void setCiErrormsg(String ciErrormsg) {
		this.ciErrormsg = ciErrormsg;
	}

	public String getCiFilenumber() {
		return this.ciFilenumber;
	}

	public void setCiFilenumber(String ciFilenumber) {
		this.ciFilenumber = ciFilenumber;
	}

	public String getCiGeneratedby() {
		return this.ciGeneratedby;
	}

	public void setCiGeneratedby(String ciGeneratedby) {
		this.ciGeneratedby = ciGeneratedby;
	}

	public Date getCiGenerateddate() {
		return this.ciGenerateddate;
	}

	public void setCiGenerateddate(Date ciGenerateddate) {
		this.ciGenerateddate = ciGenerateddate;
	}

	public byte[] getCiPdfreport() {
		return this.ciPdfreport;
	}

	public void setCiPdfreport(byte[] ciPdfreport) {
		this.ciPdfreport = ciPdfreport;
	}

	public String getCiRefnumber() {
		return this.ciRefnumber;
	}

	public void setCiRefnumber(String ciRefnumber) {
		this.ciRefnumber = ciRefnumber;
	}

	public String getCiReport() {
		return this.ciReport;
	}

	public void setCiReport(String ciReport) {
		this.ciReport = ciReport;
	}

	public String getCiReporttype() {
		return this.ciReporttype;
	}

	public void setCiReporttype(String ciReporttype) {
		this.ciReporttype = ciReporttype;
	}

	public String getCiStatus() {
		return this.ciStatus;
	}

	public void setCiStatus(String ciStatus) {
		this.ciStatus = ciStatus;
	}

}