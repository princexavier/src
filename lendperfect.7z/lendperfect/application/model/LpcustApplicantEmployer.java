package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the LPCUST_APPLICANT_EMPLOYER database table.
 * 
 */
@Entity
@Table(name="LPCUST_APPLICANT_EMPLOYER")
@NamedQuery(name="LpcustApplicantEmployer.findAll", query="SELECT l FROM LpcustApplicantEmployer l")
public class LpcustApplicantEmployer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LAE_ID")
	private long laeId;

	@Column(name="LAE_CREATEDBY")
	private String laeCreatedby;

	@Column(name="LAE_CREATEDDATE")
	private Timestamp laeCreateddate;

	@Column(name="LAE_MODIFIEDDATE")
	private Timestamp laeModifieddate;

	@Column(name="LAE_MODIFIEDDBY")
	private String laeModifieddby;

	@Column(name="LAE_PEREMP_ADDRESS1")
	private String laePerempAddress1;

	@Column(name="LAE_PEREMP_ADDRESS2")
	private String laePerempAddress2;

	@Column(name="LAE_PEREMP_ADDRESS3")
	private String laePerempAddress3;

	@Column(name="LAE_PEREMP_APPLNT")
	private String laePerempApplnt;

	@Column(name="LAE_PEREMP_CATEGORY")
	private String laePerempCategory;

	@Column(name="LAE_PEREMP_CITY")
	private String laePerempCity;

	@Column(name="LAE_PEREMP_CONTPERSON")
	private String laePerempContperson;

	@Column(name="LAE_PEREMP_DEPARTMENT")
	private String laePerempDepartment;

	@Column(name="LAE_PEREMP_DESIGN")
	private String laePerempDesign;

	@Column(name="LAE_PEREMP_DISTRICT")
	private String laePerempDistrict;

	@Column(name="LAE_PEREMP_EMAIL")
	private String laePerempEmail;

	@Column(name="LAE_PEREMP_EMPNO")
	private String laePerempEmpno;

	@Column(name="LAE_PEREMP_FAX")
	private String laePerempFax;

	@Column(name="LAE_PEREMP_JOINDATE")
	private String laePerempJoindate;

	@Column(name="LAE_PEREMP_LETTERDATE")
	private String laePerempLetterdate;

	@Column(name="LAE_PEREMP_LETTERNO")
	private String laePerempLetterno;

	@Column(name="LAE_PEREMP_NAME")
	private String laePerempName;

	@Column(name="LAE_PEREMP_NATUREOFBUSINESS")
	private String laePerempNatureofbusiness;

	@Column(name="LAE_PEREMP_PHEXTEN")
	private String laePerempPhexten;

	@Column(name="LAE_PEREMP_PHONE")
	private String laePerempPhone;

	@Column(name="LAE_PEREMP_PREVEMPCITY")
	private String laePerempPrevempcity;

	@Column(name="LAE_PEREMP_PREVEMPNAME")
	private String laePerempPrevempname;

	@Column(name="LAE_PEREMP_RETAGE")
	private BigDecimal laePerempRetage;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LAE_PEREMP_RETDATE")
	private Date laePerempRetdate;

	@Column(name="LAE_PEREMP_RETIREDATE")
	private String laePerempRetiredate;

	@Column(name="LAE_PEREMP_SERVLEFT")
	private String laePerempServleft;

	@Column(name="LAE_PEREMP_SERVLEFTMON")
	private String laePerempServleftmon;

	@Column(name="LAE_PEREMP_STATE")
	private String laePerempState;

	@Column(name="LAE_PEREMP_TALUK")
	private String laePerempTaluk;

	@Column(name="LAE_PEREMP_TYPEOFORG")
	private String laePerempTypeoforg;

	@Column(name="LAE_PEREMP_VOLUNTRYDATE")
	private String laePerempVoluntrydate;

	@Column(name="LAE_PEREMP_YEARSINBUSS")
	private BigDecimal laePerempYearsinbuss;

	@Column(name="LAE_PEREMP_YRESEMP")
	private String laePerempYresemp;

	@Column(name="LAE_PEREMP_ZIP")
	private String laePerempZip;

	@Column(name="LAD_ID")
	private long ladId;

/*	//bi-directional many-to-one association to LpcustApplicantData
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LAE_PEREMP_CUST_ID")
	private LpcustApplicantData lpcustApplicantData;*/

	public LpcustApplicantEmployer() {
	}

	public long getLaeId() {
		return this.laeId;
	}

	public void setLaeId(long laeId) {
		this.laeId = laeId;
	}

	public String getLaeCreatedby() {
		return this.laeCreatedby;
	}

	public void setLaeCreatedby(String laeCreatedby) {
		this.laeCreatedby = laeCreatedby;
	}

	public Timestamp getLaeCreateddate() {
		return this.laeCreateddate;
	}

	public void setLaeCreateddate(Timestamp laeCreateddate) {
		this.laeCreateddate = laeCreateddate;
	}

	public Timestamp getLaeModifieddate() {
		return this.laeModifieddate;
	}

	public void setLaeModifieddate(Timestamp laeModifieddate) {
		this.laeModifieddate = laeModifieddate;
	}

	public String getLaeModifieddby() {
		return this.laeModifieddby;
	}

	public void setLaeModifieddby(String laeModifieddby) {
		this.laeModifieddby = laeModifieddby;
	}

	public String getLaePerempAddress1() {
		return this.laePerempAddress1;
	}

	public void setLaePerempAddress1(String laePerempAddress1) {
		this.laePerempAddress1 = laePerempAddress1;
	}

	public String getLaePerempAddress2() {
		return this.laePerempAddress2;
	}

	public void setLaePerempAddress2(String laePerempAddress2) {
		this.laePerempAddress2 = laePerempAddress2;
	}

	public String getLaePerempAddress3() {
		return this.laePerempAddress3;
	}

	public void setLaePerempAddress3(String laePerempAddress3) {
		this.laePerempAddress3 = laePerempAddress3;
	}

	public String getLaePerempApplnt() {
		return this.laePerempApplnt;
	}

	public void setLaePerempApplnt(String laePerempApplnt) {
		this.laePerempApplnt = laePerempApplnt;
	}

	public String getLaePerempCategory() {
		return this.laePerempCategory;
	}

	public void setLaePerempCategory(String laePerempCategory) {
		this.laePerempCategory = laePerempCategory;
	}

	public String getLaePerempCity() {
		return this.laePerempCity;
	}

	public void setLaePerempCity(String laePerempCity) {
		this.laePerempCity = laePerempCity;
	}

	public String getLaePerempContperson() {
		return this.laePerempContperson;
	}

	public void setLaePerempContperson(String laePerempContperson) {
		this.laePerempContperson = laePerempContperson;
	}

	public String getLaePerempDepartment() {
		return this.laePerempDepartment;
	}

	public void setLaePerempDepartment(String laePerempDepartment) {
		this.laePerempDepartment = laePerempDepartment;
	}

	public String getLaePerempDesign() {
		return this.laePerempDesign;
	}

	public void setLaePerempDesign(String laePerempDesign) {
		this.laePerempDesign = laePerempDesign;
	}

	public String getLaePerempDistrict() {
		return this.laePerempDistrict;
	}

	public void setLaePerempDistrict(String laePerempDistrict) {
		this.laePerempDistrict = laePerempDistrict;
	}

	public String getLaePerempEmail() {
		return this.laePerempEmail;
	}

	public void setLaePerempEmail(String laePerempEmail) {
		this.laePerempEmail = laePerempEmail;
	}

	public String getLaePerempEmpno() {
		return this.laePerempEmpno;
	}

	public void setLaePerempEmpno(String laePerempEmpno) {
		this.laePerempEmpno = laePerempEmpno;
	}

	public String getLaePerempFax() {
		return this.laePerempFax;
	}

	public void setLaePerempFax(String laePerempFax) {
		this.laePerempFax = laePerempFax;
	}

	public String getLaePerempJoindate() {
		return this.laePerempJoindate;
	}

	public void setLaePerempJoindate(String laePerempJoindate) {
		this.laePerempJoindate = laePerempJoindate;
	}

	public String getLaePerempLetterdate() {
		return this.laePerempLetterdate;
	}

	public void setLaePerempLetterdate(String laePerempLetterdate) {
		this.laePerempLetterdate = laePerempLetterdate;
	}

	public String getLaePerempLetterno() {
		return this.laePerempLetterno;
	}

	public void setLaePerempLetterno(String laePerempLetterno) {
		this.laePerempLetterno = laePerempLetterno;
	}

	public String getLaePerempName() {
		return this.laePerempName;
	}

	public void setLaePerempName(String laePerempName) {
		this.laePerempName = laePerempName;
	}

	public String getLaePerempNatureofbusiness() {
		return this.laePerempNatureofbusiness;
	}

	public void setLaePerempNatureofbusiness(String laePerempNatureofbusiness) {
		this.laePerempNatureofbusiness = laePerempNatureofbusiness;
	}

	public String getLaePerempPhexten() {
		return this.laePerempPhexten;
	}

	public void setLaePerempPhexten(String laePerempPhexten) {
		this.laePerempPhexten = laePerempPhexten;
	}

	public String getLaePerempPhone() {
		return this.laePerempPhone;
	}

	public void setLaePerempPhone(String laePerempPhone) {
		this.laePerempPhone = laePerempPhone;
	}

	public String getLaePerempPrevempcity() {
		return this.laePerempPrevempcity;
	}

	public void setLaePerempPrevempcity(String laePerempPrevempcity) {
		this.laePerempPrevempcity = laePerempPrevempcity;
	}

	public String getLaePerempPrevempname() {
		return this.laePerempPrevempname;
	}

	public void setLaePerempPrevempname(String laePerempPrevempname) {
		this.laePerempPrevempname = laePerempPrevempname;
	}

	public BigDecimal getLaePerempRetage() {
		return this.laePerempRetage;
	}

	public void setLaePerempRetage(BigDecimal laePerempRetage) {
		this.laePerempRetage = laePerempRetage;
	}

	public Date getLaePerempRetdate() {
		return this.laePerempRetdate;
	}

	public void setLaePerempRetdate(Date laePerempRetdate) {
		this.laePerempRetdate = laePerempRetdate;
	}

	public String getLaePerempRetiredate() {
		return this.laePerempRetiredate;
	}

	public void setLaePerempRetiredate(String laePerempRetiredate) {
		this.laePerempRetiredate = laePerempRetiredate;
	}

	public String getLaePerempServleft() {
		return this.laePerempServleft;
	}

	public void setLaePerempServleft(String laePerempServleft) {
		this.laePerempServleft = laePerempServleft;
	}

	public String getLaePerempServleftmon() {
		return this.laePerempServleftmon;
	}

	public void setLaePerempServleftmon(String laePerempServleftmon) {
		this.laePerempServleftmon = laePerempServleftmon;
	}

	public String getLaePerempState() {
		return this.laePerempState;
	}

	public void setLaePerempState(String laePerempState) {
		this.laePerempState = laePerempState;
	}

	public String getLaePerempTaluk() {
		return this.laePerempTaluk;
	}

	public void setLaePerempTaluk(String laePerempTaluk) {
		this.laePerempTaluk = laePerempTaluk;
	}

	public String getLaePerempTypeoforg() {
		return this.laePerempTypeoforg;
	}

	public void setLaePerempTypeoforg(String laePerempTypeoforg) {
		this.laePerempTypeoforg = laePerempTypeoforg;
	}

	public String getLaePerempVoluntrydate() {
		return this.laePerempVoluntrydate;
	}

	public void setLaePerempVoluntrydate(String laePerempVoluntrydate) {
		this.laePerempVoluntrydate = laePerempVoluntrydate;
	}

	public BigDecimal getLaePerempYearsinbuss() {
		return this.laePerempYearsinbuss;
	}

	public void setLaePerempYearsinbuss(BigDecimal laePerempYearsinbuss) {
		this.laePerempYearsinbuss = laePerempYearsinbuss;
	}

	public String getLaePerempYresemp() {
		return this.laePerempYresemp;
	}

	public void setLaePerempYresemp(String laePerempYresemp) {
		this.laePerempYresemp = laePerempYresemp;
	}

	public String getLaePerempZip() {
		return this.laePerempZip;
	}

	public void setLaePerempZip(String laePerempZip) {
		this.laePerempZip = laePerempZip;
	}

/*	public LpcustApplicantData getLpcustApplicantData() {
		return this.lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}
*/
	public long getLadId() {
		return ladId;
	}

	public void setLadId(long ladId) {
		this.ladId = ladId;
	}
}