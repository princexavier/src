package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCUST_APPLICANT_EDU_COURSE_DETAILS database table.
 * 
 */
@Entity
@Table(name="LPCUST_EDU_COURSE_DETAILS")
@NamedQuery(name="LpcustApplicantEduCourseDetail.findAll", query="SELECT l FROM LpcustApplicantEduCourseDetail l")
public class LpcustApplicantEduCourseDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LAESC_EDU_LOAN_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long laescEduLoanId;

	@Column(name="LAEL_CREATEDBY")
	private String laelCreatedby;

	@Column(name="LAEL_CREATEDDATE")
	private Date laelCreateddate;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LAEL_EDU_COMMENCEDATE")
	private Date laelEduCommencedate;

	@Column(name="LAEL_EDU_COMMENTS1")
	private String laelEduComments1;

	@Column(name="LAEL_EDU_COMMENTS2")
	private String laelEduComments2;

	@Column(name="LAEL_EDU_COMMENTS3")
	private String laelEduComments3;

	@Column(name="LAEL_EDU_COMMENTS4")
	private String laelEduComments4;

	@Column(name="LAEL_EDU_COMP_STAY_HOSTEL")
	private String laelEduCompStayHostel;

	@Column(name="LAEL_EDU_COURSE_APPROVED")
	private String laelEduCourseApproved;

	@Column(name="LAEL_EDU_COURSE_APPROVEDBY")
	private String laelEduCourseApprovedby;

	@Column(name="LAEL_EDU_COURSENAME")
	private String laelEduCoursename;

	@Column(name="LAEL_EDU_DURATION")
	private String laelEduDuration;

	@Column(name="LAEL_EDU_MODE_SECURE")
	private BigDecimal laelEduModeSecure;

	@Column(name="LAEL_EDU_PARTFULL")
	private BigDecimal laelEduPartfull;

	@Column(name="LAEL_EDU_QUAL_PROPOSED")
	private BigDecimal laelEduQualProposed;

	@Column(name="LAEL_EDU_STUDIES_IN")
	private String laelEduStudiesIn;

	@Column(name="LAEL_EDU_UNIV_ADDR")
	private String laelEduUnivAddr;

	@Column(name="LAEL_EDU_UNIV_APPROVED")
	private String laelEduUnivApproved;

	@Column(name="LAEL_EDU_UNIV_APPROVEDBY")
	private String laelEduUnivApprovedby;

	@Column(name="LAEL_EDU_UNIV_NAME")
	private String laelEduUnivName;

	@Column(name="LAEL_EDU_UNIV_SITU_DOMICILE")
	private String laelEduUnivSituDomicile;

	@Column(name="LAEL_MODIFIEDDATE")
	private Date laelModifieddate;

	@Column(name="LAEL_MODIFIEDDBY")
	private String laelModifieddby;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LAEL_EDULOAN_APPNO")
	private LpcomProposal lpcomProposal;

	public LpcustApplicantEduCourseDetail() {
	}

	public long getLaescEduLoanId() {
		return this.laescEduLoanId;
	}

	public void setLaescEduLoanId(long laescEduLoanId) {
		this.laescEduLoanId = laescEduLoanId;
	}

	public String getLaelCreatedby() {
		return this.laelCreatedby;
	}

	public void setLaelCreatedby(String laelCreatedby) {
		this.laelCreatedby = laelCreatedby;
	}

	public Date getLaelCreateddate() {
		return this.laelCreateddate;
	}

	public void setLaelCreateddate(Date laelCreateddate) {
		this.laelCreateddate = laelCreateddate;
	}

	public Date getLaelEduCommencedate() {
		return this.laelEduCommencedate;
	}

	public void setLaelEduCommencedate(Date laelEduCommencedate) {
		this.laelEduCommencedate = laelEduCommencedate;
	}

	public String getLaelEduComments1() {
		return this.laelEduComments1;
	}

	public void setLaelEduComments1(String laelEduComments1) {
		this.laelEduComments1 = laelEduComments1;
	}

	public String getLaelEduComments2() {
		return this.laelEduComments2;
	}

	public void setLaelEduComments2(String laelEduComments2) {
		this.laelEduComments2 = laelEduComments2;
	}

	public String getLaelEduComments3() {
		return this.laelEduComments3;
	}

	public void setLaelEduComments3(String laelEduComments3) {
		this.laelEduComments3 = laelEduComments3;
	}

	public String getLaelEduComments4() {
		return this.laelEduComments4;
	}

	public void setLaelEduComments4(String laelEduComments4) {
		this.laelEduComments4 = laelEduComments4;
	}

	public String getLaelEduCompStayHostel() {
		return this.laelEduCompStayHostel;
	}

	public void setLaelEduCompStayHostel(String laelEduCompStayHostel) {
		this.laelEduCompStayHostel = laelEduCompStayHostel;
	}

	public String getLaelEduCourseApproved() {
		return this.laelEduCourseApproved;
	}

	public void setLaelEduCourseApproved(String laelEduCourseApproved) {
		this.laelEduCourseApproved = laelEduCourseApproved;
	}

	public String getLaelEduCourseApprovedby() {
		return this.laelEduCourseApprovedby;
	}

	public void setLaelEduCourseApprovedby(String laelEduCourseApprovedby) {
		this.laelEduCourseApprovedby = laelEduCourseApprovedby;
	}

	public String getLaelEduCoursename() {
		return this.laelEduCoursename;
	}

	public void setLaelEduCoursename(String laelEduCoursename) {
		this.laelEduCoursename = laelEduCoursename;
	}

	public String getLaelEduDuration() {
		return this.laelEduDuration;
	}

	public void setLaelEduDuration(String laelEduDuration) {
		this.laelEduDuration = laelEduDuration;
	}

	public BigDecimal getLaelEduModeSecure() {
		return this.laelEduModeSecure;
	}

	public void setLaelEduModeSecure(BigDecimal laelEduModeSecure) {
		this.laelEduModeSecure = laelEduModeSecure;
	}

	public BigDecimal getLaelEduPartfull() {
		return this.laelEduPartfull;
	}

	public void setLaelEduPartfull(BigDecimal laelEduPartfull) {
		this.laelEduPartfull = laelEduPartfull;
	}

	public BigDecimal getLaelEduQualProposed() {
		return this.laelEduQualProposed;
	}

	public void setLaelEduQualProposed(BigDecimal laelEduQualProposed) {
		this.laelEduQualProposed = laelEduQualProposed;
	}

	public String getLaelEduStudiesIn() {
		return this.laelEduStudiesIn;
	}

	public void setLaelEduStudiesIn(String laelEduStudiesIn) {
		this.laelEduStudiesIn = laelEduStudiesIn;
	}

	public String getLaelEduUnivAddr() {
		return this.laelEduUnivAddr;
	}

	public void setLaelEduUnivAddr(String laelEduUnivAddr) {
		this.laelEduUnivAddr = laelEduUnivAddr;
	}

	public String getLaelEduUnivApproved() {
		return this.laelEduUnivApproved;
	}

	public void setLaelEduUnivApproved(String laelEduUnivApproved) {
		this.laelEduUnivApproved = laelEduUnivApproved;
	}

	public String getLaelEduUnivApprovedby() {
		return this.laelEduUnivApprovedby;
	}

	public void setLaelEduUnivApprovedby(String laelEduUnivApprovedby) {
		this.laelEduUnivApprovedby = laelEduUnivApprovedby;
	}

	public String getLaelEduUnivName() {
		return this.laelEduUnivName;
	}

	public void setLaelEduUnivName(String laelEduUnivName) {
		this.laelEduUnivName = laelEduUnivName;
	}

	public String getLaelEduUnivSituDomicile() {
		return this.laelEduUnivSituDomicile;
	}

	public void setLaelEduUnivSituDomicile(String laelEduUnivSituDomicile) {
		this.laelEduUnivSituDomicile = laelEduUnivSituDomicile;
	}

	public Date getLaelModifieddate() {
		return this.laelModifieddate;
	}

	public void setLaelModifieddate(Date laelModifieddate) {
		this.laelModifieddate = laelModifieddate;
	}

	public String getLaelModifieddby() {
		return this.laelModifieddby;
	}

	public void setLaelModifieddby(String laelModifieddby) {
		this.laelModifieddby = laelModifieddby;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}