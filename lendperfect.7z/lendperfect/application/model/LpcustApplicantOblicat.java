package com.sai.lendperfect.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sai.lendperfect.app.customerdetails.CustomerDetailsService;
import com.sai.lendperfect.commodel.LpcomProposal;

/**
 * The persistent class for the LPCUST_APPLICANT_OBLICAT database table.
 * 
 */
@Entity
@Table(name="LPCUST_APPLICANT_OBLICAT")
//@NamedQuery(name="LpcustApplicantOblicat.findAll", query="SELECT l FROM LpcustApplicantOblicat l")
public class LpcustApplicantOblicat implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LAOR_ID")
	private String laorId;

	@Column(name="LAOR_BANKNAME")
	private String laorBankname;

	@Column(name="LAOR_CREATEDBY")
	private String laorCreatedby;

	@Temporal(TemporalType.DATE)
	@Column(name="LAOR_CREATEDON")
	private Date laorCreatedon;

	@Column(name="LAOR_LOANSANCAMOUNT")
	private BigDecimal laorLoansancamount;

	@Column(name="LAOR_MODIFIEDBY")
	private String laorModifiedby;

	@Temporal(TemporalType.DATE)
	@Column(name="LAOR_MODIFIEDON")
	private Date laorModifiedon;

	@Column(name="LAOR_MONEMI")
	private BigDecimal laorMonemi;

	//bi-directional many-to-one association to LpcustApplicantData
	@ManyToOne
	@JoinColumn(name="LAOR_APPID")
	private LpcustApplicantData lpcustApplicantData;

	public LpcustApplicantOblicat() {
	}

	public String getLaorId() {
		return this.laorId;
	}

	public void setLaorId(String laorId) {
		this.laorId = laorId;
	}

	public String getLaorBankname() {
		return this.laorBankname;
	}

	public void setLaorBankname(String laorBankname) {
		this.laorBankname = laorBankname;
	}

	public String getLaorCreatedby() {
		return this.laorCreatedby;
	}

	public void setLaorCreatedby(String laorCreatedby) {
		this.laorCreatedby = laorCreatedby;
	}

	public Date getLaorCreatedon() {
		return this.laorCreatedon;
	}

	public void setLaorCreatedon(Date laorCreatedon) {
		this.laorCreatedon = laorCreatedon;
	}

	public BigDecimal getLaorLoansancamount() {
		return this.laorLoansancamount;
	}

	public void setLaorLoansancamount(BigDecimal laorLoansancamount) {
		this.laorLoansancamount = laorLoansancamount;
	}

	public String getLaorModifiedby() {
		return this.laorModifiedby;
	}

	public void setLaorModifiedby(String laorModifiedby) {
		this.laorModifiedby = laorModifiedby;
	}

	public Date getLaorModifiedon() {
		return this.laorModifiedon;
	}

	public void setLaorModifiedon(Date laorModifiedon) {
		this.laorModifiedon = laorModifiedon;
	}

	public BigDecimal getLaorMonemi() {
		return this.laorMonemi;
	}

	public void setLaorMonemi(BigDecimal laorMonemi) {
		this.laorMonemi = laorMonemi;
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return this.lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}

}