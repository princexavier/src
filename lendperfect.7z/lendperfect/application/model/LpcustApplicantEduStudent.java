package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.util.Date;


/**
 * The persistent class for the LPCUST_APPLICANT_EDU_STUDENT database table.
 * 
 */
@Entity
@Table(name="LPCUST_APPLICANT_EDU_STUDENT")
@NamedQuery(name="LpcustApplicantEduStudent.findAll", query="SELECT l FROM LpcustApplicantEduStudent l")
public class LpcustApplicantEduStudent implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="LAED_EDU_STUD_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long laedEduStudId;

	@Column(name="LAEST_CREATEDBY")
	private String laestCreatedby;

	@Column(name="LAEST_CREATEDDATE")
	private Date laestCreateddate;

	@Column(name="LAEST_EDU_ADDR1")
	private String laestEduAddr1;

	@Column(name="LAEST_EDU_ADDR2")
	private String laestEduAddr2;

	@Column(name="LAEST_EDU_AGE")
	private String laestEduAge;

	@Column(name="LAEST_EDU_CASTE")
	private String laestEduCaste;

	@Column(name="LAEST_EDU_CHILD")
	private String laestEduChild;

	@Column(name="LAEST_EDU_CITY")
	private String laestEduCity;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LAEST_EDU_DOB")
	private Date laestEduDob;

	@Column(name="LAEST_EDU_NAME")
	private String laestEduName;

	@Column(name="LAEST_EDU_PINCODE")
	private String laestEduPincode;

	@Column(name="LAEST_EDU_RELATION")
	private String laestEduRelation;

	@Column(name="LAEST_EDU_RELGAURDIAN")
	private String laestEduRelgaurdian;

	@Column(name="LAEST_EDU_RELIGION")
	private String laestEduReligion;

	@Column(name="LAEST_EDU_RELNAME")
	private String laestEduRelname;

	@Column(name="LAEST_EDU_STATE")
	private String laestEduState;

	@Column(name="LAEST_EDU_STATUS")
	private String laestEduStatus;

	@Column(name="LAEST_MODIFIEDDATE")
	private Date laestModifieddate;

	@Column(name="LAEST_MODIFIEDDBY")
	private String laestModifieddby;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LAEST_EDU_APPNO")
	private LpcomProposal lpcomProposal;

	public LpcustApplicantEduStudent() {
	}

	public long getLaedEduStudId() {
		return this.laedEduStudId;
	}

	public void setLaedEduStudId(long laedEduStudId) {
		this.laedEduStudId = laedEduStudId;
	}

	public String getLaestCreatedby() {
		return this.laestCreatedby;
	}

	public void setLaestCreatedby(String laestCreatedby) {
		this.laestCreatedby = laestCreatedby;
	}

	public Date getLaestCreateddate() {
		return this.laestCreateddate;
	}

	public void setLaestCreateddate(Date laestCreateddate) {
		this.laestCreateddate = laestCreateddate;
	}

	public String getLaestEduAddr1() {
		return this.laestEduAddr1;
	}

	public void setLaestEduAddr1(String laestEduAddr1) {
		this.laestEduAddr1 = laestEduAddr1;
	}

	public String getLaestEduAddr2() {
		return this.laestEduAddr2;
	}

	public void setLaestEduAddr2(String laestEduAddr2) {
		this.laestEduAddr2 = laestEduAddr2;
	}

	public String getLaestEduAge() {
		return this.laestEduAge;
	}

	public void setLaestEduAge(String laestEduAge) {
		this.laestEduAge = laestEduAge;
	}

	public String getLaestEduCaste() {
		return this.laestEduCaste;
	}

	public void setLaestEduCaste(String laestEduCaste) {
		this.laestEduCaste = laestEduCaste;
	}

	public String getLaestEduChild() {
		return this.laestEduChild;
	}

	public void setLaestEduChild(String laestEduChild) {
		this.laestEduChild = laestEduChild;
	}

	public String getLaestEduCity() {
		return this.laestEduCity;
	}

	public void setLaestEduCity(String laestEduCity) {
		this.laestEduCity = laestEduCity;
	}

	public Date getLaestEduDob() {
		return this.laestEduDob;
	}

	public void setLaestEduDob(Date laestEduDob) {
		this.laestEduDob = laestEduDob;
	}

	public String getLaestEduName() {
		return this.laestEduName;
	}

	public void setLaestEduName(String laestEduName) {
		this.laestEduName = laestEduName;
	}

	public String getLaestEduPincode() {
		return this.laestEduPincode;
	}

	public void setLaestEduPincode(String laestEduPincode) {
		this.laestEduPincode = laestEduPincode;
	}

	public String getLaestEduRelation() {
		return this.laestEduRelation;
	}

	public void setLaestEduRelation(String laestEduRelation) {
		this.laestEduRelation = laestEduRelation;
	}

	public String getLaestEduRelgaurdian() {
		return this.laestEduRelgaurdian;
	}

	public void setLaestEduRelgaurdian(String laestEduRelgaurdian) {
		this.laestEduRelgaurdian = laestEduRelgaurdian;
	}

	public String getLaestEduReligion() {
		return this.laestEduReligion;
	}

	public void setLaestEduReligion(String laestEduReligion) {
		this.laestEduReligion = laestEduReligion;
	}

	public String getLaestEduRelname() {
		return this.laestEduRelname;
	}

	public void setLaestEduRelname(String laestEduRelname) {
		this.laestEduRelname = laestEduRelname;
	}

	public String getLaestEduState() {
		return this.laestEduState;
	}

	public void setLaestEduState(String laestEduState) {
		this.laestEduState = laestEduState;
	}

	public String getLaestEduStatus() {
		return this.laestEduStatus;
	}

	public void setLaestEduStatus(String laestEduStatus) {
		this.laestEduStatus = laestEduStatus;
	}

	public Date getLaestModifieddate() {
		return this.laestModifieddate;
	}

	public void setLaestModifieddate(Date laestModifieddate) {
		this.laestModifieddate = laestModifieddate;
	}

	public String getLaestModifieddby() {
		return this.laestModifieddby;
	}

	public void setLaestModifieddby(String laestModifieddby) {
		this.laestModifieddby = laestModifieddby;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}