package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sai.lendperfect.commodel.LpcomLiability;
import com.sai.lendperfect.commodel.LpcomOtherAssetsLiability;
import com.sai.lendperfect.commodel.LpcomPropAddInfo;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the LPCUST_APPLICANT_DATA database table.
 * 
 */
@Entity
@Table(name="LPCUST_APPLICANT_DATA")
@NamedQuery(name="LpcustApplicantData.findAll", query="SELECT l FROM LpcustApplicantData l")
public class LpcustApplicantData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LAD_ID")
	private long ladId;

	@Column(name="LAD_ADDRESS1")
	private String ladAddress1;

	@Column(name="LAD_ADDRESS2")
	private String ladAddress2;

	@Column(name="LAD_ADDRESS3")
	private String ladAddress3;

	@Temporal(TemporalType.DATE)
	@Column(name="LAD_APPDATE")
	private Date ladAppdate;

	@Column(name="LAD_APPLNT")
	private String ladApplnt;

	@Column(name="LAD_ASSETS")
	private String ladAssets;

	@Column(name="LAD_BANK")
	private String ladBank;

	@Column(name="LAD_BANKACCNO")
	private String ladBankaccno;

	@Column(name="LAD_BANKACCTYPE")
	private String ladBankacctype;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LAD_BANKSINCE")
	private Date ladBanksince;

	@Column(name="LAD_BRANCHCODE")
	private String ladBranchcode;

	@Column(name="LAD_BRDET")
	private String ladBrdet;

	@Column(name="LAD_BUSS")
	private BigDecimal ladBuss;

	@Column(name="LAD_CATEGORY")
	private String ladCategory;

	@Column(name="LAD_CBSID")
	private String ladCbsid;

	@Column(name="LAD_CHILDNUM")
	private String ladChildnum;

	@Column(name="LAD_CITY")
	private String ladCity;

	@Column(name="LAD_COUNTRY")
	private String ladCountry;

	@Column(name="LAD_CREATED_BY")
	private String ladCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LAD_CREATED_ON")
	private Date ladCreatedOn;

	@Column(name="LAD_DEPEND")
	private String ladDepend;

	@Column(name="LAD_DISTRICT")
	private String ladDistrict;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LAD_DOB")
	private Date ladDob;

	@Column(name="LAD_EARNMEM")
	private String ladEarnmem;

	@Column(name="LAD_EDUCATION")
	private String ladEducation;

	@Column(name="LAD_EDUOTHERS")
	private String ladEduothers;

	@Column(name="LAD_EMAIL")
	private String ladEmail;

	@Column(name="LAD_EMPLOYMENT")
	private String ladEmployment;

	@Column(name="LAD_FATNAME")
	private String ladFatname;

	@Column(name="LAD_FLAT_SHOP")
	private String ladFlatShop;

	@Column(name="LAD_FNAME")
	private String ladFname;

	@Column(name="LAD_HNAME")
	private String ladHname;

	@Column(name="LAD_HUSLNAME")
	private String ladHuslname;

	@Column(name="LAD_HUSMNAME")
	private String ladHusmname;

	@Column(name="LAD_HUSNAME")
	private String ladHusname;

	@Column(name="LAD_INDUSTRYCODE")
	private BigDecimal ladIndustrycode;

	@Column(name="LAD_JOBLOCATION")
	private String ladJoblocation;

	@Column(name="LAD_LNAME")
	private String ladLname;

	@Column(name="LAD_MAILADDR")
	private BigDecimal ladMailaddr;

	@Column(name="LAD_MARSTAT")
	private String ladMarstat;

	@Column(name="LAD_MEMNO")
	private String ladMemno;

	@Column(name="LAD_MEMTYPE")
	private String ladMemtype;

	@Column(name="LAD_MINORITY")
	private String ladMinority;

	@Column(name="LAD_MNAME")
	private String ladMname;

	@Column(name="LAD_MOBILE")
	private String ladMobile;

	@Column(name="LAD_MODIFIED_BY")
	private String ladModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LAD_MODIFIED_ON")
	private Date ladModifiedOn;

	@Column(name="LAD_NATUREOFBUSINESS")
	private String ladNatureofbusiness;

	@Column(name="LAD_NETWORTH")
	private String ladNetworth;

	@Temporal(TemporalType.DATE)
	@Column(name="LAD_NETWORTHASON")
	private Date ladNetworthason;

	@Column(name="LAD_NONPRIORITY")
	private String ladNonpriority;

	@Column(name="LAD_OFFID")
	private String ladOffid;

	@Column(name="LAD_OLDID")
	private BigDecimal ladOldid;

	@Column(name="LAD_OTHERNUM")
	private String ladOthernum;

	@Column(name="LAD_PANNO")
	private String ladPanno;

	@Temporal(TemporalType.DATE)
	@Column(name="LAD_PASSEXPIRY")
	private Date ladPassexpiry;

	@Column(name="LAD_PASSISSUE")
	private String ladPassissue;

	@Temporal(TemporalType.DATE)
	@Column(name="LAD_PASSISSUEDT")
	private Date ladPassissuedt;

	@Column(name="LAD_PASSPORT")
	private String ladPassport;

	@Column(name="LAD_PERMADD1")
	private String ladPermadd1;

	@Column(name="LAD_PERMADD2")
	private String ladPermadd2;

	@Column(name="LAD_PERMADD3")
	private String ladPermadd3;

	@Column(name="LAD_PERMCITY")
	private String ladPermcity;

	@Column(name="LAD_PERMDISTRICT")
	private String ladPermdistrict;

	@Column(name="LAD_PERMPHONE")
	private String ladPermphone;

	@Column(name="LAD_PERMSTATE")
	private String ladPermstate;

	@Column(name="LAD_PERMTALUK")
	private String ladPermtaluk;

	@Column(name="LAD_PERMZIP")
	private String ladPermzip;

	@Column(name="LAD_PHONE")
	private String ladPhone;

	@Lob
	@Column(name="LAD_PHOTO")
	private byte[] ladPhoto;

	@Column(name="LAD_PLACEOFDOMICILE")
	private String ladPlaceofdomicile;

	@Column(name="LAD_PRESPERM")
	private String ladPresperm;

	@Column(name="LAD_PREVADD1")
	private String ladPrevadd1;

	@Column(name="LAD_PREVADD2")
	private String ladPrevadd2;

	@Column(name="LAD_PREVADD3")
	private String ladPrevadd3;

	@Column(name="LAD_PREVCITY")
	private String ladPrevcity;

	@Column(name="LAD_PREVSTATE")
	private String ladPrevstate;

	@Column(name="LAD_PREVZIP")
	private String ladPrevzip;

	@Column(name="LAD_PRIORITY")
	private String ladPriority;

	@Column(name="LAD_PRIORITYTYPE")
	private String ladPrioritytype;

	@Column(name="LAD_PURPOSECODE")
	private BigDecimal ladPurposecode;

	@Column(name="LAD_RECFROM")
	private String ladRecfrom;

	@Column(name="LAD_REGNO")
	private String ladRegno;

	@Column(name="LAD_RELATIONSHIP")
	private String ladRelationship;

	@Column(name="LAD_RELATIVEDET")
	private String ladRelativedet;

	@Column(name="LAD_RELIGION")
	private String ladReligion;

	@Column(name="LAD_RENEW")
	private String ladRenew;

	@Column(name="LAD_RENTED_OWNED")
	private String ladRentedOwned;

	@Column(name="LAD_RESIDENCETYPE")
	private String ladResidencetype;

	@Column(name="LAD_RESIDENTIAL")
	private String ladResidential;

	@Column(name="LAD_SALARYROUTED")
	private String ladSalaryrouted;

	@Column(name="LAD_SEX")
	private String ladSex;

	@Column(name="LAD_SHARES")
	private String ladShares;

	@Column(name="LAD_SHOP")
	private String ladShop;

	@Column(name="LAD_SPOUSEEMAIL")
	private String ladSpouseemail;

	@Column(name="LAD_SPOUSEINCOME")
	private String ladSpouseincome;

	@Column(name="LAD_SPOUSEOCCU")
	private String ladSpouseoccu;

	@Column(name="LAD_SPOUSEPAN")
	private String ladSpousepan;

	@Column(name="LAD_SSN")
	private String ladSsn;

	@Column(name="LAD_STATE")
	private String ladState;

	@Column(name="LAD_STATUS")
	private String ladStatus;

	@Column(name="LAD_TALUK")
	private String ladTaluk;

	@Column(name="LAD_TITLE")
	private String ladTitle;

	@Column(name="LAD_TRANSFERABLE")
	private String ladTransferable;

	@Column(name="LAD_TYPEOFOCC")
	private String ladTypeofocc;

	@Column(name="LAD_TYPEOFPROF")
	private String ladTypeofprof;

	@Column(name="LAD_WEAK")
	private String ladWeak;

	@Column(name="LAD_YRSINPRESADD")
	private BigDecimal ladYrsinpresadd;

	@Column(name="LAD_ZIP")
	private String ladZip;

	@Column(name="LAD_RELATIVEWORKING")
	private String ladRelativeworking;
	
	@Column(name="LAD_YRSINJOB")
	private String ladYrsinjob;
	
	@Column(name="LAD_SPOUSENAME")
	private String ladSpousename;
	
	@Column(name="LAD_VICINITY")
	private String ladVicinity;
	
	//bi-directional many-to-one association to LpcustApplicantEmployer
	/*@JsonIgnore
	@OneToMany(mappedBy="lpcustApplicantData")
	private List<LpcustApplicantEmployer> lpcustApplicantEmployers;*/
	
	public String getLadRelativeworking() {
		return ladRelativeworking;
	}

	public void setLadRelativeworking(String ladRelativeworking) {
		this.ladRelativeworking = ladRelativeworking;
	}

	public String getLadYrsinjob() {
		return ladYrsinjob;
	}

	public void setLadYrsinjob(String ladYrsinjob) {
		this.ladYrsinjob = ladYrsinjob;
	}

	public String getLadSpousename() {
		return ladSpousename;
	}

	public void setLadSpousename(String ladSpousename) {
		this.ladSpousename = ladSpousename;
	}

	public String getLadVicinity() {
		return ladVicinity;
	}

	public void setLadVicinity(String ladVicinity) {
		this.ladVicinity = ladVicinity;
	}

	

	//bi-directional many-to-one association to LpcomLiability
	@OneToMany(mappedBy="lpcustApplicantData")
	private List<LpcomLiability> lpcomLiabilities;
	
	//bi-directional many-to-one association to LpcomOtherAssetsLiability
	@OneToMany(mappedBy="lpcustApplicantData")
	private List<LpcomOtherAssetsLiability> lpcomOtherAssetsLiabilities;
	
	//bi-directional many-to-one association to LpcustAppcustRelation
	@OneToMany(mappedBy="lpcustApplicantData")
	private List<LpcustAppcustRelation> lpcustAppcustRelations;
	
	//bi-directional many-to-one association to LpcustApplicantTaxDetail
	@OneToMany(mappedBy="lpcustApplicantData")
	private List<LpcustApplicantTaxDetail> lpcustApplicantTaxDetails;
	
	@OneToMany(mappedBy="lpcustApplicantData")
	private List<LpcomPropAddInfo> lpcomPropAddInfo;
			
	@Column(name="LAD_AADHAR")
	private String ladaadhar;


	@Column(name="LAD_DRIVING_LICENSE_NO")
	private String ladDrivingLicenseNo;
	
	@Column(name="LAD_RATION_NO")
	private String ladRationNo;
	
	@Column(name="LAD_VOTERID")
	private String ladVoterid;
	
    @Transient
	private String ladCityName;
    
    @Transient
   	private String ladStateName;
    
    @Transient
   	private String ladDistrictName;
    
    @Transient
	private String ladPermCityName;
    
    @Transient
   	private String ladPermStateName;
    
    @Transient
   	private String ladPermDistrictName;
    
    
	public LpcustApplicantData() {
	}

	public long getLadId() {
		return this.ladId;
	}

	public void setLadId(long ladId) {
		this.ladId = ladId;
	}

	public String getLadAddress1() {
		return this.ladAddress1;
	}

	public void setLadAddress1(String ladAddress1) {
		this.ladAddress1 = ladAddress1;
	}

	public String getLadAddress2() {
		return this.ladAddress2;
	}

	public void setLadAddress2(String ladAddress2) {
		this.ladAddress2 = ladAddress2;
	}

	public String getLadAddress3() {
		return this.ladAddress3;
	}

	public void setLadAddress3(String ladAddress3) {
		this.ladAddress3 = ladAddress3;
	}

	public Date getLadAppdate() {
		return this.ladAppdate;
	}

	public void setLadAppdate(Date ladAppdate) {
		this.ladAppdate = ladAppdate;
	}

	public String getLadApplnt() {
		return this.ladApplnt;
	}

	public void setLadApplnt(String ladApplnt) {
		this.ladApplnt = ladApplnt;
	}

	public String getLadAssets() {
		return this.ladAssets;
	}

	public void setLadAssets(String ladAssets) {
		this.ladAssets = ladAssets;
	}

	public String getLadBank() {
		return this.ladBank;
	}

	public void setLadBank(String ladBank) {
		this.ladBank = ladBank;
	}

	public String getLadBankaccno() {
		return this.ladBankaccno;
	}

	public void setLadBankaccno(String ladBankaccno) {
		this.ladBankaccno = ladBankaccno;
	}

	public String getLadBankacctype() {
		return this.ladBankacctype;
	}

	public void setLadBankacctype(String ladBankacctype) {
		this.ladBankacctype = ladBankacctype;
	}

	public Date getLadBanksince() {
		return this.ladBanksince;
	}

	public void setLadBanksince(Date ladBanksince) {
		this.ladBanksince = ladBanksince;
	}

	public String getLadBranchcode() {
		return this.ladBranchcode;
	}

	public void setLadBranchcode(String ladBranchcode) {
		this.ladBranchcode = ladBranchcode;
	}

	public String getLadBrdet() {
		return this.ladBrdet;
	}

	public void setLadBrdet(String ladBrdet) {
		this.ladBrdet = ladBrdet;
	}

	public BigDecimal getLadBuss() {
		return this.ladBuss;
	}

	public void setLadBuss(BigDecimal ladBuss) {
		this.ladBuss = ladBuss;
	}

	public String getLadCategory() {
		return this.ladCategory;
	}

	public void setLadCategory(String ladCategory) {
		this.ladCategory = ladCategory;
	}

	public String getLadCbsid() {
		return this.ladCbsid;
	}

	public void setLadCbsid(String ladCbsid) {
		this.ladCbsid = ladCbsid;
	}

	public String getLadChildnum() {
		return this.ladChildnum;
	}

	public void setLadChildnum(String ladChildnum) {
		this.ladChildnum = ladChildnum;
	}

	public String getLadCity() {
		return this.ladCity;
	}

	public void setLadCity(String ladCity) {
		this.ladCity = ladCity;
	}

	public String getLadCountry() {
		return this.ladCountry;
	}

	public void setLadCountry(String ladCountry) {
		this.ladCountry = ladCountry;
	}

	public String getLadCreatedBy() {
		return this.ladCreatedBy;
	}

	public void setLadCreatedBy(String ladCreatedBy) {
		this.ladCreatedBy = ladCreatedBy;
	}

	public Date getLadCreatedOn() {
		return this.ladCreatedOn;
	}

	public void setLadCreatedOn(Date ladCreatedOn) {
		this.ladCreatedOn = ladCreatedOn;
	}

	public String getLadDepend() {
		return this.ladDepend;
	}

	public void setLadDepend(String ladDepend) {
		this.ladDepend = ladDepend;
	}

	public String getLadDistrict() {
		return this.ladDistrict;
	}

	public void setLadDistrict(String ladDistrict) {
		this.ladDistrict = ladDistrict;
	}

	public Date getLadDob() {
		return this.ladDob;
	}

	public void setLadDob(Date ladDob) {
		this.ladDob = ladDob;
	}

	public String getLadEarnmem() {
		return this.ladEarnmem;
	}

	public void setLadEarnmem(String ladEarnmem) {
		this.ladEarnmem = ladEarnmem;
	}

	public String getLadEducation() {
		return this.ladEducation;
	}

	public void setLadEducation(String ladEducation) {
		this.ladEducation = ladEducation;
	}

	public String getLadEduothers() {
		return this.ladEduothers;
	}

	public void setLadEduothers(String ladEduothers) {
		this.ladEduothers = ladEduothers;
	}

	public String getLadEmail() {
		return this.ladEmail;
	}

	public void setLadEmail(String ladEmail) {
		this.ladEmail = ladEmail;
	}

	public String getLadEmployment() {
		return this.ladEmployment;
	}

	public void setLadEmployment(String ladEmployment) {
		this.ladEmployment = ladEmployment;
	}

	public String getLadFatname() {
		return this.ladFatname;
	}

	public void setLadFatname(String ladFatname) {
		this.ladFatname = ladFatname;
	}

	public String getLadFlatShop() {
		return this.ladFlatShop;
	}

	public void setLadFlatShop(String ladFlatShop) {
		this.ladFlatShop = ladFlatShop;
	}

	public String getLadFname() {
		return this.ladFname;
	}

	public void setLadFname(String ladFname) {
		this.ladFname = ladFname;
	}

	public String getLadHname() {
		return this.ladHname;
	}

	public void setLadHname(String ladHname) {
		this.ladHname = ladHname;
	}

	public String getLadHuslname() {
		return this.ladHuslname;
	}

	public void setLadHuslname(String ladHuslname) {
		this.ladHuslname = ladHuslname;
	}

	public String getLadHusmname() {
		return this.ladHusmname;
	}

	public void setLadHusmname(String ladHusmname) {
		this.ladHusmname = ladHusmname;
	}

	public String getLadHusname() {
		return this.ladHusname;
	}

	public void setLadHusname(String ladHusname) {
		this.ladHusname = ladHusname;
	}

	public BigDecimal getLadIndustrycode() {
		return this.ladIndustrycode;
	}

	public void setLadIndustrycode(BigDecimal ladIndustrycode) {
		this.ladIndustrycode = ladIndustrycode;
	}

	public String getLadJoblocation() {
		return this.ladJoblocation;
	}

	public void setLadJoblocation(String ladJoblocation) {
		this.ladJoblocation = ladJoblocation;
	}

	public String getLadLname() {
		return this.ladLname;
	}

	public void setLadLname(String ladLname) {
		this.ladLname = ladLname;
	}

	public BigDecimal getLadMailaddr() {
		return this.ladMailaddr;
	}

	public void setLadMailaddr(BigDecimal ladMailaddr) {
		this.ladMailaddr = ladMailaddr;
	}

	public String getLadMarstat() {
		return this.ladMarstat;
	}

	public void setLadMarstat(String ladMarstat) {
		this.ladMarstat = ladMarstat;
	}

	public String getLadMemno() {
		return this.ladMemno;
	}

	public void setLadMemno(String ladMemno) {
		this.ladMemno = ladMemno;
	}

	public String getLadMemtype() {
		return this.ladMemtype;
	}

	public void setLadMemtype(String ladMemtype) {
		this.ladMemtype = ladMemtype;
	}

	public String getLadMinority() {
		return this.ladMinority;
	}

	public void setLadMinority(String ladMinority) {
		this.ladMinority = ladMinority;
	}

	public String getLadMname() {
		return this.ladMname;
	}

	public void setLadMname(String ladMname) {
		this.ladMname = ladMname;
	}

	public String getLadMobile() {
		return this.ladMobile;
	}

	public void setLadMobile(String ladMobile) {
		this.ladMobile = ladMobile;
	}

	public String getLadModifiedBy() {
		return this.ladModifiedBy;
	}

	public void setLadModifiedBy(String ladModifiedBy) {
		this.ladModifiedBy = ladModifiedBy;
	}

	public Date getLadModifiedOn() {
		return this.ladModifiedOn;
	}

	public void setLadModifiedOn(Date ladModifiedOn) {
		this.ladModifiedOn = ladModifiedOn;
	}

	public String getLadNatureofbusiness() {
		return this.ladNatureofbusiness;
	}

	public void setLadNatureofbusiness(String ladNatureofbusiness) {
		this.ladNatureofbusiness = ladNatureofbusiness;
	}

	public String getLadNetworth() {
		return this.ladNetworth;
	}

	public void setLadNetworth(String ladNetworth) {
		this.ladNetworth = ladNetworth;
	}

	public Date getLadNetworthason() {
		return this.ladNetworthason;
	}

	public void setLadNetworthason(Date ladNetworthason) {
		this.ladNetworthason = ladNetworthason;
	}

	public String getLadNonpriority() {
		return this.ladNonpriority;
	}

	public void setLadNonpriority(String ladNonpriority) {
		this.ladNonpriority = ladNonpriority;
	}

	public String getLadOffid() {
		return this.ladOffid;
	}

	public void setLadOffid(String ladOffid) {
		this.ladOffid = ladOffid;
	}


	public BigDecimal getLadOldid() {
		return this.ladOldid;
	}


	public void setLadOldid(BigDecimal ladOldid) {
		this.ladOldid = ladOldid;
	}

	public String getLadOthernum() {
		return this.ladOthernum;
	}

	public void setLadOthernum(String ladOthernum) {
		this.ladOthernum = ladOthernum;
	}

	public String getLadPanno() {
		return this.ladPanno;
	}

	public void setLadPanno(String ladPanno) {
		this.ladPanno = ladPanno;
	}

	public Date getLadPassexpiry() {
		return this.ladPassexpiry;
	}

	public void setLadPassexpiry(Date ladPassexpiry) {
		this.ladPassexpiry = ladPassexpiry;
	}

	public String getLadPassissue() {
		return this.ladPassissue;
	}

	public void setLadPassissue(String ladPassissue) {
		this.ladPassissue = ladPassissue;
	}

	public Date getLadPassissuedt() {
		return this.ladPassissuedt;
	}

	public void setLadPassissuedt(Date ladPassissuedt) {
		this.ladPassissuedt = ladPassissuedt;
	}

	public String getLadPassport() {
		return this.ladPassport;
	}

	public void setLadPassport(String ladPassport) {
		this.ladPassport = ladPassport;
	}

	public String getLadPermadd1() {
		return this.ladPermadd1;
	}

	public void setLadPermadd1(String ladPermadd1) {
		this.ladPermadd1 = ladPermadd1;
	}

	public String getLadPermadd2() {
		return this.ladPermadd2;
	}

	public void setLadPermadd2(String ladPermadd2) {
		this.ladPermadd2 = ladPermadd2;
	}

	public String getLadPermadd3() {
		return this.ladPermadd3;
	}

	public void setLadPermadd3(String ladPermadd3) {
		this.ladPermadd3 = ladPermadd3;
	}

	public String getLadPermcity() {
		return this.ladPermcity;
	}

	public void setLadPermcity(String ladPermcity) {
		this.ladPermcity = ladPermcity;
	}

	public String getLadPermdistrict() {
		return this.ladPermdistrict;
	}

	public void setLadPermdistrict(String ladPermdistrict) {
		this.ladPermdistrict = ladPermdistrict;
	}

	public String getLadPermphone() {
		return this.ladPermphone;
	}

	public void setLadPermphone(String ladPermphone) {
		this.ladPermphone = ladPermphone;
	}

	public String getLadPermstate() {
		return this.ladPermstate;
	}

	public void setLadPermstate(String ladPermstate) {
		this.ladPermstate = ladPermstate;
	}

	public String getLadPermtaluk() {
		return this.ladPermtaluk;
	}

	public void setLadPermtaluk(String ladPermtaluk) {
		this.ladPermtaluk = ladPermtaluk;
	}

	public String getLadPermzip() {
		return this.ladPermzip;
	}

	public void setLadPermzip(String ladPermzip) {
		this.ladPermzip = ladPermzip;
	}

	public String getLadPhone() {
		return this.ladPhone;
	}

	public void setLadPhone(String ladPhone) {
		this.ladPhone = ladPhone;
	}

	public byte[] getLadPhoto() {
		return this.ladPhoto;
	}

	public void setLadPhoto(byte[] ladPhoto) {
		this.ladPhoto = ladPhoto;
	}

	public String getLadPlaceofdomicile() {
		return this.ladPlaceofdomicile;
	}

	public void setLadPlaceofdomicile(String ladPlaceofdomicile) {
		this.ladPlaceofdomicile = ladPlaceofdomicile;
	}

	public String getLadPresperm() {
		return this.ladPresperm;
	}

	public void setLadPresperm(String ladPresperm) {
		this.ladPresperm = ladPresperm;
	}

	public String getLadPrevadd1() {
		return this.ladPrevadd1;
	}

	public void setLadPrevadd1(String ladPrevadd1) {
		this.ladPrevadd1 = ladPrevadd1;
	}

	public String getLadPrevadd2() {
		return this.ladPrevadd2;
	}

	public void setLadPrevadd2(String ladPrevadd2) {
		this.ladPrevadd2 = ladPrevadd2;
	}

	public String getLadPrevadd3() {
		return this.ladPrevadd3;
	}

	public void setLadPrevadd3(String ladPrevadd3) {
		this.ladPrevadd3 = ladPrevadd3;
	}

	public String getLadPrevcity() {
		return this.ladPrevcity;
	}

	public void setLadPrevcity(String ladPrevcity) {
		this.ladPrevcity = ladPrevcity;
	}

	public String getLadPrevstate() {
		return this.ladPrevstate;
	}

	public void setLadPrevstate(String ladPrevstate) {
		this.ladPrevstate = ladPrevstate;
	}

	public String getLadPrevzip() {
		return this.ladPrevzip;
	}

	public void setLadPrevzip(String ladPrevzip) {
		this.ladPrevzip = ladPrevzip;
	}

	public String getLadPriority() {
		return this.ladPriority;
	}

	public void setLadPriority(String ladPriority) {
		this.ladPriority = ladPriority;
	}

	public String getLadPrioritytype() {
		return this.ladPrioritytype;
	}

	public void setLadPrioritytype(String ladPrioritytype) {
		this.ladPrioritytype = ladPrioritytype;
	}

	public BigDecimal getLadPurposecode() {
		return this.ladPurposecode;
	}

	public void setLadPurposecode(BigDecimal ladPurposecode) {
		this.ladPurposecode = ladPurposecode;
	}

	public String getLadRecfrom() {
		return this.ladRecfrom;
	}

	public void setLadRecfrom(String ladRecfrom) {
		this.ladRecfrom = ladRecfrom;
	}

	public String getLadRegno() {
		return this.ladRegno;
	}

	public void setLadRegno(String ladRegno) {
		this.ladRegno = ladRegno;
	}

	public String getLadRelationship() {
		return this.ladRelationship;
	}

	public void setLadRelationship(String ladRelationship) {
		this.ladRelationship = ladRelationship;
	}

	public String getLadRelativedet() {
		return this.ladRelativedet;
	}

	public void setLadRelativedet(String ladRelativedet) {
		this.ladRelativedet = ladRelativedet;
	}

	public String getLadReligion() {
		return this.ladReligion;
	}

	public void setLadReligion(String ladReligion) {
		this.ladReligion = ladReligion;
	}

	public String getLadRenew() {
		return this.ladRenew;
	}

	public void setLadRenew(String ladRenew) {
		this.ladRenew = ladRenew;
	}

	public String getLadRentedOwned() {
		return this.ladRentedOwned;
	}

	public void setLadRentedOwned(String ladRentedOwned) {
		this.ladRentedOwned = ladRentedOwned;
	}

	public String getLadResidencetype() {
		return this.ladResidencetype;
	}

	public void setLadResidencetype(String ladResidencetype) {
		this.ladResidencetype = ladResidencetype;
	}

	public String getLadResidential() {
		return this.ladResidential;
	}

	public void setLadResidential(String ladResidential) {
		this.ladResidential = ladResidential;
	}

	public String getLadSalaryrouted() {
		return this.ladSalaryrouted;
	}

	public void setLadSalaryrouted(String ladSalaryrouted) {
		this.ladSalaryrouted = ladSalaryrouted;
	}

	public String getLadSex() {
		return this.ladSex;
	}

	public void setLadSex(String ladSex) {
		this.ladSex = ladSex;
	}

	public String getLadShares() {
		return this.ladShares;
	}

	public void setLadShares(String ladShares) {
		this.ladShares = ladShares;
	}

	public String getLadShop() {
		return this.ladShop;
	}

	public void setLadShop(String ladShop) {
		this.ladShop = ladShop;
	}

	public String getLadSpouseemail() {
		return this.ladSpouseemail;
	}

	public void setLadSpouseemail(String ladSpouseemail) {
		this.ladSpouseemail = ladSpouseemail;
	}

	public String getLadSpouseincome() {
		return this.ladSpouseincome;
	}

	public void setLadSpouseincome(String ladSpouseincome) {
		this.ladSpouseincome = ladSpouseincome;
	}

	public String getLadSpouseoccu() {
		return this.ladSpouseoccu;
	}

	public void setLadSpouseoccu(String ladSpouseoccu) {
		this.ladSpouseoccu = ladSpouseoccu;
	}

	public String getLadSpousepan() {
		return this.ladSpousepan;
	}

	public void setLadSpousepan(String ladSpousepan) {
		this.ladSpousepan = ladSpousepan;
	}

	public String getLadSsn() {
		return this.ladSsn;
	}

	public void setLadSsn(String ladSsn) {
		this.ladSsn = ladSsn;
	}

	public String getLadState() {
		return this.ladState;
	}

	public void setLadState(String ladState) {
		this.ladState = ladState;
	}

	public String getLadStatus() {
		return this.ladStatus;
	}

	public void setLadStatus(String ladStatus) {
		this.ladStatus = ladStatus;
	}

	public String getLadTaluk() {
		return this.ladTaluk;
	}

	public void setLadTaluk(String ladTaluk) {
		this.ladTaluk = ladTaluk;
	}

	public String getLadTitle() {
		return this.ladTitle;
	}

	public void setLadTitle(String ladTitle) {
		this.ladTitle = ladTitle;
	}

	public String getLadTransferable() {
		return this.ladTransferable;
	}

	public void setLadTransferable(String ladTransferable) {
		this.ladTransferable = ladTransferable;
	}

	public String getLadTypeofocc() {
		return this.ladTypeofocc;
	}

	public void setLadTypeofocc(String ladTypeofocc) {
		this.ladTypeofocc = ladTypeofocc;
	}

	public String getLadTypeofprof() {
		return this.ladTypeofprof;
	}

	public void setLadTypeofprof(String ladTypeofprof) {
		this.ladTypeofprof = ladTypeofprof;
	}

	public String getLadWeak() {
		return this.ladWeak;
	}

	public void setLadWeak(String ladWeak) {
		this.ladWeak = ladWeak;
	}

	public BigDecimal getLadYrsinpresadd() {
		return this.ladYrsinpresadd;
	}

	public void setLadYrsinpresadd(BigDecimal ladYrsinpresadd) {
		this.ladYrsinpresadd = ladYrsinpresadd;
	}

	public String getLadZip() {
		return this.ladZip;
	}

	public List<LpcomLiability> getLpcomLiabilities() {
		return lpcomLiabilities;
	}

	public void setLpcomLiabilities(List<LpcomLiability> lpcomLiabilities) {
		this.lpcomLiabilities = lpcomLiabilities;
	}

	public void setLadZip(String ladZip) {
		this.ladZip = ladZip;
	}

	public String getLadaadhar() {
		return ladaadhar;
	}

	public void setLadaadhar(String ladaadhar) {
		this.ladaadhar = ladaadhar;
	}

	public String getLadDrivingLicenseNo() {
		return ladDrivingLicenseNo;
	}

	public void setLadDrivingLicenseNo(String ladDrivingLicenseNo) {
		this.ladDrivingLicenseNo = ladDrivingLicenseNo;
	}

	public String getLadRationNo() {
		return ladRationNo;
	}

	public void setLadRationNo(String ladRationNo) {
		this.ladRationNo = ladRationNo;
	}

	public String getLadVoterid() {
		return ladVoterid;
	}

	public void setLadVoterid(String ladVoterid) {
		this.ladVoterid = ladVoterid;
	}

	public String getLadCityName() {
		return ladCityName;
	}

	public void setLadCityName(String ladCityName) {
		this.ladCityName = ladCityName;
	}

	public String getLadStateName() {
		return ladStateName;
	}

	public void setLadStateName(String ladStateName) {
		this.ladStateName = ladStateName;
	}

	public String getLadDistrictName() {
		return ladDistrictName;
	}

	public void setLadDistrictName(String ladDistrictName) {
		this.ladDistrictName = ladDistrictName;
	}

	public String getLadPermCityName() {
		return ladPermCityName;
	}

	public void setLadPermCityName(String ladPermCityName) {
		this.ladPermCityName = ladPermCityName;
	}

	public String getLadPermStateName() {
		return ladPermStateName;
	}

	public void setLadPermStateName(String ladPermStateName) {
		this.ladPermStateName = ladPermStateName;
	}

	public String getLadPermDistrictName() {
		return ladPermDistrictName;
	}

	public void setLadPermDistrictName(String ladPermDistrictName) {
		this.ladPermDistrictName = ladPermDistrictName;
	}

	/*public List<LpcustApplicantEmployer> getLpcustApplicantEmployers() {
		return this.lpcustApplicantEmployers;
	}

	public void setLpcustApplicantEmployers(List<LpcustApplicantEmployer> lpcustApplicantEmployers) {
		this.lpcustApplicantEmployers = lpcustApplicantEmployers;
	}

	public LpcustApplicantEmployer addLpcustApplicantEmployer(LpcustApplicantEmployer lpcustApplicantEmployer) {
		getLpcustApplicantEmployers().add(lpcustApplicantEmployer);
		lpcustApplicantEmployer.setLpcustApplicantData(this);

		return lpcustApplicantEmployer;
	}

	public LpcustApplicantEmployer removeLpcustApplicantEmployer(LpcustApplicantEmployer lpcustApplicantEmployer) {
		getLpcustApplicantEmployers().remove(lpcustApplicantEmployer);
		lpcustApplicantEmployer.setLpcustApplicantData(null);

		return lpcustApplicantEmployer;
	}
	*/
	@Override
	public String toString() {
		return "LpcustApplicantData [ladId=" + ladId + ", ladAddress1=" + ladAddress1 + ", ladAddress2=" + ladAddress2
				+ ", ladAddress3=" + ladAddress3 + ", ladAppdate=" + ladAppdate + ", ladApplnt=" + ladApplnt
				+ ", ladAssets=" + ladAssets + ", ladBank=" + ladBank + ", ladBankaccno=" + ladBankaccno
				+ ", ladBankacctype=" + ladBankacctype + ", ladBanksince=" + ladBanksince + ", ladBranchcode="
				+ ladBranchcode + ", ladBrdet=" + ladBrdet + ", ladBuss=" + ladBuss + ", ladCategory=" + ladCategory
				+ ", ladCbsid=" + ladCbsid + ", ladChildnum=" + ladChildnum + ", ladCity=" + ladCity + ", ladCountry="
				+ ladCountry + ", ladCreatedBy=" + ladCreatedBy + ", ladCreatedOn=" + ladCreatedOn + ", ladDepend="
				+ ladDepend + ", ladDistrict=" + ladDistrict + ", ladDob=" + ladDob + ", ladEarnmem=" + ladEarnmem
				+ ", ladEducation=" + ladEducation + ", ladEduothers=" + ladEduothers + ", ladEmail=" + ladEmail
				+ ", ladEmployment=" + ladEmployment + ", ladFatname=" + ladFatname + ", ladFlatShop=" + ladFlatShop
				+ ", ladFname=" + ladFname + ", ladHname=" + ladHname + ", ladHuslname=" + ladHuslname
				+ ", ladHusmname=" + ladHusmname + ", ladHusname=" + ladHusname + ", ladIndustrycode=" + ladIndustrycode
				+ ", ladJoblocation=" + ladJoblocation + ", ladLname=" + ladLname + ", ladMailaddr=" + ladMailaddr
				+ ", ladMarstat=" + ladMarstat + ", ladMemno=" + ladMemno + ", ladMemtype=" + ladMemtype
				+ ", ladMinority=" + ladMinority + ", ladMname=" + ladMname + ", ladMobile=" + ladMobile
				+ ", ladModifiedBy=" + ladModifiedBy + ", ladModifiedOn=" + ladModifiedOn + ", ladNatureofbusiness="
				+ ladNatureofbusiness + ", ladNetworth=" + ladNetworth + ", ladNetworthason=" + ladNetworthason
				+ ", ladNonpriority=" + ladNonpriority + ", ladOffid=" + ladOffid + ", ladOldid=" + ladOldid
				+ ", ladOthernum=" + ladOthernum + ", ladPanno=" + ladPanno + ", ladPassexpiry=" + ladPassexpiry
				+ ", ladPassissue=" + ladPassissue + ", ladPassissuedt=" + ladPassissuedt + ", ladPassport="
				+ ladPassport + ", ladPermadd1=" + ladPermadd1 + ", ladPermadd2=" + ladPermadd2 + ", ladPermadd3="
				+ ladPermadd3 + ", ladPermcity=" + ladPermcity + ", ladPermdistrict=" + ladPermdistrict
				+ ", ladPermphone=" + ladPermphone + ", ladPermstate=" + ladPermstate + ", ladPermtaluk=" + ladPermtaluk
				+ ", ladPermzip=" + ladPermzip + ", ladPhone=" + ladPhone + ", ladPhoto=" + Arrays.toString(ladPhoto)
				+ ", ladPlaceofdomicile=" + ladPlaceofdomicile + ", ladPresperm=" + ladPresperm + ", ladPrevadd1="
				+ ladPrevadd1 + ", ladPrevadd2=" + ladPrevadd2 + ", ladPrevadd3=" + ladPrevadd3 + ", ladPrevcity="
				+ ladPrevcity + ", ladPrevstate=" + ladPrevstate + ", ladPrevzip=" + ladPrevzip + ", ladPriority="
				+ ladPriority + ", ladPrioritytype=" + ladPrioritytype + ", ladPurposecode=" + ladPurposecode
				+ ", ladRecfrom=" + ladRecfrom + ", ladRegno=" + ladRegno + ", ladRelationship=" + ladRelationship
				+ ", ladRelativedet=" + ladRelativedet + ", ladReligion=" + ladReligion + ", ladRenew=" + ladRenew
				+ ", ladRentedOwned=" + ladRentedOwned + ", ladResidencetype=" + ladResidencetype + ", ladResidential="
				+ ladResidential + ", ladSalaryrouted=" + ladSalaryrouted + ", ladSex=" + ladSex + ", ladShares="
				+ ladShares + ", ladShop=" + ladShop + ", ladSpouseemail=" + ladSpouseemail + ", ladSpouseincome="
				+ ladSpouseincome + ", ladSpouseoccu=" + ladSpouseoccu + ", ladSpousepan=" + ladSpousepan + ", ladSsn="
				+ ladSsn + ", ladState=" + ladState + ", ladStatus=" + ladStatus + ", ladTaluk=" + ladTaluk
				+ ", ladTitle=" + ladTitle + ", ladTransferable=" + ladTransferable + ", ladTypeofocc=" + ladTypeofocc
				+ ", ladTypeofprof=" + ladTypeofprof + ", ladWeak=" + ladWeak + ", ladYrsinpresadd=" + ladYrsinpresadd
				+ ", ladZip=" + ladZip + ", ladRelativeworking=" + ladRelativeworking + ", ladYrsinjob=" + ladYrsinjob
				+ ", ladSpousename=" + ladSpousename + ", lpcomLiabilities=" + lpcomLiabilities
				+ ", lpcomOtherAssetsLiabilities=" + lpcomOtherAssetsLiabilities + ", lpcustAppcustRelations="
				+ lpcustAppcustRelations + ", ladaadhar=" + ladaadhar + ", ladDrivingLicenseNo=" + ladDrivingLicenseNo
				+ ", ladRationNo=" + ladRationNo + ", ladVoterid=" + ladVoterid + ", ladCityName=" + ladCityName
				+ ", ladStateName=" + ladStateName + ", ladDistrictName=" + ladDistrictName + ", ladPermCityName="
				+ ladPermCityName + ", ladPermStateName=" + ladPermStateName + ", ladPermDistrictName="
				+ ladPermDistrictName + ",ladVicinity=" + ladVicinity + " ]";
	}

}