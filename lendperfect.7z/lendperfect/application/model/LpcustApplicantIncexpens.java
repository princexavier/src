package com.sai.lendperfect.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The persistent class for the LPCUST_APPLICANT_INCEXPENSES database table.
 * 
 */
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "LPCUST_APPLICANT_INCEXPENSES")
// @NamedQuery(name="LpcustApplicantIncexpens.findAll", query="SELECT l FROM
// LpcustApplicantIncexpens l")
public class LpcustApplicantIncexpens implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LAIE_ID")
	private long laieId;

	@Column(name = "LAIE_CREATED_BY")
	private String laieCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAIE_CREATED_ON")
	private Date laieCreatedOn;

	/*
	 * @Column(name="LAIE_HISTORY") private String laieHistory;
	 */

	@Column(name = "LAIE_INCTYPE")
	private String laieInctype;

	/*
	 * @Column(name="LAIE_LOYALTY") private String laieLoyalty;
	 */

	@Column(name = "LAIE_MODIFIED_BY")
	private String laieModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAIE_MODIFIED_ON")
	private Date laieModifiedOn;

	@Column(name = "LAIE_MON_NETINC")
	private BigDecimal laieMonNetinc;

	@Column(name = "LAIE_MON_OTHERDED")
	private BigDecimal laieMonOtherded;

	@Column(name = "LAIE_MON_STATDED")
	private BigDecimal laieMonStatded;

	@Column(name = "LAIE_MONSALARY")
	private BigDecimal laieMonsalary;

	@Column(name = "LAIE_TOT_ANNUALINC")
	private BigDecimal laieTotAnnualinc;

	@Column(name = "LAIE_YEAR_NETINC")
	private BigDecimal laieYearNetinc;

	@Column(name = "LAIE_YEAR_OTHERDED")
	private BigDecimal laieYearOtherded;

	@Column(name = "LAIE_YEAR_STATDED")
	private BigDecimal laieYearStatded;

	@Column(name = "LAIE_YEARSALARY")
	private BigDecimal laieYearsalary;

	/*
	 * //bi-directional many-to-one association to LpcomProposal
	 * 
	 * @ManyToOne
	 * 
	 * @JoinColumn(name="LAIE_APPNO") private LpcomProposal lpcomProposal;
	 */

	// bi-directional many-to-one association to LpcustApplicantData
	@ManyToOne
	@JoinColumn(name = "LAIE_APPID")
	private LpcustApplicantData lpcustApplicantData;

	public LpcustApplicantIncexpens() {
	}

	public long getLaieId() {
		return this.laieId;
	}

	public void setLaieId(long laieId) {
		this.laieId = laieId;
	}

	public String getLaieCreatedBy() {
		return this.laieCreatedBy;
	}

	public void setLaieCreatedBy(String laieCreatedBy) {
		this.laieCreatedBy = laieCreatedBy;
	}

	public Date getLaieCreatedOn() {
		return this.laieCreatedOn;
	}

	public void setLaieCreatedOn(Date laieCreatedOn) {
		this.laieCreatedOn = laieCreatedOn;
	}

	/*
	 * public String getLaieHistory() { return this.laieHistory; }
	 * 
	 * public void setLaiHistory(String laiHistory) { this.laiHistory =
	 * laiHistory; }
	 */
	public String getLaieInctype() {
		return this.laieInctype;
	}

	public void setLaieInctype(String laieInctype) {
		this.laieInctype = laieInctype;
	}

	/*
	 * public String getLaieLoyalty() { return this.laieLoyalty; }
	 * 
	 * public void setLaieLoyalty(String laieLoyalty) { this.laieLoyalty =
	 * laieLoyalty; }
	 */
	public String getLaieModifiedBy() {
		return this.laieModifiedBy;
	}

	public void setLaieModifiedBy(String laieModifiedBy) {
		this.laieModifiedBy = laieModifiedBy;
	}

	public Date getLaieModifiedOn() {
		return this.laieModifiedOn;
	}

	public void setLaeiModifiedOn(Date laieModifiedOn) {
		this.laieModifiedOn = laieModifiedOn;
	}

	public BigDecimal getLaieMonNetinc() {
		return this.laieMonNetinc;
	}

	public void setLaieMonNetinc(BigDecimal laieMonNetinc) {
		this.laieMonNetinc = laieMonNetinc;
	}

	public BigDecimal getLaieMonOtherded() {
		return this.laieMonOtherded;
	}

	public void setLaieMonOtherded(BigDecimal laieMonOtherded) {
		this.laieMonOtherded = laieMonOtherded;
	}

	public BigDecimal getLaieMonStatded() {
		return this.laieMonStatded;
	}

	public void setLaieMonStatded(BigDecimal laieMonStatded) {
		this.laieMonStatded = laieMonStatded;
	}

	public BigDecimal getLaieMonsalary() {
		return this.laieMonsalary;
	}

	public void setLaieMonsalary(BigDecimal laieMonsalary) {
		this.laieMonsalary = laieMonsalary;
	}

	public BigDecimal getLaieTotAnnualinc() {
		return this.laieTotAnnualinc;
	}

	public void setLaieTotAnnualinc(BigDecimal laieTotAnnualinc) {
		this.laieTotAnnualinc = laieTotAnnualinc;
	}

	public BigDecimal getLaieYearNetinc() {
		return this.laieYearNetinc;
	}

	public void setLaieYearNetinc(BigDecimal laieYearNetinc) {
		this.laieYearNetinc = laieYearNetinc;
	}

	public BigDecimal getLaieYearOtherded() {
		return this.laieYearOtherded;
	}

	public void setLaieYearOtherded(BigDecimal laieYearOtherded) {
		this.laieYearOtherded = laieYearOtherded;
	}

	public BigDecimal getLaieYearStatded() {
		return this.laieYearStatded;
	}

	public void setLaieYearStatded(BigDecimal laieYearStatded) {
		this.laieYearStatded = laieYearStatded;
	}

	public BigDecimal getLaieYearsalary() {
		return this.laieYearsalary;
	}

	public void setLaieYearsalary(BigDecimal laieYearsalary) {
		this.laieYearsalary = laieYearsalary;
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}

}
