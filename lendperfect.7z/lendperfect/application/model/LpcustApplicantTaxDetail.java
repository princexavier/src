package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCUST_APPLICANT_TAX_DETAILS database table.
 * 
 */
@Entity
@Table(name="LPCUST_APPLICANT_TAX_DETAILS")
@NamedQuery(name="LpcustApplicantTaxDetail.findAll", query="SELECT l FROM LpcustApplicantTaxDetail l")
@JsonIgnoreProperties(ignoreUnknown = true)
public class LpcustApplicantTaxDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LATP_SNO")
	private long latpSno;

	@Column(name="LATP_DESC")
	private String latpDesc;
	
	@Column(name="LATP_CREATED_BY")
	private String latpCreatedBy;
	
	@Column(name="LATP_MODIFIED_BY")
	private String latpModifiedBy;

	@Column(name="LATP_REBATE")
	private BigDecimal latpRebate;

	@Column(name="LATP_REFUND_DUE")
	private BigDecimal latpRefundDue;	
	
	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name="LATP_RETURN_FILE_ON")
	private Date latpReturnFileOn;
	
	@Temporal(TemporalType.DATE)
	@Column(name="LATP_CREATED_ON")
	private Date latpCreatedOn;
	
	@Temporal(TemporalType.DATE)
	@Column(name="LATP_MODIFIED_ON")
	private Date latpModifiedOn;

	@Column(name="LATP_SELF_ASS_PAID")
	private BigDecimal latpSelfAssPaid;

	@Column(name="LATP_TAX")
	private BigDecimal latpTax;

	@Column(name="LATP_TDS")
	private BigDecimal latpTds;

	//bi-directional many-to-one association to LpcustApplicantData
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LATP_APP_ID")
	private LpcustApplicantData lpcustApplicantData;

	public LpcustApplicantTaxDetail() {
	}

	public long getLatpSno() {
		return this.latpSno;
	}

	public void setLatpSno(long latpSno) {
		this.latpSno = latpSno;
	}

	public String getLatpDesc() {
		return this.latpDesc;
	}

	public void setLatpDesc(String latpDesc) {
		this.latpDesc = latpDesc;
	}

	public BigDecimal getLatpRebate() {
		return this.latpRebate;
	}

	public void setLatpRebate(BigDecimal latpRebate) {
		this.latpRebate = latpRebate;
	}

	public BigDecimal getLatpRefundDue() {
		return this.latpRefundDue;
	}

	public void setLatpRefundDue(BigDecimal latpRefundDue) {
		this.latpRefundDue = latpRefundDue;
	}

	public Date getLatpReturnFileOn() {
		return this.latpReturnFileOn;
	}

	public void setLatpReturnFileOn(Date latpReturnFileOn) {
		this.latpReturnFileOn = latpReturnFileOn;
	}

	public BigDecimal getLatpSelfAssPaid() {
		return this.latpSelfAssPaid;
	}

	public void setLatpSelfAssPaid(BigDecimal latpSelfAssPaid) {
		this.latpSelfAssPaid = latpSelfAssPaid;
	}

	public BigDecimal getLatpTax() {
		return this.latpTax;
	}

	public void setLatpTax(BigDecimal latpTax) {
		this.latpTax = latpTax;
	}

	public BigDecimal getLatpTds() {
		return this.latpTds;
	}

	public void setLatpTds(BigDecimal latpTds) {
		this.latpTds = latpTds;
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return this.lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}
	
	public String getLatpCreatedBy() {
		return latpCreatedBy;
	}

	public void setLatpCreatedBy(String latpCreatedBy) {
		this.latpCreatedBy = latpCreatedBy;
	}

	public String getLatpModifiedBy() {
		return latpModifiedBy;
	}

	public void setLatpModifiedBy(String latpModifiedBy) {
		this.latpModifiedBy = latpModifiedBy;
	}

	public Date getLatpCreatedOn() {
		return latpCreatedOn;
	}

	public void setLatpCreatedOn(Date latpCreatedOn) {
		this.latpCreatedOn = latpCreatedOn;
	}

	public Date getLatpModifiedOn() {
		return latpModifiedOn;
	}

	public void setLatpModifiedOn(Date latpModifiedOn) {
		this.latpModifiedOn = latpModifiedOn;
	}

}
