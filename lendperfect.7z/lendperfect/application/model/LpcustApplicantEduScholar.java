package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the LPCUST_APPLICANT_EDU_SCHOLAR database table.
 * 
 */
@Entity
@Table(name="LPCUST_APPLICANT_EDU_SCHOLAR")
@NamedQuery(name="LpcustApplicantEduScholar.findAll", query="SELECT l FROM LpcustApplicantEduScholar l")
public class LpcustApplicantEduScholar implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LAESC_EDU_SCHOLAR_ID")
	private long laescEduScholarId;

	@Column(name="LAESC_CREATEDBY")
	private String laescCreatedby;

	@Column(name="LAESC_CREATEDDATE")
	private Timestamp laescCreateddate;

	@Column(name="LAESC_EDU_ACADEMIC")
	private String laescEduAcademic;

	@Column(name="LAESC_EDU_AMOUNT")
	private BigDecimal laescEduAmount;

	@Column(name="LAESC_EDU_EXAM")
	private String laescEduExam;

	@Column(name="LAESC_EDU_FROM")
	private Date laescEduFrom;

	@Column(name="LAESC_EDU_NAME")
	private String laescEduName;

	@Column(name="LAESC_EDU_TO")
	private Date laescEduTo;

	@Column(name="LAESC_MODIFIEDDATE")
	private Timestamp laescModifieddate;

	@Column(name="LAESC_MODIFIEDDBY")
	private String laescModifieddby;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LAESC_EDUSCHOLAR_APPNO")
	private LpcomProposal lpcomProposal;

	public LpcustApplicantEduScholar() {
	}

	public long getLaescEduScholarId() {
		return this.laescEduScholarId;
	}

	public void setLaescEduScholarId(long laescEduScholarId) {
		this.laescEduScholarId = laescEduScholarId;
	}

	public String getLaescCreatedby() {
		return this.laescCreatedby;
	}

	public void setLaescCreatedby(String laescCreatedby) {
		this.laescCreatedby = laescCreatedby;
	}

	public Timestamp getLaescCreateddate() {
		return this.laescCreateddate;
	}

	public void setLaescCreateddate(Timestamp laescCreateddate) {
		this.laescCreateddate = laescCreateddate;
	}

	public String getLaescEduAcademic() {
		return this.laescEduAcademic;
	}

	public void setLaescEduAcademic(String laescEduAcademic) {
		this.laescEduAcademic = laescEduAcademic;
	}

	public BigDecimal getLaescEduAmount() {
		return this.laescEduAmount;
	}

	public void setLaescEduAmount(BigDecimal laescEduAmount) {
		this.laescEduAmount = laescEduAmount;
	}

	public String getLaescEduExam() {
		return this.laescEduExam;
	}

	public void setLaescEduExam(String laescEduExam) {
		this.laescEduExam = laescEduExam;
	}

	public Date getLaescEduFrom() {
		return this.laescEduFrom;
	}

	public void setLaescEduFrom(Date laescEduFrom) {
		this.laescEduFrom = laescEduFrom;
	}

	public String getLaescEduName() {
		return this.laescEduName;
	}

	public void setLaescEduName(String laescEduName) {
		this.laescEduName = laescEduName;
	}

	public Date getLaescEduTo() {
		return this.laescEduTo;
	}

	public void setLaescEduTo(Date laescEduTo) {
		this.laescEduTo = laescEduTo;
	}

	public Timestamp getLaescModifieddate() {
		return this.laescModifieddate;
	}

	public void setLaescModifieddate(Timestamp laescModifieddate) {
		this.laescModifieddate = laescModifieddate;
	}

	public String getLaescModifieddby() {
		return this.laescModifieddby;
	}

	public void setLaescModifieddby(String laescModifieddby) {
		this.laescModifieddby = laescModifieddby;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}