package com.sai.lendperfect.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.Columns;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sai.lendperfect.app.customerdetails.CustomerDetailsService;
import com.sai.lendperfect.commodel.LpcomProposal;

/**
 * The persistent class for the LPCUST_APPLICANT_OTHEREXP database table.
 * 
 */
@Entity
@JsonIgnoreProperties(ignoreUnknown=true)
@Table(name="LPCUST_APPLICANT_OTHEREXP")
//@NamedQuery(name="LpcustApplicantOtherexp.findAll", query="SELECT l FROM LpcustApplicantOtherexp l")
public class LpcustApplicantOtherexp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LAOE_ID")
	private long laoeId;

	@Column(name="LAOE_CREATEDBY")
	private String laoeCreatedby;

	@Temporal(TemporalType.DATE)
	@Column(name="LAOE_CREATEDON")
	private Date laoeCreatedon;

	@Column(name="LAOE_DESC")
	private String laoeDesc;

	@Column(name="LAOE_EXPAMOUNT")
	private BigDecimal laoeExpamount;

	@Column(name="LAOE_MODIFIEDBY")
	private String laoeModifiedby;

	@Temporal(TemporalType.DATE)
	@Column(name="LAOE_MODIFIEDON")
	private Date laoeModifiedon;

	//bi-directional many-to-one association to LpcustApplicantData
	@ManyToOne
	@JoinColumn(name="LAOE_APPID")
	
	private LpcustApplicantData lpcustApplicantData;

	public LpcustApplicantOtherexp() {
	}

	public long getLaoeId() {
		return this.laoeId;
	}

	public void setLaoeId(long laoeId) {
		this.laoeId = laoeId;
	}

	public String getLaoeCreatedby() {
		return this.laoeCreatedby;
	}

	public void setLaoeCreatedby(String laoeCreatedby) {
		this.laoeCreatedby = laoeCreatedby;
	}

	public Date getLaoeCreatedon() {
		return this.laoeCreatedon;
	}

	public void setLaoeCreatedon(Date laoeCreatedon) {
		this.laoeCreatedon = laoeCreatedon;
	}

	public String getLaoeDesc() {
		return this.laoeDesc;
	}

	public void setLaoeDesc(String laoeDesc) {
		this.laoeDesc = laoeDesc;
	}

	public BigDecimal getLaoeExpamount() {
		return this.laoeExpamount;
	}

	public void setLaoeExpamount(BigDecimal laoeExpamount) {
		this.laoeExpamount = laoeExpamount;
	}

	public String getLaoeModifiedby() {
		return this.laoeModifiedby;
	}

	public void setLaoeModifiedby(String laoeModifiedby) {
		this.laoeModifiedby = laoeModifiedby;
	}

	public Date getLaoeModifiedon() {
		return this.laoeModifiedon;
	}

	public void setLaoeModifiedon(Date laoeModifiedon) {
		this.laoeModifiedon = laoeModifiedon;
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return this.lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}

}