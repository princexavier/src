package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;

import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the LPCUST_APPLICANT_EDU_DETAILS database table.
 * 
 */
@Entity
@Table(name="LPCUST_APPLICANT_EDU_DETAILS")
@NamedQuery(name="LpcustApplicantEduDetail.findAll", query="SELECT l FROM LpcustApplicantEduDetail l")
public class LpcustApplicantEduDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LAED_EDU_DET_ID")
	private long laedEduDetId;

	@Column(name="LAED_CREATEDBY")
	private String laedCreatedby;

	@Column(name="LAED_CREATEDDATE")
	private Date laedCreateddate;

	@Column(name="LAED_EDU_ATTEMPTS")
	private BigDecimal laedEduAttempts;

	@Column(name="LAED_EDU_CLASS")
	private String laedEduClass;

	@Column(name="LAED_EDU_EXAM")
	private String laedEduExam;

	@Column(name="LAED_EDU_MARKS")
	private BigDecimal laedEduMarks;

	@Column(name="LAED_EDU_UNIVERSITY")
	private String laedEduUniversity;

	@Temporal(TemporalType.DATE)
	@Column(name="LAED_EDU_YEARPASS")
	private Date laedEduYearpass;

	@Column(name="LAED_MODIFIEDDATE")
	private Date laedModifieddate;

	@Column(name="LAED_MODIFIEDDBY")
	private String laedModifieddby;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JoinColumn(name="LAED_EDUDETAIL_APPNO")
	private LpcomProposal lpcomProposal;

	public LpcustApplicantEduDetail() {
	}

	public long getLaedEduDetId() {
		return this.laedEduDetId;
	}

	public void setLaedEduDetId(long laedEduDetId) {
		this.laedEduDetId = laedEduDetId;
	}

	public String getLaedCreatedby() {
		return this.laedCreatedby;
	}

	public void setLaedCreatedby(String laedCreatedby) {
		this.laedCreatedby = laedCreatedby;
	}

	public Date getLaedCreateddate() {
		return this.laedCreateddate;
	}

	public void setLaedCreateddate(Date laedCreateddate) {
		this.laedCreateddate = laedCreateddate;
	}

	public BigDecimal getLaedEduAttempts() {
		return this.laedEduAttempts;
	}

	public void setLaedEduAttempts(BigDecimal laedEduAttempts) {
		this.laedEduAttempts = laedEduAttempts;
	}

	public String getLaedEduClass() {
		return this.laedEduClass;
	}

	public void setLaedEduClass(String laedEduClass) {
		this.laedEduClass = laedEduClass;
	}

	public String getLaedEduExam() {
		return this.laedEduExam;
	}

	public void setLaedEduExam(String laedEduExam) {
		this.laedEduExam = laedEduExam;
	}

	public BigDecimal getLaedEduMarks() {
		return this.laedEduMarks;
	}

	public void setLaedEduMarks(BigDecimal laedEduMarks) {
		this.laedEduMarks = laedEduMarks;
	}

	public String getLaedEduUniversity() {
		return this.laedEduUniversity;
	}

	public void setLaedEduUniversity(String laedEduUniversity) {
		this.laedEduUniversity = laedEduUniversity;
	}

	public Date getLaedEduYearpass() {
		return this.laedEduYearpass;
	}

	public void setLaedEduYearpass(Date laedEduYearpass) {
		this.laedEduYearpass = laedEduYearpass;
	}

	public Date getLaedModifieddate() {
		return this.laedModifieddate;
	}

	public void setLaedModifieddate(Date laedModifieddate) {
		this.laedModifieddate = laedModifieddate;
	}

	public String getLaedModifieddby() {
		return this.laedModifieddby;
	}

	public void setLaedModifieddby(String laedModifieddby) {
		this.laedModifieddby = laedModifieddby;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}