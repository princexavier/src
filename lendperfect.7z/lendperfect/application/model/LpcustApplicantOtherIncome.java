package com.sai.lendperfect.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The persistent class for the LPCUST_APPLICANT_OTHER_INCOME database table.
 * 
 */
@Entity
@Table(name = "LPCUST_APPLICANT_OTHER_INCOME")
@JsonIgnoreProperties(ignoreUnknown = true)
// @NamedQuery(name="LpcustApplicantOtherIncome.findAll", query="SELECT l FROM
// LpcustApplicantOtherIncome l")
public class LpcustApplicantOtherIncome implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LAOI_ID")
	private long laoiId;

	@Column(name = "LAOI_CREATED_BY")
	private String laoiCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAOI_CREATED_ON")
	private Date laoiCreatedOn;

	@Column(name = "LAOI_DESC")
	private String laoiDesc;

	@Column(name = "LAOI_MODIFIED_BY")
	private String laoiModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAOI_MODIFIED_ON")
	private Date laoiModifiedOn;

	@Column(name = "LAOI_MONINC")
	private BigDecimal laoiMoninc;

	@Column(name = "LAOI_YEARINC")
	private BigDecimal laoiYearinc;

	// bi-directional many-to-one association to LpcustApplicantData
	@ManyToOne
	@JoinColumn(name = "LAOI_APPID")
	private LpcustApplicantData lpcustApplicantData;

	public LpcustApplicantOtherIncome() {
	}

	public long getLaoiId() {
		return this.laoiId;
	}

	public void setLaoiId(long laoiId) {
		this.laoiId = laoiId;
	}

	public String getLaoiCreatedBy() {
		return this.laoiCreatedBy;
	}

	public void setLaoiCreatedBy(String laoiCreatedBy) {
		this.laoiCreatedBy = laoiCreatedBy;
	}

	public Date getLaoiCreatedOn() {
		return this.laoiCreatedOn;
	}

	public void setLaoiCreatedOn(Date laoiCreatedOn) {
		this.laoiCreatedOn = laoiCreatedOn;
	}

	public String getLaoiDesc() {
		return this.laoiDesc;
	}

	public void setLaoiDesc(String laoiDesc) {
		this.laoiDesc = laoiDesc;
	}

	public String getLaoiModifiedBy() {
		return this.laoiModifiedBy;
	}

	public void setLaoiModifiedBy(String laoiModifiedBy) {
		this.laoiModifiedBy = laoiModifiedBy;
	}

	public Date getLaoiModifiedOn() {
		return this.laoiModifiedOn;
	}

	public void setLaoiModifiedOn(Date laoiModifiedOn) {
		this.laoiModifiedOn = laoiModifiedOn;
	}

	public BigDecimal getLaoiMoninc() {
		return this.laoiMoninc;
	}

	public void setLaoiMoninc(BigDecimal laoiMoninc) {
		this.laoiMoninc = laoiMoninc;
	}

	public BigDecimal getLaoiYearinc() {
		return this.laoiYearinc;
	}

	public void setLaoiYearinc(BigDecimal laoiYearinc) {
		this.laoiYearinc = laoiYearinc;
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return this.lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}

}