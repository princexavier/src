package com.sai.lendperfect.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.sai.lendperfect.commodel.LpcomProposal;

/**
 * The persistent class for the LPCUST_LOAN_DETAILS database table.
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "LPCUST_LOAN_DETAILS")
@NamedQuery(name = "LpcustLoanDetail.findAll", query = "SELECT l FROM LpcustLoanDetail l")
public class LpcustLoanDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "LLD_APPNO")
	private LpcomProposal lpcomProposal;

	@Column(name = "LLD_SNO")
	private long lldSno;

	@Column(name = "LLD_AMTREQD")
	private BigDecimal lldAmtreqd;

	@Column(name = "LLD_APPAMT")
	private BigDecimal lldAppamt;

	@Column(name = "LLD_BANK_REFNO")
	private String lldBankRefno;

	@Column(name = "LLD_CBSACCTNO")
	private BigDecimal lldCbsacctno;

	@Column(name = "LLD_CREATED_BY")
	private String lldCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LLD_CREATED_ON")
	private Date lldCreatedOn;

	@Column(name = "LLD_DEVIATIONLOANAMOUNT")
	private BigDecimal lldDeviationloanamount;

	@Column(name = "LLD_DOCFEE")
	private BigDecimal lldDocfee;

	@Column(name = "LLD_DOWNPAY")
	private BigDecimal lldDownpay;

	@Column(name = "LLD_EMI")
	private BigDecimal lldEmi;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name = "LLD_FILEDON")
	private Date lldFiledon;

	@Column(name = "LLD_FILENO")
	private String lldFileno;

	@Column(name = "LLD_FURMARGIN")
	private BigDecimal lldFurmargin;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LLD_ID")
	private Long lldId;

	@Column(name = "LLD_INTERESTCHARGED")
	private String lldInterestcharged;

	@Column(name = "LLD_INTRATE")
	private BigDecimal lldIntrate;

	@Column(name = "LLD_INTTYPE")
	private String lldInttype;

	@Column(name = "LLD_LOANTRADE")
	private BigDecimal lldLoantrade;

	@Column(name = "LLD_LOANTYPE")
	private String lldLoantype;

	@Column(name = "LLD_MARGIN")
	private BigDecimal lldMargin;

	@Column(name = "LLD_MARGINDESC")
	private String lldMargindesc;

	@Column(name = "LLD_MODIFIED_BY")
	private String lldModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LLD_MODIFIED_ON")
	private Date lldModifiedOn;

	@Column(name = "LLD_MODINTRATE")
	private BigDecimal lldModintrate;

	@Column(name = "LLD_MODUSRID")
	private String lldModusrid;

	@Column(name = "LLD_MORATORIUM")
	private BigDecimal lldMoratorium;

	@Column(name = "LLD_PRDCODE")
	private Long lldPrdcode;

	@Column(name = "LLD_PROFEE")
	private BigDecimal lldProfee;

	@Column(name = "LLD_PROJECTCOST")
	private BigDecimal lldProjectcost;

	@Column(name = "LLD_PURPOSEOFLOAN")
	private String lldPurposeofloan;

	@JsonSerialize(as = Date.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
	@Temporal(TemporalType.DATE)
	@Column(name = "LLD_RECEIVEDATE")
	private Date lldReceivedate;

	@Column(name = "LLD_RECMDAMT")
	private BigDecimal lldRecmdamt;

	@Column(name = "LLD_REPAYCAPACITY")
	private BigDecimal lldRepaycapacity;

	@Column(name = "LLD_REPAYMENTTYPE")
	private String lldRepaymenttype;

	@Column(name = "LLD_REQTERMS")
	private BigDecimal lldReqterms;

	@Column(name = "LLD_STEPTYPE")
	private String lldSteptype;

	@Column(name = "LLD_TERMRANGE")
	private String lldTermrange;

	@Column(name = "LLD_TERMS")
	private BigDecimal lldTerms;

	@Column(name = "LLD_TRADEIN")
	private BigDecimal lldTradein;

	@Column(name = "LLD_REC_FLAG")
	private String lldRecflag;

	@Column(name = "LLD_PERIODINSTALLMENT")
	private String lldPeriodinstallment;

	@Column(name = "LLD_INT_SCR_OBTAINED")
	private Long lldIntScrObtained;

	@Column(name = "LLD_INT_RATE_DESC")
	private String lldIntRateDesc;

	@Column(name="LLD_INPRINC_FLAG")
	private String lldInprincFlag;
	
	@Column(name="LLD_INT_CUTOFFSCORE")
	private Long lldIntCutoffscore;

	public Long getLldIntCutoffscore() {
		return lldIntCutoffscore;
	}

	public void setLldIntCutoffscore(Long lldIntCutoffscore) {
		this.lldIntCutoffscore = lldIntCutoffscore;
	}

	public Long getLldIntScrObtained() {
		return lldIntScrObtained;
	}

	public void setLldIntScrObtained(Long lldIntScrObtained) {
		this.lldIntScrObtained = lldIntScrObtained;
	}

	public String getLldIntRateDesc() {
		return lldIntRateDesc;
	}

	public void setLldIntRateDesc(String lldIntRateDesc) {
		this.lldIntRateDesc = lldIntRateDesc;
	}

	public BigDecimal getLldAmtreqd() {
		return this.lldAmtreqd;
	}

	public void setLldAmtreqd(BigDecimal lldAmtreqd) {
		this.lldAmtreqd = lldAmtreqd;
	}

	public String getLldPeriodinstallment() {
		return lldPeriodinstallment;
	}

	public void setLldPeriodinstallment(String lldPeriodinstallment) {
		this.lldPeriodinstallment = lldPeriodinstallment;
	}

	public BigDecimal getLldAppamt() {
		return this.lldAppamt;
	}

	public void setLldAppamt(BigDecimal lldAppamt) {
		this.lldAppamt = lldAppamt;
	}

	public String getLldBankRefno() {
		return this.lldBankRefno;
	}

	public void setLldBankRefno(String lldBankRefno) {
		this.lldBankRefno = lldBankRefno;
	}

	public BigDecimal getLldCbsacctno() {
		return this.lldCbsacctno;
	}

	public void setLldCbsacctno(BigDecimal lldCbsacctno) {
		this.lldCbsacctno = lldCbsacctno;
	}

	public String getLldCreatedBy() {
		return this.lldCreatedBy;
	}

	public void setLldCreatedBy(String lldCreatedBy) {
		this.lldCreatedBy = lldCreatedBy;
	}

	public Date getLldCreatedOn() {
		return this.lldCreatedOn;
	}

	public void setLldCreatedOn(Date lldCreatedOn) {
		this.lldCreatedOn = lldCreatedOn;
	}

	public BigDecimal getLldDeviationloanamount() {
		return this.lldDeviationloanamount;
	}

	public void setLldDeviationloanamount(BigDecimal lldDeviationloanamount) {
		this.lldDeviationloanamount = lldDeviationloanamount;
	}

	public BigDecimal getLldDocfee() {
		return this.lldDocfee;
	}

	public void setLldDocfee(BigDecimal lldDocfee) {
		this.lldDocfee = lldDocfee;
	}

	public BigDecimal getLldDownpay() {
		return this.lldDownpay;
	}

	public void setLldDownpay(BigDecimal lldDownpay) {
		this.lldDownpay = lldDownpay;
	}

	public BigDecimal getLldEmi() {
		return this.lldEmi;
	}

	public void setLldEmi(BigDecimal lldEmi) {
		this.lldEmi = lldEmi;
	}

	public Date getLldFiledon() {
		return this.lldFiledon;
	}

	public void setLldFiledon(Date lldFiledon) {
		this.lldFiledon = lldFiledon;
	}

	public String getLldFileno() {
		return this.lldFileno;
	}

	public void setLldFileno(String lldFileno) {
		this.lldFileno = lldFileno;
	}

	public BigDecimal getLldFurmargin() {
		return this.lldFurmargin;
	}

	public void setLldFurmargin(BigDecimal lldFurmargin) {
		this.lldFurmargin = lldFurmargin;
	}

	public Long getLldId() {
		return this.lldId;
	}

	public void setLldId(Long lldId) {
		this.lldId = lldId;
	}

	public String getLldInterestcharged() {
		return this.lldInterestcharged;
	}

	public void setLldInterestcharged(String lldInterestcharged) {
		this.lldInterestcharged = lldInterestcharged;
	}

	public BigDecimal getLldIntrate() {
		return this.lldIntrate;
	}

	public void setLldIntrate(BigDecimal lldIntrate) {
		this.lldIntrate = lldIntrate;
	}

	public String getLldInttype() {
		return this.lldInttype;
	}

	public void setLldInttype(String lldInttype) {
		this.lldInttype = lldInttype;
	}

	public BigDecimal getLldLoantrade() {
		return this.lldLoantrade;
	}

	public void setLldLoantrade(BigDecimal lldLoantrade) {
		this.lldLoantrade = lldLoantrade;
	}

	public String getLldLoantype() {
		return this.lldLoantype;
	}

	public void setLldLoantype(String lldLoantype) {
		this.lldLoantype = lldLoantype;
	}

	public BigDecimal getLldMargin() {
		return this.lldMargin;
	}

	public void setLldMargin(BigDecimal lldMargin) {
		this.lldMargin = lldMargin;
	}

	public String getLldMargindesc() {
		return this.lldMargindesc;
	}

	public void setLldMargindesc(String lldMargindesc) {
		this.lldMargindesc = lldMargindesc;
	}

	public String getLldModifiedBy() {
		return this.lldModifiedBy;
	}

	public void setLldModifiedBy(String lldModifiedBy) {
		this.lldModifiedBy = lldModifiedBy;
	}

	public Date getLldModifiedOn() {
		return this.lldModifiedOn;
	}

	public void setLldModifiedOn(Date lldModifiedOn) {
		this.lldModifiedOn = lldModifiedOn;
	}

	public BigDecimal getLldModintrate() {
		return this.lldModintrate;
	}

	public void setLldModintrate(BigDecimal lldModintrate) {
		this.lldModintrate = lldModintrate;
	}

	public String getLldModusrid() {
		return this.lldModusrid;
	}

	public void setLldModusrid(String lldModusrid) {
		this.lldModusrid = lldModusrid;
	}

	public BigDecimal getLldMoratorium() {
		return this.lldMoratorium;
	}

	public void setLldMoratorium(BigDecimal lldMoratorium) {
		this.lldMoratorium = lldMoratorium;
	}

	public Long getLldPrdcode() {
		return this.lldPrdcode;
	}

	public void setLldPrdcode(Long lldPrdcode) {
		this.lldPrdcode = lldPrdcode;
	}

	public BigDecimal getLldProfee() {
		return this.lldProfee;
	}

	public void setLldProfee(BigDecimal lldProfee) {
		this.lldProfee = lldProfee;
	}

	public BigDecimal getLldProjectcost() {
		return this.lldProjectcost;
	}

	public void setLldProjectcost(BigDecimal lldProjectcost) {
		this.lldProjectcost = lldProjectcost;
	}

	public String getLldPurposeofloan() {
		return this.lldPurposeofloan;
	}

	public void setLldPurposeofloan(String lldPurposeofloan) {
		this.lldPurposeofloan = lldPurposeofloan;
	}

	public Date getLldReceivedate() {
		return this.lldReceivedate;
	}

	public void setLldReceivedate(Date lldReceivedate) {
		this.lldReceivedate = lldReceivedate;
	}

	public BigDecimal getLldRecmdamt() {
		return this.lldRecmdamt;
	}

	public void setLldRecmdamt(BigDecimal lldRecmdamt) {
		this.lldRecmdamt = lldRecmdamt;
	}

	public BigDecimal getLldRepaycapacity() {
		return this.lldRepaycapacity;
	}

	public void setLldRepaycapacity(BigDecimal lldRepaycapacity) {
		this.lldRepaycapacity = lldRepaycapacity;
	}

	public String getLldRepaymenttype() {
		return this.lldRepaymenttype;
	}

	public void setLldRepaymenttype(String lldRepaymenttype) {
		this.lldRepaymenttype = lldRepaymenttype;
	}

	public BigDecimal getLldReqterms() {
		return this.lldReqterms;
	}

	public void setLldReqterms(BigDecimal lldReqterms) {
		this.lldReqterms = lldReqterms;
	}

	public String getLldSteptype() {
		return this.lldSteptype;
	}

	public void setLldSteptype(String lldSteptype) {
		this.lldSteptype = lldSteptype;
	}

	public String getLldTermrange() {
		return this.lldTermrange;
	}

	public void setLldTermrange(String lldTermrange) {
		this.lldTermrange = lldTermrange;
	}

	public BigDecimal getLldTerms() {
		return this.lldTerms;
	}

	public void setLldTerms(BigDecimal lldTerms) {
		this.lldTerms = lldTerms;
	}

	public BigDecimal getLldTradein() {
		return this.lldTradein;
	}

	public void setLldTradein(BigDecimal lldTradein) {
		this.lldTradein = lldTradein;
	}

	public String getLldRecflag() {
		return lldRecflag;
	}

	public void setLldRecflag(String lldRecflag) {
		this.lldRecflag = lldRecflag;
	}

	public long getLldSno() {
		return lldSno;
	}

	public void setLldSno(long lldSno) {
		this.lldSno = lldSno;
	}

	public LpcomProposal getLpcomProposal() {
		return lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}
	
	public String getLldInprincFlag() {
		return this.lldInprincFlag;
	}

	public void setLldInprincFlag(String lldInprincFlag) {
		this.lldInprincFlag = lldInprincFlag;
	}

	@Override
	public String toString() {
		return "LpcustLoanDetail [lldSno=" + lldSno + ", lldAmtreqd=" + lldAmtreqd + ", lldAppamt=" + lldAppamt + ", lldBankRefno=" + lldBankRefno + ", lldCbsacctno=" + lldCbsacctno + ", lldCreatedBy=" + lldCreatedBy + ", lldCreatedOn=" + lldCreatedOn + ", lldDeviationloanamount="
				+ lldDeviationloanamount + ", lldDocfee=" + lldDocfee + ", lldDownpay=" + lldDownpay + ", lldEmi=" + lldEmi + ", lldFiledon=" + lldFiledon + ", lldFileno=" + lldFileno + ", lldFurmargin=" + lldFurmargin + ", lldId=" + lldId + ", lldInterestcharged=" + lldInterestcharged
				+ ", lldIntrate=" + lldIntrate + ", lldInttype=" + lldInttype + ", lldLoantrade=" + lldLoantrade + ", lldLoantype=" + lldLoantype + ", lldMargin=" + lldMargin + ", lldMargindesc=" + lldMargindesc + ", lldModifiedBy=" + lldModifiedBy + ", lldModifiedOn=" + lldModifiedOn
				+ ", lldModintrate=" + lldModintrate + ", lldModusrid=" + lldModusrid + ", lldMoratorium=" + lldMoratorium + ", lldPrdcode=" + lldPrdcode + ", lldProfee=" + lldProfee + ", lldProjectcost=" + lldProjectcost + ", lldPurposeofloan=" + lldPurposeofloan + ", lldReceivedate="
				+ lldReceivedate + ", lldRecmdamt=" + lldRecmdamt + ", lldRepaycapacity=" + lldRepaycapacity + ", lldRepaymenttype=" + lldRepaymenttype + ", lldReqterms=" + lldReqterms + ", lldSteptype=" + lldSteptype + ", lldTermrange=" + lldTermrange + ", lldTerms=" + lldTerms + ", lldTradein="
				+ lldTradein + ",lldPeriodinstallment=" + lldPeriodinstallment + "]";
	}

}