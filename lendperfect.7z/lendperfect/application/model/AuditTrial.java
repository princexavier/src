package com.sai.lendperfect.application.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the AUDIT_TRIAL database table.
 * 
 */
@Entity
@Table(name="AUDIT_TRIAL")
@NamedQuery(name="AuditTrial.findAll", query="SELECT a FROM AuditTrial a")
public class AuditTrial implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="AUDIT_ROWID")
	private long rowId;
	
	@Column(name="ACTION_DATA")
	private String actionData;

	@Temporal(TemporalType.DATE)
	@Column(name="ACTION_DATE")
	private Date actionDate;

	@Column(name="ACTION_LABELNAMES")
	private String actionLabelnames;

	@Lob
	@Column(name="ACTION_NEWDATA")
	private String actionNewdata;

	@Lob
	@Column(name="ACTION_OLDDATA")
	private String actionOlddata;

	@Column(name="ACTION_TYPE")
	private String actionType;

	@Column(name="CLIENT_IP_ADDR")
	private String clientIpAddr;

	@Column(name="KEY_ID")
	private String keyId;

	@Column(name="PAGE_ID")
	private BigDecimal pageId;

	@Column(name="USR_ID")
	private String usrId;

	public long getRowId() {
		return rowId;
	}

	public void setRowId(long rowId) {
		this.rowId = rowId;
	}

	public AuditTrial() {
	}

	public String getActionData() {
		return this.actionData;
	}

	public void setActionData(String actionData) {
		this.actionData = actionData;
	}

	public Date getActionDate() {
		return this.actionDate;
	}

	public void setActionDate(Date actionDate) {
		this.actionDate = actionDate;
	}

	public String getActionLabelnames() {
		return this.actionLabelnames;
	}

	public void setActionLabelnames(String actionLabelnames) {
		this.actionLabelnames = actionLabelnames;
	}

	public String getActionNewdata() {
		return this.actionNewdata;
	}

	public void setActionNewdata(String actionNewdata) {
		this.actionNewdata = actionNewdata;
	}

	public String getActionOlddata() {
		return this.actionOlddata;
	}

	public void setActionOlddata(String actionOlddata) {
		this.actionOlddata = actionOlddata;
	}

	public String getActionType() {
		return this.actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getClientIpAddr() {
		return this.clientIpAddr;
	}

	public void setClientIpAddr(String clientIpAddr) {
		this.clientIpAddr = clientIpAddr;
	}

	public String getKeyId() {
		return this.keyId;
	}

	public void setKeyId(String keyId) {
		this.keyId = keyId;
	}

	public BigDecimal getPageId() {
		return this.pageId;
	}

	public void setPageId(BigDecimal pageId) {
		this.pageId = pageId;
	}

	public String getUsrId() {
		return this.usrId;
	}

	public void setUsrId(String usrId) {
		this.usrId = usrId;
	}

}