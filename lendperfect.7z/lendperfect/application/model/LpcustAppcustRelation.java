package com.sai.lendperfect.application.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sai.lendperfect.commodel.LpcomProposal;

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "LPCUST_APPCUST_RELATION")
@NamedQuery(name = "LpcustAppcustRelation.findAll", query = "SELECT l FROM LpcustAppcustRelation l")
public class LpcustAppcustRelation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LAR_ID")
	private long larId;

	@Column(name = "LAR_CREATED_BY")
	private String larCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAR_CREATED_ON")
	private Date larCreatedOn;

	@Column(name = "LAR_INCLUDEINCOME")
	private String larIncludeincome;

	@Column(name = "LAR_MODIFIED_BY")
	private String larModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LAR_MODIFIED_ON")
	private Date larModifiedOn;

	@Column(name = "LAR_PULLFLAG")
	private String larPullflag;

	@Column(name = "LAR_RELATION")
	private String larRelation;

	@Column(name = "LAR_TYPE")
	private String larType;

	// bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "LAR_APPNO")
	private LpcomProposal lpcomProposal;

	// bi-directional many-to-one association to LpcustApplicantData
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "LAR_APPID")
	private LpcustApplicantData lpcustApplicantData;

	public LpcustAppcustRelation() {
	}

	public long getLarId() {
		return this.larId;
	}

	public void setLarId(long larId) {
		this.larId = larId;
	}

	public String getLarCreatedBy() {
		return this.larCreatedBy;
	}

	public void setLarCreatedBy(String larCreatedBy) {
		this.larCreatedBy = larCreatedBy;
	}

	public Date getLarCreatedOn() {
		return this.larCreatedOn;
	}

	public void setLarCreatedOn(Date larCreatedOn) {
		this.larCreatedOn = larCreatedOn;
	}

	public String getLarIncludeincome() {
		return this.larIncludeincome;
	}

	public void setLarIncludeincome(String larIncludeincome) {
		this.larIncludeincome = larIncludeincome;
	}

	public String getLarModifiedBy() {
		return this.larModifiedBy;
	}

	public void setLarModifiedBy(String larModifiedBy) {
		this.larModifiedBy = larModifiedBy;
	}

	public Date getLarModifiedOn() {
		return this.larModifiedOn;
	}

	public void setLarModifiedOn(Date larModifiedOn) {
		this.larModifiedOn = larModifiedOn;
	}

	public String getLarPullflag() {
		return this.larPullflag;
	}

	public void setLarPullflag(String larPullflag) {
		this.larPullflag = larPullflag;
	}

	public String getLarRelation() {
		return this.larRelation;
	}

	public void setLarRelation(String larRelation) {
		this.larRelation = larRelation;
	}

	public String getLarType() {
		return this.larType;
	}

	public void setLarType(String larType) {
		this.larType = larType;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpcustApplicantData getLpcustApplicantData() {
		return this.lpcustApplicantData;
	}

	public void setLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		this.lpcustApplicantData = lpcustApplicantData;
	}

	@Override
	public String toString() {
		return "LpcustAppcustRelation [larCreatedBy=" + larCreatedBy + ", larCreatedOn=" + larCreatedOn + ", larIncludeincome=" + larIncludeincome + ", larModifiedBy=" + larModifiedBy + ", larModifiedOn=" + larModifiedOn + ", larPullflag=" + larPullflag + ", larRelation=" + larRelation
				+ ", lpcomProposal=" + lpcomProposal + ", lpcustApplicantData=" + lpcustApplicantData + ", larType=" + larType + ", larId=" + larId + "]";
	}

}
