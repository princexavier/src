package com.sai.lendperfect.application.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sai.lendperfect.commodel.LpcomProposal;


@JsonIgnoreProperties(ignoreUnknown =true)
@Entity
@Table(name="LPCUST_EDU_COURSE_EXP")
@NamedQuery(name="LpcustApplicantEduCourseExp.findAll", query="SELECT l FROM LpcustApplicantEduCourseExp l")
public class LpcustApplicantEduCourseExp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LAEC_EDU_COURSE_ID")
	private long laecEduCourseId;

	@Column(name="LAEC_CREATEDBY")
	private String laecCreatedby;

	@Temporal(TemporalType.DATE)
	@Column(name="LAEC_CREATEDDATE")
	private Date laecCreateddate;

	@Column(name="LAEC_EDU_COMMENTS")
	private String laecEduComments;

	@Column(name="LAEC_EDU_TYPE")
	private String laecEduType;

	@Column(name="LAEC_EDU_YEAR1")
	private BigDecimal laecEduYear1;

	@Column(name="LAEC_EDU_YEAR2")
	private BigDecimal laecEduYear2;

	@Column(name="LAEC_EDU_YEAR3")
	private BigDecimal laecEduYear3;

	@Column(name="LAEC_EDU_YEAR4")
	private BigDecimal laecEduYear4;

	@Column(name="LAEC_EDU_YEAR5")
	private BigDecimal laecEduYear5;

	@Column(name="LAEC_EDU_YEAR6")
	private BigDecimal laecEduYear6;
	
	@Temporal(TemporalType.DATE)
	@Column(name="LAEC_MODIFIEDDATE")
	private Date laecModifieddate;


	@Column(name="LAEC_MODIFIEDDBY")
	private String laecModifieddby;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LAEC_EDU_APPNO")
	private LpcomProposal lpcomProposal;

	public LpcustApplicantEduCourseExp() {
	}

	public long getLaecEduCourseId() {
		return this.laecEduCourseId;
	}

	public void setLaecEduCourseId(long laecEduCourseId) {
		this.laecEduCourseId = laecEduCourseId;
	}

	public String getLaecCreatedby() {
		return this.laecCreatedby;
	}

	public void setLaecCreatedby(String laecCreatedby) {
		this.laecCreatedby = laecCreatedby;
	}





	public String getLaecEduComments() {
		return this.laecEduComments;
	}

	public void setLaecEduComments(String laecEduComments) {
		this.laecEduComments = laecEduComments;
	}

	public String getLaecEduType() {
		return this.laecEduType;
	}

	public void setLaecEduType(String laecEduType) {
		this.laecEduType = laecEduType;
	}

	public BigDecimal getLaecEduYear1() {
		return this.laecEduYear1;
	}

	public void setLaecEduYear1(BigDecimal laecEduYear1) {
		this.laecEduYear1 = laecEduYear1;
	}

	public BigDecimal getLaecEduYear2() {
		return this.laecEduYear2;
	}

	public void setLaecEduYear2(BigDecimal laecEduYear2) {
		this.laecEduYear2 = laecEduYear2;
	}

	public BigDecimal getLaecEduYear3() {
		return this.laecEduYear3;
	}

	public void setLaecEduYear3(BigDecimal laecEduYear3) {
		this.laecEduYear3 = laecEduYear3;
	}

	public BigDecimal getLaecEduYear4() {
		return this.laecEduYear4;
	}

	public void setLaecEduYear4(BigDecimal laecEduYear4) {
		this.laecEduYear4 = laecEduYear4;
	}

	public BigDecimal getLaecEduYear5() {
		return this.laecEduYear5;
	}

	public void setLaecEduYear5(BigDecimal laecEduYear5) {
		this.laecEduYear5 = laecEduYear5;
	}

	public BigDecimal getLaecEduYear6() {
		return this.laecEduYear6;
	}

	public void setLaecEduYear6(BigDecimal laecEduYear6) {
		this.laecEduYear6 = laecEduYear6;
	}


	public String getLaecModifieddby() {
		return this.laecModifieddby;
	}

	public void setLaecModifieddby(String laecModifieddby) {
		this.laecModifieddby = laecModifieddby;
	}

	public Date getLaecCreateddate() {
		return laecCreateddate;
	}

	public void setLaecCreateddate(Date laecCreateddate) {
		this.laecCreateddate = laecCreateddate;
	}

	public Date getLaecModifieddate() {
		return laecModifieddate;
	}

	public void setLaecModifieddate(Date laecModifieddate) {
		this.laecModifieddate = laecModifieddate;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}