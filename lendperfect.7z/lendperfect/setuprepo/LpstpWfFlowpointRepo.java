package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import com.sai.lendperfect.setupmodel.LpstpWfFlowpoint;
import org.springframework.stereotype.Repository;
@Repository
public interface LpstpWfFlowpointRepo  extends JpaRepository<LpstpWfFlowpoint, BigDecimal>{
	
	List<LpstpWfFlowpoint> findAllByLwfFlowDepartmentOrderByLwfFlowId(String lwfFlowDepartment);
	List <LpstpWfFlowpoint> deleteAllByLwfFlowId(BigDecimal lwfFlowId);
	List<LpstpWfFlowpoint> findAllByOrderByLwfFlowId();
	LpstpWfFlowpoint findByLwfFlowId(BigDecimal lwfFlowpoint);
	LpstpWfFlowpoint findByLwfFlowIdAndLwfFlowDepartment(BigDecimal lwfFlowpoint, String lwfWfType);

}
