package com.sai.lendperfect.setuprepo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpScorecardMaster;
import com.sai.lendperfect.setupmodel.LpstpScorecardOptionMaster;

@Repository
public interface LpstpScorecardOptionMasterRepo extends JpaRepository<LpstpScorecardOptionMaster, Long> {

	List<LpstpScorecardOptionMaster> findByLpstpScorecardMaster(LpstpScorecardMaster lpstpScorecardMaster);

	List<LpstpScorecardOptionMaster> findByLpstpScorecardMasterAndScpmdelete(LpstpScorecardMaster lpstpScorecardMaster, String scpmDelete);

	List<LpstpScorecardOptionMaster> findByLpstpScorecardMasterAndScpmdeleteAndScpmOptionAvailable(LpstpScorecardMaster lpstpScorecardMaster, String scpmDelete, String scpmOptionAvailable);

	LpstpScorecardOptionMaster findByLpstpScorecardMasterAndScpmOptionValueAndScpmOptionAvailable(LpstpScorecardMaster lpstpScorecardMaster, String scpmOptionValue, String scpmOptionAvailable);
}
