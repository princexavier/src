package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.setupmodel.LpstpPrdProFee;

@Repository
public interface LpstpPrdProFeeRepo extends JpaRepository<LpstpPrdProFee,Long>{

	//List<LpstpPrdProFee> findByLpfProdIdOrderByLpfRowId(BigDecimal bigDecimal);

	List<LpstpPrdProFee> findByLpfProdIdOrderByLpfRowId(Long lpfProdId);

	
	

}
