package com.sai.lendperfect.setuprepo;


import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpUserAccess;
import com.sai.lendperfect.setupmodel.SetUserGroup;


@Repository
public interface SetUserGroupRepo extends JpaRepository<SetUserGroup, Long> {

	List<SetUserGroup> findBysugGrpVertical(String sugGrpVertical );
	List<SetUserGroup> findBysugGrpActive(String sugGrpActive );
	SetUserGroup findBySugGrpId(long sugGrpId);
	SetUserGroup findBySugGrpId(BigDecimal luaGroup);
	SetUserGroup findBySugGrpVerticalAndLugGrpDeptAndSugGrpName(String sugGrpVertical, String lugGrpDept, String sugGrpName);
	List<SetUserGroup> findBySugGrpVerticalAndLugGrpDept(String sugGrpVertical, String lugGrpDept);
	List<SetUserGroup> findBySugGrpVerticalAndLugGrpDeptAndSugGrpActive(String sugGrpVertical, String lugGrpDept,String sugGrpActive);
	List<SetUserGroup> findBySugGrpVerticalAndLugGrpDeptAndSugGrpId(String grpVertical, String lwfWfType, long grpId);
}
