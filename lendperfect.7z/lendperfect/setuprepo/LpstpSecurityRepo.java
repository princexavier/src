package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpSecurity;

@Repository
public interface LpstpSecurityRepo extends JpaRepository<LpstpSecurity, Long> {

	LpstpSecurity findBylsSecClassiId(long lsSecClassiId);

	LpstpSecurity findByLsSecDesc(String lsSecDesc);

	List<LpstpSecurity> findByLsParentId(BigDecimal lsParentId);

	LpstpSecurity findByLsSecClassiIdAndLsParentId(long lsSecClassiId, BigDecimal lsParentId);

	LpstpSecurity findBylsSecClassiIdAndLsActive(long lsSecClassiId, String lsActive);

}
