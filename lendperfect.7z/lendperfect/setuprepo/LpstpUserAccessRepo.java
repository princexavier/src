package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpUserAccess;

@Repository
public interface LpstpUserAccessRepo extends JpaRepository<LpstpUserAccess,Long>{
	
	List<LpstpUserAccess> findByLuaUserIdOrderByLuaSeqNo(String luaUserId);
	LpstpUserAccess findByluaUserIdAndLuaBizVertical(String luaUserId, BigDecimal luaBizVertical);
	LpstpUserAccess findByluaUserId(String luaUserId);
}
