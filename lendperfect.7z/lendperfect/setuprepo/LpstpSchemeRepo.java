package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import com.sai.lendperfect.setupmodel.LpstpScheme;
import org.springframework.stereotype.Repository;

@Repository

public interface LpstpSchemeRepo extends JpaRepository<LpstpScheme, Long>{
	
	List <LpstpScheme> findAllByLsSchemeName(String lsSchemeName);
	List<LpstpScheme> findAllDistinct();
	List <LpstpScheme> deleteAllByLsSchemeId(BigDecimal lsSchemeId);
	List<LpstpScheme> findAllByOrderByLsSchemeId();
	List<LpstpScheme> findAllByLsBizVerticalOrderByLsSchemeId(BigDecimal lsBizVertical);
	LpstpScheme findByLsSchemeId(BigDecimal lsSchemeId);
	List<LpstpScheme> findAllByLsBizVerticalAndLsActiveOrderByLsSchemeId(BigDecimal lsBizVertical,String lsActive);
	LpstpScheme findByLsSchemeId(Long lsSchemeId);
	LpstpScheme findByLsSubFacility(Long lsSubFacility);
}
