package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpAnnexMaster;

@Repository
public interface LpstpAnnexMasterRepo extends JpaRepository<LpstpAnnexMaster, BigDecimal> {
	List<LpstpAnnexMaster> findByLamParentIdOrderByLamRowId(BigDecimal lamParentId);

	List<LpstpAnnexMaster> findByLamAnnexTypeAndLamParentIdOrderByLamRowId(String lamAnnexType, BigDecimal lamParentId);

	List<LpstpAnnexMaster> findByLamAnnexType(String annxType);

	List<LpstpAnnexMaster> findByLamRowIdIn(List<BigDecimal> lamRowIdList);

	List<LpstpAnnexMaster> findByLamActiveAndLamParentIdIn(String lamActive, List<BigDecimal> lamParentIdList);
}
