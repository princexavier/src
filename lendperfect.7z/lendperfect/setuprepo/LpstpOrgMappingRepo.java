package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpOrgMapping;
import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setupmodel.SetOrganisation;

@Repository
public interface LpstpOrgMappingRepo extends JpaRepository<LpstpOrgMapping, BigDecimal>  {
	List<LpstpOrgMapping> findByLomOrgParent(BigDecimal lomOrgParent);
	List<LpstpOrgMapping> findByLpstpOrganisation(LpstpOrganisation lpstpOrganisation);
	List<LpstpOrgMapping> findByLomBizVerticalAndLomDepartment(String lomBizVertical, String lomDepartment);
	LpstpOrgMapping findByLomBizVerticalAndLomDepartmentAndLpstpOrganisation(String bizVertical, String dept,
			LpstpOrganisation setOrganisation);
}
