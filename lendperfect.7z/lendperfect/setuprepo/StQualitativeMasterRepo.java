package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.StQualitativeMaster;

@Repository
public interface StQualitativeMasterRepo extends JpaRepository<StQualitativeMaster,Long> {

	StQualitativeMaster findBysqmRowId(long id);

	List<StQualitativeMaster> findBysqmActive(String flag);

	List<StQualitativeMaster> findBySqmBizVerticalAndSqmCommentFor(String sqmBizVertical, String sqmCommentFor);
	
	List<StQualitativeMaster> findBySqmBizVerticalAndSqmCommentForAndSqmActive(String sqmBizVertical, String sqmCommentFor,String sqmActive);

}
