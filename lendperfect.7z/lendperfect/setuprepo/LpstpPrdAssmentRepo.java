package com.sai.lendperfect.setuprepo;


import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.setupmodel .LpstpPrdAssment;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository

public interface LpstpPrdAssmentRepo extends JpaRepository<LpstpPrdAssment, BigDecimal>{
	
	List<LpstpPrdAssment> findAllByLpaProdId(BigDecimal lpaProdId);
	List <LpstpPrdAssment> deleteAllByLpaProdId(BigDecimal lpaProdId);
	List <LpstpPrdAssment> deleteAllByLpaProdIdAndLpaAssmntId(BigDecimal lpaProdId,BigDecimal lpaAssmntId);
	//List<LpstpPrdAssment> findByLpaProdIdAndLpaAssmntType(BigDecimal lpaProdId, char lpaAssmntType);
	List<LpstpPrdAssment> findByLpaProdIdAndLpaAssmntTypeLike(BigDecimal lpaProdId, String lpaAssmntType);
}
