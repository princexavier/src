package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpFacility;


@Repository
public interface LpstpFacilityRepo  extends JpaRepository<LpstpFacility,Long>{
	
	LpstpFacility findBylsfFacParentId(BigDecimal lsfFacParentId);
	LpstpFacility findBylsfFacId(long facId);
	List<LpstpFacility> findBylsfFacParentIdAndLsfFacActive(BigDecimal lsfFacParentId,String lsfFacActive);
	List<LpstpFacility>  findByLsfFacActive(String LsfFacActive);
	LpstpFacility findByLsfFacDesc(String lsfFacDesc);
}
