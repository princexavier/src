package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpComFinData;

@Repository
public interface LpComFinDataRepo extends JpaRepository<LpComFinData, Long> {
	List<BigDecimal> getFinRowIdByPropNumforData(@Param("lfdPropNo") BigDecimal lfdPropNo,	
			@Param("lfdCustNewId")BigDecimal lfdCustNewId,@Param("lfdCmaNo")BigDecimal lfdCmaNo );	
	List<LpComFinData>	getAllRowByPropNumforData(@Param("lfdPropNo")BigDecimal lfdPropNo ,
			@Param("lfdCustNewId")BigDecimal lfdCustNewId,@Param("lfdCmaNo")BigDecimal lfdCmaNo );
	@Query(nativeQuery=true)
	List<LpComFinData>  getAllRowByPropNumAndTabNameforData(@Param("lfdPropNo")BigDecimal lfdPropNo , @Param("finPage")String finPage , @Param("finTabname")String finTabname, 
															@Param("lfdCustNewId")BigDecimal lfdCustNewId,@Param("lfdCmaNo")BigDecimal lfdCmaNo);
//	List<LpstpFinData>  getAllRowFilterforData(@Param("lfdPropNo")BigDecimal lfdPropNo,@Param("finTabname")String finTabname );
	
	@Query(nativeQuery=true)
	List<BigDecimal>	getFinRowIdByPropNumAndCustomerIdAndFinRowType(@Param("lfdPropNo")BigDecimal lfdPropNo ,@Param("lfdCustNewId")BigDecimal lfdCustNewId ,
			@Param("finRowType")String finRowType,@Param("finTabname")String finTabname,@Param("lfdCmaNo")BigDecimal lfdCmaNo );
	
	@Modifying
	Integer updateyear1to5ByfinRowIdandProNum( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear1")BigDecimal lfdYear1 ,@Param("lfdYear2")BigDecimal lfdYear2 , @Param("lfdYear3")BigDecimal lfdYear3 , 
	@Param("lfdYear4")BigDecimal lfdYear4 , @Param("lfdYear5")BigDecimal lfdYear5 , @Param("lfdFinRowId")BigDecimal lfdFinRowId , @Param("lfdPropNo")BigDecimal lfdPropNo ,@Param("lfdCustNewId")BigDecimal lfdCustNewId);
			 
	@Modifying
	Integer updateyear6to10ByfinRowIdandProNum( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear6")BigDecimal lfdYear6 ,@Param("lfdYear7")BigDecimal lfdYear7 , @Param("lfdYear8")BigDecimal lfdYear8 , 
	@Param("lfdYear9")BigDecimal lfdYear9 , @Param("lfdYear10")BigDecimal lfdYear10 ,@Param("lfdFinRowId")BigDecimal lfdFinRowId , @Param("lfdPropNo")BigDecimal lfdPropNo,@Param("lfdCustNewId")BigDecimal lfdCustNewId );

	@Modifying
	Integer updateyear11to15ByfinRowIdandProNum( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear11")BigDecimal lfdYear11 ,@Param("lfdYear12")BigDecimal lfdYear12 , @Param("lfdYear13")BigDecimal lfdYear13 , 
			@Param("lfdYear14")BigDecimal lfdYear14 , @Param("lfdYear15")BigDecimal lfdYear15 , @Param("lfdFinRowId")BigDecimal lfdFinRowId , @Param("lfdPropNo")BigDecimal lfdPropNo,@Param("lfdCustNewId")BigDecimal lfdCustNewId );
	
	@Modifying
	Integer updateyear16to20ByfinRowIdandProNum( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear16")BigDecimal lfdYear16 ,@Param("lfdYear17")BigDecimal lfdYear17 , @Param("lfdYear18")BigDecimal lfdYear18 , 
			@Param("lfdYear19")BigDecimal lfdYear19 , @Param("lfdYear20")BigDecimal lfdYear20 , @Param("lfdFinRowId")BigDecimal lfdFinRowId , @Param("lfdPropNo")BigDecimal lfdPropNo,@Param("lfdCustNewId")BigDecimal lfdCustNewId );
	@Modifying
	Integer updateyear21to25ByfinRowIdandProNum( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear21")BigDecimal lfdYear21 ,@Param("lfdYear22")BigDecimal lfdYear22 , @Param("lfdYear23")BigDecimal lfdYear23 , 
			@Param("lfdYear24")BigDecimal lfdYear24 , @Param("lfdYear25")BigDecimal lfdYear25 , @Param("lfdFinRowId")BigDecimal lfdFinRowId , @Param("lfdPropNo")BigDecimal lfdPropNo ,
			@Param("lfdCustNewId")BigDecimal lfdCustNewId);

	@Modifying
	Integer updateyear26to30ByfinRowIdandProNum( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear26")BigDecimal lfdYear26 ,@Param("lfdYear27")BigDecimal lfdYear27 , @Param("lfdYear28")BigDecimal lfdYear28 , 
			@Param("lfdYear29")BigDecimal lfdYear29 , @Param("lfdYear30")BigDecimal lfdYear30 , @Param("lfdFinRowId")BigDecimal lfdFinRowId , @Param("lfdPropNo")BigDecimal lfdPropNo ,
			@Param("lfdCustNewId")BigDecimal lfdCustNewId);

	@Modifying
	Integer updateyear1to5ByLfdRowId( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear1")BigDecimal lfdYear1 ,@Param("lfdYear2")BigDecimal lfdYear2 , @Param("lfdYear3")BigDecimal lfdYear3 , 
			@Param("lfdYear4")BigDecimal lfdYear4 , @Param("lfdYear5")BigDecimal lfdYear5 , @Param("lfdRowId") long lfdRowId );
			 
	@Modifying
	Integer updateyear6to10ByLfdRowId( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear6")BigDecimal lfdYear6 ,@Param("lfdYear7")BigDecimal lfdYear7 , @Param("lfdYear8")BigDecimal lfdYear8 , 
			@Param("lfdYear9")BigDecimal lfdYear9 , @Param("lfdYear10")BigDecimal lfdYear10, @Param("lfdRowId") long lfdRowId );

	@Modifying
	Integer updateyear11to15ByLfdRowId( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear11")BigDecimal lfdYear11 ,@Param("lfdYear12")BigDecimal lfdYear12 , @Param("lfdYear13")BigDecimal lfdYear13 , 
			@Param("lfdYear14")BigDecimal lfdYear14 , @Param("lfdYear15")BigDecimal lfdYear15 , @Param("lfdRowId") long lfdRowId );
	
	@Modifying
	Integer updateyear16to20ByLfdRowId( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear16")BigDecimal lfdYear16 ,@Param("lfdYear17")BigDecimal lfdYear17 , @Param("lfdYear18")BigDecimal lfdYear18 , 
			@Param("lfdYear19")BigDecimal lfdYear19 , @Param("lfdYear20")BigDecimal lfdYear20 , @Param("lfdRowId") long lfdRowId );
	
	@Modifying
	Integer updateyear21to25ByLfdRowId( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear21")BigDecimal lfdYear21 ,@Param("lfdYear22")BigDecimal lfdYear22 , @Param("lfdYear23")BigDecimal lfdYear23 , 
			@Param("lfdYear24")BigDecimal lfdYear24 , @Param("lfdYear25")BigDecimal lfdYear25 , @Param("lfdRowId") long lfdRowId );

	@Modifying
	Integer updateyear26to30ByLfdRowId( @Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,@Param("lfdYear26")BigDecimal lfdYear26 ,@Param("lfdYear27")BigDecimal lfdYear27 , @Param("lfdYear28")BigDecimal lfdYear28 , 
			@Param("lfdYear29")BigDecimal lfdYear29 , @Param("lfdYear30")BigDecimal lfdYear30 , @Param("lfdRowId") long lfdRowId );
	
	List<LpComFinData>  findByLfdPropNoAndLfdFinRowIdIn(BigDecimal LfdPropNo, List<BigDecimal>lfdFinRowId);
	List<Object[]>	getDataRowIdandFormulaValueByListOfDataFinRowId(@Param("lfdPropNo")BigDecimal LfdPropNo,@Param("lfdCustNewId")BigDecimal lfdCustNewId ,  
			@Param("lfdFinRowId") List<BigDecimal>lfdFinRowId ,@Param("ldfCmaNo") BigDecimal ldfCmaNo );
	
	List<Object[]> getSumOfYearCloumnWise(@Param("lfdPropNo")BigDecimal lfdPropNo,@Param("lfdCustNewId")BigDecimal lfdCustNewId,@Param("lfdCmaNo") BigDecimal lfdCmaNo );
	
	@Modifying
	Integer  updateyearForCalculatedFieldByRowId(@Param("lfdModifiedBy")String lfdModifiedBy, @Param("lfdModifiedOn")Date lfdModifiedOn ,
			@Param("lfdYear1")BigDecimal lfdYear1 ,@Param("lfdYear2")BigDecimal lfdYear2 , @Param("lfdYear3")BigDecimal lfdYear3 , 
			@Param("lfdYear4")BigDecimal lfdYear4 , @Param("lfdYear5")BigDecimal lfdYear5 ,
			@Param("lfdYear6")BigDecimal lfdYear6 ,@Param("lfdYear7")BigDecimal lfdYear7 , @Param("lfdYear8")BigDecimal lfdYear8 , 
			@Param("lfdYear9")BigDecimal lfdYear9 , @Param("lfdYear10")BigDecimal lfdYear10 ,
			@Param("lfdYear11")BigDecimal lfdYear11 ,@Param("lfdYear12")BigDecimal lfdYear12 , @Param("lfdYear13")BigDecimal lfdYear13 , 
			@Param("lfdYear14")BigDecimal lfdYear14 , @Param("lfdYear15")BigDecimal lfdYear15 ,
			@Param("lfdYear16")BigDecimal lfdYear16 ,@Param("lfdYear17")BigDecimal lfdYear17 , @Param("lfdYear18")BigDecimal lfdYear18 , 
			@Param("lfdYear19")BigDecimal lfdYear19 , @Param("lfdYear20")BigDecimal lfdYear20 ,
			@Param("lfdYear21")BigDecimal lfdYear21 ,@Param("lfdYear22")BigDecimal lfdYear22 , @Param("lfdYear23")BigDecimal lfdYear23 , 
			@Param("lfdYear24")BigDecimal lfdYear24 , @Param("lfdYear25")BigDecimal lfdYear25 ,
			@Param("lfdYear26")BigDecimal lfdYear26 ,@Param("lfdYear27")BigDecimal lfdYear27 , @Param("lfdYear28")BigDecimal lfdYear28 , 
			@Param("lfdYear29")BigDecimal lfdYear29 , @Param("lfdYear30")BigDecimal lfdYear30 , @Param("lfdRowId") long lfdRowId);
//	List<BigDecimal> getFinRowIdByPropNumAndCustomerIdAndFinRowType(BigDecimal valueOf, BigDecimal valueOf2,
//			String rowType);
	
	@Query(value="select * from LPSTP_FINMASTER join LPCOM_FIN_DATA on FIN_ROW_ID=LFD_FIN_ROW_ID where FIN_PAGE=?1 and FIN_TABNAME=?2 and LFD_PROP_NO=?3 and LFD_CUST_NEW_ID=?4",nativeQuery=true)
	List<LpComFinData> getFinancialYear(String finPage, String finTabName, BigDecimal propNum, BigDecimal customerId);
	
	List<LpComFinData> findByLfdPropNoAndLfdCmaNoAndLfdCustNewId(BigDecimal bigDecimal, BigDecimal bigDecimal2,
			BigDecimal bigDecimal3);
	
	void deleteByLfdPropNoAndLfdCustNewIdAndLfdCmaNo(BigDecimal lfdPropNo,BigDecimal lfdCustNewId,BigDecimal lfdCmaNo);	
}
