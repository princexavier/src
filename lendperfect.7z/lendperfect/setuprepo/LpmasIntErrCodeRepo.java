package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.mastermodel.LpmasIntErrcode;
import com.sai.lendperfect.mastermodel.LpmasInterfaceLink;


@Repository
public interface LpmasIntErrCodeRepo extends JpaRepository<LpmasIntErrcode, BigDecimal> {
	
	List<LpmasIntErrcode> findByLpmasInterfaceLink(LpmasInterfaceLink  lpmasInterfaceLink);
	LpmasIntErrcode findByLieRowId(BigDecimal lieRowId);
	List<LpmasIntErrcode> findAllByOrderByLieRowId();
	List<LpmasIntErrcode> findByLpmasInterfaceLinkOrderByLieErrCode(LpmasInterfaceLink  lpmasInterfaceLink);
	LpmasIntErrcode findByLpmasInterfaceLinkAndLieErrCode(LpmasInterfaceLink  lpmasInterfaceLink,String lieErrCode);
	
}
