package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpPrdCoappguacount;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

@Repository
	public interface LpstpPrdCoappguacountRepo extends JpaRepository<LpstpPrdCoappguacount,Long>{

	List<LpstpPrdCoappguacount> findByLrcProdIdOrderByLrcRowId(Long prdId);

//		List<LpstpPrdCoappguacount> findByLpstpProductDet(LpstpProductDet lpstpProductDet);
		
//		List<LpstpPrdCoappguacount> findByLpstpProductDetOrderByLrcRowId(LpstpProductDet lpstpProductDet);
		
	@Query(value="select * from LPSTP_PRD_COAPPGUACOUNT where LRC_PROD_ID=?1 and ?2 between LRC_AMT_FROM and LRC_AMT_TO",nativeQuery=true)
	LpstpPrdCoappguacount findByRow(BigDecimal lrcProdId,BigDecimal amount);
		

	}


