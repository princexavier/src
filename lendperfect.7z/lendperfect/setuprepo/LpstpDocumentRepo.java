package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import com.sai.lendperfect.setupmodel.LpstpDocument;
import org.springframework.stereotype.Repository;

@Repository
public interface LpstpDocumentRepo  extends JpaRepository<LpstpDocument, BigDecimal>{
	
	List <LpstpDocument> findAllByLdDocDesc(String ldDocDesc);
	List <LpstpDocument> findDistinctByLdDocDescNotIn(String ldDocDesc);
	List<LpstpDocument> findAllDistinct();
	List <LpstpDocument> findAllByLdDocDescIgnoreCaseContainingAndLdDocType(String ldDocDesc,String ldDocType);
	List<LpstpDocument> findAllByLdDocActive(String ldDocActive);
	List<LpstpDocument> findAllByldDocType(String ldDocType);
	List<LpstpDocument> findAllByLdDocTypeAndLdDocActive(String ldDocType,String ldDocActive );
	List<LpstpDocument> findAllByLdDocId(BigDecimal ldDocId);
}
