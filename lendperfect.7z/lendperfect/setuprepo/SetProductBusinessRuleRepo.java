package com.sai.lendperfect.setuprepo;
/*package com.sai.lendperfect.repo.master;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.model.SetPrdBusiRuleVersion;
import com.sai.lendperfect.model.SetProductBusinessRule;

@Repository
public interface SetProductBusinessRuleRepo extends JpaRepository<SetProductBusinessRule,Long>{
	
	

}
*/