package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.NamedQuery;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpUser;

@Repository
public interface LpstpUserRepo extends JpaRepository<LpstpUser, Long> {
	
	//public List<LpstpUser> findBysuRowId(long suRowId ) ;
	//public List<LpstpUser> findBysuRowId(String suRowId ) ;
	public LpstpUser findBysuRowId(String suRowId );
	public LpstpUser findBySuempid(String suempid );
	public List<LpstpUser> findBysuAvailable(String suAvailable); 
	/*Long countBysuRowIdGreaterThan (String suRowId);*/
	
	//suClassLevel,suDelegation, suGroup,suReportingTo,suUserFunction,suVerticalAccess |||suSupervisor== suSupervisorUsr "
	
	@Modifying
	public Integer updateWithoutPassword(@Param("suempid") String suempid,
			@Param("suFirstName")String suFirstName,@Param("suLastName")String suLastName,@Param("suUserAdId")String suUserAdId,@Param("suDesignation")String suDesignation,
			@Param("luaUserDept") String luaUserDept,@Param("suLocation") BigDecimal suLocation,
			@Param("suAvailable") String suAvailable,@Param("suResignedOn") Date suResignedOn,@Param("suEmailId") String suEmailId,
			@Param("suEmailNotify") String suEmailNotify,@Param("suMobNo") String suMobNo,@Param("suMobNotify") String suMobNotify,@Param("suSupervisorUsr") String suSupervisorUsr,
			@Param("suEmpType") String suEmpType,
			@Param("suRowId")String suRowId
					);
	
/*	public Integer updateWithoutPassword(@Param("suAvailable") String suAvailable,@Param("suClassLevel")String suClassLevel,
										@Param("suRowId")long suRowId);*/
	
	public List<LpstpUser> findBysuSupervisorUsr(String suSupervisorUsr); 
	
	@Query("select DISTINCT m.suSupervisorUsr from LpstpUser m")
	List<LpstpUser> findAllOrderBySuRowId();
List<LpstpUser> findBySuFirstNameIgnoreCaseContaining(String searchval);
List<LpstpUser> findBySuSupervisorUsrAndSuFirstNameIgnoreCaseContaining(String suSupervisorUsr,String searchval);

public LpstpUser findBySuSupervisorUsrAndSuRowIdIgnoreCase(String suSupervisorUsr,String suRowId);


List<LpstpUser> findBysuLocation(BigDecimal groupId);


//public Integer updateWithoutPassword(@Param("suRowId")String suRowId,@Param("suAvailable") String suAvailable,
//@Param("suDesignation")String suDesignation,@Param("suEmailId")String suEmailId,@Param("suEmailNotify")String suEmailNotify,@Param("suFirstName")String suFirstName,
//@Param("suLastName") String suLastName,@Param("suLocation") BigDecimal suLocation,
//@Param("suSupervisorUsr") String suSupervisorUsr,
//
//
}
