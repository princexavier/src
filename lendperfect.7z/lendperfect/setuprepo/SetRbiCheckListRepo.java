/*
package com.sai.lendperfect.setuprepo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.SetRbiCheckList;


@Repository
public interface SetRbiCheckListRepo extends JpaRepository<SetRbiCheckList,Long> {
	   
	   public List<SetRbiCheckList> getListByBVandIsDeleteOrNull(@Param("srcBizVertical")long srcBizVertical,@Param("valueOf")String srcIsDelete);
   public List<SetRbiCheckList> getListByIsDeleteOrNull(@Param("valueOf")String srcIsDelete);
}


*/