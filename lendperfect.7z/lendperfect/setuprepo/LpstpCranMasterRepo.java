package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpAnnexMaster;
import com.sai.lendperfect.setupmodel.LpstpCranMaster;

@Repository
public interface LpstpCranMasterRepo extends JpaRepository<LpstpCranMaster, BigDecimal> {

	List<LpstpCranMaster> findByLcmVerticalAndLcmCranId(BigDecimal verticalName,BigDecimal CranId);
	@Query(value ="select lcm_cran_id,LCM_CRAN_TITLE,sum(lcm_cran_id) from LPSTP_CRAN_MASTER "
			+ "cranmaster where lcm_vertical=?1 group by lcm_cran_id,LCM_CRAN_TITLE",nativeQuery=true)	
	List<Object[]> getCranTitleList(BigDecimal verticalName);
	
	@Query(value ="select NVL(MAX(lcm_cran_id), 0) +1 as cranid from LPSTP_CRAN_MASTER",nativeQuery=true)	
	BigDecimal getMaxCranId();
	
	List<LpstpCranMaster> findByLcmCranIdOrderByLcmTempSeq(BigDecimal lsCranId);

	List<Object[]> getDistinctCranIdandTitle();
	
}
