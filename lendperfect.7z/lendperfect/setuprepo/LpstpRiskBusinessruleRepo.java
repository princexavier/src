package com.sai.lendperfect.setuprepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.setupmodel.LpstpRiskBusinessrule;

public interface LpstpRiskBusinessruleRepo extends JpaRepository<LpstpRiskBusinessrule,Long> {
	
}
