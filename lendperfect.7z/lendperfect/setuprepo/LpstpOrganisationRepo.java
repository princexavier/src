package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.setupmodel.LpstpOrganisation;

public interface LpstpOrganisationRepo  extends JpaRepository<LpstpOrganisation,Long>{
	LpstpOrganisation findByLoOrgId(long loOrgId);
	LpstpOrganisation findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndLoOrgId(String loOrgBizVertical, String loOrgDepartment, String loOrgLevel, long loOrgId);
	List<LpstpOrganisation> findByLoOrgLevelOrderByLoName(String loOrgLevel);
	List<LpstpOrganisation> findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(String loOrgBizVertical, String loOrgDepartment, String loOrgLevel);
	LpstpOrganisation findByLoOrgLevel(String loOrgLevel);
	LpstpOrganisation findByLoName(String loName);

}
