package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpDelegatedPower;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.SetUserGroup;

@Repository
public interface LpstpDelegatedPowersRepo extends JpaRepository<LpstpDelegatedPower, Long> {	
	List<LpstpDelegatedPower> findByLpstpProductDet(LpstpProductDet lpstpProductDet);
	LpstpDelegatedPower findByLpstpProductDetAndSetUserGroup(LpstpProductDet lpstpProductDet,SetUserGroup setUserGroup);
}
