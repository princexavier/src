package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpUserClass;

@Repository
public interface LpstpUserClassRepo extends JpaRepository< LpstpUserClass, Long> {

List<LpstpUserClass> findByLucDepartmentOrderByLucClassCode(String lucDepartment);
List<LpstpUserClass> findByLucDepartmentAndLucActive(String lucDepartment, String lucActive);
List<LpstpUserClass> findByLucDepartmentAndLucActiveOrderByLucClassCode(String lucDepartment, String lucActive);
LpstpUserClass findBylucClassCode(BigDecimal lucClassCode);
}
