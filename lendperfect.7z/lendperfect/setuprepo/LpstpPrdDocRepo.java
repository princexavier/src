package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.setupmodel.LpstpPrdDoc;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface LpstpPrdDocRepo extends JpaRepository<LpstpPrdDoc, BigDecimal> {
	
	List<LpstpPrdDoc> findAllByLpdProdId(BigDecimal lpdProdId);
	List <LpstpPrdDoc> deleteAllByLpdProdId(BigDecimal lpdProdId);
	List <LpstpPrdDoc> deleteAllByLpdProdIdAndLpdDocId(BigDecimal lpdProdId,String lpdDocId);
	List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocId(BigDecimal lpdProdId,BigDecimal lpdDocId);
	List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocType(BigDecimal lpdProdId,String lpdDocType);
	List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocTypeAndLpdDocFor(BigDecimal lpdProdId,String lpdDocType,String lpdDocFor);
	List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocFor(BigDecimal bigDecimal, String string);
	List<LpstpPrdDoc> findAllByLpdDocType(String lpdDocType);
}
