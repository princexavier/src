package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.setupmodel.LpstpPrdRepayCapacity;

@Repository
public interface LpstpPrdRepayCapacityRepo extends JpaRepository<LpstpPrdRepayCapacity,Long>{


	List<LpstpPrdRepayCapacity> findByLrcProdIdOrderByLrcRowId(Long lrcProdId);
	
	@Query(value="SELECT lrcSalRepayCapa FROM LpstpPrdRepayCapacity WHERE lrcProdId=?1 AND ?2 BETWEEN lrcIncFrom AND lrcIncTo")
	String findRepayCapacityPerc(long prdCode,BigDecimal finalNetIncome);

	
	

}
