package com.sai.lendperfect.setuprepo;
/*package com.sai.lendperfect.repo.master;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.model.SetPrdBusiRuleVersion;

@Repository
public interface SetPrdBusiRuleVersionRepo extends JpaRepository<SetPrdBusiRuleVersion,Long>{
	
	

}
*/