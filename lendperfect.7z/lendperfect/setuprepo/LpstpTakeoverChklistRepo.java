package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.setupmodel.LpstpTakeoverChklist;

public interface LpstpTakeoverChklistRepo extends JpaRepository<LpstpTakeoverChklist,Long> {

	LpstpTakeoverChklist findByltcRowId(BigDecimal ltcRowId);

List<LpstpTakeoverChklist> findByltcBizVertical(String ltcBizVertical);

}
