package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.setupmodel.LpstpBulletInfo;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;

@Repository
public interface LpstpBulletInfoRepo extends JpaRepository<LpstpBulletInfo,Long>{

	
	List<LpstpBulletInfo> findByLbiShowUptoAfter(Date lbishowuptodate);


}
