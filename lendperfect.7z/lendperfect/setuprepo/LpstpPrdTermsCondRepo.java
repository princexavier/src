package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.setupmodel.LpstpPrdTermsCond;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository

public interface LpstpPrdTermsCondRepo extends JpaRepository<LpstpPrdTermsCond, BigDecimal> {

	List<LpstpPrdTermsCond> findAllByLptcProdId(BigDecimal lptcProdId);
	List <LpstpPrdTermsCond> deleteAllByLptcProdId(BigDecimal lptcProdId);
	List <LpstpPrdTermsCond> deleteAllByLptcProdIdAndLptcTermsId(BigDecimal lptcProdId,BigDecimal lptcTermsId);
	List<LpstpPrdTermsCond> findAllByLptcProdIdAndLptcTermsId(BigDecimal lptcProdId,BigDecimal lptcTermsId);
	List<LpstpPrdTermsCond> findAllByLptcProdIdAndLptcTermsFor(BigDecimal lptcProdId,String lptcTermsFor);

	
}
