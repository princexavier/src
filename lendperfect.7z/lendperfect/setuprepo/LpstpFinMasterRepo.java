package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpFinMaster;

@Repository
public interface LpstpFinMasterRepo extends JpaRepository<LpstpFinMaster,Long> {


	 public List<LpstpFinMaster> findByfinRowid(long finRowid );
	 public List<LpstpFinMaster> findAllFinMasterByfinCmaNo(@Param("cmaNum") BigDecimal  cmaNum);
	 
	 public List<LpstpFinMaster> findByfinPage(String finPage);
	 public List<LpstpFinMaster> findByFinPageAndFinRowtypeIn(String finPage,List<String> finRowType);

	// public List<SetFinMaster> findByfinPageAndFinTabnameOrderByFinRowidFinSnoAsc(String finPage,String finTabname);
	 public List<LpstpFinMaster> getAlldataByListOfRowId(@Param("finRowid") List<Long>  finRowid);
	 public List<LpstpFinMaster> getDataByFinaTabandFinPage(@Param("finPage") String  finPage,@Param("finTabname") String  finTabname,@Param("finCmaNo") BigDecimal  finCmaNo);
	 public String[] 	 getDistinctTabName(@Param("finPage") String  finPage ,@Param("finCmaNo") BigDecimal  finCmaNo);
	 public String[] 	 getDistinctTabName2();
	 public List<LpstpFinMaster>  getAllDataRowTypeAsEntry();
	 public String[] 	 getDistinctRowName();
	 public List<LpstpFinMaster>  findByfinPageAndFinCmaNoAndFinTabnameOrderByFinRowidDesc(String finPage,BigDecimal finCmaNo , String finTabname );
	 List<LpstpFinMaster> findAllByFinPageOrderByFinSno(String finPage);

	 public List<LpstpFinMaster> findByFinCmaNoAndFinPageOrderByFinTabnameAscFinSnoAsc(BigDecimal cmano, String finpage);

	 List<LpstpFinMaster>  findByFinPageAndFinCmaNo(String finPage , BigDecimal finCmaNo );
}

