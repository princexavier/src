/**
 * 
 */
package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.setupmodel.StGeographyMaster;

/**
 * @author pawananjay.r This is repository for StGeographyMaster
 */

@Repository
public interface StGeographyMasterRepo extends JpaRepository<StGeographyMaster, Long> {

	@Query("select distinct   geoObj.sgmRowId, geoObj.sgmStateCode , upper(replace(geoObj.sgmStateName, ' ','')), geoObj.lgmZone, geoObj.lgmSpecialState, geoObj.sgmActive from StGeographyMaster  geoObj  where geoObj.sgmParentId is null or geoObj.sgmParentId=0 ORDER BY upper(replace(geoObj.sgmStateName, ' ',''))")
	public List<StGeographyMaster> getdistinctState();

	//
	@Query("select DISTINCT  geoObj.sgmRowId, geoObj.sgmCityCode , upper(replace(geoObj.sgmCityName, ' ','')),geoObj.sgmParentId, geoObj.sgmActive from StGeographyMaster geoObj where sgmStateCode=:sgmStateCode AND geoObj.sgmParentId=:sgmParentId ORDER BY   upper(replace(geoObj.sgmCityName, ' ',''))")
	public List<Object> getdistinctCityByStateCode(@Param("sgmStateCode") String sgmStateCode,
			@Param("sgmParentId") BigDecimal sgmParentId);

	// @Query("select DISTINCT geoObj.sgmRowId, geoObj.sgmDistrictCode,
	// geoObj.sgmDistrictName from StGeographyMaster geoObj where
	// sgmCityCode=:sgmCityCode AND sgmStateCode=:sgmStateCode AND
	// geoObj.sgmParentId=:sgmParentId ORDER BY geoObj.sgmDistrictName DESC")
	@Query("select geoObj from StGeographyMaster geoObj where sgmCityCode=:sgmCityCode AND sgmStateCode=:sgmStateCode AND geoObj.sgmParentId=:sgmParentId  ORDER BY geoObj.sgmDistrictName ")
	public List<Object> getdistinctDistrictByCityCodeAndStateCode(@Param("sgmCityCode") String sgmCityCode,
			@Param("sgmStateCode") String sgmStateCode, @Param("sgmParentId") BigDecimal sgmParentId);

	public List<StGeographyMaster> findBySgmCityCodeAndSgmStateCode(String sgmCityCode, String sgmStateCode);

	public List<Object[]> findAllStates();

	List<Object[]> findAllCity();

	List<Object[]> findAllDistrict();

	// @Query("select * from StGeographyMaster where sgmCityCode not in('null')
	// and sgmStateCode=?1 group by sgmCityCode" )
	// List<StGeographyMaster> findBysgmStateCode(String sgmStateCode);

	public List<StGeographyMaster> findAll();

	public StGeographyMaster findBySgmRowId(long sgmRowId);

	@Query("select geoObj.sgmDistrictCode, geoObj.sgmDistrictName from StGeographyMaster geoObj where geoObj.sgmStateCode=:sgmStateCode and geoObj.sgmDistrictName is not null ORDER BY geoObj.sgmDistrictName  DESC")
	public List<Object> getDistinctDistrictByStateCode(@Param("sgmStateCode") String sgmStateCode);

	List<StGeographyMaster> findAllBySgmStateNameIgnoreCaseContaining(String sgmStateName);

	List<StGeographyMaster> findAllBySgmCityCodeIgnoreCaseContaining(String sgmCityCode);

	List<StGeographyMaster> findAllBySgmCityNameIgnoreCaseContaining(String sgmCityName);

	List<StGeographyMaster> findAllBySgmParentIdAndSgmStateCodeIgnoreCaseContainingOrderBySgmStateNameAsc(
			BigDecimal sgmParentId, String sgmStateCode);

	List<StGeographyMaster> findAllBySgmParentIdAndSgmStateNameIgnoreCaseContainingOrderBySgmStateNameAsc(
			BigDecimal sgmParentId, String sgmStateName);

	List<StGeographyMaster> findAllBysgmDistrictCodeIgnoreCaseContaining(String sgmDistrictCode);

	List<StGeographyMaster> findAllBysgmDistrictNameIgnoreCaseContaining(String sgmDistrictName);

	StGeographyMaster findBysgmCityCode(String sgmCityCode);

	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContaining(
			String sgmStateCode, String sgmCityCode);

	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContaining(
			String sgmStateCode, String sgmCityName);

	List<StGeographyMaster> findBySgmCityCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContaining(
			String sgmCityCode, String sgmDistrictCode);

	List<StGeographyMaster> findBySgmCityCodeIgnoreCaseContainingAndSgmDistrictNameIgnoreCaseContaining(
			String sgmCityCode, String sgmDistrictName);

	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContaining(
			String sgmStateCode, String sgmDistrictCode);

	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictNameIgnoreCaseContaining(
			String sgmStateCode, String sgmDistrictName);

	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContaining(
			String sgmStateCode, String sgmDistrictCode, String sgmCityCode);

	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContaining(
			String sgmStateCode, String sgmDistrictCode, String sgmCityName);

	StGeographyMaster findBySgmStateCodeAndSgmCityCode(String sgmStateCode, String sgmCityName);

	@Query(value = "select NVL(max(LGM_STATE_CODE),0)+1 as maxid from LPSTP_GEOGRAPHY_MASTER ", nativeQuery = true)
	String findstatemaxid();

	@Query(value = "select NVL(max(LGM_CITY_CODE),0)+1 as maxid from LPSTP_GEOGRAPHY_MASTER ", nativeQuery = true)
	String findcitymaxid();

	@Query(value = "select NVL(max(LGM_DISTRICT_CODE),0)+1 as maxid from LPSTP_GEOGRAPHY_MASTER", nativeQuery = true)
	String finddistrictmaxid();

	@Query(value = "select count(*)  from LPSTP_GEOGRAPHY_MASTER where  upper(replace(lgm_state_name,' ','')) =upper(replace(?1,' ',''))", nativeQuery = true)
	String getsaveflage(String state);

	@Query(value = "select count(*) from LPSTP_GEOGRAPHY_MASTER where  upper(replace(lgm_state_name,' ','')) =upper(replace(?1,' ','')) and upper(replace(LGM_CITY_NAME,' ','')) =upper(replace(?2,' ',''))", nativeQuery = true)
	String getcityflage(String state, String city);

	@Query(value = "select count(*) from LPSTP_GEOGRAPHY_MASTER where  upper(replace(lgm_state_name,' ','')) =upper(replace(?1,' ','')) and upper(replace(LGM_CITY_NAME,' ','')) =upper(replace(?2,' ',''))  and upper(replace(LGM_DISTRICT_NAME,' ','')) =upper(replace(?3,' ',''))", nativeQuery = true)
	String getdistflage(String state, String city, String dist);

	public List<StGeographyMaster> findBySgmParentIdOrderBySgmStateCode(BigDecimal parentId);

	StGeographyMaster findBySgmStateCodeAndSgmCityCodeAndSgmDistrictCode(String sgmStateCode, String sgmCityCode,
			String sgmDistrictCode);

	public StGeographyMaster findFirstBySgmStateCodeAndSgmCityCodeAndSgmPincodeIsNotNullOrderBySgmPincode(
			String sgmStateCode, String sgmCityCode);

	@Query(value = "select distinct LGM_PINCODE from LPSTP_GEOGRAPHY_MASTER where LGM_STATE_CODE=?1 and LGM_CITY_CODE=?2 and LGM_PINCODE=?3", nativeQuery = true)
	List<Object> findSgmStateCodeAndSgmCityCodeAndSgmPincode(String sgmStateCode, String sgmCityName,
			BigDecimal sgmPincode);

	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContainingAndSgmDistrictCode(
			String sgmStateCode, String sgmCityName, String sgmDistrictCode);

	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContainingAndSgmDistrictCode(
			String sgmStateCode, String sgmCityCode, String sgmDistrictCode);

	List<StGeographyMaster> findAllBySgmCityCodeIgnoreCaseContainingAndSgmDistrictCode(String sgmCityCode,
			String sgmDistrictCode);

	List<StGeographyMaster> findAllBySgmCityNameIgnoreCaseContainingAndSgmDistrictCode(String sgmCityName,
			String sgmDistrictCode);

	StGeographyMaster findBySgmDistrictCode(String sgmDistrictCode);

	StGeographyMaster findBySgmCityCodeAndSgmDistrictCode(String sgmStateCode, String sgmCityCode);

	long newRowGeneratorforGeographyMaster();

	// List<StGeographyMaster>
	// findAllBySgmParentIdAndLgmDeviationAndSgmStateCodeIgnoreCaseContainingOrderBySgmStateNameAsc(BigDecimal
	// sgmParentId,String lgmDeviation,String sgmStateCode);
	// List<StGeographyMaster>
	// findAllBySgmParentIdAndLgmDeviationAndSgmStateNameIgnoreCaseContainingOrderBySgmStateNameAsc(BigDecimal
	// sgmParentId,String lgmDeviation,String sgmStateName);

	@Query(value = "SELECT DISTINCT sgmStateName AS StateName, sgmStateCode AS StateCode FROM StGeographyMaster ORDER BY sgmStateName")
	List[] findDistinctSgmStateName();

	@Query("select geo from StGeographyMaster geo where sgmStateCode=?1 and sgmParentId!=0 order by sgmCityName")
	List<StGeographyMaster> findBySgmStateCode(String sgmStateCode);

	List<StGeographyMaster> findAllBySgmStateCodeIgnoreCaseContaining(String sgmStateCode);

	@Query(value = "SELECT DISTINCT sgmCityCode AS CityCode,sgmCityName AS CityName FROM StGeographyMaster where sgmStateCode=?1 and sgmCityCode not in('null') ORDER BY sgmCityName")
	List[] findDistinctSgmCityCode(String sgmStateCode);
	
	StGeographyMaster findBysgmStateCode(String sgmStateCode);
	//public StGeographyMaster findBysgmStateCode(String sgmStateCode);
}
