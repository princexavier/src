package com.sai.lendperfect.setuprepo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.SetOrgLevel;

@Repository
public interface SetOrgLevelRepo extends JpaRepository<SetOrgLevel,Long> {

	

}
