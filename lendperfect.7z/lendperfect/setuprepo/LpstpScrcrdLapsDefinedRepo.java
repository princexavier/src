package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sai.lendperfect.setupmodel.LpstpScrcrdLapsDefined;

public interface LpstpScrcrdLapsDefinedRepo extends JpaRepository<LpstpScrcrdLapsDefined, BigDecimal> {
	@Query(value = "SELECT TRUNC((SYSDATE - lad_doB)/ 365.25) AS AGE, LLD_REQTERMS AS TENOR,LAD_EMPLOYMENT as EMPLOYMENT,LAD_EDUCATION as EDUCATIONAL_QULAIFICATION,LAD_YRSINPRESADD as MOBILITY,LAD_RESIDENCETYPE as RESIDENCE_TYPE,LAD_SALARYROUTED as SALARY_ROUTED,LAD_EARNMEM as EARNING_MEMBERS,LAD_DEPEND as NO_OF_DEPENDENTS FROM LPCUST_APPLICANT_DATA,Lpcust_appcust_relation, LPCUST_LOAN_DETAILS WHERE  LAD_ID=lar_appid AND lar_type='A' AND lar_appno=LLD_APPNO AND lar_appno=?1 AND LLD_SNO =?2 AND ROWNUM = 1 ORDER BY LLD_CREATED_ON DESC", nativeQuery = true)
	List[] getSystemDefinedParameter(Long proposalNo, Long facilityNo);

	@Query(value = "select ((select SUM(LAIE_MON_NETINC) as TOT_MON_INCOME  from LPCOM_PROPOSAL,LPCUST_APPCUST_RELATION,LPCUST_APPLICANT_INCEXPENSES where lp_prop_no=LPCUST_APPCUST_RELATION.lar_appno and lar_appid=LAIE_APPID and (LPCUST_APPCUST_RELATION.lar_type='A' OR LPCUST_APPCUST_RELATION.lar_includeincome='Y')  and lp_prop_no=?1)/(select SUM(LAIE_MON_STATDED+LAIE_MON_OTHERDED) as TOT_MON_DEDUCTION from LPCOM_PROPOSAL,LPCUST_APPCUST_RELATION,LPCUST_APPLICANT_INCEXPENSES where lp_prop_no=LPCUST_APPCUST_RELATION.lar_appno and lar_appid=LAIE_APPID and (LPCUST_APPCUST_RELATION.lar_type='A' OR LPCUST_APPCUST_RELATION.lar_includeincome='Y')  and lp_prop_no=?1)) as DSCR from dual", nativeQuery = true)
	Object getDscrValue(Long proposalNo);
}
