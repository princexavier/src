package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.setupmodel.LpstpProductDet;


@Repository
public interface LpstpProductDetRepo extends JpaRepository<LpstpProductDet,Long>{

	LpstpProductDet findByLpdProdNewId(long lpdProdNewId);
	List<LpstpProductDet> findByLpdProdNewIdIn(List<Long> lpdProdNewId);

	List<LpstpProductDet> findByLpdPrdMainCatAndLpdPrdSubCatAndLpdActiveAndLpdComplete(String lpdPrdMainCat,String lpdPrdSubCat,String lpdActive,String lpdComplete);
	List<LpstpProductDet> findByLpdPrdMainCatAndLpdActiveAndLpdComplete(String lpdPrdMainCat,String lpdActive,String lpdComplete);
	LpstpProductDet findByLpdPrdSubCat(String lpdPrdSubCat);
	List<LpstpProductDet> findByLpdActiveAndLpdComplete(String lpdActive,String lpdComplete);
	List<LpstpProductDet> findAllByLpdActiveAndLpdComplete(String lpdActive, String lpdComplete);
	//get products for chart report 
	List<LpstpProductDet> findBylpdPrdType(String lpdPrdType);

}





