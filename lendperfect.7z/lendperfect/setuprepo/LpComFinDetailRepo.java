package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpComFinDetail;


@Repository
public interface LpComFinDetailRepo extends JpaRepository<LpComFinDetail, Long> { 

	long	  maxOfSeqNumByPropNum(@Param("lfdPropNoValue")BigDecimal lfdPropNo,@Param("lfdCustNewId")BigDecimal lfdCustNewId,@Param("lfdCmaNo")BigDecimal lfdCmaNo);
	
	List<LpComFinDetail>     getAllRowByPropNumforDetail 	(@Param("lfdPropNo")BigDecimal lfdPropNo ,@Param("lfdCustNewId")BigDecimal lfdCustNewId ,@Param("lfdCmaNo")BigDecimal lfdCmaNo);
	LpComFinDetail getAllRowOfMaxDateByAuditType(@Param("lfdAuditType")String lfdAuditType ,@Param("lfdPropNo")BigDecimal lfdPropNo ,
												 @Param("lfdCustNewId")BigDecimal lfdCustNewId ,@Param("lfdCmaNo")BigDecimal lfdCmaNo);

	List<LpComFinDetail> findByLfdPropNoAndLfdCmaNoAndLfdCustNewId(BigDecimal bigDecimal, BigDecimal bigDecimal2,
			BigDecimal bigDecimal3);
	List<Object[]>getDistinctCustomerIdandCMANo(@Param("lfdPropNo")BigDecimal lfdPropNo);
	void deleteByLfdPropNoAndLfdCustNewIdAndLfdCmaNo(BigDecimal lfdPropNo,BigDecimal lfdCustNewId,BigDecimal lfdCmaNo);
	List<LpComFinDetail>  findByLfdPropNoAndLfdCustNewId(BigDecimal lfdPropNo,
			BigDecimal lfdCustNewId);
}
