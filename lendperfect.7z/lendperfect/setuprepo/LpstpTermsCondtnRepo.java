package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.sai.lendperfect.setupmodel.LpstpTermsCondtn;
import org.springframework.stereotype.Repository;

@Repository
public interface LpstpTermsCondtnRepo extends JpaRepository<LpstpTermsCondtn, BigDecimal> {
	
	List <LpstpTermsCondtn> findAllByLtcTcType(String ltcTcType);
}
