package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpDelegation;
import com.sai.lendperfect.setupmodel.LpstpScheme;

@Repository
public interface LpstpDelegationRepo extends JpaRepository<LpstpDelegation, BigDecimal>  {
	List<LpstpDelegation> findAllByOrderByLdpRowId();
	List<LpstpDelegation> findByLdpStateIdAndLdpCityIdOrderByLdpRowId(String ldpStateId, String ldpCityId);
	List<LpstpDelegation> findByLdpStateIdAndLdpCityIdAndLpstpSchemeOrderByLdpRowId(String ldpStateId, String ldpCityId,LpstpScheme lpstpScheme);
	List<LpstpDelegation> findBylpstpScheme(LpstpScheme lpstpScheme);
}
