package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.setupmodel.LpstpRiskBusinessrule;
import com.sai.lendperfect.setupmodel.LpstpRiskruleCutoffrange;

public interface LpstpRiskruleCutoffrangeRepo extends JpaRepository<LpstpRiskruleCutoffrange,BigDecimal>{
	List<LpstpRiskruleCutoffrange> findByLpstpRiskBusinessrule(LpstpRiskBusinessrule lpstpRiskBusinessrule);
}
