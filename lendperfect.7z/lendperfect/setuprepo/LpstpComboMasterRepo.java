package com.sai.lendperfect.setuprepo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.setupmodel.LpstpPrdComboConfig;

public interface LpstpComboMasterRepo extends JpaRepository<LpstpPrdComboConfig, Serializable>{

	List<LpstpPrdComboConfig> findAll();

}
