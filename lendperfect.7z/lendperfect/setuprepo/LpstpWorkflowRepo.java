package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.sai.lendperfect.setupmodel.LpstpWorkflow;
import org.springframework.stereotype.Repository;

@Repository
public interface LpstpWorkflowRepo extends JpaRepository<LpstpWorkflow, Long>{
	
	List<LpstpWorkflow> findAllDistinct();
	List<LpstpWorkflow> findAllByLwWfType(String lwWfType);
	LpstpWorkflow findByLwWfIdAndLwWfType(long lsWfProcessId, String type);
	@Query(value="select LW_WF_TYPE from LPSTP_WF_FLOWS join LPSTP_WORKFLOWS on LWF_WORKFLOW_ID=LW_WF_ID  where LWF_FLOWPOINT_ID=?1",nativeQuery=true)
	String getworkflowtype(Long lwfFlowpointId);
	List<LpstpWorkflow> findAllByLwWfBizVertical(BigDecimal lwWfBizVertical);
	@Query(value="select LW_WF_TYPE from LPSTP_WORKFLOWS where LW_WF_ID=?1",nativeQuery=true)
	String getworkmastertype(Long lwWfId);
	@Query(value="select LW_WF_BIZ_VERTICAL from LPSTP_WORKFLOWS where LW_WF_ID=?1",nativeQuery=true)
	String getworkmastervertical(Long lwWfId);
	@Query(value="select LUG_GRP_ID,LUG_GRP_NAME from  LPSTP_USER_GROUP where LUG_GRP_VERTICAL=?1 and  (LUG_GRP_DEPT=?2 or LUG_GRP_DEPT=?3) and LUG_GRP_ACTIVE='Y' order by LUG_GRP_ID",nativeQuery=true)
	List<Object[]> getusergroup(String  vertical,String dep1,String dep2);
	@Query(value="select LPM_PAGE_ID,LPM_PAGE_NAME,LPM_PARENT_LINK,LPM_SEQ_NUM,LPM_PAGE_TYPE,LPM_PAGE_ACTIVE,LPM_LINK_NAME,LPM_PAGE_PROPERTY1 from LPMAS_PAGE_MASTER1 join LPSTP_WF_PAGELIST on LPM_PAGE_ID=LWP_PAGE_ID  where LWP_FLOWPOINT_ID=?1 and LWP_PAGE_ACCESS!='D' order by LPM_SEQ_NUM",nativeQuery=true)
	List<Object[]> verticalpagelist(BigDecimal flwid);

}
