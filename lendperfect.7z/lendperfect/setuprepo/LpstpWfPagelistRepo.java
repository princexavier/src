package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import com.sai.lendperfect.setupmodel.LpstpWfPagelist;
import org.springframework.stereotype.Repository;


@Repository
public interface LpstpWfPagelistRepo  extends JpaRepository<LpstpWfPagelist, BigDecimal> {
	
	List <LpstpWfPagelist> deleteAllByLwpFlowpointId(BigDecimal lwpFlowpointId);
	List<LpstpWfPagelist> findAllBylwpFlowpointId(BigDecimal lwpFlowpointId);
	

}
