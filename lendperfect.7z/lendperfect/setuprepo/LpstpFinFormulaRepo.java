package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpFinFormula;


@Repository
public interface LpstpFinFormulaRepo extends JpaRepository<LpstpFinFormula, Long> {
	
	List<LpstpFinFormula>    getAllDataOrderByName();
	
	String getFormulaValueByRowId(@Param("lffFormId")long lffFormId);

	@Modifying
	Integer updateRowofFinFormula(@Param("lffCmaNo")BigDecimal lffCmaNo,@Param("lffFormDesc")String lffFormDesc,@Param("lffFormFor")String lffFormFor,
			@Param("lffFormName")String lffFormName,@Param("lffFormValue")String lffFormValue,@Param("lffModifiedBy")String lffModifiedBy,
			@Param("lffModifiedOn")Date lffModifiedOn,@Param("lffFormId")long lffFormId);
	
	List<LpstpFinFormula>  findByLffCmaNoAndLffFormForOrderByLffFormIdAsc(BigDecimal lffCmaNo, String lffFormFor);
}
