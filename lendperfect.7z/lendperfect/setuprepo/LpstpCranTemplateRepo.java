package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpCranTemplate;

@Repository
public interface LpstpCranTemplateRepo extends JpaRepository<LpstpCranTemplate, BigDecimal> {

	@Query(value ="SELECT crantemplate.LCT_TEMP_VERTICAL,crantemplate.LCT_TEMP_ID,crantemplate.LCT_TEMP_DESC,crantemplate.LCT_TEMP_COMPNT,"
			+ "cranmaster.LCM_CRAN_ID,cranmaster.LCM_CRAN_TITLE,cranmaster.LCM_TEMP_ID,cranmaster.LCM_TEMP_SEQ,cranmaster.LCM_VERTICAL,cranmaster.LCM_ROW_ID"
			+ " FROM LPSTP_CRAN_TEMPLATES crantemplate left join LPSTP_CRAN_MASTER cranmaster  on crantemplate.LCT_TEMP_ID=cranmaster.LCM_TEMP_ID"
			+ " and cranmaster.LCM_CRAN_ID=?2 "
			+ "where crantemplate.LCT_TEMP_VERTICAL=?1 and cranmaster.LCM_CRAN_ID is not null order by cranmaster.LCM_TEMP_SEQ",nativeQuery=true)
	List<Object[]> getCranMasterData(String verticalName,BigDecimal cranId);
	
	
	@Query(value ="SELECT crantemplate.LCT_TEMP_VERTICAL,crantemplate.LCT_TEMP_ID,crantemplate.LCT_TEMP_DESC,crantemplate.LCT_TEMP_COMPNT,"
			+ "cast(null AS number) AS lm_cranid,null AS LCM_CRAN_TITLE,cast(null AS number) AS LCM_TEMP_ID,cast(null AS number) AS LCM_TEMP_SEQ,"
			+ "cast(null AS number) AS LCM_VERTICAL "
			+ "FROM LPSTP_CRAN_TEMPLATES crantemplate where crantemplate.LCT_TEMP_VERTICAL=?1  order by crantemplate.LCT_TEMP_ID",nativeQuery=true)
	List<Object[]> getCranMasterByVerticalName(String verticalName);
	
	
}
