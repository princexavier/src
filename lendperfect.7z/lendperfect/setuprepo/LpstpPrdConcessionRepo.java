package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.setupmodel.LpstpPrdConcession;

@Repository
public interface LpstpPrdConcessionRepo extends JpaRepository<LpstpPrdConcession,Long>{

	LpstpPrdConcession findByLpcProdId(long lpdProdId);

	List<LpstpPrdConcession> findByLpcProdIdOrderByLpcRowId(Long lpcProdId);

	
	

}
