package com.sai.lendperfect.setuprepo;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpUser;


@Repository
public interface SetUserRepo extends JpaRepository<LpstpUser, Long> {
	
//	public List<LpstpUser> findByLuRowId(long suRowId ) ;
//public List<LpstpUser> findByluUserId(String suUserId ) ;
//	public List<LpstpUser> findByluAvailable(String suAvailable); 
//Long countByluRowIdGreaterThan (long suRowId);
	
	
}
