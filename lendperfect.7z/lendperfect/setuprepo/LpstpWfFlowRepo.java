package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.sai.lendperfect.setupmodel.LpstpWfFlow;
import org.springframework.stereotype.Repository;

@Repository
public interface LpstpWfFlowRepo extends JpaRepository<LpstpWfFlow, Long> {
	
	List <LpstpWfFlow> deleteAllByLwfFlowpointId(Long lwfFlowpointId);
	List <LpstpWfFlow> findAllByLwfWorkflowIdOrderByLwfWorkflowId(Long lwfWorkflowId);
	List<LpstpWfFlow> findAllByLwfFlowpointId(Long lwfFlowpointId);
	List<LpstpWfFlow> findAllByLwfWorkflowIdAndLwfWfType(Long lsWfProcessId, String type);
	LpstpWfFlow findAllByLwfWorkflowIdAndLwfWfTypeAndLwfFlowpoint(BigDecimal workflowId, String type,
			Long lmFlowId);
	@Query(value="select LU_USER_ID,LU_FIRST_NAME from LPSTP_USERS join  LPSTP_USER_LOCATION on LU_USER_ID=LUL_USER_ID  join LPSTP_ORGANISATIONS on LUL_ORG_ID=LO_ORG_ID  join LPSTP_USER_ACCESS on LUA_USER_ID=LU_USER_ID where  LUA_GROUP=?1 and LUA_BIZ_VERTICAL=?2",nativeQuery=true)
	List<Object[]> getUserId(String lwfUserGrp, BigDecimal bizVertical);
	List<LpstpWfFlow> findByLwfWorkflowIdOrderByLwfCreatedOn(Long flowId);

	LpstpWfFlow findAllByLwfWorkflowIdAndLwfWfTypeAndLwfFlowpointId(Long flowId, String type, long id);
	LpstpWfFlow findByLwfFlowpointId(long lwfFlowpointId);
	List<LpstpWfFlow> findByLwfWorkflowIdOrderByLwfFlowpoint(Long flowId);

}
