package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.SetOrganisation;
@Repository
public interface SetOrganisationRepo extends JpaRepository<SetOrganisation,Long>{

	SetOrganisation findBysoName(String soName);
	SetOrganisation findBysoOrgId(long soOrgId);
	List<SetOrganisation> findAllByOrderBySoName();
	SetOrganisation findBysoOrgId(BigDecimal suLocation);
	List<SetOrganisation> findByLoOrgLevelOrderBySoName(String loOrgLevel);
	List<SetOrganisation> findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(String loOrgBizVertical, String loOrgDepartment, String loOrgLevel);
	SetOrganisation findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndSoOrgId(BigDecimal loOrgBizVertical, String loOrgDepartment, String loOrgLevel, long soOrgId);
	List<Object> findDistinctLevel(@Param("loOrgBizVertical")String loOrgBizVertical,@Param("loOrgDepartment")String loOrgDepartment);
	List<SetOrganisation> findByLoOrgLevelAndLoOrgBizVertical(String orglevel, BigDecimal bizVertical);
}
