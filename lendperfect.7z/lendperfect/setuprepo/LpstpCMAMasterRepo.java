package com.sai.lendperfect.setuprepo;


import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpCMAMaster;


@Repository
public interface LpstpCMAMasterRepo  extends JpaRepository<LpstpCMAMaster, Long> {

	LpstpCMAMaster findByCmaNo(BigDecimal bigDecimal);
	
}
