/*package com.sai.lendperfect.setuprepo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.model.SetBusinessRulesMaster;
import com.sai.lendperfect.model.SetStaticData;
import com.sai.lendperfect.model.SetWorkflowMaster;
@Repository
public interface SetWorkflowMasterRepo extends JpaRepository<SetWorkflowMaster,Long>{
	
	

}
*/