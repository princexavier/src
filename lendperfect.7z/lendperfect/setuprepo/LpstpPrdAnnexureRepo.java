package com.sai.lendperfect.setuprepo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpPrdAnnexure;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

@Repository
public interface LpstpPrdAnnexureRepo extends JpaRepository<LpstpPrdAnnexure, Long> {
	List<LpstpPrdAnnexure> findByLpstpProductDet(LpstpProductDet lpstpProductDet);
}
