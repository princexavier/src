package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.setupmodel.LpstpAssessment;

@Repository
public interface LpstpAssessmentRepo extends JpaRepository<LpstpAssessment, BigDecimal>  {
	
	List<LpstpAssessment> deleteAllByLaAssmntId(BigDecimal laAssmntId);
	List<LpstpAssessment> findAllByLaAssmntIdOrderByLaRowId(BigDecimal LaAssmntId);
	List<LpstpAssessment> deleteAllByLaRowId(BigDecimal laRowId);
	List<Object[]> findAllDistinct();

}
