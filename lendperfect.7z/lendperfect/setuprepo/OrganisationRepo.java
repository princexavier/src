package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.Organisation;
@Repository
public interface OrganisationRepo extends JpaRepository<Organisation,Long>{

	Organisation findByorgId(long orgId);
	Organisation findByorgCode(String orgCode);

	
}
