package com.sai.lendperfect.setuprepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.setupmodel.LpstpScorecardMaster;

@Repository
public interface LpstpScorecardMasterRepo extends JpaRepository<LpstpScorecardMaster, Long> {
	List<Object> getDistinctHeader(@Param("valueOf") String scpmAvailable);

	List<Object> getDistinctHeaderByScFor(@Param("scmScFor") String scmScFor);

	List<Object> getDistinctHeaderByScForAndBizVerticalAndBusinessrule(@Param("scmScFor") String scmScFor, @Param("scmBizVertical") String scmBizVertical, @Param("scmLrbSeqno") long scmLrbSeqno);// ,

	// scpmAvailable);

	// List<LpstpScorecardMaster>
	// getActiveorNullQuestionList(@Param("scmQuesHeaderId") BigDecimal
	// scmQuesHeaderId, @Param("scmAvailable") String scmAvailable);
	List<LpstpScorecardMaster> findByScmQuesHeaderIdAndScmAvailable(BigDecimal scmQuesHeaderId, String scmAvailable);

	// List<LpstpScorecardMaster>
	// getIsDeleteorNullQuestionList(@Param("scmQuesHeaderId") BigDecimal
	// scmQuesHeaderId);// ,@Param("scmIsdelete")String
	// scmIsdelete);

	@Modifying
	Integer updateHeaderDescByQuesHeaderId(@Param("scmHeaderDesc") String scmHeaderDesc, @Param("scmQuesHeaderId") BigDecimal scmQuesHeaderId);

	// List<LpstpScorecardMaster>
	// findByScmScForAndScmAvailableOrderByScmRowId(String scmScFor,String
	// scmAvailable);
	List<LpstpScorecardMaster> findByScmScForAndScmAvailableAndScmLrbSeqnoAndScmLapsDefinedOrderByScmQuesHeaderId(String scmScFor, String scmAvailable, long scmLrbSeqno, String scmLapsDefined);

	// List<LpstpScorecardMaster> findByScmQuesHeaderId(BigDecimal
	// scmQuesHeaderId);

	List<LpstpScorecardMaster> findDistinctByScmQuesHeaderIdAndScmLapsDefined(BigDecimal scmQuesHeaderId, String scmLapsDefined);

}
