package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomCustAddr;
import com.sai.lendperfect.commodel.LpcomCustContctDet;
import com.sai.lendperfect.commodel.LpcomCustInfo;


@Repository
public interface LpcomCustContctDetRepo extends JpaRepository<LpcomCustContctDet,BigDecimal>{
	 
	LpcomCustContctDet findByLcdOrderNoAndLcdRowId(BigDecimal lcdOrderNo,BigDecimal lcdRowId);
	List<LpcomCustContctDet> findByLpcomCustInfo(LpcomCustInfo LpcomCustInfo);

}
