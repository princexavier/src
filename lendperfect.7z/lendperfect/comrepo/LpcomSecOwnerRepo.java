package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomSecOwner;
import com.sai.lendperfect.commodel.LpcomSecurity;


@Repository
public interface LpcomSecOwnerRepo extends  JpaRepository<LpcomSecOwner, BigDecimal>{
	List<LpcomSecOwner> findByLsoOwnerId(BigDecimal ownerId);
	LpcomSecOwner findByLsoOwnerIdAndLsoOwnerSno(BigDecimal ownerId, BigDecimal lsoOwnerSno);
	List<LpcomSecOwner> findByLpcomSecurity(LpcomSecurity lpcomSecurity);
	LpcomSecOwner findByLsoRowId(BigDecimal lsoRowId);
	List<LpcomSecOwner> findBylsProductId(BigDecimal lsProductId);
	List<LpcomSecOwner> findBylsProposalNo(BigDecimal lsProposalNo);
	LpcomSecOwner findBylpcomSecurity(LpcomSecurity lpcomSecurity);
	List<LpcomSecOwner> findByLsProposalNoAndLsoOwnerId(BigDecimal lsProposalNo, BigDecimal ownerId);

}