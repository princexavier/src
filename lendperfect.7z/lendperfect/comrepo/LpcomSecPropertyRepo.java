package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecProperty;
import com.sai.lendperfect.commodel.LpcomSecurity;


@Repository
public interface LpcomSecPropertyRepo extends JpaRepository<LpcomSecProperty, BigDecimal> {
	LpcomSecProperty findByLpcomSecurity(LpcomSecurity lpcomSecurity);
	
	@Query(value="select distinct LU_USER_ID,LU_FIRST_NAME from LPSTP_USERS join LPSTP_USER_LOCATION on LU_USER_ID=LUL_USER_ID  join LPSTP_ORGANISATIONS on LUL_ORG_ID=LO_ORG_ID  where LU_DEPARTMENT='T' and LO_ORG_ID=?1",nativeQuery=true)
	List<Object[]> getUserIdForPropertyValuer(long homeBranch);

	@Query(value="select distinct LU_USER_ID,LU_FIRST_NAME from LPSTP_USERS join LPSTP_USER_LOCATION on LU_USER_ID=LUL_USER_ID  join LPSTP_ORGANISATIONS on LUL_ORG_ID=LO_ORG_ID  where LU_DEPARTMENT='L' and LO_ORG_ID=?1",nativeQuery=true)
	List<Object[]> getUserListForLegal(long homeBranch);
	
}
