package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSetFacMap;

@Repository
public interface LpcomSetFacMapRepo extends JpaRepository<LpcomSetFacMap, Long>{
	
	
	List<LpcomSetFacMap> findUniqueSetIdinFacMap(@Param("lbsmSetId")BigDecimal lbsmSetId,@Param("lpcomProposalObject")LpcomProposal LpcomProposalObj);

	List<LpcomSetFacMap> findByLpcomProposal(LpcomProposal lpcomProposal);

	List<LpcomSetFacMap> findByLpcomProposalAndLbsmSetId(LpcomProposal lpcomProposal, BigDecimal lbsmSetId);
}
