package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomGlobalVariable;


@Repository
public interface LpcomGlobalVariableRepo  extends JpaRepository<LpcomGlobalVariable, Long> {
	
//	List<LpcomGlobalVariable>    getAllDataOrderByName();

	LpcomGlobalVariable findFirstByLgvPropNoAndLgvGlVarIdOrderByLgvCreatedOnDesc(BigDecimal propNo, BigDecimal glbId);

	LpcomGlobalVariable findByLgvPartyIdAndLgvPropNoAndLgvGlVarId(BigDecimal lfbmCustNewId, BigDecimal propNo,BigDecimal glbId);

	LpcomGlobalVariable findByLgvFacNoAndLgvPropNoAndLgvGlVarId(BigDecimal lbsmRowId, BigDecimal propNo,
			BigDecimal glblId);
 
	List<LpcomGlobalVariable> findBylgvPropNo(BigDecimal lgvPropNo);
}
