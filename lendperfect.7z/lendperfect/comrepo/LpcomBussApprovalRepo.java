package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomBussApproval;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface LpcomBussApprovalRepo extends JpaRepository<LpcomBussApproval,BigDecimal> {
	
	@Query(value="select LF_FAC_NO,LPD_PRD_DESC,LFBM_SET_ID,LPD_PROD_NEW_ID,LF_SANC_LIMIT  from LPCOM_SET_BORR_MAP join LPCOM_CUST_INFO on LFBM_CUST_ID=LCI_CUST_ID join LPCOM_SET_FAC_MAP on LFBM_SET_ID=LBSM_SET_ID and LBSM_PROP_NO=LFBM_PROP_NO join  LPCORP_FACILITIES on  LBSM_FAC_NO=LF_FAC_NO and LF_PROP_NO=LFBM_PROP_NO join  LPSTP_PRODUCT_DET on LF_PROD_ID=LPD_PROD_NEW_ID where LFBM_BORR_TYPE='B'   and LFBM_PROP_NO=?1 and LCI_CUST_ID=?2  and LCI_RECENT='Y'",nativeQuery=true)
	List<Object[]> findborrowerfacility(LpcomProposal  lpcomProposal,BigDecimal custId);
	List<LpcomBussApproval>findByLpcomProposalAndLbaCustIdAndLbaFacIdOrderByLbaRowId(LpcomProposal  lpcomProposal,BigDecimal lbaCustId,BigDecimal lbaFacId);
	@Query(value="select LIR_TR_PREFR,LIR_MCLR_PREFR from LPSTP_PRD_INT_RATE where LIR_PROD_ID =?1 and LIR_AMT_FROM <=?2 and  LIR_AMT_TO >=?2",nativeQuery=true)
	List<Object[]> findinterest(BigDecimal prdid,BigDecimal range);
	@Query(value="select LUA_USER_ID from LPSTP_USER_ACCESS where LUA_CLASS= (select cast( min(LDP_USER_CLASS) as VARCHAR(50))  from LPCOM_CASE_DET_SALES JOIN LPSTP_DELEGATION ON LPCDS_SCHEME_ID=LDP_SCHEME_ID where LPCDS_PROP_NO =?1  and LDP_DELECATION_FOR='S' and  LDP_LIMIT=?2) order by LUA_ROW_ID fetch first  row only",nativeQuery=true)
	String findAuthority(LpcomProposal  lpcomProposal,BigDecimal limit);
}
