package com.sai.lendperfect.comrepo;



import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.sai.lendperfect.commodel.LpcomCustInfo;
import com.sai.lendperfect.commodel.LpcomPropParty;
import com.sai.lendperfect.commodel.LpcomProposal;



public interface LpcomCustInfoRepo  extends JpaRepository<LpcomCustInfo, Long> {
	
	
	LpcomCustInfo findByLciNewId(long lciNewId);
	List<LpcomCustInfo> findByLciCustId(BigDecimal lciCustId);
	List<LpcomCustInfo> findByLciCustNameIgnoreCaseContaining(String lciCustName);
	LpcomCustInfo findByLciCustIdAndLciRecent(BigDecimal lciCustId, String lciRecent);
	List<LpcomCustInfo>	getDataByPropNumandCustomerTypefromPropNumPartyMapping(@Param("lppCustType")String lppCustType,
			@Param("lpcomProposalObject")LpcomProposal lfdPropNo );
	List<LpcomCustInfo> findByLpcomPropPartiesIn(List<LpcomPropParty> lpcomPropPartiesList);
	
}
