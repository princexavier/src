package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecFindocNtrade;


@Repository
public interface LpcomSecFindocNtradeRepo extends JpaRepository<LpcomSecFindocNtrade, Long> {
//	LpcomSecFindocNtrade findByLsfnSecId(BigDecimal lsfnSecId);
}
