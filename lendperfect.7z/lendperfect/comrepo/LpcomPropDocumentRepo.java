package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.commodel.LpcomPropDocument;
import com.sai.lendperfect.commodel.LpcomProposal;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


@Repository
public interface LpcomPropDocumentRepo extends JpaRepository<LpcomPropDocument, BigDecimal>   {
	
	List <LpcomPropDocument >findAllByLpcomProposal(LpcomProposal lpcomProposal);
	List<LpcomPropDocument>deleteAllByLpcomProposal(LpcomProposal LpcomProposal);
	List<LpcomPropDocument> deleteAllByLpcomProposalAndLpdOrderNo(LpcomProposal LpcomProposal,BigDecimal lpdOrderNo);
	List<LpcomPropDocument>findAllByLpcomProposalAndLpdDocHolder(LpcomProposal lpcomProposal,String lpdDocHolder);
	@Query(value="select LM_FROM_USR from lpcom_mailbox where LM_PROP_NO=?1  and LM_TO_USR=?2 and LM_TYPE=?3  order by  TO_CHAR(LM_RECVD_TIME,'DD/MM/YYYY  hh:mm:ss') desc fetch first row only  ",nativeQuery=true)
	String findByinitiated(LpcomProposal lpcomProposal,String lmToUsr,String lmType);
	@Query(value="select LCI_CUST_NAME from LPCOM_CUST_INFO where LCI_CUST_ID =?1 and LCI_RECENT=?2",nativeQuery=true)
	String findBycustomername(BigDecimal lciCustId,String lciRecent);
	@Query(value="select ic.LCI_FIRST_NAME,ic.LCI_FATHER_NAME,ic.LCI_SPOUSE_NAME,ic.LCI_GENDER,ic.LCI_DOB,ca.LCA_ADDRESS1,ca.LCA_ADDRESS2,ca.LCA_ADDRESS3,(select distinct(LGM_STATE_NAME) from LPSTP_GEOGRAPHY_MASTER where LGM_STATE_CODE=ca.LCA_STATE and LGM_DISTRICT_CODE=ca.LCA_DISTRICT and LGM_CITY_CODE=ca.LCA_CITY ) as state,(select distinct(LGM_DISTRICT_NAME) from LPSTP_GEOGRAPHY_MASTER where LGM_STATE_CODE=ca.LCA_STATE and LGM_DISTRICT_CODE=ca.LCA_DISTRICT and LGM_CITY_CODE=ca.LCA_CITY) as district,(select distinct(LGM_CITY_NAME) from LPSTP_GEOGRAPHY_MASTER where LGM_STATE_CODE=ca.LCA_STATE and LGM_DISTRICT_CODE=ca.LCA_DISTRICT and LGM_CITY_CODE=ca.LCA_CITY) as city,ca.LCA_PINCODE,floor(months_between(sysdate,LCI_DOB)/12)as age from LPCOM_CUST_INFO ci join LPCOM_CUST_DATA_IND ic on  ci.LCI_NEW_ID=ic.LCI_NEW_ID join LPCOM_CUST_ADDR ca on ca.LCA_NEW_ID=ci.LCI_NEW_ID where ci.LCI_CUST_ID=?1 and LCI_RECENT=?2",nativeQuery=true)
	List<Object[]>findCusBasicInfo(BigDecimal lciCustId,String lciRecent);
	@Query(value="select LU_USER_ID,LO_NAME from LPSTP_USERS join  LPSTP_USER_LOCATION on LU_USER_ID=LUL_USER_ID  join LPCOM_PROP_LOCATION on (LUL_ORG_ID=LPL_LEVEL_1 or LUL_ORG_ID=LPL_LEVEL_2 or LUL_ORG_ID=LPL_LEVEL_3 or LUL_ORG_ID=LPL_LEVEL_4 or LUL_ORG_ID=LPL_LEVEL_5 or LUL_ORG_ID=LPL_LEVEL_6 or LUL_ORG_ID=LPL_LEVEL_7 or LUL_ORG_ID=LPL_LEVEL_8)  join LPSTP_ORGANISATIONS on LUL_ORG_ID=LO_ORG_ID where LPL_PROP_NO=?1 and LU_EMP_TYPE=?2",nativeQuery=true)
	List<Object[]>findAgencyid(LpcomProposal lpcomProposal,String type);
	@Query(value="select LSD_RM_EMP_ID from LPCOM_SOURCING_DET where LSD_PROP_NO=?1",nativeQuery=true)
	String getRMid (LpcomProposal lpcomProposal);
	
	@Modifying
	@Transactional(readOnly=false)
	@Query(value="update LPCOM_PROP_DOCUMENTS set LPD_DOC_HOLDER=?1 where LPD_PROP_NO=?2 and LPD_DOC_ID=?3",nativeQuery=true)
	Integer updatedocholder(String Holder,LpcomProposal lpcomProposal,BigDecimal Docid);
	
	 
	@Query(value="select LM_FROM_USR from LPCOM_MAILBOX where LM_PROP_NO=?1 and LM_TO_USR=?2 and LM_REFERENCE_ID=?3",nativeQuery=true)
	String getRCUid (LpcomProposal lpcomProposal,String user,BigDecimal refernceId);
	
	@Modifying
	@Transactional(readOnly=false)
	@Query(value="update LPCOM_MAILBOX set LM_FRWD_TIME=?1 where LM_PROP_NO=?2 and LM_TO_USR=?3 and LM_REFERENCE_ID=?4",nativeQuery=true)
	Integer updatemailforwartime(Date forwardtime,LpcomProposal lpcomProposal,String user,BigDecimal refernceId);
	
	@Query(value="select LWF_USER_GRP,LWF_FLOWPOINT_ID from LPCOM_CASE_DET_SALES join LPSTP_SCHEME on LS_SCHEME_ID=LPCDS_SCHEME_ID join LPSTP_WF_FLOWS on LWF_WORKFLOW_ID=LS_WF_RCU_ID where LPCDS_PROP_NO =?1 order by LWF_FLOWPOINT_ID",nativeQuery=true)
	List<Object[]> getWFidanduserid (LpcomProposal lpcomProposal);
	
	@Modifying
	@Transactional(readOnly=false)
	@Query(value="update LPCOM_PROP_DOCUMENTS set LPD_DOC_HOLDER=?1 where LPD_PROP_NO=?2",nativeQuery=true)
	Integer updateholder(String Holder,LpcomProposal lpcomProposal);
	
	
	@Modifying
	@Transactional(readOnly=false)
	@Query(value="update LPCOM_MAILBOX set LM_FRWD_TIME=?1  where LM_PROP_NO=?2 and LM_TO_USR=?3 and LM_TYPE=?4  and LM_REFERENCE_ID is not null and LM_FRWD_TIME is null",nativeQuery=true)
	Integer updatemailapproveforwartime(Date forwardtime,LpcomProposal lpcomProposal,String user,String type);
	
	@Modifying
	@Transactional(readOnly=false)
	@Query(value="update LPCOM_MAILBOX set LM_FRWD_TIME=?1  where LM_PROP_NO=?2 and LM_TO_USR=?3 and LM_TYPE=?4  and LM_REFERENCE_ID is null",nativeQuery=true)
	Integer updatemailRCUforwartime(Date forwardtime,LpcomProposal lpcomProposal,String user,String type );
		
	@Query(value="select (select count(*) from LPCOM_PROP_DOCUMENTS  where LPD_PROP_NO=?1 and  LPD_DOC_HOLDER=?2 and LPD_RCU_ACTION is not null)as rectot,(select count(*) from LPCOM_PROP_DOCUMENTS  where LPD_PROP_NO=?1) as total, (select count(*) from LPCOM_PROF_SAMPLING where LPS_PROP_NO=?1 and  LPS_HOLDER=?2 and LPS_CIBIL_STATUS is not null)as profrectot,(select count(*) from LPCOM_PROF_SAMPLING where LPS_PROP_NO=?1) as proftotal from dual",nativeQuery=true)
	List<Object[]> getsendflag (LpcomProposal lpcomProposal,String holder);
	
}
