package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.commodel.LpcomProfSampling;
import com.sai.lendperfect.commodel.LpcomProposal;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface LpcomProfSamplingRepo extends JpaRepository<LpcomProfSampling, BigDecimal> {
	
	List<LpcomProfSampling>findAllByLpcomProposalAndLpsCustIdAndLpsHolder(LpcomProposal lpcomProposal,BigDecimal lpsCustId,String lpsHolder);
	List<LpcomProfSampling>findAllByLpcomProposalAndLpsHolder(LpcomProposal lpcomProposal,String lpsHolder);
	
	@Query(value="select distinct (LCI_CUST_ID),(select LFBM_BORR_TYPE from LPCOM_SET_BORR_MAP where LFBM_CUST_ID=LPP_CUST_ID order by LFBM_BORR_TYPE fetch first row only),LCI_CUST_NAME from LPCOM_PROP_PARTIES join LPCOM_CUST_INFO on LPP_CUST_ID=LCI_CUST_ID  join LPCOM_SET_BORR_MAP on LPP_CUST_ID=LFBM_CUST_ID where LPP_PROP_NO =?1 and LCI_RECENT=?2 order by LCI_CUST_ID",nativeQuery=true)
	List<Object[]> findprofilesampling(LpcomProposal lpcomProposal, String lciRecent);
	
	@Query(value="select distinct (LCI_CUST_ID),(select LFBM_BORR_TYPE from LPCOM_SET_BORR_MAP where LFBM_CUST_ID=LPP_CUST_ID order by LFBM_BORR_TYPE fetch first row only),LCI_CUST_NAME from LPCOM_PROP_PARTIES join LPCOM_CUST_INFO on LPP_CUST_ID=LCI_CUST_ID  join LPCOM_SET_BORR_MAP on LPP_CUST_ID=LFBM_CUST_ID where LPP_PROP_NO =?1 and LCI_RECENT=?2 and LCI_CUST_ID=?3 order by LCI_CUST_ID",nativeQuery=true)
	List<Object[]> findprofilesamplingcust(LpcomProposal lpcomProposal, String lciRecent,BigDecimal custid);
	
	
	@Modifying
	@Transactional(readOnly=false)
	@Query(value="update LPCOM_PROF_SAMPLING set LPS_HOLDER=?1 where LPS_PROP_NO=?2 and LPS_CUST_ID=?3",nativeQuery=true)
	Integer updateprofileholder(String Holder,LpcomProposal lpcomProposal,BigDecimal custid);
	
	@Modifying
	@Transactional(readOnly=false)
	@Query(value="update LPCOM_PROF_SAMPLING set LPS_HOLDER=?1 where LPS_PROP_NO=?2",nativeQuery=true)
	Integer updateallholder(String Holder,LpcomProposal lpcomProposal);
	

}
