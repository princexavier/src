package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomInternalVal;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSecurity;


@Repository
public interface LpcomInternalValRepo extends JpaRepository<LpcomInternalVal, BigDecimal> {

	LpcomInternalVal findByLpcomSecurityAndLpcomProposal(LpcomSecurity lpcomSecurityObj,
			LpcomProposal lpcomProposal);

}
