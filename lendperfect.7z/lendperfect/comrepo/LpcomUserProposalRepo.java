package com.sai.lendperfect.comrepo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomUserProposal;
import com.sai.lendperfect.setupmodel.LpstpUser;

@Repository
public interface LpcomUserProposalRepo extends JpaRepository<LpcomUserProposal, Long> {
	
	List<LpcomUserProposal> findByLpstpUserOrderByLupSnoDesc(LpstpUser lpstpUser);
	LpcomUserProposal findByLpcomProposalAndLpstpUser(LpcomProposal lpcomProposal, LpstpUser lpstpUser);
	
}
