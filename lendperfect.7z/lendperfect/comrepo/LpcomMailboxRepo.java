package com.sai.lendperfect.comrepo;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomMailbox;
import com.sai.lendperfect.commodel.LpcomProposal;

@Repository
public interface LpcomMailboxRepo  extends JpaRepository<LpcomMailbox,Long>{
    
	@Query(value="select LM_PROP_NO,LWF_FLOW_DESC,LM_FROM_USR || ' - ' || LU_FIRST_NAME || ' ' || LU_LAST_NAME as LM_FROM_USR,LM_TO_USR || ' - ' || LU_FIRST_NAME || ' ' || LU_LAST_NAME as LM_TO_USR, LM_RECVD_TIME,LM_FRWD_TIME,LM_TYPE,LM_COMMENTS from LPCOM_MAILBOX,LPSTP_WF_FLOWPOINT,LPSTP_WF_FLOWS,lpstp_users where LM_FLOW_ID=LWF_FLOWPOINT_ID and LWF_FLOWPOINT=LWF_FLOW_ID and lu_user_id=LM_TO_USR and LM_PROP_NO=?1 ORDER BY LM_RECVD_TIME asc",nativeQuery=true)
	List[] findByWorkFlowDetails(String lpcomprslno);


	@Query(value="select DISTINCT LM_FROM_USR from LPCOM_MAILBOX  where LM_PROP_NO=?1 union select DISTINCT LM_TO_USR from LPCOM_MAILBOX  where LM_PROP_NO=?1",nativeQuery=true)
	List<Object> findByLpcomProposalOrderByLmType(LpcomProposal lpcomProposal);

	List<LpcomMailbox> findByLpcomProposal(LpcomProposal lpcomProposal);

	LpcomMailbox findByLpcomProposalAndLmRowId(LpcomProposal lpcomProposalobj, BigDecimal string);

	LpcomMailbox findByLpcomProposalAndLmToUsr(LpcomProposal lpcomProposalobj, String string);

	@Query(value="select LWP_PAGE_ACCESS from LPSTP_PRODUCT_DET join LPCUST_LOAN_DETAILS on LLD_PRDCODE= LPD_PROD_NEW_ID join LPSTP_SCHEME on LS_SUB_FACILITY = LPD_PRD_SUB_CAT join LPSTP_WORKFLOWS on LS_WF_PROCESS_ID=LW_WF_ID join LPCOM_MAILBOX on LW_WF_ID=LM_FLOW_ID join LPSTP_WF_FLOWS on LWF_WORKFLOW_ID=LW_WF_ID join LPSTP_WF_PAGELIST on LWP_FLOWPOINT_ID=LWF_FLOWPOINT_ID where  LLD_APPNO=?1 and LWP_PAGE_ID=?2 order by  TO_CHAR(LM_RECVD_TIME,'DD/MM/YYYY  hh:mm:ss') desc fetch first row only", nativeQuery=true)
	String getPageAccess(BigDecimal lpPropNo,BigDecimal pageId);
	@Query(value="select min(LWF_FLOWPOINT_ID) from LPSTP_WF_FLOWS where LWF_WORKFLOW_ID=?1 and LWF_WF_TYPE=?2", nativeQuery=true)
	long getFlowPointId(Long lsWfProcessId, String type);
	
	LpcomMailbox  findBylpcomProposal(LpcomProposal lpcomProposal);
	
	@Query(value="select LM_TO_USR,LM_TYPE,NVL(SUM(TO_DATE(LM_FRWD_TIME,'dd/mm/yyyy') - TO_DATE(LM_RECVD_TIME,'dd/mm/yyyy')),0) AS TYPE_COUNT  from LPCOM_MAILBOX where LM_PROP_NO=?1  GROUP BY LM_TO_USR,LM_TYPE order by lm_type",nativeQuery=true)
	List[] findByTATreports(String lpcomprslno);
	
	@Query(value="select min(LM_RECVD_TIME) as min_date, max(LM_FRWD_TIME) as max_date from LPCOM_MAILBOX where LM_PROP_NO=?1",nativeQuery=true)
	List[] findByTATmaxDaysreports(String lpcomprslno);
	
	
	
	
	@Query(value="select LM_PROP_NO,LM_TYPE,LM_FRWD_TIME  from LPCOM_MAILBOX where LM_PROP_NO=?1 and  LM_FRWD_TIME IS NULL and LM_TYPE=?2",nativeQuery=true)
	List<LpcomMailbox> findByLpcomProposalAndLmFrwdTimeIsNullAndLmType(BigDecimal lpcomProposalobj,String lmType);

	LpcomMailbox findByLpcomProposalAndLmReferenceIdAndLmFrwdTimeIsNull(LpcomProposal lpcomProposalobj,BigDecimal secID);

	LpcomMailbox findByLpcomProposalAndLmReferenceIdAndLmTypeAndLmFrwdTimeIsNull(LpcomProposal lpcomProposalobj, BigDecimal secID, String lmType);

	
	List<LpcomMailbox>findByLmReferenceId(BigDecimal secID);

	LpcomMailbox findByLpcomProposalAndLmTypeAndLmFrwdTimeIsNull(LpcomProposal lpcomProposal,String lmType);
	

}
