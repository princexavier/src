package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomTakeoverChklist;
import com.sai.lendperfect.corpmodel.LpcorpCirAnnex;
import com.sai.lendperfect.corpmodel.LpcorpExtRating;

@Repository
public interface LpcomTakeoverChklistRepo extends JpaRepository<LpcomTakeoverChklist,BigDecimal> {

	List<LpcomTakeoverChklist> findByLpcomProposal(LpcomProposal lpcomProposal);
	List<LpcomTakeoverChklist> findByLpcomProposalOrderByLtcRowId(LpcomProposal lpcomProposal);
	
	LpcomTakeoverChklist findByLpcomProposalAndLtcChklistItem(LpcomProposal lpcomProposal,String ltcChklistItem);

}
