package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomCustAddr;
import com.sai.lendperfect.commodel.LpcomCustDataInd;
import com.sai.lendperfect.commodel.LpcomCustInfo;




@Repository
public interface LpcomCustAddrRepo extends JpaRepository<LpcomCustAddr,BigDecimal>{
//	LpcomCustAddr findBylcaCustNewId(BigDecimal lcaCustNewId);
	//LpcomCustAddr findByLpcomCustInfo(LpcomCustInfo LpcomCustInfo);
	List<LpcomCustAddr> findAllByLpcomCustInfo(LpcomCustInfo LpcomCustInfo);
	LpcomCustAddr findByLpcomCustInfo(LpcomCustInfo LpcomCustInfo);

}
