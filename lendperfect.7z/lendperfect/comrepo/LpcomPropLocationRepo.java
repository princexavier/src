package com.sai.lendperfect.comrepo;
import java.math.BigDecimal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomPropLocation;

@Repository
public interface LpcomPropLocationRepo extends JpaRepository<LpcomPropLocation, BigDecimal>  {

}
