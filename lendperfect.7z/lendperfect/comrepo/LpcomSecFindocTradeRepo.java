package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecFindocTrade;


@Repository
public interface LpcomSecFindocTradeRepo extends JpaRepository<LpcomSecFindocTrade, Long> {
//	LpcomSecFindocTrade findByLsftSecId(BigDecimal lsftSecId);
}
