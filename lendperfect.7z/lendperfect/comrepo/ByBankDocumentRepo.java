package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.commodel.LpcomDocument;
import com.sai.lendperfect.commodel.LpcomProposal;


public interface ByBankDocumentRepo extends JpaRepository<LpcomDocument, Long>{

	List<LpcomDocument> findByLpcomProposal(LpcomProposal lpcomProposal);
	List<LpcomDocument> findByLpcomProposalAndLpdProdId(LpcomProposal lpcomProposal,BigDecimal prdId);
}
