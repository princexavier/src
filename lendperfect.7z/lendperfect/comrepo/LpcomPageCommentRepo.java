package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomPageComment;

@Repository
public interface LpcomPageCommentRepo extends JpaRepository<LpcomPageComment,Long>{

List<LpcomPageComment> findByLpcPageId(BigDecimal lpcPageId);

LpcomPageComment findByLpcHeader(String LpcHeader);

LpcomPageComment findBylpcRowIdAndLpcHeader(BigDecimal lpcRowId,String LpcHeader);

LpcomPageComment findBylpcRowId(BigDecimal lpcRowId);
}
