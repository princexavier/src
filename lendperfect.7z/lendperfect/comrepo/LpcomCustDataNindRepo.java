package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomCustDataNind;
import com.sai.lendperfect.commodel.LpcomCustInfo;


@Repository
public interface LpcomCustDataNindRepo extends JpaRepository<LpcomCustDataNind,Long> {
	
	List<LpcomCustDataNind> findByLcnBussNameIgnoreCaseContaining(String lcnBussName);
	List<LpcomCustDataNind> findAllByOrderByLcnCreatedOn();
	LpcomCustDataNind findByLpcomCustInfo(LpcomCustInfo LpcomCustInfo);
	
}
