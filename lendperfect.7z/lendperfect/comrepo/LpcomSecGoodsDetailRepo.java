package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecGoodsDet;

@Repository
public interface LpcomSecGoodsDetailRepo extends JpaRepository<LpcomSecGoodsDet,Long>{

//	LpcomSecGoodsDet findBylsgdSecId(BigDecimal bigDecimal);



}
