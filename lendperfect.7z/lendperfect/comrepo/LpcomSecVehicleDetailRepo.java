package com.sai.lendperfect.comrepo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecVehicleDet;
import com.sai.lendperfect.commodel.LpcomSecurity;

@Repository
public interface LpcomSecVehicleDetailRepo extends JpaRepository<LpcomSecVehicleDet, Long> {
	LpcomSecVehicleDet findByLpcomSecurity(LpcomSecurity lpcomSecurity);
}
