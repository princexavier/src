package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomPrevSanction;
import com.sai.lendperfect.commodel.LpcomProposal;


@Repository
public interface LpcomPrev3SanctionRepo extends JpaRepository<LpcomPrevSanction,BigDecimal> {

	List<LpcomPrevSanction>	findByLpcomProposalOrderByLpsOrderNo(LpcomProposal lpcomProposal);
}
