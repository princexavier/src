package com.sai.lendperfect.comrepo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomLegalVerifcation;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSecurity;

@Repository
public interface LpcomLegalVerifcationRepo extends JpaRepository<LpcomLegalVerifcation, Long> {
	LpcomLegalVerifcation findByLpcomProposalAndLpcomSecurity(LpcomProposal lpcomProposal, LpcomSecurity lpcomSecurity);
}
