package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.commodel.LpcomExposureDet;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcomExposureDetRepo extends JpaRepository<LpcomExposureDet, BigDecimal> {
	LpcomExposureDet findByLpcomProposalAndLedOrderNo(LpcomProposal lpcomProposal,BigDecimal ledOrderNo);
	List<LpcomExposureDet> findByLpcomProposalOrderByLedOrderNo(LpcomProposal lpcomProposal);
}
