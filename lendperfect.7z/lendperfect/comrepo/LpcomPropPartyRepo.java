package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomCustInfo;
import com.sai.lendperfect.commodel.LpcomPropParty;
import com.sai.lendperfect.commodel.LpcomProposal;

@Repository
public interface LpcomPropPartyRepo extends  JpaRepository<LpcomPropParty, BigDecimal>{
	
	
	LpcomPropParty findBylppCustId(BigDecimal lppCustId);
	
	List<LpcomProposal> findBylpcomProposal(LpcomProposal LpcomProposal);
	LpcomPropParty findByLpcomProposalAndLppCustId(LpcomProposal LpcomProposal,BigDecimal lppCustId);

	@Query("select DISTINCT  geoObj.sgmRowId, geoObj.sgmCityCode , geoObj.sgmCityName,geoObj.sgmParentId from StGeographyMaster geoObj where sgmStateCode=:sgmStateCode AND geoObj.sgmParentId=:sgmParentId ORDER BY   geoObj.sgmCityName DESC")
	public List<Object> getdistinctCityByStateCode(@Param("sgmStateCode")String sgmStateCode,@Param("sgmParentId")BigDecimal sgmParentId);
	List<Object[]> findDistinctParties(@Param("lpcomProposalObject")LpcomProposal lpcomProposalObject);
	List<LpcomPropParty> findByLpcomProposal(LpcomProposal lpcomProposal);
	LpcomPropParty findByLpcomProposalAndLpcomCustInfo(LpcomProposal lpcomProposal,LpcomCustInfo LpcomCustInfo);
	List<LpcomPropParty> findByLpcomProposalAndLppCustType(LpcomProposal lpcomProposal,String lppCustType);
	List<LpcomPropParty> findByLppCrnId(String crnNo);
	List<LpcomPropParty> findByLpcomProposalAndLppBorrower(LpcomProposal lpcomProposal,String lppBorrower);
}
