package com.sai.lendperfect.comrepo;
import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSourcingDet;

public interface LpcomSourcingDetRepo  extends JpaRepository<LpcomSourcingDet,Long> {

	LpcomProposal findByLpcomProposal(LpcomProposal lpcomProposal);
	LpcomSourcingDet findByLsdKleadId(String leadid);
	LpcomSourcingDet findAllByLpcomProposal(LpcomProposal lpcomProposal);
    LpcomSourcingDet findBylpcomProposal(LpcomProposal lpcomProposal);


}
