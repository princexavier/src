package com.sai.lendperfect.comrepo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecBankDeposit;
import com.sai.lendperfect.commodel.LpcomSecurity;

@Repository
public interface LpcomSecBankDepositRepo extends JpaRepository<LpcomSecBankDeposit, Long> {
	LpcomSecBankDeposit findByLpcomSecurity(LpcomSecurity lpcomSecurity);
}
