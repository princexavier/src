package com.sai.lendperfect.comrepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.commodel.LpcomDocument;

public interface LpcomChartReportRepo extends JpaRepository<LpcomDocument, Long>{
  
	
}
