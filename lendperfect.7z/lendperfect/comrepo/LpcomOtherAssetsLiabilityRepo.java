package com.sai.lendperfect.comrepo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.commodel.LpcomOtherAssetsLiability;
import com.sai.lendperfect.commodel.LpcomProposal;


@Repository
public interface LpcomOtherAssetsLiabilityRepo extends JpaRepository<LpcomOtherAssetsLiability, Long>{
	
	List<LpcomOtherAssetsLiability> findAllByLpcomProposalAndLpcustApplicantData(LpcomProposal lpcomProposal,LpcustApplicantData lpcustApplicantData);
	void deleteByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
}
