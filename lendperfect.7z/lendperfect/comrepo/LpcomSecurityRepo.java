package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecurity;

@Repository
public interface LpcomSecurityRepo extends JpaRepository<LpcomSecurity, Long> {
	LpcomSecurity findByLsSecClassificationAndLsSecType(BigDecimal lsSecClassification, BigDecimal lsSecType);

	LpcomSecurity findByLsSecIdAndLsSecType(Long lsSecId, BigDecimal lsSecType);
}
