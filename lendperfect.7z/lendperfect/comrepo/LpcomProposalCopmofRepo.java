package com.sai.lendperfect.comrepo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSecPropertyCopMof;


public interface LpcomProposalCopmofRepo extends JpaRepository <LpcomSecPropertyCopMof,Serializable>  {
	List<LpcomSecPropertyCopMof> findByLpcomProposal(LpcomProposal lpcomProposal);
	List<LpcomSecPropertyCopMof> findByLspcSecId(BigDecimal lspcSecId);
	List<LpcomSecPropertyCopMof> findByLpcomProposalAndLspcType(LpcomProposal lpcomProposal, String lspcType);
	List<LpcomSecPropertyCopMof> findDistinctByLpcomProposal(LpcomProposal lpcomProposal);


}
