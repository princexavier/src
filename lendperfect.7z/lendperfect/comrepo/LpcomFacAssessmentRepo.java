package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomFacAssessment;
import com.sai.lendperfect.commodel.LpcomGlobalVariable;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

@Repository
public interface LpcomFacAssessmentRepo extends JpaRepository<LpcomFacAssessment, BigDecimal> {
	
	List<LpcomFacAssessment> findAllByLpcomProposalAndLfaFacNoAndLfaAssessmntId(LpcomProposal lpcomProposal,BigDecimal lfaFacNo,BigDecimal lfaAssessmntId);
	List<LpcomFacAssessment> deleteAllByLpcomProposalAndLfaFacNoAndLfaAssessmntId(LpcomProposal lpcomProposal,BigDecimal lfaFacNo,BigDecimal lfaAssessmntId);
	@Query(value=" select LPSTP_PRODUCT_DET.LPD_PRD_DESC,LPSTP_PRODUCT_DET.LPD_PROD_NEW_ID from LPSTP_PRODUCT_DET join  LPCUST_LOAN_DETAILS on LLD_PRDCODE= LPD_PROD_NEW_ID where LLD_APPNO=?1 order by LPD_PROD_ID",nativeQuery=true)
	List<Object[]>findfacility(LpcomProposal lpcomProposal);
	@Query(value="select FIN_ROWTYPE,LA_LINEITEM_ID,FIN_FORMULA,FIN_ROWDESC  from LPSTP_ASSESSMENT join LPSTP_FINMASTER on LA_LINEITEM_ID=FIN_ROW_ID where LA_ASSMNT_ID=?1 order by LA_ROW_ID",nativeQuery=true)
	List<Object[]>findassmntLineItm(BigDecimal assmnt_Id);
	@Query(value="select LFA_ROW_ID,LFA_PROP_NO,LFA_CREATED_BY,LFA_CREATED_ON,LFA_MODIFIED_BY,LFA_MODIFIED_ON ,LFA_FAC_NO,LFA_ASSESSMNT_ID,LFA_LINEITEM_ID,LFA_LINEITEM_VALUE,LFA_LINEITEM_TYPE,FIN_ROWDESC,FIN_FORMULA   from LPCOM_FAC_ASSESSMENT join LPSTP_FINMASTER on FIN_ROW_ID=LFA_LINEITEM_ID where LFA_PROP_NO=?1 and LFA_FAC_NO=?2 and LFA_ASSESSMNT_ID=?3",nativeQuery=true)
	List<Object[]>findAllfacassmnt(LpcomProposal lpcomProposal,BigDecimal fac_no,BigDecimal assmnt_no);
	@Query(value="select LGV_GL_VAR_ID,LGV_GL_VAR_VALUE,LGV_GL_VAR_DESC  from LPCOM_GLOBAL_VARIABLE where LGV_PROP_NO=?1 and LGV_FAC_NO=?2 and LGV_PARTY_ID=?3",nativeQuery=true)
	List<Object[]>findCalAsteDetails(LpcomProposal lpcomProposal,BigDecimal fac_no,BigDecimal assmnt_no);
	@Query(value="select FIN_ROWDESC,LFF_FORM_VALUE,FIN_ELIG_TYPE from LPSTP_PRD_ASSMENT join LPSTP_ASSESSMENT on LPA_ASSMNT_ID = LA_ASSMNT_ID join LPSTP_FINMASTER on FIN_ROW_ID = LPSTP_ASSESSMENT.LA_LINEITEM_ID join LPSTP_FIN_FORMULA on FIN_FORMULA=LPSTP_FIN_FORMULA.LFF_FORM_ID where LPSTP_PRD_ASSMENT.LPA_ASSMNT_ID=?1 and LPA_PROD_ID=?2 and LPA_ASSMNT_TYPE=?3 order by FIN_SNO",nativeQuery=true)
	List<Object[]> findGetFormula(String lfaAssessmntId, BigDecimal lfaFacNo, String assementType);
	@Query(value="select LFF_FORM_VALUE from LPSTP_FIN_FORMULA where LFF_FORM_ID=?1",nativeQuery=true)
	String findFormulaFromFormula(String lfaAssessmntId);
	@Procedure(name = "PROC_ASSESSMENT_PARAMETERS")
	String PROC_ASSESSMENT_PARAMETERS(BigDecimal proposal_no,BigDecimal prod_code,String createdby,BigDecimal lfaAssessmntId);
}
