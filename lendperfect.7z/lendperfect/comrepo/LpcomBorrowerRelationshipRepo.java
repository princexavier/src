package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomPartiesRelationship;
import com.sai.lendperfect.commodel.LpcomProposal;

@Repository
public interface LpcomBorrowerRelationshipRepo extends JpaRepository<LpcomPartiesRelationship,BigDecimal> {

	List<LpcomPartiesRelationship> findByLpcomProposal(LpcomProposal lpcomProposal);

	List<LpcomPartiesRelationship> findByLpcomProposalAndLprCustId(LpcomProposal lpcomProposal, BigDecimal custId);

	LpcomPartiesRelationship findByLpcomProposalAndLprRelCustIdAndLprCustId(LpcomProposal lpcomProposal,
			BigDecimal lpshCustId, BigDecimal lpshShareheldCustId);

	LpcomPartiesRelationship findByLprRelCustIdAndLprCustId(BigDecimal lpshCustId, BigDecimal lpshShareheldCustId);
	
}
