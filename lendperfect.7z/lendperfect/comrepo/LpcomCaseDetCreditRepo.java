package com.sai.lendperfect.comrepo;
import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.commodel.LpcomCaseDetCredit;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcomCaseDetCreditRepo extends JpaRepository<LpcomCaseDetCredit, Long>{

	
	LpcomCaseDetCredit findByLpcomProposal(LpcomProposal lpcomProposal);

}
