package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSetBorrMap;

@Repository
public interface LpcomSetBorrMapRepo extends JpaRepository<LpcomSetBorrMap, Long>{
//	
//	List<LpcomSetBorrMap> findBylfbmBorrType(String borrowertype);
//	List<LpcomSetBorrMap> findBylfbmBorrTypeAndLfbmPropNo(String borrowertype,BigDecimal LfbmPropNo);
//	List<LpcomSetBorrMap> findBylfbmPropNo(BigDecimal LfbmPropNo);
//	List<LpcomSetBorrMap> findBylfbmPropNoAndLfbmBorrTypeAndLfbmCustOldId(BigDecimal LfbmPropNo,String lfbmBorrType,BigDecimal lfbmCustOldId);
//	List<LpcomSetBorrMap> findBylfbmPropNoAndLfbmSetId(BigDecimal lfbmPropId,BigDecimal lfbmSetId);
//	LpcomSetBorrMap findByLfbmSetIdAndLfbmBorrTypeAndLfbmCustOldId(BigDecimal lfbmSetId,String lfbmBorrType,BigDecimal lfbmCustOldId);
//	List<LpcomSetBorrMap> findBylfbmPropNoAndLfbmBorrTypeAndLfbmSetId(BigDecimal LfbmPropNo,String lfbmBorrType,BigDecimal LfbmSetId);
//	LpcomSetBorrMap findBylfbmPropNoAndLfbmBorrTypeAndLfbmSetIdAndLfbmCustOldId(BigDecimal LfbmPropNo,String lfbmBorrType,BigDecimal LfbmSetId,BigDecimal lfbmCustOldId);
//	List<LpcomSetBorrMap> findBylfbmPropNoAndLfbmBorrTypeAndLfbmCustNewId(BigDecimal LfbmPropNo,String lfbmBorrType,BigDecimal lfbmCustNewId);
//	List<LpcomSetBorrMap> findByLfbmPropNoAndLfbmCustNewId(BigDecimal LfbmPropNo,BigDecimal lfbmCustNewId);
	List<LpcomSetBorrMap> findByLpcomProposal(LpcomProposal lpcomProposal);
	List<LpcomSetBorrMap> findBorrower(@Param("lfbmBorrType")String lfbmBorrType,@Param("lpcomProposalObject")LpcomProposal lpcomProposalObject);
	List<LpcomSetBorrMap> findUniqueSetId(@Param("lfbmSetId")BigDecimal lfbmSetId,@Param("lpcomProposalObject")LpcomProposal lpcomProposalObject);
	List<LpcomSetBorrMap> findUniqueSetIdAndBorr(@Param("lfbmSetId")BigDecimal lfbmSetId,@Param("lpcomProposalObject")LpcomProposal lpcomProposalObject,@Param("lfbmBorrType")String borrowertype);
	List<LpcomSetBorrMap> findUniqueBorrInProposal(@Param("lfbmCustNewId")BigDecimal lfbmCustNewId,@Param("lpcomProposalObject")LpcomProposal lpcomProposalObject,@Param("lfbmBorrType")String borrowertype);
	List<Object[]> findDistinctBorrower(@Param("lpcomProposalObject")LpcomProposal lpcomProposalObject);
	List<LpcomSetBorrMap> findByLfbmCustIdAndLpcomProposal(BigDecimal lfbmCustId, LpcomProposal lpcomProposal);
	List<LpcomSetBorrMap> findByLpcomProposalAndLfbmCustIdAndLfbmBorrType(LpcomProposal lpcomProposal, BigDecimal lfbmCustId, String lfbmBorrType);
	List<LpcomSetBorrMap> findByLpcomProposalAndLfbmBorrType(LpcomProposal lpcomProposal, String lfbmBorrType);
	@Query(value="select   c.LF_FAC_STATUS,c.LF_PROP_NO,d.LCI_NEW_ID from LPCOM_SET_BORR_MAP a, LPCOM_PROPOSAL b , LPCORP_FACILITIES c,LPCOM_CUST_INFO d   where d.LCI_BCIF_NO=?1 and a.LFBM_CUST_NEW_ID=d.LCI_NEW_ID and a.LFBM_PROP_NO=b.LP_PROP_NO and b.LP_PROP_NO=c.LF_PROP_NO",nativeQuery=true)
	List<Object[]> findByLciBcifNo(String lciBcifNo);
	LpcomSetBorrMap findByLpcomProposalAndLfbmBorrTypeAndLfbmFacNo(LpcomProposal lpcomProposal,String lfbmBorrType,BigDecimal lfbmFacNo);
}

