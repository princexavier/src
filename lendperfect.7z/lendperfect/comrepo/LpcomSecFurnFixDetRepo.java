package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecFurnFixDet;
import com.sai.lendperfect.commodel.LpcomSecurity;


@Repository
public interface LpcomSecFurnFixDetRepo extends JpaRepository<LpcomSecFurnFixDet, Long> {
	LpcomSecFurnFixDet findByLpcomSecurity(LpcomSecurity lpcomSecurity);
}
