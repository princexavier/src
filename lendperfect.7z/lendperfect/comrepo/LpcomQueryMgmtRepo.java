package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomQueryMgmt;

public interface LpcomQueryMgmtRepo extends JpaRepository<LpcomQueryMgmt,BigDecimal>{
	
	LpcomQueryMgmt findByLqmQueryId(String queryId);
	List<LpcomQueryMgmt> findByLpcomProposal(LpcomProposal lpcomProposal);
	List<LpcomQueryMgmt> findByLqmSender(String usrId);
	long findQueryCount(@Param("propId") BigDecimal lpPropNo);
	List<LpcomQueryMgmt> findByLqmRecipientAndLqmResponseAndLqmRecentOrderByLqmCreatedOn(String receiver,String response,String recent);
	List<LpcomQueryMgmt> findByLpcomProposalAndLqmQueryId(LpcomProposal lpcomProposal,String lqmQueryId);
	LpcomQueryMgmt findByLpcomProposalAndLqmQueryIdAndLqmRecipientAndLqmRecent(LpcomProposal lpcomProposal,String lqmQueryId,String lqmRecipient,String lqmRecent);
	List<LpcomQueryMgmt> findByLqmSenderAndLqmRecentAndLqmResponseNotNullAndLqmClosed(String lqmRecipient,String lqmRecent,String lqmClosed);
	List<LpcomQueryMgmt> findByLpcomProposalAndLqmQueryIdAndLqmRecipientOrderByLqmVersion(LpcomProposal lpcomProposal,String lqmQueryId,String lqmRecipient);
	List<LpcomQueryMgmt> findByLqmSenderAndLpcomProposalAndLqmVersion(String userId,LpcomProposal lpcomProposal,BigDecimal lqmVersion); //for query History
	List<LpcomQueryMgmt> findByLpcomProposalAndLqmVersion(LpcomProposal lpcomProposal,BigDecimal lqmVersion);
	
	@Modifying
	@Transactional(readOnly=false)
	@Query(value="update LPCOM_DOC_ATTACHMENT set LDA_QUERY_ID=?1,LDA_Q_TYPE=?5,LDA_Q_VERSION=?6 where LDA_PROP_NO=?2 and LDA_DOC_ID=?3 and LDA_QUERY_ID=?4",nativeQuery=true)
	Integer updatequeryid(String newqueryid,LpcomProposal lpcomProposal,BigDecimal docid,String queryid,String qtype,BigDecimal version);
	
	
	@Query(value="select count (*) from LPCOM_QUERY_MGMT where LQM_RECIPIENT =?1 and LQM_RESPONSE is null and LQM_RECENT='Y'",nativeQuery=true)
	String receivedmailcount(String userid);
	
	
	@Query(value="select count(*) from  LPCOM_QUERY_MGMT where LQM_SENDER=?1 and LQM_RESPONSE is not null and LQM_RECENT='Y' and  LQM_CLOSED='N'",nativeQuery=true)
	String resolveddmailcount(String userid);
	
	
	
}
