package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomDocAttachment;
import com.sai.lendperfect.commodel.LpcomProposal;

@Repository
public interface LpcomDocAttachmentRepo  extends JpaRepository<LpcomDocAttachment, BigDecimal>{
	
	List<LpcomDocAttachment>findAllByLpcomProposalAndLdaPageIdAndLdaDocId(LpcomProposal lpcomProposal,String ldaPageId,BigDecimal ldaDocId);
	List<LpcomDocAttachment> deleteAllByLpcomProposalAndLdaRowId(LpcomProposal lpcomProposal,BigDecimal ldaRowId);
	List<LpcomDocAttachment>findAllByLpcomProposalAndLdaPageIdAndLdaDocName(LpcomProposal lpcomProposal,String ldaPageId,String ldaDocName);
	LpcomDocAttachment findByLpcomProposalAndLdaCustId(LpcomProposal lpcomProposal, BigDecimal custId);
	@Query(value="select LDA_DOC_LOCATION from LPCOM_DOC_ATTACHMENT where LDA_PROP_NO=?1 and LDA_PAGE_ID=?2 and LDA_DOC_ID=?3 and LDA_DOC_NAME=?4",nativeQuery=true)
	String findlocation(LpcomProposal lpcomProposal,String ldaPageId,BigDecimal ldaDocId,String ldaDocName);

	List<LpcomDocAttachment> findByLpcomProposalAndLdaCustIdIn(LpcomProposal lpcomProposal, List<BigDecimal> custId);

	List<LpcomDocAttachment> findAllByLpcomProposalAndLdaPageIdAndLdaDocIdAndLdaQueryIdAndLdaQVersion(LpcomProposal lpcomProposal,String ldaPageId,BigDecimal ldaDocId,String queryId,BigDecimal version);
	LpcomDocAttachment findByLpcomProposalAndLdaPageId(LpcomProposal lpcomProposal, String pageId);
	String findMaxOrderNoBasedLpcomProposalAndLdaSecId(@Param("propNo") BigDecimal propNo, @Param("ldaSecId") BigDecimal ldaSecId);
	List<LpcomDocAttachment> findAllByLpcomProposalAndLdaSecIdOrderByLdaOrderNo(LpcomProposal lpcomProposal,BigDecimal ldaSecId);

}
