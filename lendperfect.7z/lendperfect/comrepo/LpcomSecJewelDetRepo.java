package com.sai.lendperfect.comrepo;
import java.math.BigDecimal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomSecJewelDet;

@Repository
public interface LpcomSecJewelDetRepo extends  JpaRepository<LpcomSecJewelDet, BigDecimal>{

//	LpcomSecJewelDet findByLsjdSecId(BigDecimal lsjdSecId);

}
