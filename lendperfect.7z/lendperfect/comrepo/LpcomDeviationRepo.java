package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomDeviation;


@Repository
public interface LpcomDeviationRepo  extends JpaRepository<LpcomDeviation, Long> {

	LpcomDeviation findByLdDevIdAndLdPropNo(BigDecimal devId,BigDecimal propNo);

	LpcomDeviation findByLdDevIdAndLdPropNoAndLdPartyId(BigDecimal devId, BigDecimal propNo, BigDecimal lfbmCustNewId);

	LpcomDeviation findByLdDevIdAndLdPropNoAndLdFacId(BigDecimal devId, BigDecimal propNo, BigDecimal lbsmRowId);

	List<LpcomDeviation> findByLdPropNoOrderByLdRowId(BigDecimal propNo);

	List<LpcomDeviation> findByLdPropNoAndLdDevType(BigDecimal propNo, String devTyye);
	

}
