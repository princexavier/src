package com.sai.lendperfect.comrepo;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomPropTermsCond;
import com.sai.lendperfect.commodel.LpcomProposal;

@Repository
public interface LpcomPropTermsCondRepo   extends JpaRepository<LpcomPropTermsCond, BigDecimal>{

	List<LpcomPropTermsCond> findByLpcomProposal(LpcomProposal lpcomProposal);

	void deleteAllByLpcomProposal(LpcomProposal lpcomProposal);
	
	List<LpcomPropTermsCond> findByLpcomProposalAndLptcTypeAndLptcFacNoAndLptcDeleted(LpcomProposal lpcomProposal, String lptcType, BigDecimal lptcFacNo, String lptcDeleted);
	
	LpcomPropTermsCond findByLptcRowId(BigDecimal lptcRowId);

}
