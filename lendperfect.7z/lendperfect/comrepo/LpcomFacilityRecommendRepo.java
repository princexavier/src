package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.corpmodel.LpcorpFacility;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public interface LpcomFacilityRecommendRepo extends JpaRepository<LpcorpFacility,BigDecimal>{
	
	List<LpcorpFacility> findByLpcomProposalOrderByLfFacLevel(LpcomProposal LpcomProposal);
	
	List<LpcorpFacility> findByLpcomProposalAndLfFacParentAndLfFacLevelOrderByLfFacNo(LpcomProposal LpcomProposal,BigDecimal LfFacParent,BigDecimal LfFacLevel);
	
	LpcorpFacility findByLfFacNoAndLfFacLevel(BigDecimal lfFacNo,BigDecimal lfFacLevel);
	
	List<LpcorpFacility> findByLpcomProposalAndLfFacParentOrderByLfFacNo(LpcomProposal lfPLpcomProposalropNo,BigDecimal LfFacParent);
	
	List<LpcorpFacility> findByLpcomProposalAndLfFacLevel(LpcomProposal LpcomProposal,BigDecimal lfFacLevel);
	
	List<LpcorpFacility> findByLpcomProposal(LpcomProposal LpcomProposal);
	

}
