package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.commodel.LpcomCaseDetSale;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.setupmodel.LpstpScheme;


public interface LpcomCaseDetSaleRepo extends JpaRepository<LpcomCaseDetSale,Long>{

	LpcomCaseDetSale findByLpcomProposal(LpcomProposal lpcdsPropNo);

	LpstpScheme findByLpstpScheme(LpstpScheme lpstpScheme);

}
