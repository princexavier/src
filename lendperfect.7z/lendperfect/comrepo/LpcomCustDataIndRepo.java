package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomCustDataInd;
import com.sai.lendperfect.commodel.LpcomCustInfo;


@Repository
public interface LpcomCustDataIndRepo  extends JpaRepository<LpcomCustDataInd,Long> {
	
	List<LpcomCustDataInd> findByLciFirstNameIgnoreCaseContaining(String lciFirstName);
	List<LpcomCustDataInd> findAllByOrderByLciCreatedOn();
	LpcomCustDataInd findByLpcomCustInfo(LpcomCustInfo LpcomCustInfo);
	
}
