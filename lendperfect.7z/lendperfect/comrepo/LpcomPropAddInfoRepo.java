package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.commodel.LpcomPropAddInfo;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcomPropAddInfoRepo extends JpaRepository<LpcomPropAddInfo, Long> {

	@Query(value = "select propaddinfo.LPAI_PROP_NO,qualmastobj.SQM_ROW_ID,qualmastobj.SQM_COMMENT_HEADER,qualmastobj.SQM_TEMPLATE,propaddinfo.LPAI_COMMENTS,propaddinfo.LPAI_ROW_ID,propaddinfo.LPAI_CMT_ID,propaddinfo.LPAI_CMT_HEADING from ST_QUALITATIVE_MASTER qualmastobj left join LPCOM_PROP_ADD_INFO propaddinfo on qualmastobj.SQM_ROW_ID=propaddinfo.LPAI_CMT_ID and  propaddinfo.LPAI_PROP_NO= ?1 where qualmastobj.SQM_COMMENT_FOR= ?2 and qualmastobj.SQM_BIZ_VERTICAL= ?3", nativeQuery = true)
	List<Object[]> findAdditionalInfoDetails(BigDecimal lpaiPropNo, String lpaiCmtFor, BigDecimal sqmBizVertical);
	
	@Query(value = "select propaddinfo.LPAI_PROP_NO,qualmastobj.SQM_ROW_ID,qualmastobj.SQM_COMMENT_HEADER,qualmastobj.SQM_TEMPLATE,propaddinfo.LPAI_COMMENTS,propaddinfo.LPAI_ROW_ID,propaddinfo.LPAI_CMT_ID,propaddinfo.LPAI_CMT_HEADING from ST_QUALITATIVE_MASTER qualmastobj left join LPCOM_PROP_ADD_INFO propaddinfo on qualmastobj.SQM_ROW_ID=propaddinfo.LPAI_CMT_ID and  propaddinfo.LPAI_PROP_NO= ?1 and propaddinfo.LPAI_APP_ID= ?4 where qualmastobj.SQM_COMMENT_FOR= ?2 and qualmastobj.SQM_BIZ_VERTICAL= ?3", nativeQuery = true)
	List<Object[]> findAdditionalInfoDetailsAI(BigDecimal lpaiPropNo, String lpaiCmtFor, BigDecimal sqmBizVertical, BigDecimal lpaiAppId);

	LpcomPropAddInfo findByLpaiCmtIdAndLpaiRowIdAndLpcomProposal(BigDecimal lpaiCmtId, BigDecimal lpaiRowId, LpcomProposal lpcomProposal);

	List<LpcomPropAddInfo> findByLpaiCmtForAndLpaiCmtIdAndLpcomProposal(String lpaiCmtFor, BigDecimal lpaiCmtId, LpcomProposal lpcomProposal);

	List<LpcomPropAddInfo> findByLpcomProposalAndLpaiCmtFor(LpcomProposal lpPropNo, String type);

	// List<Object[]> findAdditionalInfoDetails(Long ladId ,String
	// lpaiCmtFor,BigDecimal sqmBizVertical);
	List<LpcomPropAddInfo> findByLpaiCmtForAndLpcustApplicantDataAndLpcomProposalAndLpaiCmtId(String lpaiCmtFor, LpcustApplicantData lpcustApplicantData, LpcomProposal lpcomProposal, BigDecimal lpaiCmtId);

	LpcomPropAddInfo findByLpcomProposalAndLpcustApplicantDataAndLpaiCmtHeading(LpcomProposal lpPropNo, LpcustApplicantData lpcustApplicantData, String lpaiCmtHeading);

}
