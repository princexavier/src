package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.commodel.LpcomRcuApproval;
import com.sai.lendperfect.commodel.LpcomProposal;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface LpcomRcuApprovalRepo extends JpaRepository<LpcomRcuApproval, BigDecimal>{
	
	List<LpcomRcuApproval>findAllByLpcomProposal(LpcomProposal lpcomProposal);

}
