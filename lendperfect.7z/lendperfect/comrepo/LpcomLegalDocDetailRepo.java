package com.sai.lendperfect.comrepo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.sai.lendperfect.commodel.LpcomLegalDocDetail;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSecurity;

@Repository
public interface LpcomLegalDocDetailRepo  extends JpaRepository<LpcomLegalDocDetail, Long> {
	List<LpcomLegalDocDetail> findByLpcomProposalAndLpcomSecurityOrderByLlddSeqNo(LpcomProposal lpcomProposal, LpcomSecurity lpcomSecurity);
	LpcomLegalDocDetail findByLpcomProposalAndLpcomSecurityAndLlddRowId(LpcomProposal lpcomProposal, LpcomSecurity lpcomSecurity, long llddRowId);
}
