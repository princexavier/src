package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomSecFacMapping;
import com.sai.lendperfect.commodel.LpcomSecurity;

@Repository
public interface LpcomSecFacMappingRepo extends JpaRepository<LpcomSecFacMapping, BigDecimal> {
	List<LpcomSecFacMapping> findByLpcomSecurity(LpcomSecurity lpcomSecurity);

	List<LpcomSecFacMapping> findByLpcomSecurityAndLsfmFacNo(LpcomSecurity lpcomSecurity, BigDecimal lsfmFacNo);

	List<LpcomSecFacMapping> findByLsfmFacNo(BigDecimal lsfmFacNo);

	List<LpcomSecFacMapping> findByLsfmFacNoAndLpcomProposal(BigDecimal lsfmFacNo, LpcomProposal lpcomProposal);

	List<LpcomSecFacMapping> findByLpcomProposal(LpcomProposal lpPropNo);

	List<LpcomSecFacMapping> findByLpcomProposalAndLsfmFacNoAndLfsmAttachedAs(LpcomProposal lpPropNo, BigDecimal lsfmFacNo, String lsfmAttachedAs);

	@Query(value="SELECT  distinct(LSFM_SEC_ID) FROM LPCOM_SEC_FAC_MAPPING   WHERE  LSFM_PROP_NO=?1",nativeQuery=true)
	List<Object> selectDistinctSecIdBasedOnProposal(LpcomProposal lfdPropNo);
	
	List<LpcomSecFacMapping> findByLpcomProposalAndLpcomSecurity(LpcomProposal lpcomProposal, LpcomSecurity lpcomSecurity);
}
