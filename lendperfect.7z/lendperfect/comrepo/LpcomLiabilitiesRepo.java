package com.sai.lendperfect.comrepo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.commodel.LpcomLiability;
import com.sai.lendperfect.commodel.LpcomProposal;



@Repository
public interface LpcomLiabilitiesRepo extends JpaRepository<LpcomLiability, Long> {
	
	List<LpcomLiability> findByLpcomProposal(LpcomProposal lpcomProposal);	
	LpcomLiability findByLlSno(Long id);	
	List<LpcomLiability> findByLpcomProposalAndLpcustApplicantData(LpcomProposal lpcomProposal,LpcustApplicantData lpcustApplicantData);

	List<LpcomLiability> findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
	boolean existsByLlAccountno(String llAccountno);
	LpcomLiability findByLlAccountno(String llAccountno);
	void  deleteByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);

	
}