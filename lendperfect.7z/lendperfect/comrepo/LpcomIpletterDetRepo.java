package com.sai.lendperfect.comrepo;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.DecimalMax;
import com.sai.lendperfect.commodel.LpcomIpletterDet;
import com.sai.lendperfect.commodel.LpcomProposal;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface LpcomIpletterDetRepo  extends JpaRepository<LpcomIpletterDet, BigDecimal>{
	
	@Query(value="select LSD_RM_USER,LSD_ROW_ID from LPCOM_SOURCING_DET where LSD_PROP_NO=?1 ",nativeQuery=true)
	List<Object[]>findrmList(LpcomProposal lpcomProposal);
	
	@Query(value="select LFBM_CUST_ID,LCI_CUST_NAME,LFBM_SET_ID from LPCOM_SET_BORR_MAP join LPCOM_CUST_INFO on LFBM_CUST_ID=LCI_CUST_ID  where LFBM_BORR_TYPE='B'   and LFBM_PROP_NO=?  and LCI_RECENT='Y'",nativeQuery=true)
	List<Object[]>findBorrowerList(LpcomProposal lpcomProposal);
	
	@Query(value="select sum(LF_PROPOSED_LIMIT),LBSM_SET_ID from LPCOM_SET_FAC_MAP join LPCOM_FACILITIES on LBSM_FAC_NO=LF_FAC_NO and  LF_PROP_NO=LBSM_PROP_NO    where  LBSM_PROP_NO=?1 and LBSM_SET_ID=?2 group by LBSM_SET_ID",nativeQuery=true)
	List<Object[]>findsanList(LpcomProposal lpcomProposal,BigDecimal lbsmSetId);
	
	@Query(value="select LID_CUST_ID,LCI_CUST_NAME from LPCOM_IPLETTER_DET join LPCOM_CUST_INFO on LCI_CUST_ID=LID_CUST_ID  where LID_PROP_NO=?1 and LCI_RECENT='Y' ",nativeQuery=true)
	List<Object[]>findIPcustdet(LpcomProposal lpcomProposal);
	
	List<LpcomIpletterDet>findAllByLpcomProposal(LpcomProposal lpcomProposal);
	
	@Query(value="select  LPD_PRD_DESC,LF_PROPOSED_LIMIT,LF_TENOR,(select LBA_MCLR_TYPE ||'+'||LBA_PRD_DEFINED ||'='|| LBA_RECMD_VALUE from LPCOM_BUSS_APPROVALS where LBA_PROP_NO=LBSM_PROP_NO and  LBA_FAC_ID=LF_FAC_NO and LBA_CHARGE_TYPE='I') as intr from LPCOM_SET_FAC_MAP join LPCOM_FACILITIES on LBSM_FAC_NO=LF_FAC_NO and  LF_PROP_NO=LBSM_PROP_NO  join LPSTP_PRODUCT_DET on  LPD_PROD_NEW_ID=LF_PROD_ID where  LBSM_PROP_NO=?1 and LBSM_SET_ID=?2",nativeQuery=true)
	List<Object[]>findIPletterdet(LpcomProposal lpcomProposal,BigDecimal lbsmSetId);
	
	@Query(value="select LFBM_CUST_ID,LCI_CUST_NAME,LFBM_SET_ID from LPCOM_SET_BORR_MAP join LPCOM_CUST_INFO on LFBM_CUST_ID=LCI_CUST_ID  where LFBM_BORR_TYPE='C'   and LFBM_PROP_NO=? and LCI_RECENT='Y' ",nativeQuery=true)
	List<Object[]>findcoBorrowerList(LpcomProposal lpcomProposal);
	
	@Query(value="select LCI_CUST_ID,LCI_CUST_NAME from LPCOM_CUST_INFO where LCI_CUST_ID =?1 and LCI_RECENT='Y' ",nativeQuery=true)
	List<Object[]>findcustdet(BigDecimal custid);
	
	@Query(value="select count(*) from LPSTP_WF_FLOWS where LWF_WORKFLOW_ID=?1 and LWF_FLOW_LVL='IP' and LWF_FLOWPOINT=?2",nativeQuery=true)
	String ipaccess(BigDecimal wfid,BigDecimal flowid);
	
	@Query(value="select LLV_OPTION_DESC from LPCOM_CASE_DET_SALES join LPMAS_LISTOFVALUES on LLV_OPTION_VAL=LPCDS_CASE_TYPE where LPCDS_PROP_NO=?1 and LLV_HEADER='typeofcase' ",nativeQuery=true)
	String findtype(LpcomProposal lpcomProposal);
	
	@Query(value="select count(*) from LPCOM_IPLETTER_DET where LID_PROP_NO=?1 and LID_CUST_ID=?2 ",nativeQuery=true)
	String findflagapprove(LpcomProposal lpcomProposal,BigDecimal custid);
	
	@Query(value="select LPD_DOC_DESC,LPD_DOC_ID  from LPCOM_SET_FAC_MAP join LPCOM_FACILITIES on LBSM_FAC_NO=LF_FAC_NO and  LF_PROP_NO=LBSM_PROP_NO  join LPSTP_PRD_DOCS on  LPD_PROD_ID=LF_PROD_ID where  LBSM_PROP_NO=?1 and LBSM_SET_ID=?2",nativeQuery=true)
	List<Object[]>findprddoclist(LpcomProposal lpcomProposal,BigDecimal lbsmSetId);
	
	@Query(value="select LPD_DOC_DESC,LPD_DOC_ID from LPSTP_PRD_DOCS where LPD_PROD_ID=(select LPCDS_SCHEME_ID from LPCOM_CASE_DET_SALES where LPCDS_PROP_NO=?1)",nativeQuery=true)
	List<Object[]>findschemedoclist(LpcomProposal lpcomProposal);
	
	@Query(value="select  LBA_MCLR_TYPE,LBA_MCLR_RATE  from LPCOM_SET_FAC_MAP join LPCOM_FACILITIES on LBSM_FAC_NO=LF_FAC_NO and  LF_PROP_NO=LBSM_PROP_NO join LPCOM_BUSS_APPROVALS on LBA_PROP_NO=LBSM_PROP_NO and   LBA_FAC_ID=LF_FAC_NO join LPSTP_PRODUCT_DET on  LPD_PROD_NEW_ID=LF_PROD_ID   where  LBSM_PROP_NO=?1 and LBSM_SET_ID=?2 and LBA_CHARGE_TYPE='I'",nativeQuery=true)
	List<Object[]>findmclr(LpcomProposal lpcomProposal,BigDecimal lbsmSetId);
	
	@Query(value="select LPAI_CMT_HEADING,LPAI_COMMENTS from LPCOM_PROP_ADD_INFO where LPAI_PROP_NO=?1  and LPAI_CMT_FOR='AI' and LPAI_CMT_ID in ('6','7')  order by LPAI_CMT_ID",nativeQuery=true)
	List<Object[]>findfaccond(LpcomProposal lpcomProposal);
	
	@Query(value="select LPAI_CMT_HEADING,LPAI_COMMENTS,LPAI_CMT_ID from LPCOM_PROP_ADD_INFO where LPAI_PROP_NO=?1  and LPAI_CMT_FOR='AI' and LPAI_CMT_ID in ('8','9','10','11','12','13','14')  order by LPAI_CMT_ID",nativeQuery=true)
	List<Object[]>findseccond(LpcomProposal lpcomProposal);



	

}
