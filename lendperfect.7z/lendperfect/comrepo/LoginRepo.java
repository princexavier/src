package com.sai.lendperfect.comrepo;
import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sai.lendperfect.setupmodel.LpstpUser;
import com.sai.lendperfect.setupmodel.LpstpUserAccess;

public interface LoginRepo  extends JpaRepository<LpstpUserAccess, Long> {
	LpstpUserAccess findByLuaUserIdAndLuaSeqNo(String id, BigDecimal luaSeqNo);


}
