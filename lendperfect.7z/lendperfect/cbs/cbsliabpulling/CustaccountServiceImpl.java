package com.sai.lendperfect.cbs.cbsliabpulling;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.cbsmodel.Custaccount;
import com.sai.lendperfect.cbsrepo.CustaccountRepo;

@Service("CustaccountService")
@Transactional("cbsTransactionManager")
public class CustaccountServiceImpl implements CustaccountService {
	
	@Autowired
	CustaccountRepo custaccountRepo;
	
	@Override
	public List<Custaccount> findByCifId(String cifId) {
		
		return custaccountRepo.findByCifId(cifId);
	}

}
