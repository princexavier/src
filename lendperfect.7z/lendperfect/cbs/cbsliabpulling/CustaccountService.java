package com.sai.lendperfect.cbs.cbsliabpulling;

import java.util.*;
import com.sai.lendperfect.cbsmodel.Custaccount;

public interface CustaccountService {

	List<Custaccount> findByCifId(String cifId);
}
