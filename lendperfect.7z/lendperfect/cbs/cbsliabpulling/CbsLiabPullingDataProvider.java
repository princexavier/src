package com.sai.lendperfect.cbs.cbsliabpulling;

import java.math.BigDecimal;
import java.util.*;
import javax.servlet.http.HttpSession;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.cbsmodel.Custaccount;
import com.sai.lendperfect.commodel.LpcomLiability;
import com.sai.lendperfect.logging.Logging;

public class CbsLiabPullingDataProvider {
	
	@SuppressWarnings("unchecked")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		Map <String,Object> requestMap=new HashMap<String,Object>();
		requestMap = (Map<String, Object>) allRequestParams.get("requestData");
		String cbsId = serviceProvider.getCustomerDetailsService().findByLadId(Long.parseLong(requestMap.get("appId").toString())).getLadCbsid();
//		List<LpcomLiability> liabilityList = new ArrayList<LpcomLiability>();		
		
		try{
			 if(dpMethod.equals("getCbsLiabilities"))
				{
				 	if(cbsId != null){
				 		
				 		List<Custaccount> cbsLiabilityList = serviceProvider.getCustaccountService().findByCifId(cbsId);
				 		Iterator<Custaccount> cbsLiabilityListItr = cbsLiabilityList.iterator();
				 		while(cbsLiabilityListItr.hasNext()){
				 			
				 			Custaccount custaccount = new Custaccount();
				 			custaccount = cbsLiabilityListItr.next();
				 			LpcomLiability lpcomLiability = new LpcomLiability();
				 			
				 			if(serviceProvider.getLpcomLiabilitiesService().existsByLlAccountno(custaccount.getForacid())){
				 				lpcomLiability = serviceProvider.getLpcomLiabilitiesService().findByLlAccountno(custaccount.getForacid());
				 			}				 				
				 			if(lpcomLiability.getLlSno() == 0){
				 				lpcomLiability.setLlCreatedBy(session.getAttribute("userid").toString());
					 			lpcomLiability.setLlCreatedOn(new Date(System.currentTimeMillis()));
				 			}
				 			lpcomLiability.setLlOurbank("Y");
				 			lpcomLiability.setLlBank("PMCB");				 			
				 			lpcomLiability.setLlModifiedBy(session.getAttribute("userid").toString());
				 			lpcomLiability.setLlModifiedOn(new Date(System.currentTimeMillis()));
				 			lpcomLiability.setLlAccountno(custaccount.getForacid());
				 			lpcomLiability.setLlBalance(custaccount.getClrBalAmt());
				 			lpcomLiability.setLlCrdlimit(custaccount.getSanctLim());
				 			lpcomLiability.setLlLiabtype("Y");
				 			lpcomLiability.setLlSancdate(custaccount.getLimSanctDate());
				 			lpcomLiability.setLpcomProposal(serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString())));
				 			lpcomLiability.setLpcustApplicantData(serviceProvider.getCustomerDetailsService().findByLadId(Long.parseLong(requestMap.get("appId").toString())));
				 			serviceProvider.getLpcomLiabilitiesService().saveLpcomLiability(lpcomLiability);
				 		
//				 			liabilityList.add(serviceProvider.getLpcomLiabilitiesService().saveLpcomLiability(lpcomLiability));
				 		
				 		}				 		
				 	}
				 	
//				 	dataHashMap.put("liabilityList", liabilityList);
				 	responseHashMap.put("success", true);
				 	responseHashMap.put("responseData", dataHashMap);
				 	
				}
		}
		catch (Exception ex) {
			ex.printStackTrace();
			dataHashMap.put("errorData", ex.getLocalizedMessage());
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		
		return responseHashMap;
	}
}
