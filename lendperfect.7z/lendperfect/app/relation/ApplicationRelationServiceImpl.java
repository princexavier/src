package com.sai.lendperfect.app.relation;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.repo.LpApplicationRelationRepo;
import com.sai.lendperfect.commodel.LpcomProposal;;

@Service("ApplicationRelationService")
@Transactional
public class ApplicationRelationServiceImpl implements ApplicationRelationService {

	@Autowired
	LpApplicationRelationRepo lpApplicationRelationRepo;

	@Override
	public LpcustAppcustRelation save(LpcustAppcustRelation lpcustAppcustRelation) {
		return lpApplicationRelationRepo.save(lpcustAppcustRelation);
	}

	@Override
	public LpcustAppcustRelation findBylarId(Long larId) {
		return lpApplicationRelationRepo.findBylarId(larId);
	}

	@Override
	public LpcustAppcustRelation findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		return lpApplicationRelationRepo.findByLpcustApplicantData(lpcustApplicantData);
	}

	@Override
	public List<LpcustAppcustRelation> findByLpcomProposal(LpcomProposal lpcomProposal) {
		// TODO Auto-generated method stub
		return lpApplicationRelationRepo.findByLpcomProposal(lpcomProposal);
	}

	@Override
	public LpcustAppcustRelation findByLpcomProposalAndLarType(LpcomProposal lpcomProposal, String larType) {
		// TODO Auto-generated method stub
		return lpApplicationRelationRepo.findByLpcomProposalAndLarType(lpcomProposal, larType);
	}

	@Override
	public LpcustAppcustRelation findByLpcustApplicantDataAndLarType(LpcustApplicantData lpcustApplicantData, String larType) {
		// TODO Auto-generated method stub
		return lpApplicationRelationRepo.findByLpcustApplicantDataAndLarType(lpcustApplicantData, larType);
	}

	@Override
	public List<LpcustAppcustRelation> findByLpcomProposalOrderByLpcustApplicantData(LpcomProposal lpcomProposal) {
		// TODO Auto-generated method stub
		return lpApplicationRelationRepo.findByLpcomProposalOrderByLpcustApplicantData(lpcomProposal);
	}

	@Override
	public void deleteByLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		lpApplicationRelationRepo.deleteByLpcustApplicantData(lpcustApplicantData);

	}

	@Override
	public List<LpcustAppcustRelation> findByLpcomProposalOrderByLarId(LpcomProposal lpcomProposal) {
		return lpApplicationRelationRepo.findByLpcomProposalOrderByLarId(lpcomProposal);
	}

	@Override
	public List<LpcustAppcustRelation> findByLpcomProposalAndLarType1(LpcomProposal lpcomProposal, String larType) {
		// TODO Auto-generated method stub
		return lpApplicationRelationRepo.findByLpcomProposalAndLarTypeOrderByLarId(lpcomProposal, larType);
	}

	@Override
	public LpcustAppcustRelation findByLpcomProposalAndLpcustApplicantData(LpcomProposal lpcomProposal, LpcustApplicantData lpcustApplicantData) {
		// TODO Auto-generated method stub
		return lpApplicationRelationRepo.findByLpcomProposalAndLpcustApplicantData(lpcomProposal, lpcustApplicantData);
	}

}
