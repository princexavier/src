package com.sai.lendperfect.app.relation;

import java.util.List;

import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface ApplicationRelationService {
	LpcustAppcustRelation save(LpcustAppcustRelation lpcustAppcustRelation);

	List<LpcustAppcustRelation> findByLpcomProposal(LpcomProposal lpcomProposal);

	List<LpcustAppcustRelation> findByLpcomProposalOrderByLarId(LpcomProposal lpcomProposal);

	LpcustAppcustRelation findBylarId(Long larId);

	LpcustAppcustRelation findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);

	LpcustAppcustRelation findByLpcomProposalAndLarType(LpcomProposal lpcomProposal, String larType);

	LpcustAppcustRelation findByLpcustApplicantDataAndLarType(LpcustApplicantData lpcustApplicantData, String larType);

	List<LpcustAppcustRelation> findByLpcomProposalOrderByLpcustApplicantData(LpcomProposal lpcomProposal);

	void deleteByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);

	List<LpcustAppcustRelation> findByLpcomProposalAndLarType1(LpcomProposal lpcomProposal, String larType);

	LpcustAppcustRelation findByLpcomProposalAndLpcustApplicantData(LpcomProposal lpcomProposal, LpcustApplicantData lpcustApplicantData);
}
