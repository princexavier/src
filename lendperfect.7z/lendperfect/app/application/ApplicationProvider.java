package com.sai.lendperfect.app.application;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;

public class ApplicationProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map <String,Object> responseHashMap=new HashMap<String,Object>();
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		
		
		
		return dataHashMap;
		
		
	}

}
