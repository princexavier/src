package com.sai.lendperfect.app.application;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.util.Helper;

@Service("ApplicationService")
@Transactional
public class ApplicationServiceImpl implements ApplicationService {

	@PersistenceContext
	private EntityManager entityManager;
	Logger logger = LoggerFactory.getLogger(this.getClass());
	List max;
	BigDecimal b, propno;
	int digitlen;

	public BigDecimal getProposalNo(String orgScode) {
		StringBuffer sb = new StringBuffer(orgScode);
		try {
			Query query = entityManager.createNativeQuery("select nvl(max(LP_PROP_NO),0) from LPCOM_PROPOSAL");
			max = query.getResultList();
			b = new BigDecimal(max.get(0).toString());
			if (b.intValue() == 0) {
				digitlen = 10 - b.toString().length();
				for (int i = 1; i <= digitlen; i++) {
					sb.append("0");
				}
				b = new BigDecimal(sb.append(b.add(new BigDecimal(1))).toString());
			}

			else {
				StringBuffer substr = new StringBuffer(max.get(0).toString());
				String temp = substr.substring(5, 15).toString();
				propno = new BigDecimal(temp).add(new BigDecimal(1));
				digitlen = 10 - propno.toString().length();
				for (int i = 1; i <= digitlen; i++) {
					sb.append("0");
				}
				b = new BigDecimal(sb.append(propno).toString());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
	}

	@Override
	public long getOrgId() {
		long orgId = -1;
		try {

			String orgid = "LA_ORGCODE";
			String tablename = "LPSTP_ORGANISATIONS";
			Query query = entityManager.createNativeQuery("select nvl(max(" + orgid + "),0) from " + tablename + "");
			max = query.getResultList();
			orgId = Long.parseLong(max.get(0).toString());
			if (orgId == 0) {
				orgId = 10000 + 1;
			} else
				orgId = orgId + 1;
		} catch (Exception e) {
			e.printStackTrace();

		}

		return orgId;
	}
	
	
	
	@Override
	public String[] getOrgCode(String strCode,String strValue) {
		long orgId = -1;
		int intValue = 0;
		String strlevelvalue="";
		String[] strValues=new String[2];
		String strlevel="";
		java.text.NumberFormat nf=java.text.NumberFormat.getInstance();
		nf.setMinimumIntegerDigits(3);
		try {
			if(strCode.equalsIgnoreCase("C")) //c
			{
				//strValue="001000000000000";
				strlevelvalue="'R'";
				String strLValue="";
				String strTempValue ="";
				strTempValue = strValue;
				strLValue = strValue.substring(0,3);
				Query query = entityManager.createNativeQuery("select max(ORG_CODE) from organisations where org_code like '"+strLValue+"%' and ORG_LEVEL="+strlevelvalue+"");
				max = query.getResultList();
				strValue = Helper.correctNull((String) max.get(0));
				if(strValue.equals("") || strValue == null)
				{
					strValue = strTempValue;
					intValue = Integer.parseInt(strValue.substring(3,6));
					intValue = intValue + 1;
					strValue = strValue.substring(0,3)+nf.format((long)intValue)+strValue.substring(6,strValue.length());
				}
				else
				{
					intValue = Integer.parseInt(strValue.substring(3,6));
					intValue = intValue + 1;
					strValue = strValue.substring(0,3)+nf.format((long)intValue)+
					strValue.substring(6,strValue.length());
				}
				strValues[0]=strValue;
				strValues[1]="R";
			}
			else if(strCode.equalsIgnoreCase("R")) //R
			{
				//strValue="001009000000000";
				strlevelvalue=" 'D' ";
				String strLValue="";
				String strTempValue ="";
				strTempValue = strValue;
				strLValue = strValue.substring(0,6);
				Query query = entityManager.createNativeQuery("select max(ORG_CODE) from organisations where org_code like '"+strLValue+"%' and ORG_LEVEL="+strlevelvalue+"");
				max = query.getResultList();
				strValue = Helper.correctNull((String) max.get(0));
				if(strValue.equals("") || strValue == null)
				{
					strValue = strTempValue;
					intValue = Integer.parseInt(strValue.substring(6,9));
					intValue = intValue + 1;
					strValue = strValue.substring(0,6)+nf.format((long)intValue)+
					strValue.substring(9,strValue.length());
				}
				else 
				{
					intValue = Integer.parseInt(strValue.substring(6,9));
					intValue = intValue + 1;
					strValue = strValue.substring(0,6)+nf.format((long)intValue)+
					strValue.substring(9,strValue.length());
				}
				strValues[0]=strValue;
				strValues[1]="D";
			}
			else if(strCode.equalsIgnoreCase("D")) //D
			{
			//	strValue="001001001000000";
				strlevelvalue="'A'";
				String strLValue="";
				String strTempValue ="";
				strTempValue = strValue;
				strLValue = strValue.substring(0,9);
				Query query = entityManager.createNativeQuery("select max(ORG_CODE) from organisations where org_code like '"+strLValue+"%' and ORG_LEVEL="+strlevelvalue+"");
				max = query.getResultList();
				strValue = Helper.correctNull((String) max.get(0));
				if(strValue.equals("") || strValue == null || strValue.isEmpty())
				{
					strValue = strTempValue;
					intValue = Integer.parseInt(strValue.substring(9,12));
					intValue = intValue + 1;
					strValue= strValue.substring(0,9)+nf.format((long)intValue)+
					strValue.substring(12,strValue.length());
				}
				else
				{
					intValue = Integer.parseInt(strValue.substring(9,12));
					intValue = intValue + 1;
					strValue= strValue.substring(0,9)+nf.format((long)intValue)+
					strValue.substring(12,strValue.length());
				}
				strValues[0]=strValue;
				strValues[1]="A";
			}
			else if(strCode.equalsIgnoreCase("A")) //A
			{
			//	strValue="001001001001000";
				strlevelvalue="'B'";
				String strLValue="";
				String strTempValue ="";
				strTempValue = strValue;
				strLValue = strValue.substring(0,12);
				Query query = entityManager.createNativeQuery("select max(ORG_CODE) from organisations where org_code like '"+strLValue+"%' and ORG_LEVEL="+strlevelvalue+"");
				max = query.getResultList();
				strValue = Helper.correctNull((String) max.get(0));
				if(strValue.equals("") || strValue == null)
				{
					strValue = strTempValue;
					intValue = Integer.parseInt(strValue.substring(12,15));
					intValue = intValue + 1;
					strValue= strValue.substring(0,12)+nf.format((long)intValue)+
					strValue.substring(15,strValue.length());
				}
				else
				{
					intValue = Integer.parseInt(strValue.substring(12,15));
					intValue = intValue + 1;
					strValue= strValue.substring(0,12)+nf.format((long)intValue)+
					strValue.substring(15,strValue.length());
				}
				strValues[0]=strValue;
				strValues[1]="B";	
			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return strValues;
	}
	
}
