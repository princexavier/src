package com.sai.lendperfect.app.application;

import java.math.BigDecimal;

public interface ApplicationService {
	BigDecimal getProposalNo(String orgScode);

	long getOrgId();

	String[] getOrgCode(String strCode, String strValue);
}
