package com.sai.lendperfect.app.eduscholarshipdetails;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.app.educationloan.LpcustApplicantEduDetailService;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEduDetail;
import com.sai.lendperfect.application.model.LpcustApplicantEduScholar;
import com.sai.lendperfect.application.repo.EducationLoanDetailsRepo;
import com.sai.lendperfect.application.repo.LpApplicationDataRepo;
import com.sai.lendperfect.application.repo.LpcustApplicantEduScholarRepo;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.comrepo.LpcomProposalRepo;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.masterrepo.LpmasListofvalueRepo;

@Service("LpcustApplicantEduScholarService")
@Transactional
public class LpcustApplicantEduScholarServiceImpl implements LpcustApplicantEduScholarService{

	@Autowired
	LpcustApplicantEduScholarRepo lpcustApplicantEduScholarRepo;

	@Override
	public LpcustApplicantEduScholar saveApplicant(LpcustApplicantEduScholar lpcustApplicantEduScholar) {
		// TODO Auto-generated method stub
		return lpcustApplicantEduScholarRepo.save(lpcustApplicantEduScholar);
	}

	@Override
	public List<LpcustApplicantEduScholar> findByLpcomProposal(LpcomProposal lpcomProposal) {
		// TODO Auto-generated method stub
		return lpcustApplicantEduScholarRepo.findByLpcomProposal(lpcomProposal);
	}

	@Override
	public void deleteRecord(LpcustApplicantEduScholar lpcustApplicantEduScholar) {
		// TODO Auto-generated method stub
		lpcustApplicantEduScholarRepo.delete(lpcustApplicantEduScholar);
	}

	@Override
	public LpcustApplicantEduScholar findByLaescEduScholarId(Long id) {
		// TODO Auto-generated method stub
		return lpcustApplicantEduScholarRepo.findByLaescEduScholarId(id);
	}

	@Override
	public List<LpcustApplicantEduScholar> saveApplicantList(List<LpcustApplicantEduScholar> lpcustApplicantEduScholarList) {
		// TODO Auto-generated method stub
		return lpcustApplicantEduScholarRepo.save(lpcustApplicantEduScholarList);
	}

	
}
