package com.sai.lendperfect.app.eduscholarshipdetails;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEduDetail;
import com.sai.lendperfect.application.model.LpcustApplicantEduScholar;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;


public class LpcustApplicantEduScholarProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map <String,Object> responseHashMap=new HashMap<String,Object>();
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		LpcustApplicantData lpcustApplicantData = new LpcustApplicantData();
        //session.setAttribute("LP_COM_PROP_NO", "100000000000038");
		//BigDecimal propNo=(BigDecimal)session.getAttribute("LP_COM_PROP_NO");
		String userid = (String) session.getAttribute("userid");
		Map<String, Object> requestMap = new HashMap<String, Object>();
		
		try{
			
			
			if(dpMethod.equals("getRecord"))
			{
				LpcomProposal lpcomProposal=serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
				//lpcomProposal.setLpPropNo(propNo);
				List<LpcustApplicantEduScholar> lpcustApplicantEduScholar = serviceProvider.getLpcustApplicantEduScholarService().findByLpcomProposal(lpcomProposal);
				 dataHashMap.put("lpcustApplicantEduScholar",lpcustApplicantEduScholar);
				 if(lpcustApplicantEduScholar != null){
					 responseHashMap.put("success", true);
				 }else{
					 responseHashMap.put("success", false);
				 }
				 responseHashMap.put("responseData", dataHashMap);
			
			  
			}
			
				else	 
					 if(dpMethod.equals("deleteRecord"))
					 {
						 LpcustApplicantEduScholar lpcustApplicantEduScholar=new LpcustApplicantEduScholar();
						 //Long id = new Long(String.valueOf(allRequestParams.get("requestData")));						 
						 //Long id= Long.parseLong((allRequestParams.get("requestData")).toString());
						 requestMap = (Map<String, Object>) allRequestParams.get("requestData");
						 Long id = Long.parseLong(requestMap.get("id").toString());
						//Long id = new Long(String.valueOf(allRequestParams.get("requestData")));	
						 lpcustApplicantEduScholar = serviceProvider.getLpcustApplicantEduScholarService().findByLaescEduScholarId(id);
						 serviceProvider.getLpcustApplicantEduScholarService().deleteRecord(lpcustApplicantEduScholar);
						 responseHashMap.put("success", true);
					 }
			
			
				 else if(dpMethod.equals("saveRecord"))
					
							
					 {		
					 
					    	List<LpcustApplicantEduScholar> lpcustApplicantEduScholarList= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpcustApplicantEduScholar>>() { });
					    	
					    	    lpcustApplicantEduScholarList.forEach(lpcustApplicantEduScholar->{
					    	    	lpcustApplicantEduScholar.setLaescCreateddate(Helper.getSystemDate());
					    	    	lpcustApplicantEduScholar.setLaescCreatedby(session.getAttribute("userid").toString());
					    	    	lpcustApplicantEduScholar.setLaescModifieddby(session.getAttribute("userid").toString());
					    	    	lpcustApplicantEduScholar.setLpcomProposal(serviceProvider.getLpcomProposalService()
											.findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString())));
								 lpcustApplicantEduScholar.setLaescModifieddate(Helper.getSystemDate());
					    	});
					    	
					    List<LpcustApplicantEduScholar> lpcustApplicantEduScholarSaved = serviceProvider.getLpcustApplicantEduScholarService().saveApplicantList(lpcustApplicantEduScholarList);
					 	
						 dataHashMap.put("RecordSaved", lpcustApplicantEduScholarSaved);
						 responseHashMap.put("success", true);
						 responseHashMap.put("responseData", dataHashMap);
					  
					 }
			
				 else if(dpMethod.equals("getPropNo")){
						responseHashMap.put("propNo",session.getAttribute("LP_COM_PROP_NO"));
					}
					
			}
			catch (Exception ex) {
					ex.printStackTrace();
					dataHashMap.put("errorData", ex.getLocalizedMessage());
					responseHashMap.put("success", false);		
					responseHashMap.put("responseData", dataHashMap);
				}
			
			
			
			return responseHashMap;	
		}

	}
