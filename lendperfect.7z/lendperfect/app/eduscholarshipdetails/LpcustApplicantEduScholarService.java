package com.sai.lendperfect.app.eduscholarshipdetails;

import java.util.List;

import com.sai.lendperfect.application.model.LpcustApplicantEduDetail;
import com.sai.lendperfect.application.model.LpcustApplicantEduScholar;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcustApplicantEduScholarService {
	
	LpcustApplicantEduScholar saveApplicant(LpcustApplicantEduScholar lpcustApplicantEduScholar);
	List<LpcustApplicantEduScholar> findByLpcomProposal(LpcomProposal lpcomProposal);
	
	void deleteRecord(LpcustApplicantEduScholar lpcustApplicantEduScholar);
	
	LpcustApplicantEduScholar findByLaescEduScholarId(Long id);
	List<LpcustApplicantEduScholar> saveApplicantList(List<LpcustApplicantEduScholar> lpcustApplicantEduScholarList);

	
}

