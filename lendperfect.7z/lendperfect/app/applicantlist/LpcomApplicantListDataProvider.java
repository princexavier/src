package com.sai.lendperfect.app.applicantlist;

import java.math.BigDecimal;
import java.util.*;
import javax.servlet.http.HttpSession;
import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.logging.Logging;

public class LpcomApplicantListDataProvider {
	
	@SuppressWarnings("unchecked")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		
		try{
			if(dpMethod.equals("getApplicantList"))
			 {
				 LpcomProposal lpcomProposal=new LpcomProposal();
				 lpcomProposal.setLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
				 List<LpcustAppcustRelation> lpcustAppcustRelationList = serviceProvider.getApplicationRelationService().findByLpcomProposalOrderByLpcustApplicantData(lpcomProposal);
				 Iterator<LpcustAppcustRelation> lpcustAppcustRelationListItr = lpcustAppcustRelationList.iterator();
				 List<Map<String,Object>> lpcustApplicantDataList = new ArrayList<Map<String,Object>>();
				 while(lpcustAppcustRelationListItr.hasNext())
				 {
					 Map<String,Object> lpcustApplicantDataMap = new HashMap<String,Object>();
					 String type = null;
					 LpcustAppcustRelation lpcustAppcustRelation = lpcustAppcustRelationListItr.next();
					 LpcustApplicantData lpcustApplicantData = serviceProvider.getCustomerDetailsService().findByLadId(lpcustAppcustRelation.getLpcustApplicantData().getLadId());
					 lpcustApplicantDataMap.put("ladId",lpcustApplicantData.getLadId());
					 if(lpcustAppcustRelation.getLarType().equals("A"))
					 type="(Appl) - ";
					 if(lpcustAppcustRelation.getLarType().equals("C"))
					 type="(Co-Appl) - ";
					 if(lpcustAppcustRelation.getLarType().equals("G"))
					 type="(Guar) - ";
					 if(lpcustApplicantData.getLadMname() == null)
						 lpcustApplicantDataMap.put("ladFname",type+lpcustApplicantData.getLadFname()+" "+Helper.correctNull(lpcustApplicantData.getLadLname()));			
					 else
						 lpcustApplicantDataMap.put("ladFname",type+lpcustApplicantData.getLadFname()+" "+Helper.correctNull(lpcustApplicantData.getLadMname()) +" "+Helper.correctNull(lpcustApplicantData.getLadLname()));					 			 
					 lpcustApplicantDataList.add(lpcustApplicantDataMap);
				 }				 
				 dataHashMap.put("lpcustApplicantDataList",lpcustApplicantDataList);
				 responseHashMap.put("success",true);
				 responseHashMap.put("responseData", dataHashMap);
				 	
			 }
		}
		catch(Exception ex){
			ex.printStackTrace();
			dataHashMap.put("errorData", ex.getLocalizedMessage());
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		
		return responseHashMap;
	}
	

}
