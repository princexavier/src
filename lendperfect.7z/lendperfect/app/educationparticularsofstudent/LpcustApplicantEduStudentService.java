package com.sai.lendperfect.app.educationparticularsofstudent;

import com.sai.lendperfect.application.model.LpcustApplicantEduStudent;
import com.sai.lendperfect.commodel.LpcomProposal;



public interface LpcustApplicantEduStudentService {

	LpcustApplicantEduStudent saveEmployerType(LpcustApplicantEduStudent lpcustApplicantEduStudent);

	LpcustApplicantEduStudent findBylpcomProposal(LpcomProposal lpcomProposal);

}
