package com.sai.lendperfect.app.educationparticularsofstudent;

import java.math.BigDecimal;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustApplicantEduStudent;
import com.sai.lendperfect.application.repo.LpcustApplicantEduStudentRepo;
import com.sai.lendperfect.commodel.LpcomProposal;



@Service("LpcustApplicantEduStudentService")
@Transactional
public class LpcustApplicantEduStudentServiceImpl implements LpcustApplicantEduStudentService {
	
	@Autowired
	LpcustApplicantEduStudentRepo lpcustApplicantEduStudentRepo;
	
	@Override
	public LpcustApplicantEduStudent saveEmployerType(LpcustApplicantEduStudent lpcustApplicantEduStudent) {
		return lpcustApplicantEduStudentRepo.save(lpcustApplicantEduStudent);
	}

	@Override
	public LpcustApplicantEduStudent findBylpcomProposal(LpcomProposal lpcomProposal) {
		return lpcustApplicantEduStudentRepo.findBylpcomProposal(lpcomProposal);
	}

	
	
}
