package com.sai.lendperfect.app.otherincomes;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;

import com.sai.lendperfect.application.repo.LpcustApplicantOtherIncomeRepo;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;


@Service("LpcustApplicantOtherIncomeService")
@Transactional
public class LpcustApplicantOtherIncomeServiceImpl implements LpcustApplicantOtherIncomeService{

	@Autowired
	LpcustApplicantOtherIncomeRepo lpcustApplicantOtherIncomeRepo;
	
	@Override
	public List<LpcustApplicantOtherIncome> saveIncomeDetailsList(List<LpcustApplicantOtherIncome> lpcustApplicantOtherIncome) {
		// TODO Auto-generated method stub
		return lpcustApplicantOtherIncomeRepo.save(lpcustApplicantOtherIncome);
	}

	/*public void deleteLpcustApplicantOtherIncome(List<LpcustApplicantOtherIncome> lpcustApplicantOtherIncome){
		
		lpcustApplicantOtherIncomeRepo.delete(lpcustApplicantOtherIncome);
	}*/
	public LpcustApplicantOtherIncome findByLaoiId(Long id){
		// TODO Auto-generated method stub
		 return lpcustApplicantOtherIncomeRepo.findByLaoiId(id);
	}

	@Override
	public void delete(LpcustApplicantOtherIncome lpcustApplicantOtherIncome) {
		// TODO Auto-generated method stub
		lpcustApplicantOtherIncomeRepo.delete(lpcustApplicantOtherIncome);
	}

	
	@Override
	public List<LpcustApplicantOtherIncome> findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		// TODO Auto-generated method stub
		return lpcustApplicantOtherIncomeRepo.findByLpcustApplicantData(lpcustApplicantData);
	}

	@Override
	public LpcustApplicantOtherIncome saveIncomeDetails(LpcustApplicantOtherIncome lpcustApplicantOtherIncome) {
		// TODO Auto-generated method stub
		return lpcustApplicantOtherIncomeRepo.save(lpcustApplicantOtherIncome);
	}


	
	
}
