package com.sai.lendperfect.app.otherincomes;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;



public interface LpcustApplicantOtherIncomeService {
	
	LpcustApplicantOtherIncome saveIncomeDetails(LpcustApplicantOtherIncome lpcustApplicantOtherIncome);
	List<LpcustApplicantOtherIncome> saveIncomeDetailsList(List<LpcustApplicantOtherIncome> lpcustApplicantOtherIncome);
	//List<LpcustOtherIncome> findByLadId(LpcustApplicantData lpcustApplicantData);
	
	void delete(LpcustApplicantOtherIncome lpcustApplicantOtherIncome);
	//void deleteLpcustApplicantOtherIncome(List<LpcustApplicantOtherIncome> lpcustApplicantOtherIncome);
	//LpcustApplicantOtherIncome findByLaoiId(Long id);
	LpcustApplicantOtherIncome findByLaoiId(Long id);
	List<LpcustApplicantOtherIncome> findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
	}
