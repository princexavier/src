package com.sai.lendperfect.app.educationloan;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEduDetail;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;
import com.sai.lendperfect.application.repo.EducationLoanDetailsRepo;
import com.sai.lendperfect.application.repo.LpApplicationDataRepo;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.comrepo.LpcomProposalRepo;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.masterrepo.LpmasListofvalueRepo;

@Service("LpcustApplicantEduDetailService")
@Transactional
public class LpcustApplicantEduDetailServiceImpl implements LpcustApplicantEduDetailService{

	@Autowired
	EducationLoanDetailsRepo educationLoanDetailsRepo;

	@Override
	public List<LpcustApplicantEduDetail> saveApplicantList(List<LpcustApplicantEduDetail> lpcustApplicantEduDetail) {
		// TODO Auto-generated method stub
		return educationLoanDetailsRepo.save(lpcustApplicantEduDetail);
	}
	@Override
	public void deleteRecord(LpcustApplicantEduDetail lpcustApplicantEduDetail) {
		// TODO Auto-generated method stub
		educationLoanDetailsRepo.delete(lpcustApplicantEduDetail);
	}
	@Override
	public List<LpcustApplicantEduDetail> findByLpcomProposal(LpcomProposal lpcomProposal) {
		// TODO Auto-generated method stub
		return educationLoanDetailsRepo.findByLpcomProposal(lpcomProposal);
	}
	@Override
	public LpcustApplicantEduDetail findByLaedEduDetId(Long id) {
		// TODO Auto-generated method stub
		return educationLoanDetailsRepo.findByLaedEduDetId(id);
	}
}
