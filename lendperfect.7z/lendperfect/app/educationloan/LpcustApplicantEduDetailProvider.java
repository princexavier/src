package com.sai.lendperfect.app.educationloan;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEduDetail;
import com.sai.lendperfect.application.model.LpcustApplicantEduScholar;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;
import com.sai.lendperfect.setupmodel.LpstpProductDet;


public class LpcustApplicantEduDetailProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map <String,Object> responseHashMap=new HashMap<String,Object>();
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		LpcustApplicantData lpcustApplicantData = new LpcustApplicantData();
		//session.setAttribute("LP_COM_PROP_NO", "100000000000038");
		BigDecimal propNo=(BigDecimal)session.getAttribute("LP_COM_PROP_NO");
		String userid = (String) session.getAttribute("userid");
		
		try{
			
			if(dpMethod.equals("getRecord"))
			{
				LpcomProposal lpcomProposal=serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
				//lpcomProposal.setLpPropNo(propNo);
				List<LpcustApplicantEduDetail> lpcustApplicantEduDetail = serviceProvider.getLpcustApplicantEduDetailService().findByLpcomProposal(lpcomProposal);
				 dataHashMap.put("lpcustApplicantEduDetail",lpcustApplicantEduDetail);
				 if(lpcustApplicantEduDetail != null){
					 responseHashMap.put("success", true);
				 }else{
					 responseHashMap.put("success", false);
				 }
				 dataHashMap.put("propNo",session.getAttribute("LP_COM_PROP_NO"));
				 responseHashMap.put("responseData", dataHashMap);
			
			  
			}
			
				else	 
					 if(dpMethod.equals("deleteRecord"))
					 {
						 LpcustApplicantEduDetail lpcustApplicantEduDetail=new LpcustApplicantEduDetail();
						 //Long id = new Long(String.valueOf(allRequestParams.get("requestData")));
						 Long id= Long.parseLong((allRequestParams.get("requestData")).toString());
						 lpcustApplicantEduDetail = serviceProvider.getLpcustApplicantEduDetailService().findByLaedEduDetId(id);
						 serviceProvider.getLpcustApplicantEduDetailService().deleteRecord(lpcustApplicantEduDetail);
						 responseHashMap.put("success", true);
					 }
			
			
				 else if(dpMethod.equals("saveRecord"))
													 			
					{		
					 
					    	List<LpcustApplicantEduDetail> lpcustApplicantEduDetailList= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpcustApplicantEduDetail>>() { });
					    	
					    	lpcustApplicantEduDetailList.forEach(lpcustApplicantEduDetail->{
					    		lpcustApplicantEduDetail.setLaedCreateddate(Helper.getSystemDate());
					    		lpcustApplicantEduDetail.setLaedCreatedby(session.getAttribute("userid").toString());
					    		lpcustApplicantEduDetail.setLaedModifieddby(session.getAttribute("userid").toString());
					    		lpcustApplicantEduDetail.setLpcomProposal(serviceProvider.getLpcomProposalService()
											.findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString())));
					    		lpcustApplicantEduDetail.setLaedModifieddate(Helper.getSystemDate());
					    	});
					    	
					    List<LpcustApplicantEduDetail> lpcustApplicantEduDetailSaved = serviceProvider.getLpcustApplicantEduDetailService().saveApplicantList(lpcustApplicantEduDetailList);
					 	
						 dataHashMap.put("RecordSaved", lpcustApplicantEduDetailSaved);
						 responseHashMap.put("success", true);
						 responseHashMap.put("responseData", dataHashMap);
					  
					 }
			}
			catch (Exception ex) {
					ex.printStackTrace();
					dataHashMap.put("errorData", ex.getLocalizedMessage());
					responseHashMap.put("success", false);		
					responseHashMap.put("responseData", dataHashMap);
				}
			
			
			
			return responseHashMap;	
		}

	}
