package com.sai.lendperfect.app.educationloan;

import java.util.List;

import com.sai.lendperfect.application.model.LpcustApplicantEduDetail;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;
import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcustApplicantEduDetailService {
	
	//LpcustApplicantEduDetail saveApplicant(LpcustApplicantEduDetail lpcustApplicantEduDetail);
	List<LpcustApplicantEduDetail> saveApplicantList(List<LpcustApplicantEduDetail> lpcustApplicantEduDetail);
	List<LpcustApplicantEduDetail> findByLpcomProposal(LpcomProposal lpcomProposal);
	
	void deleteRecord(LpcustApplicantEduDetail lpcustApplicantEduDetail);
	
	//void deleteLpcustApplicantEduDetail(List<LpcustApplicantEduDetail> lpcustApplicantEduDetail);
	LpcustApplicantEduDetail findByLaedEduDetId(Long id);
	//List<LpcustApplicantEduDetail> findByLaedEduDetId(Long id);

	
}
