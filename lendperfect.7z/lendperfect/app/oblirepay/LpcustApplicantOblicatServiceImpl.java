package com.sai.lendperfect.app.oblirepay;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantOblicat;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;
import com.sai.lendperfect.application.repo.LpcustApplicantOblicatRepo;



@Service("LpcustApplicantOblicatService")
@Transactional
public class LpcustApplicantOblicatServiceImpl implements LpcustApplicantOblicatService{

	@Autowired
	LpcustApplicantOblicatRepo lpcustApplicantOblicatRepo;

	@Override
	public List<LpcustApplicantOblicat> saveIncomeDetailsList(List<LpcustApplicantOblicat> lpcustApplicantOblicatList) {
		// TODO Auto-generated method stub
		return lpcustApplicantOblicatRepo.save(lpcustApplicantOblicatList);
	}

	public void deleteLpcustApplicantOtherIncome(Long lpcustApplicantOtherIncome){
		
		lpcustApplicantOblicatRepo.delete(lpcustApplicantOtherIncome);
	}
	
	public List<LpcustApplicantOblicat> findByLaorId(Long id){
		// TODO Auto-generated method stub
		 return lpcustApplicantOblicatRepo.findByLaorId(id);
	}

	


	
	
	
}
