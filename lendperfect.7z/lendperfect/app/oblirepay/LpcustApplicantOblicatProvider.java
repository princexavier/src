package com.sai.lendperfect.app.oblirepay;

import java.math.BigDecimal;
import java.util.*;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantIncexpens;
import com.sai.lendperfect.application.model.LpcustApplicantOblicat;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;
import com.sai.lendperfect.application.model.LpcustApplicantOtherexp;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomLiability;
import com.sai.lendperfect.commodel.LpcomProposal;

import com.sai.lendperfect.logging.Logging;

public class LpcustApplicantOblicatProvider {
	
	@SuppressWarnings("unchecked")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {

		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		Map<String, Object> requestMap = new HashMap<String, Object>();
		LpcustApplicantData lpcustApplicantData=new LpcustApplicantData();
		
		LpcomProposal lpcomProposal=new LpcomProposal();
		long proposalNoValue = Long.parseLong(session.getAttribute("LP_COM_PROP_NO").toString());
		
		//Long appid=(long) 166;
		try {
			if (dpMethod.equals("getOblicationdetails")) {
				
				requestMap = (Map<String, Object>) allRequestParams.get("requestData");
				 Long ladId = Long.parseLong(requestMap.get("appId").toString());
				//Long ladId= Long.parseLong(requestMap.get("ladId").toString());
			    lpcustApplicantData.setLadId(ladId);
				
				
				List<LpcomLiability> lpcustApplicantOblicat=serviceProvider.getLpcomLiabilitiesService().findByLpcomProposalAndLpcustApplicantData(serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString())), lpcustApplicantData);
				List<LpcustApplicantOtherexp> lpcustApplicantOtherexp= serviceProvider.getLpcustApplicantOtherexpService().findByLpcustApplicantData(lpcustApplicantData);
				dataHashMap.put("lpcustApplicantOblicat",lpcustApplicantOblicat);
				dataHashMap.put("lpcustApplicantOtherexp",lpcustApplicantOtherexp);
				 if(lpcustApplicantOblicat != null || lpcustApplicantOtherexp != null )
				 {
					 responseHashMap.put("success", true);
				 }else{
					 responseHashMap.put("success", false);
				 }
				 responseHashMap.put("responseData", dataHashMap);
			
			}
			
			else if (dpMethod.equals("saveOblicationdetails")) {
				requestMap = (Map<String, Object>) allRequestParams.get("requestData");
				
				List<LpcomLiability> lpcustApplicantOblicatList = new ObjectMapper()
						.convertValue(requestMap.get("obligationRepayList"), new TypeReference<List<LpcomLiability>>(){});
				List<LpcustApplicantOtherexp> lpcustApplicantOtherexpList = new ObjectMapper()
						.convertValue(requestMap.get("otherExpenditureList"), new TypeReference<List<LpcustApplicantOtherexp>>(){});
				
				Long ladId= Long.parseLong(requestMap.get("ladId").toString());
				lpcustApplicantOblicatList.forEach(lpcustApplicantOblicat->{
					lpcustApplicantOblicat.setLlCreatedOn(Helper.getSystemDate());
					lpcustApplicantOblicat.setLlCreatedBy(session.getAttribute("userid").toString());
					lpcustApplicantOblicat.setLlModifiedBy(session.getAttribute("userid").toString());
					lpcustApplicantOblicat.setLlModifiedOn(Helper.getSystemDate());
					lpcustApplicantData.setLadId(ladId);
					lpcustApplicantOblicat.setLpcustApplicantData(lpcustApplicantData);
					if(lpcustApplicantOblicat.getLlBalance() == null)
						lpcustApplicantOblicat.setLlBalance(new BigDecimal(0));
					lpcustApplicantOblicat.setLpcomProposal(serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString())));
					if(lpcustApplicantOblicat.getLlBank().equals("PMCB"))
						lpcustApplicantOblicat.setLlOurbank("Y");
					else
						lpcustApplicantOblicat.setLlOurbank("N");
					LpcustAppcustRelation lpcustAppcustRelation = serviceProvider.getApplicationRelation().findByLpcomProposalAndLpcustApplicantData(serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString())), serviceProvider.getCustomerDetailsService().findByLadId(ladId));
					if(lpcustAppcustRelation.getLarType().equals("A"))
						lpcustApplicantOblicat.setLlLiabtype("Y");
					else
						lpcustApplicantOblicat.setLlLiabtype("N");
	    	});
		    	
				lpcustApplicantOtherexpList.forEach(lpcustApplicantOtherexp->{
					lpcustApplicantOtherexp.setLaoeCreatedon(Helper.getSystemDate());
					lpcustApplicantOtherexp.setLaoeCreatedby(session.getAttribute("userid").toString());
					lpcustApplicantOtherexp.setLaoeModifiedby(session.getAttribute("userid").toString());
					lpcustApplicantOtherexp.setLaoeModifiedon(Helper.getSystemDate());
					lpcustApplicantData.setLadId(ladId);
					lpcustApplicantOtherexp.setLpcustApplicantData(lpcustApplicantData);
				
	    	});
	    	
	    List<LpcomLiability> lpcustApplicantOblicatListSaved = serviceProvider.getLpcomLiabilitiesService().saveLpcomLiabilityList(lpcustApplicantOblicatList);
	    List<LpcustApplicantOtherexp> lpcustApplicantOtherExpListSaved = serviceProvider.getLpcustApplicantOtherexpService().saveIncomeDetailsList(lpcustApplicantOtherexpList);	
				
				dataHashMap.put("lpcustApplicantOblicat", lpcustApplicantOblicatListSaved);
				dataHashMap.put("lpcustApplicantOtherexp", lpcustApplicantOtherExpListSaved);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
			
			else	 
				 if(dpMethod.equals("deleteObliRecord"))
				 {
					 LpcomLiability lpcomLiability = new LpcomLiability();
						Long id = new Long(String.valueOf(allRequestParams.get("requestData")));
						lpcomLiability = serviceProvider.getLpcomLiabilitiesService().findByLlSno(id);
						serviceProvider.getLpcomLiabilitiesService().deleteLpcomLiability(lpcomLiability);
						responseHashMap.put("success", true);
						responseHashMap.put("responseData", dataHashMap);
				 }
				 else	 
					 if(dpMethod.equals("deleteotherexpRecord"))
					 {
						 LpcustApplicantOtherexp lpcustApplicantOtherexp=new LpcustApplicantOtherexp();
						 //Long id = new Long(String.valueOf(allRequestParams.get("requestData")));
						 Long id= Long.parseLong(allRequestParams.get("requestData").toString());
						 lpcustApplicantOtherexp = serviceProvider.getLpcustApplicantOtherexpService().findByLaoeId(id);
						 serviceProvider.getLpcustApplicantOtherexpService().delete(lpcustApplicantOtherexp);
						 responseHashMap.put("success", true);
					 }
		} catch (Exception ex) {
			ex.printStackTrace();
			dataHashMap.put("errorData", ex.getLocalizedMessage());
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}

		return responseHashMap;
	}

}
