package com.sai.lendperfect.app.oblirepay;

import java.util.List;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantOblicat;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;



public interface LpcustApplicantOblicatService {
	
	//LpcustApplicantOblicat saveIncomeDetails(LpcustApplicantOblicat lpcustApplicantOblicat);
	List<LpcustApplicantOblicat> saveIncomeDetailsList(List<LpcustApplicantOblicat> LpcustApplicantOblicatList);
	//List<LpcustOtherIncome> findByLadId(LpcustApplicantData lpcustApplicantData);
	
	//void deleteLpcomLiability(LpcustIncExpDetail lpcomLiability);
	
	//LpcustApplicantOblicat findByLaorId(Long id);
	List<LpcustApplicantOblicat> findByLaorId(Long id);
	}
