package com.sai.lendperfect.app.incexpenses;

import java.util.List;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantIncexpens;

import com.sai.lendperfect.commodel.LpcomProposal;

public interface LpcustApplicantIncexpensService {
	
	LpcustApplicantIncexpens saveIncomeDetails(LpcustApplicantIncexpens lpcustIncExpDetail);
  
	//List<LpcustApplicantIncexpens> findByLpcomProposal(LpcomProposal lpcomProposal);
	
	void deleteRecord(LpcustApplicantIncexpens lpcustApplicantIncexpens);
	
	LpcustApplicantIncexpens findByLaieId(Long id);
	
	LpcustApplicantIncexpens findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
	
	
	}
