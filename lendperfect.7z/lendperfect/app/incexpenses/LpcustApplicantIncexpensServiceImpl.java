package com.sai.lendperfect.app.incexpenses;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantIncexpens;

import com.sai.lendperfect.application.repo.LpcustApplicantIncexpensRepo;
import com.sai.lendperfect.commodel.LpcomProposal;

@Service("LpcustApplicantIncexpensService")
@Transactional
public class LpcustApplicantIncexpensServiceImpl implements LpcustApplicantIncexpensService{

	@Autowired
	LpcustApplicantIncexpensRepo lpcustApplicantIncexpensRepo;
	
	@Override
	public LpcustApplicantIncexpens saveIncomeDetails(LpcustApplicantIncexpens lpcustApplicantIncexpens) {
		// TODO Auto-generated method stub
		return (LpcustApplicantIncexpens) lpcustApplicantIncexpensRepo.save(lpcustApplicantIncexpens);
	}

	@Override
	public LpcustApplicantIncexpens findByLaieId(Long id) {
		// TODO Auto-generated method stub
		return lpcustApplicantIncexpensRepo.findByLaieId(id);
	}

	@Override
	public void deleteRecord(LpcustApplicantIncexpens lpcustApplicantIncexpens) {
		// TODO Auto-generated method stub
		lpcustApplicantIncexpensRepo.delete(lpcustApplicantIncexpens);
	}

	@Override
	public LpcustApplicantIncexpens findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		// TODO Auto-generated method stub
		return lpcustApplicantIncexpensRepo.findByLpcustApplicantData(lpcustApplicantData);
	}

	/*@Override
	public List<LpcustApplicantIncexpens> findByLpcomProposal(LpcomProposal lpcomProposal) {
		// TODO Auto-generated method stub
		return lpcustApplicantIncexpensRepo.findByLpcomProposal(lpcomProposal);
	}
*/
	
	

	
	



	
}
