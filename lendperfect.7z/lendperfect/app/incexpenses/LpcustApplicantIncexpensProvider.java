package com.sai.lendperfect.app.incexpenses;

import java.math.BigDecimal;
import java.util.*;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEduScholar;
import com.sai.lendperfect.application.model.LpcustApplicantIncexpens;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;
import com.sai.lendperfect.logging.Logging;

public class LpcustApplicantIncexpensProvider {

	@SuppressWarnings("unchecked")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {

		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		LpcustApplicantData lpcustApplicantData=new LpcustApplicantData();
		Map<String, Object> requestMap = new HashMap<String, Object>();
		
		//LpcomProposal  lpcomProposal=new LpcomProposal();
		//lpcomProposal.setLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
		
	    //Long ladId=(long) 166;
		//lpcustApplicantData.setLadId(ladId);
		
		try {
			if (dpMethod.equals("getIncomedetails")) {
				
				
//				Long appIallRequestParams.get("requestData");
				
				//Long ladId = new Long(String.valueOf(allRequestParams.get("requestData")));
				requestMap = (Map<String, Object>) allRequestParams.get("requestData");
				 Long ladId = Long.parseLong(requestMap.get("appId").toString());
//				Long ladId= Long.parseLong(allRequestParams.get("requestData").toString());
				
				lpcustApplicantData.setLadId(ladId);
				LpcustApplicantIncexpens lpcustApplicantIncexpens=serviceProvider.getLpcustApplicantIncexpensService().findByLpcustApplicantData(lpcustApplicantData);
				List<LpcustApplicantOtherIncome> lpcustApplicantOtherIncome=serviceProvider.getLpcustApplicantOtherIncomeService().findByLpcustApplicantData(lpcustApplicantData);
				dataHashMap.put("lpcustApplicantIncexpens",lpcustApplicantIncexpens);
				dataHashMap.put("lpcustApplicantOtherIncomeList",lpcustApplicantOtherIncome);
				 if(lpcustApplicantIncexpens != null || lpcustApplicantOtherIncome != null){
					 responseHashMap.put("success", true);
				 }else{
					 responseHashMap.put("success", false);
				 }
				 responseHashMap.put("responseData", dataHashMap);
			
			}
			
			 if (dpMethod.equals("saveIncomedetails")) {
				requestMap = (Map<String, Object>) allRequestParams.get("requestData");
				
				LpcustApplicantIncexpens lpcustApplicantIncexpens = new ObjectMapper()
						.convertValue(requestMap.get("incExpensesdetails"), LpcustApplicantIncexpens.class);
				List<LpcustApplicantOtherIncome> lpcustApplicantOtherIncomeList = new ObjectMapper()
						.convertValue(requestMap.get("otherIncomeList"), new TypeReference<List<LpcustApplicantOtherIncome>>(){});
				 
				Long ladId= Long.parseLong(requestMap.get("ladId").toString());
				
				lpcustApplicantIncexpens.setLaieCreatedBy((String)session.getAttribute("userid"));
				lpcustApplicantIncexpens.setLaieCreatedOn(Helper.getSystemDate());
				lpcustApplicantIncexpens.setLaieModifiedBy((String)session.getAttribute("userid"));
				lpcustApplicantIncexpens.setLaeiModifiedOn(Helper.getSystemDate());
				lpcustApplicantData.setLadId(ladId);
				lpcustApplicantIncexpens.setLpcustApplicantData(lpcustApplicantData);  
				
				serviceProvider.getLpcustApplicantIncexpensService().saveIncomeDetails(lpcustApplicantIncexpens);
				 
				
		    	
				lpcustApplicantOtherIncomeList.forEach(lpcustApplicantOtherIncome->{
					lpcustApplicantOtherIncome.setLaoiCreatedOn(Helper.getSystemDate());
					lpcustApplicantOtherIncome.setLaoiCreatedBy(session.getAttribute("userid").toString());
					lpcustApplicantOtherIncome.setLaoiModifiedBy(session.getAttribute("userid").toString());
					lpcustApplicantOtherIncome.setLaoiModifiedOn(Helper.getSystemDate());
					lpcustApplicantData.setLadId(ladId);
					lpcustApplicantOtherIncome.setLpcustApplicantData(lpcustApplicantData);
				
	    	});
	    	
	    List<LpcustApplicantOtherIncome> lpcustApplicantOtherIncomeSaved = serviceProvider.getLpcustApplicantOtherIncomeService().saveIncomeDetailsList(lpcustApplicantOtherIncomeList);
				
				
				dataHashMap.put("incExpensesdetails", lpcustApplicantIncexpens);
				dataHashMap.put("otherIncomeList", lpcustApplicantOtherIncomeSaved);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
			
			else	 
				 if(dpMethod.equals("deleteIncRecord"))
				 {
					 LpcustApplicantIncexpens lpcustApplicantIncexpens=new LpcustApplicantIncexpens();
					 //Long id = new Long(String.valueOf(allRequestParams.get("requestData")));
					 Long id= Long.parseLong((allRequestParams.get("requestData")).toString());
					 lpcustApplicantIncexpens = serviceProvider.getLpcustApplicantIncexpensService().findByLaieId(id);
					 serviceProvider.getLpcustApplicantIncexpensService().deleteRecord(lpcustApplicantIncexpens);
					 responseHashMap.put("success", true);
				 }
				 else	 
					 if(dpMethod.equals("deleteotherIncRecord"))
					 {
						 LpcustApplicantOtherIncome lpcustApplicantOtherIncome=new LpcustApplicantOtherIncome();
						 //Long id = new Long(String.valueOf(allRequestParams.get("requestData")));
						 Long id= Long.parseLong(allRequestParams.get("requestData").toString());
						 lpcustApplicantOtherIncome = serviceProvider.getLpcustApplicantOtherIncomeService().findByLaoiId(id);
						 serviceProvider.getLpcustApplicantOtherIncomeService().delete(lpcustApplicantOtherIncome);
						 responseHashMap.put("success", true);
					 }
		} catch (Exception ex) {
			ex.printStackTrace();
			dataHashMap.put("errorData", ex.getLocalizedMessage());
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}

		return responseHashMap;
	}

}
