package com.sai.lendperfect.app.applicantemployertype;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEmployer;

public interface LpcustApplicantEmployerService {

	LpcustApplicantEmployer saveEmployerType(LpcustApplicantEmployer lpcustApplicantEmployer);

	LpcustApplicantEmployer findByLadId(Long lng_custId);

	//LpcustApplicantEmployer findByLaePerempCustId(BigDecimal laePerempCustId);

	//LpcustApplicantEmployer findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);

}
