package com.sai.lendperfect.app.applicantemployertype;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEduCourseExp;
import com.sai.lendperfect.application.model.LpcustApplicantEmployer;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpDelegatedPower;

public class LpcustApplicantEmployerProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map <String,Object> responseHashMap = new HashMap<String,Object>();
		Map <String,Object> dataHashMap = new HashMap<String,Object>();
		LpcustApplicantData lpcustApplicantData = new LpcustApplicantData();
		LpcustApplicantEmployer lpcustApplicantEmployer = new LpcustApplicantEmployer();
		LpcustApplicantEmployer lpcustApplicantEmployerList = new LpcustApplicantEmployer();
		ObjectMapper mapper = new ObjectMapper();
		String userid = (String) session.getAttribute("userid");
		Timestamp sysDate = (Timestamp) Helper.getSystemDate();
		String appId = (String) session.getAttribute("laiAppid");
		try{
				if(dpMethod.equals("getApplicantList1"))
				 {
					 LpcomProposal lpcomProposal=new LpcomProposal();
					 lpcomProposal.setLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
					 List<LpcustAppcustRelation> lpcustAppcustRelationList = serviceProvider.getApplicationRelationService().findByLpcomProposal(lpcomProposal);
					 Iterator<LpcustAppcustRelation> lpcustAppcustRelationListItr = lpcustAppcustRelationList.iterator();
					 List<Map<String,Object>> lpcustApplicantDataList = new ArrayList<Map<String,Object>>();
					 String type = null;
					 while(lpcustAppcustRelationListItr.hasNext())
					 {
						Map<String,Object> lpcustApplicantDataMap = new HashMap<String,Object>();
						LpcustAppcustRelation lpcustAppcustRelation = lpcustAppcustRelationListItr.next();
						lpcustApplicantData = serviceProvider.getCustomerDetailsService().findByLadId(lpcustAppcustRelation.getLpcustApplicantData().getLadId()); 
						if(lpcustAppcustRelation.getLarType().equals("A"))
						type="(Appl) - ";
						if(lpcustAppcustRelation.getLarType().equals("C"))
						type="(Co-Appl) - ";
						if(lpcustAppcustRelation.getLarType().equals("G"))
						type="(Guar) - ";
						//lpcustApplicantEmployerList = serviceProvider.getLpcustApplicantEmployerService().findByLpcustApplicantData(lpcustApplicantData);
						if(lpcustApplicantEmployerList != null)
						{
							if(lpcustApplicantData.getLadMname() == null)
							{
								lpcustApplicantEmployerList.setLaePerempName(type+lpcustApplicantData.getLadFname()+" "+Helper.correctNull(lpcustApplicantData.getLadLname()));
							}
							else
							{
								lpcustApplicantEmployerList.setLaePerempName(type+lpcustApplicantData.getLadFname()+" "+Helper.correctNull(lpcustApplicantData.getLadMname()) +" "+Helper.correctNull(lpcustApplicantData.getLadLname()));
							}	
							dataHashMap.put("lpcustApplicantDataList",lpcustApplicantEmployerList);
						}
						if(lpcustApplicantEmployerList == null)
						{	
							//lpcustApplicantEmployer.setLpcustApplicantData(lpcustApplicantData);
							if(lpcustApplicantData.getLadMname() == null)
							{
								lpcustApplicantEmployer.setLaePerempName(type+lpcustApplicantData.getLadFname()+" "+Helper.correctNull(lpcustApplicantData.getLadLname()));
							}
							else 
							{
								lpcustApplicantEmployer.setLaePerempName(type+lpcustApplicantData.getLadFname()+" "+Helper.correctNull(lpcustApplicantData.getLadMname()) +" "+Helper.correctNull(lpcustApplicantData.getLadLname()));
							}	
						 	dataHashMap.put("lpcustApplicantDataList",lpcustApplicantEmployer);
						}
					 }						
					 responseHashMap.put("success",true);
					 responseHashMap.put("responseData", dataHashMap);
				 }		 	
				else if(dpMethod.equals("saveEmployerTypeDetail"))
				{
	 				Map<String,Object> requestMap = (Map<String,Object>)allRequestParams.get("requestData");
	 				
					lpcustApplicantEmployer = new ObjectMapper().convertValue(requestMap, LpcustApplicantEmployer.class);
					lpcustApplicantEmployer.setLaeCreatedby(Helper.correctNull(userid));
					lpcustApplicantEmployer.setLaeModifieddby(Helper.correctNull(userid));
					lpcustApplicantEmployer.setLaeCreateddate(sysDate);
					lpcustApplicantEmployer.setLaeModifieddate(sysDate);
					 if(lpcustApplicantEmployer.getLaeId() == 0)
					 {
						// lpcustApplicantData.setLadId(ladId);
						 //lpcustApplicantData.setLadId(lpcustApplicantEmployer.getLadId());
						// lpcustApplicantEmployer.setLpcustApplicantData(lpcustApplicantData);
						 lpcustApplicantEmployer = serviceProvider.getLpcustApplicantEmployerService().saveEmployerType(lpcustApplicantEmployer);
					 }
					 else{
						 lpcustApplicantEmployer = serviceProvider.getLpcustApplicantEmployerService().saveEmployerType(lpcustApplicantEmployer);
					 }
					 
					 dataHashMap.put("lpcustApplicantEmployer",lpcustApplicantEmployer);
					 responseHashMap.put("success", true);
					 responseHashMap.put("responseData", dataHashMap);
				}
				else if(dpMethod.equals("getEmploymentTypeDetails"))
				{
					//Map<String,Object> requestMap = (Map<String,Object>)allRequestParams.get("requestData");
					 Long lng_custId=new Long(allRequestParams.get("requestData").toString());
					//long lng_custId =  (long) session.getAttribute("CustId");
					lpcustApplicantData = serviceProvider.getCustomerDetailsService().findByID(lng_custId.longValue());	
					dataHashMap.put("lpcustApplicantData",lpcustApplicantData.getLadEmployment());
					//lpcustApplicantEmployer.setLaePerempCustId(lng_custId);
					//lpcustApplicantData.setLadId(lng_custId);
					lpcustApplicantEmployerList = serviceProvider.getLpcustApplicantEmployerService().findByLadId(lng_custId);	
					dataHashMap.put("lpcustApplicantEmployer",lpcustApplicantEmployerList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);
				}
				
			}catch(Exception e) {
				if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
						dataHashMap.put("errorData",new CustomErr(e.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
		return responseHashMap;
	}

}
