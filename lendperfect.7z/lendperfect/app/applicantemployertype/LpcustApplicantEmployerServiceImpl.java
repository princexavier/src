package com.sai.lendperfect.app.applicantemployertype;

import java.math.BigDecimal;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantEmployer;
import com.sai.lendperfect.application.repo.LpcustApplicantEmployerRepo;

@Service("LpcustApplicantEmployerService")
@Transactional
public class LpcustApplicantEmployerServiceImpl implements LpcustApplicantEmployerService {
	
	@Autowired
	LpcustApplicantEmployerRepo lpcustApplicantEmployerRepo;
	
	@Override
	public LpcustApplicantEmployer saveEmployerType(LpcustApplicantEmployer lpcustApplicantEmployer) {
		return lpcustApplicantEmployerRepo.save(lpcustApplicantEmployer);
	}

	@Override
	public LpcustApplicantEmployer findByLadId(Long lng_custId) {
		return lpcustApplicantEmployerRepo.findByLadId(lng_custId);
	}

	/*@Override
	public LpcustApplicantEmployer findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		// TODO Auto-generated method stub
		return lpcustApplicantEmployerRepo.findByLpcustApplicantData(lpcustApplicantData);
	}*/

	
	
	

	
}
