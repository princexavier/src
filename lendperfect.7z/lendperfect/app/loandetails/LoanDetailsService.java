package com.sai.lendperfect.app.loandetails;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.application.model.LpcustLoanDetail;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.setupmodel.LpstpPrdDocFee;

public interface LoanDetailsService {
	
	List<LpcustLoanDetail> saveDetiled(List<LpcustLoanDetail> lpcustLoanDetail);
	LpcustLoanDetail save(LpcustLoanDetail lpcustLoanDetail);
	LpcustLoanDetail findByLpcomProposal(LpcomProposal lpcomProposal);	
	List<LpcustLoanDetail> findByLpcomProposalList(LpcomProposal lpcomProposal);	
	LpcustLoanDetail findById(long lldSno);
	LpcustLoanDetail findByLldId(long lldId);
	LpcustLoanDetail findByLpcomProposalAndLldSno(LpcomProposal lpcomProposal, long lldSno);
	LpcustLoanDetail deleteloandetails(BigDecimal propNo,long sno,long prdCode);
	List<LpcustLoanDetail> findByLpProposal(LpcomProposal lpcomProposal);
	LpcustLoanDetail findByLpcomProposalAndLldPrdcode(LpcomProposal lpcomProposal, Long lfaFacNo);
	List<LpcustLoanDetail> findByLpProposalOrderByLldSno(LpcomProposal lpcomProposal);
}
