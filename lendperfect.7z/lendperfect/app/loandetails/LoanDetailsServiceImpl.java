package com.sai.lendperfect.app.loandetails;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustLoanDetail;
import com.sai.lendperfect.application.repo.LoanDetailsRepo;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.setupmodel.LpstpPrdDocFee;

@Service("LoanDetailsService")
@Transactional
public class LoanDetailsServiceImpl implements LoanDetailsService{

	@Autowired
	LoanDetailsRepo loanDetailsRepo;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public LpcustLoanDetail save(LpcustLoanDetail lpcustLoanDetail) {
		return loanDetailsRepo.save(lpcustLoanDetail);
	}

	
	@Override
	public LpcustLoanDetail findById(long lldSno) {
		return loanDetailsRepo.findByLldSno(lldSno);
	}


	


	@Override
	public LpcustLoanDetail findByLpcomProposalAndLldSno(LpcomProposal lpcomProposal, long lldSno) {
		// TODO Auto-generated method stub
		return loanDetailsRepo.findByLpcomProposalAndLldSno(lpcomProposal, lldSno);
	}

	@Override
	public LpcustLoanDetail deleteloandetails(BigDecimal propNo,long sno,long prdCode) {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("deleteProduct"); 

        //Declare the parameters in the same order
		query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(3, String.class, ParameterMode.IN);
     
        
        //Pass the parameter values
        query.setParameter(1, propNo+"");
        query.setParameter(2, sno+"");
        query.setParameter(3, prdCode+"");
       
        //Execute query
        query.execute();
		return null;
		
	}


	@Override
	public List<LpcustLoanDetail> saveDetiled(List<LpcustLoanDetail> lpcustLoanDetail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<LpcustLoanDetail> findByLpProposal(LpcomProposal lpcomProposal) {
		return loanDetailsRepo.findBylpcomProposal(lpcomProposal);
	}



	@Override
	public List<LpcustLoanDetail> findByLpProposalOrderByLldSno(LpcomProposal lpcomProposal) {
		return loanDetailsRepo.findBylpcomProposalOrderByLldSno(lpcomProposal);
	}


	@Override
	public LpcustLoanDetail findByLldId(long lldId) {
		// TODO Auto-generated method stub
		return loanDetailsRepo.findByLldId(lldId);
	}



	@Override
	public List<LpcustLoanDetail> findByLpcomProposalList(LpcomProposal lpcomProposal) {
		// TODO Auto-generated method stub
		return loanDetailsRepo.findBylpcomProposalOrderByLldSno(lpcomProposal);
	}



	@Override
	public LpcustLoanDetail findByLpcomProposalAndLldPrdcode(LpcomProposal lpcomProposal, Long lfaFacNo) {
		// TODO Auto-generated method stub
		return loanDetailsRepo.findByLpcomProposalAndLldPrdcode(lpcomProposal,lfaFacNo);
	}


	@Override
	public LpcustLoanDetail findByLpcomProposal(LpcomProposal lpcomProposal) {
		// TODO Auto-generated method stub
		return loanDetailsRepo.findByLpcomProposal(lpcomProposal);
	}



	




}
