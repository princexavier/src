package com.sai.lendperfect.app.loandetails;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustLoanDetail;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomCaseDetSale;
import com.sai.lendperfect.commodel.LpcomMailbox;
import com.sai.lendperfect.commodel.LpcomPropTermsCond;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomUserProposal;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasPageMaster;
import com.sai.lendperfect.setupmodel.LpstpPrdCoappguacount;
import com.sai.lendperfect.setupmodel.LpstpPrdConcession;
import com.sai.lendperfect.setupmodel.LpstpPrdDocFee;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;
import com.sai.lendperfect.setupmodel.LpstpPrdMargin;
import com.sai.lendperfect.setupmodel.LpstpPrdProFee;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.LpstpScheme;

public class LoanDetailsProvider {

	@SuppressWarnings("unused")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> resultmap = new HashMap<String, Object>();
		List<Map<String, Object>> resultmapList = new ArrayList();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		LpcustApplicantData lpcustApplicantData = new LpcustApplicantData();
		LpcustLoanDetail lpLoanDetail = new LpcustLoanDetail();
		LpcustLoanDetail lpcustLoanDetail = new LpcustLoanDetail();
		LpcomCaseDetSale lpcomCaseDetSale = new LpcomCaseDetSale();
		LpcomMailbox lpcomMailbox = new LpcomMailbox();
		LpcomProposal lpcomProposalObj = new LpcomProposal();
		String userid = (String) session.getAttribute("userid");
		String pageLoad = "";

		// BigDecimal propNo = (BigDecimal)
		// session.getAttribute("LP_COM_PROP_NO");
		// LpcomProposal
		// lpcomProposalobj=serviceProvider.getLpcomProposalService().findByLpPropNo(new
		// BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));

		BigDecimal proposalNoValue = (BigDecimal) session.getAttribute("LP_COM_PROP_NO");
		LpcomProposal lpcomProposal = serviceProvider.getLpcomProposalService().findByLpPropNo(proposalNoValue);

		if (dpMethod.equals("saveLoanDetail")) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");
				lpcomProposal = mapper.convertValue(requestMap.get("lcm"), LpcomProposal.class);
				lpcustLoanDetail = mapper.convertValue(requestMap.get("lld"), LpcustLoanDetail.class);
				lpcustApplicantData = mapper.convertValue(requestMap.get("lad"), LpcustApplicantData.class);
				pageLoad = "save";

				lpcustLoanDetail.setLpcomProposal(lpcomProposal);

				if (lpcustLoanDetail.getLpcomProposal() != null)

					session.setAttribute("prdCode", lpcustLoanDetail.getLldPrdcode());

				lpcustLoanDetail.setLpcomProposal(lpcomProposal);
				if (lpcustLoanDetail.getLpcomProposal() != null) {
					lpLoanDetail = serviceProvider.getLoanDetailsService().findByLpcomProposal(lpcomProposal);
				}
				if (lpLoanDetail != null) {
					lpcustLoanDetail.setLldId(lpLoanDetail.getLldId());
					dataHashMap.put("loanDetails", serviceProvider.getLoanDetailsService().save(lpcustLoanDetail));
					lpcustLoanDetail.setLldModifiedBy(userid);
					lpcustLoanDetail.setLldModifiedOn(Helper.getSystemDate());
					dataHashMap.put("loanDetails", serviceProvider.getLoanDetailsService().save(lpcustLoanDetail));
				} else {
					LpstpProductDet LpstpProductDet = serviceProvider.getLpstpProductDetService()
							.findByLpdProdNewId(lpcustLoanDetail.getLldPrdcode());
					LpstpScheme LpstpScheme = serviceProvider.getLpstpSchemeService()
							.findByLsSubFacility(Long.valueOf(LpstpProductDet.getLpdPrdSubCat()));

					lpcomMailbox.setLmToUsr(userid);
					lpcomMailbox.setLmCreatedBy(userid);
					lpcomMailbox.setLmCreatedOn(Helper.getSystemDate());
					lpcomMailbox.setLmRecvdTime(Helper.getSystemDate());
					lpcomMailbox.setLmType("P");
					lpcomMailbox.setLmModifiedBy(userid);
					lpcomMailbox.setLmFromUsr(userid);
					lpcomMailbox.setLmToUsr(userid);
					lpcomMailbox.setLmModifiedOn(Helper.getSystemDate());
					lpcomMailbox.setLmFlowId(serviceProvider.getLpcomMailboxService()
							.getFlowPointId(LpstpScheme.getLsWfProcessId(), "P"));

					BigDecimal propNo = lpcomProposal.getLpPropNo();
					lpcomProposalObj = serviceProvider.getLpcomProposalService().findByLpPropNo(propNo);
					lpcomMailbox.setLpcomProposal(lpcomProposalObj);
					lpcomMailbox = serviceProvider.getLpcomMailboxService().saveMailbox(lpcomMailbox);

					session.setAttribute("Flow_Type", lpcomMailbox.getLmType());
					session.setAttribute("Workflow_Id", LpstpScheme.getLsWfProcessId());

					lpcustLoanDetail.setLldSno(1);
					lpcustLoanDetail.setLldCreatedOn(Helper.getSystemDate());
					lpcustLoanDetail.setLldCreatedBy(userid);
					lpcustLoanDetail.setLldModifiedBy(userid);
					lpcustLoanDetail.setLldModifiedOn(Helper.getSystemDate());
					dataHashMap.put("loanDetails", serviceProvider.getLoanDetailsService().save(lpcustLoanDetail));
					dataHashMap.put("pageLoad", pageLoad);

					List<LpcomUserProposal> lpcomUserProposalList = serviceProvider.getLpcomUserProposalService()
							.findByLpstpUserOrderByLupSnoDesc(serviceProvider.getLpstpUserService()
									.findBysuRowId(session.getAttribute("userid").toString()));
					Iterator<LpcomUserProposal> lpcomUserProposalListItr = lpcomUserProposalList.iterator();
					while (lpcomUserProposalListItr.hasNext()) {
						LpcomUserProposal lpcomUserProposalObject = lpcomUserProposalListItr.next();
						if (lpcomUserProposalObject.getLpcomProposal().getLpPropNo()
								.equals(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()))
								&& lpcomUserProposalObject.getLpstpUser().getSuRowId()
										.equals(session.getAttribute("userid").toString())) {
							serviceProvider.getLpcomUserProposalService()
									.deleteLpcomUserProposal(lpcomUserProposalObject);
							lpcomUserProposalListItr.remove();
						}
					}
					if (lpcomUserProposalList.size() > 3) {
						for (int i = 0; i < lpcomUserProposalList.size(); i++) {
							if (i > 1) {
								serviceProvider.getLpcomUserProposalService()
										.deleteLpcomUserProposal(lpcomUserProposalList.get(i));
							}
						}
					}
					LpcomUserProposal lpcomUserProposal = new LpcomUserProposal();
					lpcomUserProposal.setLpcomProposal(serviceProvider.getLpcomProposalService()
							.findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString())));
					lpcomUserProposal.setLpstpUser(serviceProvider.getLpstpUserService()
							.findBysuRowId(session.getAttribute("userid").toString()));
					lpcomUserProposal.setLupModifiedDate(new Date(System.currentTimeMillis()));
					serviceProvider.getLpcomUserProposalService().saveLpcomUserProposal(lpcomUserProposal);
				}
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			} catch (Exception e) {
				e.printStackTrace();
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),
							dpMethod, e.getMessage());
					dataHashMap.put("errorData", new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		} else if (dpMethod.equals("saveDetailedLoanDetail")) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				LinkedHashMap<Integer, String> lpcutd = new LinkedHashMap<Integer, String>();
				lpcutd = (LinkedHashMap<Integer, String>) allRequestParams.get("requestData");

				LpcustLoanDetail lpcustLoanDetail1 = new LpcustLoanDetail();
				lpcomProposal = serviceProvider.getLpcomProposalService().findByLpPropNo(proposalNoValue);
				lpcustLoanDetail1 = mapper.convertValue(lpcutd, LpcustLoanDetail.class);
				lpcustLoanDetail1.setLpcomProposal(lpcomProposal);
				lpcustLoanDetail1.setLldModifiedBy(userid);
				lpcustLoanDetail1.setLldModifiedOn(Helper.getSystemDate());
				lpcustLoanDetail1.setLldCreatedBy(userid);
				lpcustLoanDetail1.setLldCreatedOn(Helper.getSystemDate());
				lpcustLoanDetail1.setLldFiledon(Helper.getSystemDate());
				dataHashMap.put("loanDetails", serviceProvider.getLoanDetailsService().save(lpcustLoanDetail1));

				if (lpcustLoanDetail.getLpcomProposal() != null) {
					lpLoanDetail = serviceProvider.getLoanDetailsService().findByLpcomProposal(lpcomProposal);
				}
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			} catch (Exception e) {
				e.printStackTrace();
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),
							dpMethod, e.getMessage());
					dataHashMap.put("errorData", new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		} else if (dpMethod.equals("getProductFeeDetails")) {
			long prdCode;
			try {
				prdCode = Long.valueOf(allRequestParams.get("requestData").toString());
				LpstpProductDet lpstpProductDetfromDB = serviceProvider.getLpstpProductDetService()
						.findByLpdProdNewId(Helper.convertLong((long) prdCode));
				List<LpstpPrdDocFee> lpstpPrdDocFee = serviceProvider.getLpstpPrdDocFeeService()
						.findByLdfProdIdOrderByLdfRowId(prdCode);
				List<LpstpPrdIntRate> lpstpPrdIntRate = serviceProvider.getLpstpPrdInterestRateService()
						.findByLirProdIdOrderByLirRowId(prdCode);

//				LpstpPrdIntRate lpstpPrdIntRateobj = serviceProvider.getLpstpPrdInterestRateService()
//						.findByLirProdId(prdCode);

				List<LpstpPrdMargin> lpstpPrdMargin = serviceProvider.getLpstpPrdMarginService()
						.findByLmgProdIdOrderByLmgRowId(prdCode);
				List<LpstpPrdProFee> lpstpPrdProFee = serviceProvider.getLpstpPrdProFeeService()
						.findByLpfProdIdOrderByLpfRowId(prdCode);
				List<LpstpPrdCoappguacount> lpstpCoappGuar = serviceProvider.getLpstpPrdCoapguarcountService()
						.findByLrcProdIdOrderByLrcRowId(prdCode);
				List<LpstpPrdConcession> lpstpPrdConcession = serviceProvider.getLpstpPrdConcessionService()
						.findByLpcProdIdOrderByLpcRowId(prdCode);
				// DetailedEntry Loandetails Masters Added by Sathish
				dataHashMap.put("lpstpProductDet", lpstpProductDetfromDB);
				dataHashMap.put("lpstpPrdDocFee", lpstpPrdDocFee);
				dataHashMap.put("lpstpPrdIntRate", lpstpPrdIntRate);
				dataHashMap.put("lpstpPrdMargin", lpstpPrdMargin);
				dataHashMap.put("lpstpPrdProFee", lpstpPrdProFee);
//				dataHashMap.put("lpstpPrdIntRateobj", lpstpPrdIntRateobj);
				dataHashMap.put("lpstpCoappGuar", lpstpCoappGuar);
				dataHashMap.put("lpstpPrdConcession", lpstpPrdConcession);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			} catch (Exception e) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),
							dpMethod, e.getMessage());
					dataHashMap.put("errorData", new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		} else if (dpMethod.equals("deleteloandetails")) {
			Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");
			int slno = (int) requestMap.get("slno");
			LpcomProposal lpcomProposalobj = serviceProvider.getLpcomProposalService()
					.findByLpPropNo((BigDecimal) session.getAttribute("LP_COM_PROP_NO"));
			LpcustLoanDetail loanDetail = serviceProvider.getLoanDetailsService()
					.findByLpcomProposalAndLldSno(lpcomProposalobj, slno);
			serviceProvider.getLoanDetailsService().deleteloandetails(lpcomProposalobj.getLpPropNo(),
					loanDetail.getLldSno(), loanDetail.getLldPrdcode());
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}

		else if (dpMethod.equals("getLoanDetails")) {
			ArrayList desc = new ArrayList<>();
			String prddesc = "";
			try {
				LpcomProposal lpcomProposalobj = serviceProvider.getLpcomProposalService()
						.findByLpPropNo((BigDecimal) session.getAttribute("LP_COM_PROP_NO"));
				List<LpcustLoanDetail> lpcustLoanDetailList = serviceProvider.getLoanDetailsService()
						.findByLpProposalOrderByLldSno(lpcomProposalobj);
				Iterator<LpcustLoanDetail> lpcustLoanDetailItr = lpcustLoanDetailList.iterator();
				while (lpcustLoanDetailItr.hasNext()) {
					HashMap lpCustomerInfoMap = new HashMap<String, Object>();
					LpcustLoanDetail lpcustLoanDetails = lpcustLoanDetailItr.next();
					Long prdcode = lpcustLoanDetails.getLldPrdcode();
					LpstpProductDet lpstpProductDet = (LpstpProductDet) serviceProvider.getLpstpProductDetService()
							.findByLpdProdNewId(prdcode);
					prddesc = lpstpProductDet.getLpdPrdDesc();
					lpCustomerInfoMap.put("ProductDesc", prddesc);
					lpCustomerInfoMap.put("lpcustLoanDetail", lpcustLoanDetails);
					resultmapList.add(lpCustomerInfoMap);
				}
				LpmasPageMaster lpmasPageMaster = serviceProvider.getLpmasPageMasterService()
						.findByLpmPageId(Long.parseLong((session.getAttribute("LP_PageId")).toString()));
				String pageAccess = Helper.pageAccessRights(lpmasPageMaster.getLpmPageType(),
						new BigDecimal((lpmasPageMaster.getLpmPageId())),
						new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()), serviceProvider, session);
				responseHashMap.put("propNo", session.getAttribute("LP_COM_PROP_NO"));
				responseHashMap.put("pageAccess", pageAccess);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", resultmapList);

			} catch (Exception e) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),
							dpMethod, e.getMessage());
					dataHashMap.put("errorData", new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}

		else if (dpMethod.equals("getLoanDetailsselect")) {
			try {

				LpcomProposal lpcomProposalobj = serviceProvider.getLpcomProposalService()
						.findByLpPropNo((BigDecimal) (session.getAttribute("LP_COM_PROP_NO")));
				List<LpcustLoanDetail> lpcustLoanDetail1 = (List<LpcustLoanDetail>) serviceProvider
						.getLoanDetailsService().findByLpProposal(lpcomProposalobj);
				BigDecimal propNo = (BigDecimal) session.getAttribute("LP_COM_PROP_NO");
				dataHashMap.put("lpcustLoanDetail", lpcustLoanDetail1);
				dataHashMap.put("lpcustappno", propNo);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);

			} catch (Exception e) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),
							dpMethod, e.getMessage());
					dataHashMap.put("errorData", new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}

		else if (dpMethod.equals("getDetailsForDropDown")) {
			try {
				// BigDecimal propNo = (BigDecimal)
				// session.getAttribute("LP_COM_PROP_NO");
				LpcomProposal lpcomProposalobj = serviceProvider.getLpcomProposalService()
						.findByLpPropNo((BigDecimal) (session.getAttribute("LP_COM_PROP_NO")));
				Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");

				long lldSno = Long.parseLong(String.valueOf(requestMap.get("lldSno")));
				lpLoanDetail = serviceProvider.getLoanDetailsService().findByLpcomProposalAndLldSno(lpcomProposalobj,
						lldSno);
				dataHashMap.put("lpLoanDetail", lpLoanDetail);

				// LpcomProposal
				// lpcomProposalobj=serviceProvider.getLpcomProposalService().findByLpPropNo(new
				// BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
				// List<LpcustLoanDetail> lpLoanDetail =
				// (List<LpcustLoanDetail>)
				// serviceProvider.getLoanDetailsService().findByLpProposal(lpcomProposalobj);
				//
				// dataHashMap.put("prodDescription", LpstpProductDet);
				// dataHashMap.put("lldLoanDetail",lpLoanDetail);
				responseHashMap.put("responseData", dataHashMap);

			} catch (Exception e) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),
							dpMethod, e.getMessage());
					dataHashMap.put("errorData", new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		} else if (dpMethod.equals("getAmortChart")) {
			try {
				HashMap hshResult = new HashMap();
				ArrayList arryRow = new ArrayList();
				ArrayList arryCol = new ArrayList();
				int i = 1;
				double dblInterest = 0.0;
				double dblPrincipal = 0.0;
				double dblloans = 0.0;
				double dblEMI = 0.0;
				double dblDenomi = 0.0;
				double dblNumeri = 0.0;
				double dblRate = 0.0;
				double dblActualAmtDue = 0.0;
				double dblTotalInterest = 0.0;
				double dblTotalEMI = 0.0;
				double dblTotalPrincipal = 0.0;
				double dblModIntRate = 0.0;
				int intTerms = 0;
				double dblRecAmount = 0.0;
				String bool = "false";
				String emdate = "";
				String strQuery = "", str_intcalmode = "";
				ObjectMapper mapper = new ObjectMapper();
				Map<String, Object> hshValues = (Map<String, Object>) allRequestParams.get("requestData");
				String strrepaymenttype = (String) hshValues.get("hidrepaymenttype");
				emdate = (String) hshValues.get("emidate");
				String strLockPayment = (String) hshValues.get("locktype");
				String strPendingPaymentMode = (String) hshValues.get("lockpaymentmode");
				String strperidicity = (String) hshValues.get("peridicity");
				if (strperidicity.equalsIgnoreCase("")) {
					strperidicity = "m";
				}

				double dblHolidayEMI = 0.0;
				double dblHolidayBalanceOS = 0.0;
				double dblHolidayBalance = 0.0;
				double dblHolidayPrincipal = 0.0;
				double dblHolidayInterest = 0.0;
				double dblPendingPayment = 0.0;

				DecimalFormat dc = new DecimalFormat();
				dc.setGroupingUsed(false);
				dc.setMaximumFractionDigits(2);
				dc.setMinimumFractionDigits(2);
				try {
					if (strrepaymenttype.equals("repay"))// &&
															// strperidicity.equalsIgnoreCase("m"))
					{/*
						 * 
						 * 
						 * dblModIntRate =
						 * Double.parseDouble(Helper.correctNull((String)
						 * hshValues.get("txtloan_modintrate"))); dblRecAmount =
						 * Double.parseDouble(Helper.correctNull((String)
						 * hshValues.get("txtloan_sancamt")));
						 * 
						 * String strstartterms =
						 * Helper.correctNull((String)hshValues.get(
						 * "hidstartterms")); String
						 * terms3=Helper.correctNull((String)hshValues.get(
						 * "terms2"));// int intHolidayPeriod = (terms3!=null &&
						 * !terms3.trim().equals(""))?Integer.parseInt(terms3):
						 * 0;
						 * 
						 * intTerms
						 * =Integer.parseInt(Helper.correctInt((String)hshValues
						 * .get("txtloan_reqterms")));
						 * hshResult.put("txtloan_reqterms",Integer.toString(
						 * intTerms));
						 * hshResult.put("peridicity",strperidicity); int
						 * intRepayMonths=0; if(intTerms>intHolidayPeriod) {
						 * intRepayMonths = intTerms - intHolidayPeriod; }else{
						 * intRepayMonths = intTerms; }
						 * if(strperidicity.equalsIgnoreCase("q")) {
						 * intRepayMonths=intRepayMonths/3; } else
						 * if(strperidicity.equalsIgnoreCase("h")) {
						 * intRepayMonths=intRepayMonths/6; } else
						 * if(strperidicity.equalsIgnoreCase("y")) {
						 * intRepayMonths=intRepayMonths/12; }
						 * 
						 * int repayincludholiday=intTerms+intHolidayPeriod;
						 * hshResult.put("txtloan_RepayMonths",
						 * Integer.toString(intRepayMonths));
						 * 
						 * intTerms=intRepayMonths;
						 * 
						 * // start use not known String strendterms =
						 * Helper.correctNull((String)hshValues.get(
						 * "hidendterms")); //int intTerms= 10; double x1=0.0;
						 * x1 = Double.parseDouble(Helper.correctNull((String)
						 * hshValues.get("txtloan_sancamt"))); //end
						 * 
						 * 
						 * String strAppNo =
						 * Helper.correctNull((String)hshValues.get("appno"));
						 * hshResult.put("txtloan_modintrate",Double.toString(
						 * dblModIntRate));
						 * 
						 * hshResult.put("txtloan_sancamt",Double.toString(
						 * dblRecAmount));
						 * hshResult.put("appno",Helper.correctNull(strAppNo));
						 * hshResult.put("term3",terms3);
						 * hshResult.put("repayincludholiday",Integer.toString(
						 * repayincludholiday));
						 * hshResult.put("intHolidayPeriod",Integer.toString(
						 * intHolidayPeriod));
						 * hshResult.put("actualrepayperiod",Helper.correctNull(
						 * (String)hshValues.get("actualrepayperiod")));
						 * strQuery =
						 * SQLParser.getSqlQuery("selamortization^"+strAppNo);
						 * rs = DBUtils.executeQuery(strQuery); int count=0;
						 * while(rs.next()) { double dblTemp = 0.00; double
						 * dblActualInt =0.00; double dblActualPrincipal =0.00;
						 * double dblTotalAmount =0.00;
						 * 
						 * bool ="true"; arryCol = new ArrayList(); dblTemp =
						 * Double.parseDouble((String)(rs.getString(
						 * "amort_terms"))); arryCol.add(new
						 * Double(dc.format(dblTemp))); dblTemp =
						 * Double.parseDouble((String)(rs.getString(
						 * "amort_orginalamountos"))); arryCol.add(new
						 * Double(dc.format(dblTemp))); dblActualInt =
						 * Double.parseDouble((String)(rs.getString(
						 * "amort_actualinterest"))); arryCol.add(new
						 * Double(dc.format(dblActualInt))); dblTemp =
						 * Double.parseDouble(Helper.correctDouble((String)(rs.
						 * getString("amort_orginalinterest"))));
						 * arryCol.add(new Double(dc.format(dblTemp)));
						 * dblActualPrincipal=Double.parseDouble((String)(rs.
						 * getString("amort_actualprincipal"))); arryCol.add(new
						 * Double(dc.format(dblActualPrincipal))); dblTemp =
						 * Double.parseDouble((String)(rs.getString(
						 * "amort_orginalprincipal"))); arryCol.add(new
						 * Double(dc.format(dblTemp))); dblTotalAmount =
						 * dblActualInt +dblActualPrincipal ; arryCol.add(new
						 * Double(dc.format(Math.round(dblTotalAmount))));
						 * dblTemp = Double.parseDouble((String)(rs.getString(
						 * "amort_actualamountos"))); if(dblTemp<0) { dblTemp=0;
						 * } arryCol.add(new Double(dc.format(dblTemp)));
						 * arryRow.add(arryCol); count++;
						 * hshResult.put("txtloan_RepayMonths",
						 * Integer.toString(count)); }
						 * 
						 * if (bool.equals("false")) { dblRate = dblModIntRate /
						 * (12 * 100);
						 * 
						 * dblDenomi = Math.pow(dblRate + 1, intTerms) - 1;
						 * 
						 * dblNumeri = dblRate * Math.pow(dblRate + 1,
						 * intTerms);
						 * 
						 * dblEMI = (dblNumeri / dblDenomi) * dblRecAmount;
						 * 
						 * dblPrincipal = dblEMI - (dblRecAmount * dblRate);
						 * 
						 * dblInterest = dblRecAmount * dblRate;
						 * 
						 * dblActualAmtDue = dblRecAmount - dblPrincipal;
						 * 
						 * //dblTotalEMI = dblEMI * intTerms;
						 * 
						 * arryCol = new ArrayList(); arryCol.add(new
						 * Integer(i)); arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblRecAmount)));
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblInterest)));
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblInterest)));
						 * dblTotalInterest = dblInterest; arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblPrincipal)));
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblPrincipal)));
						 * dblTotalPrincipal = dblPrincipal; double tempTot =
						 * dblPrincipal + dblInterest; arryCol.add(new
						 * Double(Helper.formatDoubleValue(Math.round(tempTot)))
						 * ); // arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblEMI)));
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblActualAmtDue)));
						 * arryRow.add(arryCol);
						 * 
						 * // i=i+1;
						 * 
						 * while (i <= intTerms) { arryCol = new ArrayList();
						 * arryCol.add(new Integer(i)); arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblActualAmtDue)));
						 * dblInterest = dblActualAmtDue * dblRate;
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblInterest)));
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblInterest)));
						 * dblTotalInterest = dblTotalInterest + dblInterest;
						 * dblPrincipal = dblEMI - (dblActualAmtDue * dblRate);
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblPrincipal)));
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblPrincipal)));
						 * dblTotalPrincipal = dblTotalPrincipal + dblPrincipal;
						 * 
						 * double TotalAmt = dblInterest + dblPrincipal;
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(Math.round(TotalAmt))
						 * )); dblActualAmtDue = dblActualAmtDue - dblPrincipal;
						 * arryCol.add(new
						 * Double(Helper.formatDoubleValue(dblActualAmtDue)));
						 * arryRow.add(arryCol); i = i + 1; } }
						 * hshResult.put("arryRow", arryRow);
						 * hshResult.put("hidstartterms", strstartterms);
						 * 
						 * if (bool.equals("false")) { hshResult.put("isDataDb",
						 * "true"); } else { hshResult.put("isDataDb", "true");
						 * }
						 */
					} else if (strrepaymenttype.equals("amort")) {
						dblModIntRate = Double.parseDouble(Helper.correctNull((String) hshValues.get("lldModintrate")));

						String interestcharged = Helper.correctNull((String) hshValues.get("lockpaymentmode"));
						if (interestcharged.equalsIgnoreCase("1")) {
							strLockPayment = "P";
							strPendingPaymentMode = "1";
						} else if (interestcharged.equalsIgnoreCase("3")) {
							strLockPayment = "I";
							strPendingPaymentMode = "3";
						} else {
							strLockPayment = "I";
							strPendingPaymentMode = "3";
						}

						intTerms = Integer.parseInt(Helper.correctInt(hshValues.get("terms").toString()));
						int intHolidayPeriod = Integer.parseInt(Helper.correctInt((String) hshValues.get("terms2")));
						dblRecAmount = Double.parseDouble(Helper.correctDouble((String) hshValues.get("recamt")));
						double dblRecAmount1 = Double
								.parseDouble(Helper.correctDouble((String) hshValues.get("varAmtrecomd")));

						double dblTenor = intTerms - intHolidayPeriod;
						String txtmonPayamor = Helper.correctNull((String) hshValues.get("txtmonPay"));
						hshResult.put("txtmonPayamor", txtmonPayamor);
						hshResult.put("strLockPayment", strLockPayment);
						hshResult.put("lockpaymentmode", strPendingPaymentMode);
						hshResult.put("dblrequested_amount", (Helper.correctNull((String) hshValues.get("recmdAmt"))));
						hshResult.put("terms", Integer.toString(intTerms - intHolidayPeriod));
						hshResult.put("terms2", Integer.toString(intHolidayPeriod));
						hshResult.put("inttype", Helper.correctNull((String) hshValues.get("inttype")));
						hshResult.put("cattype", Helper.correctNull((String) hshValues.get("cattype")));
						dblRate = dblModIntRate / (12 * 100);

						if (strLockPayment.trim().equalsIgnoreCase("I") && strPendingPaymentMode.trim().equals("2")) {
							dblDenomi = Math.pow(dblRate + 1, (intTerms)) - 1;
							dblNumeri = dblRate * Math.pow(dblRate + 1, (intTerms));
						} else {
							dblDenomi = Math.pow(dblRate + 1, (dblTenor)) - 1;
							dblNumeri = dblRate * Math.pow(dblRate + 1, (dblTenor));
						}

						if (dblNumeri != 0.0 && dblDenomi != 0.0) {
							dblEMI = ((dblNumeri / dblDenomi) * dblRecAmount1);
						}

						dblInterest = (dblRecAmount * dblRate); // monthly
																// interest
						dblloans = dblRecAmount; // loan amount
						double dblInterest_new = 0.00;
						double dblActualAmtDue_new = 0.00;
						double dblloans_new = dblRecAmount;
						dblActualAmtDue_new = dblRecAmount;
						// Amortization for Holiday Period
						if (!strLockPayment.trim().equalsIgnoreCase("S") && intHolidayPeriod > 0) {
							while (i <= intHolidayPeriod) {
								if (strLockPayment.trim().equalsIgnoreCase("P")) {
									arryCol = new ArrayList();
									arryCol.add(new Integer(i));

									// Lock Only Principal amount. Only interest
									// will be paid. No change in balance amount
									// and OS Loan amount.
									dblInterest = (dblloans * dblRate);
									dblActualAmtDue = dblloans;
									dblTotalInterest = dblTotalInterest + dblInterest;
									dblTotalPrincipal = 0.0;

									dblPendingPayment = 0.0;

									arryCol.add(new Double(dc.format(dblActualAmtDue + dblInterest))); // Loan
																										// Amount
																										// OS
									arryCol.add(new Double(dc.format(dblInterest))); // Interest
																						// Amount
									arryCol.add(new Double(dc.format(0))); // Principal
																			// Amount
									arryCol.add(new Double(dc.format((dblInterest)))); // EMI
									arryCol.add(new Double(dc.format(dblloans))); // Balance
																					// Amount

									arryRow.add(arryCol);
									dblHolidayEMI += dblInterest;// changes* For
																	// toal
																	// calculation

								}
								// to add in arraylist during holiday
								// period--ilakkiya
								else if (strLockPayment.trim().equalsIgnoreCase("I")) {// calamort

									str_intcalmode = Helper.correctNull((String) hshValues.get("varIntCalcMode"));

									if (str_intcalmode.equalsIgnoreCase("S")) {
										dblInterest = (dblloans * dblRate);
										dblloans_new = dblloans_new + dblInterest;
										dblActualAmtDue_new = dblActualAmtDue_new + dblInterest;

										arryCol = new ArrayList();
										arryCol.add(new Integer(i));

										arryCol.add(new Double(dc.format(dblActualAmtDue_new))); // Balance
																									// Amount
										arryCol.add(new Double(dc.format(dblInterest))); // Interest
																							// Amount
										arryCol.add(new Double(dc.format(0))); // Principal
																				// Amount
										arryCol.add(new Double(dc.format((0)))); // EMI
										arryCol.add(new Double(dc.format(dblloans_new))); // Loan
																							// Amount
																							// OS
										arryRow.add(arryCol);

									} else if (str_intcalmode.equalsIgnoreCase("C")) {
										dblInterest = (dblloans * dblRate);
										dblloans_new = dblloans_new + dblInterest;
										dblActualAmtDue_new = dblActualAmtDue_new + dblInterest;
										dblloans = dblloans_new;

										arryCol = new ArrayList();
										arryCol.add(new Integer(i));

										arryCol.add(new Double(dc.format((dblActualAmtDue_new)))); // Balance
																									// Amount
										arryCol.add(new Double(dc.format(dblInterest))); // Interest
																							// Amount
										arryCol.add(new Double(dc.format(0))); // Principal
																				// Amount
										arryCol.add(new Double(dc.format((0)))); // EMI
										arryCol.add(new Double(dc.format((dblloans_new)))); // Loan
																							// Amount
																							// OS
										arryRow.add(arryCol);
									} else {
										dblInterest = (dblloans * dblRate);
										dblloans_new = dblloans_new + dblInterest;
										dblActualAmtDue_new = dblActualAmtDue_new + dblInterest;
										dblloans = dblloans_new;
										arryCol = new ArrayList();
										arryCol.add(new Integer(i));
										arryCol.add(new Double(dc.format((dblActualAmtDue_new)))); // Balance
																									// Amount
										arryCol.add(new Double(dc.format(dblInterest))); // Interest
																							// Amount
										arryCol.add(new Double(dc.format(0))); // Principal
																				// Amount
										arryCol.add(new Double(dc.format((0)))); // EMI
										arryCol.add(new Double(dc.format((dblloans_new)))); // Loan
																							// Amount
																							// OS
										arryRow.add(arryCol);
									}
									dblHolidayEMI += dblPrincipal;// changes*
																	// For toal
																	// calculation*/
								}
								i = i + 1;
							}
						}
						// Recalculating EMI
						// LOGIC STARTS HERE
						boolean blnPendingPayment = false;
						double dblFirstEMI = 0.0;

						dblloans = dblRecAmount1;

						double dblTotIntPrincLock = 0.00;
						if (!strLockPayment.trim().equalsIgnoreCase("S") && intHolidayPeriod > 0) {
							if (strPendingPaymentMode.trim().equals("2")) {
								blnPendingPayment = true;
								dblTotalEMI = (dblHolidayEMI);
							} else if (strPendingPaymentMode.trim().equals("3")) {
								// Add pending payments to the Principal and
								// recalculate the EMI
								// commented ---- dblloans = dblloans +
								// dblPendingPayment;
								dblRate = dblModIntRate / (12 * 100);
								dblDenomi = Math.pow(dblRate + 1, (intTerms - intHolidayPeriod)) - 1;
								dblNumeri = dblRate * Math.pow(dblRate + 1, (intTerms - intHolidayPeriod));
								// if(strLockPayment.trim().equalsIgnoreCase("B"))
								{
									if (dblNumeri != 0.0 && dblDenomi != 0.0) {
										dblEMI = (dblNumeri / dblDenomi * dblloans);
									}
								} /*
									 * else { if(dblNumeri!=0.0 &&
									 * dblDenomi!=0.0) {
									 * dblEMI=dblNumeri/dblDenomi*(dblloans +
									 * dblPendingPayment); } }
									 */
								dblInterest = ((dblloans + dblPendingPayment) * dblRate);
								dblPrincipal = dblEMI - dblInterest;
								// dblActualAmtDue=dblloans + dblInterest;
								dblActualAmtDue = dblloans + dblPendingPayment + dblInterest;
								dblTotalEMI = (dblEMI * (intTerms - intHolidayPeriod) + dblHolidayEMI);

							} else if (strPendingPaymentMode.trim().equals("4")) {
								// Add pending payments to the Principal and
								// recalculate the EMI
								// commented ---- dblloans = dblloans +
								// dblPendingPayment;
								dblRate = dblModIntRate / (12 * 100);
								dblDenomi = Math.pow(dblRate + 1, (intTerms - intHolidayPeriod)) - 1;
								dblNumeri = dblRate * Math.pow(dblRate + 1, (intTerms - intHolidayPeriod));

								dblloans += dblPendingPayment;
								// if(strLockPayment.trim().equalsIgnoreCase("B"))
								{
									if (dblNumeri != 0.0 && dblDenomi != 0.0) {
										dblEMI = (dblNumeri / dblDenomi * dblloans);
									}
								}
								dblInterest = (dblloans * dblRate);
								dblPrincipal = dblEMI - dblInterest;
								// dblActualAmtDue=dblloans + dblInterest;
								dblActualAmtDue = dblloans + dblInterest;
								dblTotalEMI = (dblEMI * (intTerms - intHolidayPeriod) + dblHolidayEMI);

							} else {
								dblTotalEMI = (dblHolidayEMI);
							}
						}
						int j = 0;
						while (i <= (dblTenor + intHolidayPeriod)) {
							arryCol = new ArrayList();
							arryCol.add(new Integer(i));
							if (blnPendingPayment && j == 0) {

								dblFirstEMI = (dblEMI + dblPendingPayment);
								dblInterest = (dblloans * dblRate);
								dblTotalInterest = dblTotalInterest + dblInterest;

								dblPrincipal = dblEMI - dblInterest;
								dblTotalPrincipal = dblTotalPrincipal + dblPrincipal;
								dblActualAmtDue = dblloans + dblInterest; // Formula:
																			// Balance
																			// Amt
																			// :=
																			// OS
																			// Loan
																			// +
																			// IR
								if (strLockPayment.trim().equalsIgnoreCase("B")) {
									dblloans = dblloans + dblInterest - dblFirstEMI;
								} else if (strLockPayment.trim().equalsIgnoreCase("I")) {
									dblloans = dblloans + dblInterest - dblEMI;
								}

								dblInterest += dblPendingPayment;
								if (dblloans <= 0) {
									dblloans = 0.00;
								}
								arryCol.add(new Double(dc.format(dblActualAmtDue)));
								arryCol.add(new Double(dc.format(dblInterest)));
								arryCol.add(new Double(dc.format(dblPrincipal)));
								arryCol.add(new Double(dc.format((dblFirstEMI))));
								arryCol.add(new Double(dc.format(dblloans)));

								dblTotalEMI += (dblFirstEMI);

							} else {
								// Checking for Last Entry(To Adjust final
								// amount)
								if (i == dblTenor + intHolidayPeriod) {
									double dblTempLoans = 0.0;
									dblInterest = (dblloans * dblRate);
									dblActualAmtDue = dblloans + dblInterest;
									dblPrincipal = dblEMI - dblInterest;
									dblTempLoans = dblloans + dblInterest - dblEMI;

									// Add the balance to the EMI and
									// recalculate
									dblEMI = (dblEMI + dblTempLoans);
									dblPrincipal = dblEMI - dblInterest;
									dblloans = dblloans + dblInterest - dblEMI;
									if (strLockPayment.trim().equalsIgnoreCase("B")) {
										dblTotIntPrincLock += dblInterest + dblPendingPayment;// changes*
																								// Total
																								// interest
																								// calculation
									} else {
										dblTotIntPrincLock += dblInterest;
									}
									dblTotalInterest = dblTotalInterest + dblInterest;
									dblTotalPrincipal = dblTotalPrincipal + dblPrincipal;
								} else {
									dblInterest = (dblloans * dblRate);
									dblTotIntPrincLock += dblInterest;// changes*
									dblActualAmtDue = dblloans + dblInterest;
									dblTotalInterest = dblTotalInterest + dblInterest;
									dblPrincipal = dblEMI - dblInterest;
									dblTotalPrincipal = dblTotalPrincipal + dblPrincipal;
									dblloans = dblloans + dblInterest - dblEMI;
								}
								if (dblloans <= 0) {
									dblloans = 0.00;
								}
								arryCol.add(new Double(dc.format(dblActualAmtDue)));
								arryCol.add(new Double(dc.format(dblInterest)));
								arryCol.add(new Double(dc.format(dblPrincipal)));
								arryCol.add(new Double(dc.format((dblEMI))));
								arryCol.add(new Double(dc.format(dblloans)));
								/*
								 * if(
								 * strLockPayment.trim().equalsIgnoreCase("P"))
								 * dblTotalEMI+=Math.round(dblEMI);
								 */
								dblTotalEMI = (dblTotalPrincipal + dblTotalInterest);
							}
							arryRow.add(arryCol);

							i = i + 1;
							j++;
						}
						if (strPendingPaymentMode.trim().equals("3") || strPendingPaymentMode.trim().equals("4")) {
							dblTotalInterest = dblTotIntPrincLock; // for
																	// showing
																	// total
																	// interest
																	// when
																	// pricipal
																	// is locked
						}
						arryCol = new ArrayList();
						arryCol.add(new String("Total"));
						arryCol.add("");
						if ((strLockPayment.trim().equalsIgnoreCase("B"))
								&& (strPendingPaymentMode.trim().equals("4"))) {
							arryCol.add(new Double(dc.format(dblTotalInterest - dblHolidayInterest)));
						} else {
							arryCol.add(new Double(dc.format(dblTotalInterest))); // int
						}
						arryCol.add(new Double(dc.format(dblTotalPrincipal))); // prin
						if (strLockPayment.trim().equalsIgnoreCase("P")) {
							arryCol.add(new Double(dc.format((dblTotalInterest + dblTotalPrincipal)))); // emi
						} else {
							arryCol.add(new Double(dc.format((dblTotalEMI))));
						}
						arryRow.add(arryCol);
						hshResult.put("arryRow", arryRow);
						hshResult.put("emidate", emdate);
						hshResult.put("totalInterest", dc.format(dblTotalInterest));
						hshResult.put("strperidicity", strperidicity);
					}
					responseHashMap.put("arryRowList", arryRow);
				} catch (Exception e) {
					// throw new EJBException("Error in closing
					// calcAmortization"+e.getMessage());
					e.printStackTrace();
				} finally {
					arryRow = null;
					arryCol = null;
				}
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", resultmapList);
			} catch (Exception e) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),
							dpMethod, e.getMessage());
					dataHashMap.put("errorData", new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		return responseHashMap;

	}
}
