package com.sai.lendperfect.app.customerdetails;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantOtherIncome;
import com.sai.lendperfect.application.model.LpcustCibilIndividual;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.common.proposalsearch.ProposalSearch;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;

public interface CustomerDetailsService {
	
	LpcustApplicantData saveApplicant(LpcustApplicantData lpcustApplicantData);
	List<LpmasListofvalue> findByllvHeader(String header);
	LpcomProposal save(LpcomProposal lpcomProposal);
	LpcustApplicantData findByID(long ladId);
	LpcustApplicantData findBy(long ladId);
	//LpcustApplicantData findByLadId(LpcustApplicantData lpcustApplicantData);
	LpcustApplicantData findByLadId(long ladId);
	List<LpcustApplicantData> findByLadOldid(BigDecimal ladOldid);
	LpcustApplicantData findByLadMobile(String ladMobile);
	LpcustApplicantData findByLadaadhar(String ladaadhar);
	LpcustApplicantData findByLadEmail(String ladEmail);
	List<LpcustApplicantData> findByLadFnameIgnoreCaseContaining(String ladFname);
	LpcustApplicantData findByLadCbsid(String ladCbsid);
	 List<ProposalSearch> findByLadPannoOrLadMobileOrLadaadharOrLadFnameOrLadEmailOrLadCbsid(
			String queryString);
	 List<Map<String,Object>> findByLadPannoOrLadMobileOrLadaadharOrLadFnameOrLadEmailOrLadCbsidForSecurities(
				String queryString);
	 void delete(LpcustApplicantData lpcustApplicantData);
	 String findByLlvHeaderAndLlvOptionVal(String llvHeader, String llvOptionVal);
	
}
