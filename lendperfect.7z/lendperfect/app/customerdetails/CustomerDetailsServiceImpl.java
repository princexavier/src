package com.sai.lendperfect.app.customerdetails;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustCibilIndividual;
import com.sai.lendperfect.application.repo.LpApplicationDataRepo;
import com.sai.lendperfect.application.repo.LpcustCibilIndividualRepo;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.common.proposalsearch.ProposalSearch;
import com.sai.lendperfect.comrepo.LpcomProposalRepo;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.masterrepo.LpmasListofvalueRepo;
import com.sai.lendperfect.setupmodel.LpstpUser;

@Service("CustomerDetailsService")
@Transactional
public class CustomerDetailsServiceImpl implements CustomerDetailsService{

	@Autowired
	LpApplicationDataRepo lpApplicationDataRepo;
	
	@Autowired
	private LpmasListofvalueRepo lpmasListofvalueRepo;
	
	@Autowired
	private LpcomProposalRepo lpcomProposalRepo;
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public LpcustApplicantData saveApplicant(LpcustApplicantData lpcustApplicantData) {
		return lpApplicationDataRepo.save(lpcustApplicantData);
	}

	@Override
	public List<LpmasListofvalue> findByllvHeader(String header) {
		return lpmasListofvalueRepo.findByLlvHeader(header);
	}

	@Override
	public LpcomProposal save(LpcomProposal lpcomProposal) {
		return lpcomProposalRepo.save(lpcomProposal);
	}

	@Override
	public LpcustApplicantData findByID(long ladId) {
		return lpApplicationDataRepo.findByladId(ladId);
	}

	/*@Override
	public LpcustApplicantData findByLadId(LpcustApplicantData lpcustApplicantData) {
		return lpApplicationDataRepo.findByLpcustApplicantData(lpcustApplicantData);
	}*/


	public List<LpcustApplicantData> findByLadOldid(BigDecimal ladOldid) {
		// TODO Auto-generated method stub
		return lpApplicationDataRepo.findByLadOldid(ladOldid);
	}

	@Override
	public LpcustApplicantData findByLadaadhar(String ladaadhar) {
		// TODO Auto-generated method stub
		return lpApplicationDataRepo.findByLadaadhar(ladaadhar);
	}
	public LpcustApplicantData findByLadMobile(String ladMobile){
		return lpApplicationDataRepo.findByLadMobile(ladMobile);
	}
	
	public LpcustApplicantData findByLadEmail(String ladEmail){
		return lpApplicationDataRepo.findByLadEmail(ladEmail);
	}
	public List<LpcustApplicantData> findByLadFnameIgnoreCaseContaining(String ladFname){
		return lpApplicationDataRepo.findByLadFnameIgnoreCaseContaining(ladFname);
	}
	public LpcustApplicantData findByLadCbsid(String ladCbsid){
		return lpApplicationDataRepo.findByLadCbsid(ladCbsid);
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<ProposalSearch> findByLadPannoOrLadMobileOrLadaadharOrLadFnameOrLadEmailOrLadCbsid(
			String queryString) {
			List<ProposalSearch> proposalSearchList=new ArrayList<>();
			List<Object[]> searchList=entityManager.createQuery("select p.lpPropNo,u.suFirstName,c.ladFname,p.lpCreatedOn,p.lpStatus from LpcustApplicantData c,LpcustAppcustRelation r,LpcomProposal p,LpstpUser u where c.ladId=r.lpcustApplicantData and r.lpcomProposal=p.lpPropNo and p.lpPropHolder=u.suRowId and "+queryString).getResultList();
			Iterator<Object[]> searchListItr=searchList.iterator();
			while(searchListItr.hasNext())
			{
				ProposalSearch proposalSearch=new ProposalSearch();
				Object[] colList=searchListItr.next();
				proposalSearch.setProposalNo((BigDecimal) colList[0]);
				proposalSearch.setHolder((String) colList[1]);
				proposalSearch.setBorrowerName((String) colList[2]);
				proposalSearch.setCreatedOn((Date) colList[3]);
				proposalSearch.setStatus((String) colList[4]);
				proposalSearchList.add(proposalSearch);
			}
				 return proposalSearchList;
			  
	}

	@Override
	public LpcustApplicantData findBy(long ladId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public LpcustApplicantData findByLadId(long ladId) {
		// TODO Auto-generated method stub
		return lpApplicationDataRepo.findByladId(ladId) ;

	}

	@Override
	public void delete(LpcustApplicantData lpcustApplicantData) {
		 
		lpApplicationDataRepo.delete(lpcustApplicantData);
	}
	
	public String findByLlvHeaderAndLlvOptionVal(String llvHeader, String llvOptionVal){
		LpmasListofvalue lpmasListofvalue=lpmasListofvalueRepo.findByLlvHeaderAndLlvOptionVal(llvHeader,llvOptionVal);
		return lpmasListofvalue.getLlvOptionDesc();
	}
 
	@Override
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Map<String, Object>> findByLadPannoOrLadMobileOrLadaadharOrLadFnameOrLadEmailOrLadCbsidForSecurities(
			String queryString) {
		List<Map<String, Object>> proposalSearchMapList = new ArrayList<Map<String, Object>>();
		List<Object[]> searchList=entityManager.createQuery("select  c.ladFname,c.ladMname,c.ladLname,c.ladCbsid,c.ladId,c.ladPanno from LpcustApplicantData c where "+queryString).getResultList();
		Iterator<Object[]> searchListItr = searchList.iterator();
		while(searchListItr.hasNext()){
			Map<String,Object> proposalSearchMap = new HashMap<String,Object>();
			Object[] searchObj = searchListItr.next();
			String customerName = "";
			customerName = (String) searchObj[0];
			if(searchObj[1] != null)
				customerName += (String) " "+searchObj[1];
			if(searchObj[2] != null)
				customerName += (String) " "+searchObj[2];
			proposalSearchMap.put("custName", customerName);
			proposalSearchMap.put("cbsId", searchObj[3]);
			proposalSearchMap.put("appId", searchObj[4]);
			proposalSearchMap.put("panNo", searchObj[5]);
			proposalSearchMapList.add(proposalSearchMap);
		}
		return proposalSearchMapList;
	}

	
	
}
