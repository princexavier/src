package com.sai.lendperfect.app.customerdetails;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.jsoup.Jsoup;
import org.jsoup.select.Elements;
//import org.jsoup.Jsoup;
//import org.jsoup.select.Elements;
import org.xml.sax.InputSource;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.sai.lendperfect.ackresponse.REQUESTRESPONSE;
import com.sai.lendperfect.application.model.LpcustAppcustRelation;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustCibilIndividual;
import com.sai.lendperfect.application.model.LpcustLoanDetail;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.cbsmodel.Custdetails;
import com.sai.lendperfect.cibil.ObjectFactory;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.ADDRESSES;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.ADDRESSES.ADDRESS;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.APPLICANTNAME;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.DOB;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.EMAILS;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.IDS;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.IDS.ID;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.PHONES;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.PHONES.PHONE;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.RELATIONS;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICANTSEGMENT.RELATIONS.RELATION;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.APPLICATIONSEGMENT;
import com.sai.lendperfect.cibil.REQUESTREQUESTFILE.HEADERSEGMENT;
import com.sai.lendperfect.commodel.LpcomMailbox;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.gson.ApplicationParams;
import com.sai.lendperfect.gson.BureauResponse;
import com.sai.lendperfect.gson.ResponsejsonData;
import com.sai.lendperfect.gson.Status;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasProperty;
import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setupmodel.LpstpPrdCoappguacount;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.LpstpScheme;
import com.sai.lendperfect.setupmodel.StGeographyMaster;


@SuppressWarnings({"rawtypes","unchecked","unused","deprecation"})
public class CustomerDetailsProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map <String,Object> responseHashMap=new HashMap<String,Object>();
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		LpcustApplicantData lpcustApplicantData = new LpcustApplicantData();
		Custdetails custDetails = new Custdetails();
		LpcomProposal lpcomProposal = new LpcomProposal();
		LpcustAppcustRelation lpcustAppcustRelation = new LpcustAppcustRelation();
		LpcustLoanDetail lpcustLoanDetail = new LpcustLoanDetail();
		StGeographyMaster stGeographyMaster = new StGeographyMaster();
		StGeographyMaster stGeographyMasterPermAddr = new StGeographyMaster();
		String userid = (String) session.getAttribute("userid");
		BigDecimal code =   (BigDecimal) session.getAttribute("orgId");
		ObjectMapper mapper = new ObjectMapper();
		if(dpMethod.equals("saveRecord")){
			try{	
						
				 Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
				 lpcustApplicantData = mapper.convertValue(requestMap.get("lad"),LpcustApplicantData.class);
				 lpcomProposal = mapper.convertValue(requestMap.get("lcm"),LpcomProposal.class);
				 lpcustAppcustRelation = mapper.convertValue(requestMap.get("lar"),LpcustAppcustRelation.class);
				 LpcustAppcustRelation lpcustAppRelation = new LpcustAppcustRelation();
				 List<LpcustLoanDetail> lpcustLoanDetail1=new ArrayList<>();
				 LpcustLoanDetail lpcustLoanDetails = new LpcustLoanDetail();
				 LpstpProductDet LpstpProductDet = new LpstpProductDet();	
				 
				 
				 if(lpcustApplicantData.getLadId() == 0)
				 {
					 if(lpcustAppcustRelation.getLarType() == null || lpcustAppcustRelation.getLarType().equals("s"))
					 {
						 
						    
						    lpcustApplicantData.setLadCreatedBy(userid);
						    lpcustApplicantData.setLadCreatedOn(Helper.getSystemDate());
						    lpcustApplicantData.setLadModifiedBy(userid);
						    lpcustApplicantData.setLadModifiedOn(Helper.getSystemDate());
						    lpcustApplicantData = serviceProvider.getCustomerDetailsService().saveApplicant(lpcustApplicantData);	
						    if(lpcustApplicantData.getLadState()!=null && lpcustApplicantData.getLadCity()!= null)
							 {
								    stGeographyMaster = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadState(), lpcustApplicantData.getLadCity());
									stGeographyMasterPermAddr = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadPermstate(), lpcustApplicantData.getLadPermcity());
									
									lpcustApplicantData.setLadCityName(stGeographyMaster.getSgmCityName());
//									lpcustApplicantData.setLadDistrictName(stGeographyMaster.getSgmDistrictName());
									lpcustApplicantData.setLadStateName(stGeographyMaster.getSgmStateName());
									
									lpcustApplicantData.setLadPermCityName(stGeographyMasterPermAddr.getSgmCityName());
//									lpcustApplicantData.setLadPermDistrictName(stGeographyMasterPermAddr.getSgmDistrictName());
									lpcustApplicantData.setLadPermStateName(stGeographyMasterPermAddr.getSgmStateName());
							 }
						 	if(lpcustApplicantData.getLadOldid()==null)		{	
						    lpcustApplicantData.setLadOldid(new BigDecimal(lpcustApplicantData.getLadId()));
						 	}
						    lpcustApplicantData = serviceProvider.getCustomerDetailsService().saveApplicant(lpcustApplicantData);
						 
						 	//lpcomProposal.setLpOrgCode(code);
						    lpcomProposal.setLpPropNo(serviceProvider.getApplication().getProposalNo((session.getAttribute("orgId")).toString()));
						    lpcomProposal.setLpBizVertical("Retail");
						    lpcomProposal.setLpIsDeleted("N");
						    lpcomProposal.setLpStatus("OP");
						    lpcomProposal.setLpPropHolder(userid);
						    lpcomProposal.setLpCreatedBy(userid);
						    lpcomProposal.setLpCreatedOn(Helper.getSystemDate());
						    lpcomProposal.setLpModifiedBy(userid);
						    lpcomProposal.setLpModifiedOn(Helper.getSystemDate());
						    lpcomProposal = serviceProvider.getCustomerDetailsService().save(lpcomProposal);
 
						    
							
						    LpcustApplicantData lpApplicantData = serviceProvider.getCustomerDetailsService().findByID(lpcustApplicantData.getLadId());
							lpcustAppRelation.setLpcustApplicantData(lpApplicantData);
							lpcustAppRelation.setLpcomProposal(lpcomProposal);
							lpcustAppRelation.setLarType("A");
							lpcustAppRelation.setLarIncludeincome("Y");
							lpcustAppRelation.setLarCreatedBy(userid);
							lpcustAppRelation.setLarCreatedOn(Helper.getSystemDate());
							lpcustAppRelation.setLarModifiedBy(userid);
							lpcustAppRelation.setLarModifiedOn(Helper.getSystemDate());
							lpcustAppRelation = serviceProvider.getApplicationRelation().save(lpcustAppRelation);
								
							
					 }
					 else
					 {
						 
						 lpcustApplicantData.setLadCreatedBy(userid);
						 lpcustApplicantData.setLadCreatedOn(Helper.getSystemDate());
						 lpcustApplicantData.setLadModifiedBy(userid);
						 lpcustApplicantData.setLadModifiedOn(Helper.getSystemDate());
						 lpcustApplicantData = serviceProvider.getCustomerDetailsService().saveApplicant(lpcustApplicantData);
						 if(lpcustApplicantData.getLadOldid()==null)		{	
							   lpcustApplicantData.setLadOldid(new BigDecimal(lpcustApplicantData.getLadId()));
							}
						 lpcustApplicantData = serviceProvider.getCustomerDetailsService().saveApplicant(lpcustApplicantData);
						 
						 lpcomProposal.setLpBizVertical("Retail");
						 lpcomProposal.setLpIsDeleted("N");
						 lpcomProposal.setLpStatus("OP");
						 lpcomProposal.setLpPropHolder(userid);
						 lpcomProposal.setLpCreatedBy(userid);
						 lpcomProposal.setLpCreatedOn(Helper.getSystemDate());
						 lpcomProposal.setLpModifiedBy(userid);
						 lpcomProposal.setLpModifiedOn(Helper.getSystemDate());
						// lpcomProposal.setLpOrgCode(code);
						 lpcomProposal = serviceProvider.getCustomerDetailsService().save(lpcomProposal);
						 
						 LpcustApplicantData lpApplicantData = serviceProvider.getCustomerDetailsService().findByID(lpcustApplicantData.getLadId());
						 lpcustAppRelation.setLpcustApplicantData(lpApplicantData);
						 lpcustAppRelation.setLpcomProposal(lpcomProposal);
						 lpcustAppRelation.setLarType(lpcustAppcustRelation.getLarType());
						 lpcustAppRelation.setLarIncludeincome(lpcustAppcustRelation.getLarIncludeincome());
						 lpcustAppRelation.setLarModifiedBy(userid);
						 lpcustAppRelation.setLarRelation(lpcustAppcustRelation.getLarRelation());
						 lpcustAppRelation.setLarModifiedOn(Helper.getSystemDate());
						 lpcustAppRelation = serviceProvider.getApplicationRelation().save(lpcustAppRelation);
						 
						 
					 }
					 dataHashMap.put("ladDetails",lpcustApplicantData);
					 dataHashMap.put("lpcustAppRelation",lpcustAppRelation);
					 dataHashMap.put("lldApplicant",lpcustAppRelation.getLpcomProposal()); 
					 dataHashMap.put("prodDescription", LpstpProductDet);	
					 dataHashMap.put("lpcustLoanDetail",lpcustLoanDetails);					 
				 }
				 
				 
				 else
				 {
					 lpcustApplicantData.setLadCreatedBy(userid);
					 lpcustApplicantData.setLadCreatedOn(Helper.getSystemDate());
					 lpcustApplicantData.setLadModifiedBy(userid);
					 lpcustApplicantData.setLadModifiedOn(Helper.getSystemDate());
					 lpcustApplicantData = serviceProvider.getCustomerDetailsService().saveApplicant(lpcustApplicantData);
					 
					 lpcustApplicantData.setLadOldid(lpcustApplicantData.getLadOldid());
					 lpcustApplicantData = serviceProvider.getCustomerDetailsService().saveApplicant(lpcustApplicantData);

					 if(lpcustApplicantData.getLadState()!=null && lpcustApplicantData.getLadCity()!= null)
					 {
						    stGeographyMaster = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadState(), lpcustApplicantData.getLadCity());
							stGeographyMasterPermAddr = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadPermstate(), lpcustApplicantData.getLadPermcity());
							
							lpcustApplicantData.setLadCityName(stGeographyMaster.getSgmCityName());
//							lpcustApplicantData.setLadDistrictName(stGeographyMaster.getSgmDistrictName());
							lpcustApplicantData.setLadStateName(stGeographyMaster.getSgmStateName());
							
							lpcustApplicantData.setLadPermCityName(stGeographyMasterPermAddr.getSgmCityName());
//							lpcustApplicantData.setLadPermDistrictName(stGeographyMasterPermAddr.getSgmDistrictName());
							lpcustApplicantData.setLadPermStateName(stGeographyMasterPermAddr.getSgmStateName());
					 }
					 
					 lpcustAppRelation =  serviceProvider.getApplicationRelation().findByLpcustApplicantData(lpcustApplicantData);
					 
					 LpcomProposal proposal = serviceProvider.getLpcomProposalService().findByLpPropNo(lpcomProposal.getLpPropNo());
					 
					 proposal.setLpOrgCode(lpcomProposal.getLpOrgCode());
					 
					 lpcomProposal = serviceProvider.getCustomerDetailsService().save(proposal);
					 

					 if(lpcustAppRelation.getLarId() != 0)
					 {
						 lpcustAppcustRelation.setLarId(lpcustAppRelation.getLarId());
						 LpcustApplicantData lpApplicantData = serviceProvider.getCustomerDetailsService().findByID(lpcustApplicantData.getLadId());
						 lpcustAppcustRelation.setLpcustApplicantData(lpcustApplicantData);
						 lpcustAppcustRelation.setLpcomProposal(lpcustAppRelation.getLpcomProposal());
						 lpcustAppcustRelation.setLarCreatedOn(Helper.getSystemDate());
						 lpcustAppcustRelation.setLarCreatedBy(userid);
						 lpcustAppRelation.setLarIncludeincome(lpcustAppcustRelation.getLarIncludeincome());
						 lpcustAppcustRelation.setLarModifiedBy(userid);
						 lpcustAppcustRelation.setLarModifiedOn(Helper.getSystemDate());
						 lpcustAppcustRelation = serviceProvider.getApplicationRelation().save(lpcustAppcustRelation);
					 }      
					 lpcustLoanDetail1= (List<LpcustLoanDetail>) serviceProvider.getLoanDetailsService().findByLpProposal(lpcustAppcustRelation.getLpcomProposal());
					
					 long prod_code = 0;
						 for(int i=0;i<lpcustLoanDetail1.size();i++)
						 {
							 if(lpcustLoanDetail1.get(i).getLldSno() != 0)
							 {
								 prod_code = lpcustLoanDetail1.get(i).getLldPrdcode();
								  if(prod_code != 0)
									 {
										 LpstpProductDet = serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prod_code);
									 }
								 }									 
						 }
						 dataHashMap.put("prodDescription", LpstpProductDet);	
						 dataHashMap.put("lpcustLoanDetail",lpcustLoanDetail1);
						 dataHashMap.put("lldApplicant",lpcustAppcustRelation.getLpcomProposal()); 
						 dataHashMap.put("ladDetails",lpcustApplicantData);
						 dataHashMap.put("lpcustAppRelation",lpcustAppcustRelation);
						 session.setAttribute("LP_COM_PROP_NO", lpcustAppcustRelation.getLpcomProposal().getLpPropNo());
				 }
				
					
					dataHashMap.put("ladDetails",lpcustApplicantData);
					session.setAttribute("CustId", lpcustApplicantData.getLadId());
					session.setAttribute("Status", lpcustApplicantData.getLadStatus());
					
							
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
						
			}catch (Exception e) {
				if (!dataHashMap.containsKey("errorData")) {
			logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
			dataHashMap.put("errorData",new CustomErr(e.getMessage()));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
		
 			else if(dpMethod.equals("getProductDetails"))
			{	
				try
				{
					BigDecimal propNo = (BigDecimal) session.getAttribute("LP_COM_PROP_NO");
					Map <String,Object> dpHashMap=new HashMap<String,Object>();
					dpHashMap=(Map<String, Object>) allRequestParams.get("requestData");
					String mainfacId= dpHashMap.get("lpdPrdMainCat").toString();
					String subfacId= dpHashMap.get("lpdPrdSubCat").toString();
					List<LpstpProductDet> LpstpProductDetailsList=serviceProvider.getLpstpProductDetService().findByLpdPrdMainCatAndLpdPrdSubCatAndLpdActiveAndLpdComplete(mainfacId, subfacId, "Y", "Y");
					Iterator lpstpProductDetailsListItr = LpstpProductDetailsList.iterator();
					while(lpstpProductDetailsListItr.hasNext())
					{
						LpstpProductDet lpstpProductDet = (LpstpProductDet) lpstpProductDetailsListItr.next();
					}
					dataHashMap.put("LpstpProductDetailsList", LpstpProductDetailsList);
					responseHashMap.put("responseData", dataHashMap);
					responseHashMap.put("success", true);
				}
				catch (Exception ex) {
					dataHashMap.put("errorData", ex.getLocalizedMessage());
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
				 
			}
	}
 			else if(dpMethod.equals("getSchemeDetails"))
			{	
				try
				{
					BigDecimal propNo = (BigDecimal) session.getAttribute("LP_COM_PROP_NO");
					Map <String,Object> dpHashMap=new HashMap<String,Object>();
					List<LpstpProductDet> productDetailsList = new ArrayList<LpstpProductDet>();
					dpHashMap=(Map<String, Object>) allRequestParams.get("requestData");
					String mainfacId= dpHashMap.get("lpdPrdMainCat").toString();					
					List<LpstpProductDet> LpstpProductDetailsList=serviceProvider.getLpstpProductDetService().findByLpdPrdMainCatAndLpdActiveAndLpdComplete(mainfacId, "Y", "Y");
					Iterator lpstpProductDetailsListItr = LpstpProductDetailsList.iterator();
					while(lpstpProductDetailsListItr.hasNext())
					{
						LpstpProductDet lpstpProductDet = (LpstpProductDet) lpstpProductDetailsListItr.next();
						productDetailsList.add(lpstpProductDet);
					}
					dataHashMap.put("LpstpProductDetailsList", productDetailsList);
					responseHashMap.put("responseData", dataHashMap);
					responseHashMap.put("success", true);
				}
				catch (Exception ex) {
					dataHashMap.put("errorData", ex.getLocalizedMessage());
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
				 
			}
	}
		else
			if(dpMethod.equals("getMasterData"))
			{
				 
				try{
					dataHashMap.put("title",serviceProvider.getCustomerDetailsService().findByllvHeader("title"));
					dataHashMap.put("resident",serviceProvider.getCustomerDetailsService().findByllvHeader("resident"));
					//DetailedEntry Customerdetails Added By Sathish.S
					dataHashMap.put("gender",serviceProvider.getCustomerDetailsService().findByllvHeader("gender"));
					dataHashMap.put("educationqualification",serviceProvider.getCustomerDetailsService().findByllvHeader("educationqualification"));
					dataHashMap.put("typeofprofession",serviceProvider.getCustomerDetailsService().findByllvHeader("typeofprofession"));
					dataHashMap.put("religion",serviceProvider.getCustomerDetailsService().findByllvHeader("religion"));
					dataHashMap.put("minority",serviceProvider.getCustomerDetailsService().findByllvHeader("minority"));
					dataHashMap.put("maritalstatus",serviceProvider.getCustomerDetailsService().findByllvHeader("maritalstatus"));
					dataHashMap.put("employment",serviceProvider.getCustomerDetailsService().findByllvHeader("employment"));
					dataHashMap.put("lineofactivity",serviceProvider.getCustomerDetailsService().findByllvHeader("lineofactivity"));
					dataHashMap.put("category",serviceProvider.getCustomerDetailsService().findByllvHeader("category"));
					dataHashMap.put("applbanking",serviceProvider.getCustomerDetailsService().findByllvHeader("applbanking"));
					dataHashMap.put("bankrelation",serviceProvider.getCustomerDetailsService().findByllvHeader("bankrelation"));
					dataHashMap.put("jobtransferrable",serviceProvider.getCustomerDetailsService().findByllvHeader("jobtransferrable"));
					dataHashMap.put("jobnoofyears",serviceProvider.getCustomerDetailsService().findByllvHeader("jobnoofyears"));
					//DetailedEntry Loandetails Masters Added by Sathish
					dataHashMap.put("interesttype",serviceProvider.getCustomerDetailsService().findByllvHeader("interesttype"));
					dataHashMap.put("interesttypestatus",serviceProvider.getCustomerDetailsService().findByllvHeader("interesttypestatus"));
					dataHashMap.put("interestchargedhoildayperiod",serviceProvider.getCustomerDetailsService().findByllvHeader("interestchargedhoildayperiod"));
					dataHashMap.put("periodicityinstallment",serviceProvider.getCustomerDetailsService().findByllvHeader("periodicityinstallment"));
					dataHashMap.put("repaymnenttype",serviceProvider.getCustomerDetailsService().findByllvHeader("repaymnenttype"));
					dataHashMap.put("HolidayPeriodRequest",serviceProvider.getCustomerDetailsService().findByllvHeader("HolidayPeriodRequest"));
					dataHashMap.put("loansecured",serviceProvider.getCustomerDetailsService().findByllvHeader("loansecured"));
					dataHashMap.put("Applicant",serviceProvider.getCustomerDetailsService().findByllvHeader("Applicant"));
					dataHashMap.put("Relationship",serviceProvider.getCustomerDetailsService().findByllvHeader("Relationship"));
					dataHashMap.put("memtype", serviceProvider.getCustomerDetailsService().findByllvHeader("membershiptype"));
					dataHashMap.put("mobility", serviceProvider.getCustomerDetailsService().findByllvHeader("mobility"));
					dataHashMap.put("residencetype", serviceProvider.getCustomerDetailsService().findByllvHeader("residencetype"));
					dataHashMap.put("salaryrouted", serviceProvider.getCustomerDetailsService().findByllvHeader("salaryrouted"));
					dataHashMap.put("vicinity", serviceProvider.getCustomerDetailsService().findByllvHeader("vicinity"));
					
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
							
				}catch (Exception e) {
					if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
				dataHashMap.put("errorData",new CustomErr(e.getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
		
			else
				if(dpMethod.equals("getBasicDetails"))
				{
					try{

                     	BigDecimal propNo = new BigDecimal((String) session.getAttribute("LP_COM_PROP_NO").toString());
						LpcomProposal lpcomProposalobj=serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
						List<LpcustLoanDetail> lpLoanDetail = (List<LpcustLoanDetail>) serviceProvider.getLoanDetailsService().findByLpProposal(lpcomProposalobj);
						List<LpcustAppcustRelation> lpcustAppcustRelate =  (List<LpcustAppcustRelation>) serviceProvider.getApplicationRelationService().findByLpcomProposal(lpcomProposalobj);
						List<LpcustApplicantData> al = new ArrayList<LpcustApplicantData>();
						List<LpcustAppcustRelation> LpRelation = new ArrayList<LpcustAppcustRelation>();
						LpcustLoanDetail lpcustDetail = new LpcustLoanDetail();
						LpcustAppcustRelation lpcustRelation = new LpcustAppcustRelation();

						for(int i=0;i<lpcustAppcustRelate.size();i++)
						{ 		
							if(lpcustAppcustRelate.get(i).getLarType().equals("A")){
							LpcustApplicantData lpcustAppData = new LpcustApplicantData();
							lpcustRelation = lpcustAppcustRelate.get(i);
							LpRelation.add(lpcustRelation);
							
							lpcustAppData = lpcustAppcustRelate.get(i).getLpcustApplicantData();
							lpcustApplicantData = serviceProvider.getCustomerDetailsService().findByID(lpcustAppData.getLadId());
							lpcustApplicantData.setLadDistrict(lpcustApplicantData.getLadDistrict());
							lpcustApplicantData.setLadPermdistrict(lpcustApplicantData.getLadPermdistrict());
							stGeographyMaster = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadState(), lpcustApplicantData.getLadCity());
							stGeographyMasterPermAddr = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadPermstate(), lpcustApplicantData.getLadPermcity());
							
							lpcustApplicantData.setLadCityName(stGeographyMaster.getSgmCityName());
//							lpcustApplicantData.setLadDistrictName(stGeographyMaster.getSgmDistrictName());
							lpcustApplicantData.setLadStateName(stGeographyMaster.getSgmStateName());
							
							lpcustApplicantData.setLadPermCityName(stGeographyMasterPermAddr.getSgmCityName());
//							lpcustApplicantData.setLadPermDistrictName(stGeographyMasterPermAddr.getSgmDistrictName());
							lpcustApplicantData.setLadPermStateName(stGeographyMasterPermAddr.getSgmStateName());
																				
							al.add(lpcustApplicantData);
							 							
						}
					}
						for(int i=0;i<lpLoanDetail.size();i++)
						{
                           	long serialNo  = lpLoanDetail.get(i).getLldSno();
                           	if(serialNo == 1)
                           	{
                           		lpcustDetail = lpLoanDetail.get(i);
                           		session.setAttribute("ProcFlag", lpcustDetail.getLldInprincFlag());
                           	}
							
						}
						
						LpstpProductDet LpstpProductDet = new LpstpProductDet();
						 long prod_code = 0;
													 
								 if(lpcustDetail.getLldSno() != 0)
								 {
									 prod_code = lpcustDetail.getLldPrdcode();
									  if(prod_code != 0)
										 {
											 LpstpProductDet = serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prod_code);
										 }
									 }									 
						 List<LpcomMailbox>  lpcomMailbox = serviceProvider.getLpcomMailboxService().findByLpcomProposal(lpcomProposalobj);	
						 if(LpstpProductDet.getLpdPrdSubCat() != null){
							 LpstpScheme LpstpScheme = serviceProvider.getLpstpSchemeService().findByLsSubFacility(Long.valueOf(LpstpProductDet.getLpdPrdSubCat()));
						
						 int flowSize = lpcomMailbox.size() - 1;
												 

					//	 session.setAttribute("Flow_Type",lpcomMailbox.get(flowSize).getLmType());

						 session.setAttribute("Workflow_Id", LpstpScheme.getLsWfProcessId());
								 
						 dataHashMap.put("prodDescription", LpstpProductDet);
						 dataHashMap.put("lpcomProposal",lpcomProposalobj);
						 dataHashMap.put("ladDetails",al);
						
						
						dataHashMap.put("larRelation",LpRelation);	
						dataHashMap.put("lldApplicant",lpcustDetail);
						dataHashMap.put("lcmPropNo", propNo);
						responseHashMap.put("success", true);
						responseHashMap.put("responseData", dataHashMap);
						 }
					}catch (Exception e) {
						if (!dataHashMap.containsKey("errorData")) {;
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
					dataHashMap.put("errorData",new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
							}
						}
				}
					else
						if(dpMethod.equals("getDropdownDetails"))
						{
							try{
								List<Map<String,Object>> lpApplicantDataList=new ArrayList<>();
								BigDecimal propNo = (BigDecimal) session.getAttribute("LP_COM_PROP_NO");
								LpcomProposal lpcomProposalobj=serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
								List<LpcustAppcustRelation> lpcustAppRelationlist = (List<LpcustAppcustRelation>) serviceProvider.getApplicationRelation().findByLpcomProposalOrderByLpcustApplicantData(lpcomProposalobj);
								Iterator<LpcustAppcustRelation> lpcustAppcustRelationIterator=lpcustAppRelationlist.iterator();
								while(lpcustAppcustRelationIterator.hasNext()) {
									LpcustAppcustRelation lpCustRelationData=lpcustAppcustRelationIterator.next();
									Long value = lpCustRelationData.getLpcustApplicantData().getLadId();
									lpcustApplicantData = serviceProvider.getCustomerDetailsService().findByID(value);
									String larType = lpCustRelationData.getLarType();									
									
									HashMap<String,Object> lpCustRelation=new HashMap<>();
									lpCustRelation.put("lpcustApplicantData", lpcustApplicantData);
									lpCustRelation.put("larType",larType);
									lpApplicantDataList.add(lpCustRelation);
								}								
								responseHashMap.put("success", true);
								responseHashMap.put("responseData", lpApplicantDataList);	
							}catch (Exception e) {
								if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
							dataHashMap.put("errorData",new CustomErr(e.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
									}
								}
						}
						else
							if(dpMethod.equals("getDetailsForDropDown"))
							{
								try{
									 BigDecimal propNo = (BigDecimal) session.getAttribute("LP_COM_PROP_NO");
									 Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
									 long l_ladId = Long.parseLong(String.valueOf( requestMap.get("custId")));
									 lpcustApplicantData = serviceProvider.getCustomerDetailsService().findByID(l_ladId);
									 lpcustApplicantData.setLadDistrict(lpcustApplicantData.getLadDistrict());
									 lpcustApplicantData.setLadPermdistrict(lpcustApplicantData.getLadPermdistrict());
									 stGeographyMaster = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadState(), lpcustApplicantData.getLadCity());
									 stGeographyMasterPermAddr = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadPermstate(), lpcustApplicantData.getLadPermcity());
									 
									    lpcustApplicantData.setLadCityName(stGeographyMaster.getSgmCityName());
//										lpcustApplicantData.setLadDistrictName(stGeographyMaster.getSgmDistrictName());
										lpcustApplicantData.setLadStateName(stGeographyMaster.getSgmStateName());
										
										lpcustApplicantData.setLadPermCityName(stGeographyMasterPermAddr.getSgmCityName());
//										lpcustApplicantData.setLadPermDistrictName(stGeographyMasterPermAddr.getSgmDistrictName());
										lpcustApplicantData.setLadPermStateName(stGeographyMasterPermAddr.getSgmStateName());
										
									 dataHashMap.put("ladDetails",lpcustApplicantData);
									 LpcomProposal lpcomProposalobj=serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
									 List<LpcustLoanDetail> lpLoanDetail = (List<LpcustLoanDetail>) serviceProvider.getLoanDetailsService().findByLpProposal(lpcomProposalobj);

									 //lpcustAppcustRelation = serviceProvider.getApplicationRelation().findBylarAppid(l_ladId);

									

									 lpcustAppcustRelation = serviceProvider.getApplicationRelation().findByLpcustApplicantData(lpcustApplicantData);

									 LpstpProductDet LpstpProductDet = new LpstpProductDet();
									 long prod_code = 0;
										 for(int i=0;i<lpLoanDetail.size();i++)
										 {
											 if(lpLoanDetail.get(i).getLldSno() != 0)
											 {
												 prod_code = lpLoanDetail.get(i).getLldPrdcode();
												  if(prod_code != 0)
													 {
														 LpstpProductDet = serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prod_code);
													 }
												 }									 
										 }
										 String larType = lpcustAppcustRelation.getLarType();
										 dataHashMap.put("Type",larType);
									 dataHashMap.put("prodDescription", LpstpProductDet);
									 dataHashMap.put("lldLoanDetail",lpLoanDetail);
									 dataHashMap.put("larDetails", lpcustAppcustRelation);
									 responseHashMap.put("responseData", dataHashMap);				
								}catch (Exception e) {
									if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
								dataHashMap.put("errorData",new CustomErr(e.getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
										}
									}
							}
								else
									if(dpMethod.equals("saveDropDown"))
									{
										try{

											List<Map<String,Object>> lpApplicantDataList=new ArrayList<>();
											lpApplicantDataList = (List<Map<String, Object>>) allRequestParams.get("requestData");
											for(int i=0;i<lpApplicantDataList.size();i++)
											{
												lpcustApplicantData = mapper.convertValue(lpApplicantDataList.get(i).get("lpcustApplicantData"),LpcustApplicantData.class);
												long val = lpcustApplicantData.getLadId();

												lpcustAppcustRelation = serviceProvider.getApplicationRelation().findByLpcustApplicantData(lpcustApplicantData);

												if(lpcustAppcustRelation != null)
												{
													lpcustAppcustRelation.setLarType((String) lpApplicantDataList.get(i).get("larType"));
													lpcustAppcustRelation.setLarModifiedBy(userid);
													lpcustAppcustRelation.setLarModifiedOn(Helper.getSystemDate());
													serviceProvider.getApplicationRelation().save(lpcustAppcustRelation);
												}

												System.out.println(lpcustApplicantData);
											}
											
										}catch (Exception e) {
											if (!dataHashMap.containsKey("errorData")) {
										logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
										dataHashMap.put("errorData",new CustomErr(e.getMessage()));
										responseHashMap.put("success", false);
										responseHashMap.put("responseData", dataHashMap);
												}
											}
									}

			
									else
										if(dpMethod.equals("saveAdditionalDetails"))
										{
											try{
												Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
												lpcustApplicantData = mapper.convertValue(requestMap.get("lad"),LpcustApplicantData.class);
												
												 lpcustApplicantData.setLadCreatedBy(userid);
											     lpcustApplicantData.setLadCreatedOn(Helper.getSystemDate());
											     lpcustApplicantData.setLadModifiedBy(userid);
											     lpcustApplicantData.setLadModifiedOn(Helper.getSystemDate());
											     lpcustApplicantData = serviceProvider.getCustomerDetailsService().saveApplicant(lpcustApplicantData);	
											    
											     dataHashMap.put("ladDetails",lpcustApplicantData);
												
											     responseHashMap.put("success", true);
												 responseHashMap.put("responseData", dataHashMap);
												
											}catch (Exception e) {
												if (!dataHashMap.containsKey("errorData")) {
											logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
											dataHashMap.put("errorData",new CustomErr(e.getMessage()));
											responseHashMap.put("success", false);
											responseHashMap.put("responseData", dataHashMap);
													}
												}
										}

						
		
									else if(dpMethod.equals("getInboxDetails"))
									{	
										try
										{
											BigDecimal propNo = (BigDecimal) session.getAttribute("LP_COM_PROP_NO");
											LpcomProposal lpcomProposalobj=serviceProvider.getLpcomProposalService().findByLpPropNo(propNo);
											LpcustAppcustRelation lpcustAppRelation = serviceProvider.getApplicationRelation().findByLpcomProposalAndLarType(lpcomProposalobj, "A");
											LpcustApplicantData LpcustApplicantData =  serviceProvider.getCustomerDetailsService().findByID(lpcustAppRelation.getLpcustApplicantData().getLadId());
											LpcustLoanDetail lpcustDetail = serviceProvider.getLoanDetailsService().findByLpcomProposalAndLldSno(lpcomProposalobj, 1);	
											
											dataHashMap.put("lldLoanDetail", lpcustDetail);
											dataHashMap.put("ladDetails", LpcustApplicantData);
											dataHashMap.put("larRelation", lpcustAppRelation);
											
											responseHashMap.put("responseData", dataHashMap);
											responseHashMap.put("success", true);
										}
										catch (Exception ex) {
											    dataHashMap.put("errorData", ex.getLocalizedMessage());
												responseHashMap.put("success", false);
												responseHashMap.put("responseData", dataHashMap);
										 
									}
							}
									else if(dpMethod.equals("getDedupeLapsDetails")){
										try{
											 Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
											 long l_ladId = Long.parseLong(String.valueOf( requestMap.get("custId")));
											 lpcustApplicantData = serviceProvider.getCustomerDetailsService().findByID(l_ladId);
											 LpcustAppcustRelation lpcustAppRelation = serviceProvider.getApplicationRelation().findByLpcustApplicantData(lpcustApplicantData);
											 dataHashMap.put("ladDetails",lpcustApplicantData);
											 dataHashMap.put("larDetails","s");
											 dataHashMap.put("ladCbsId", lpcustApplicantData.getLadCbsid());
											 dataHashMap.put("gridCheck" , "true");
											 responseHashMap.put("responseData", dataHashMap);
										}
										catch(Exception ex){
											dataHashMap.put("errorData", ex.getLocalizedMessage());
											responseHashMap.put("success", false);
											responseHashMap.put("responseData", dataHashMap);
										}
									}
									else if(dpMethod.equals("getDedupeCbsDetails")){
										try{
											 Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
											 String l_cbsId = (String.valueOf( requestMap.get("cbsId")));
											 custDetails = serviceProvider.getCbsService().findByCifId(l_cbsId);
											 DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
										     String today = formatter.format(custDetails.getCustDob());
											 String phoneNo=custDetails.getMailingPhoneno();
											 String phno=phoneNo.substring(4, 6);
											 String num=phoneNo.substring(7);
											 String phneNum=phno.concat(num);
											 dataHashMap.put("name", custDetails.getName());
											 dataHashMap.put("mailingPhoneno", phneNum);
											 dataHashMap.put("custDob", today);
											 dataHashMap.put("panGirNum", custDetails.getPanGirNum());
											 dataHashMap.put("cifId", custDetails.getCifId());
											 dataHashMap.put("aadharNum", custDetails.getAadharNum());
											 dataHashMap.put("psprtNum", custDetails.getPsprtNum());
											 dataHashMap.put("mailingEmail", custDetails.getMailingEmail());
											 dataHashMap.put("addressLine1", custDetails.getMailingAddress1());
											 dataHashMap.put("addressLine2", custDetails.getMailingAddress2());
											 dataHashMap.put("addressLine3", custDetails.getMailingAddress3());
											 dataHashMap.put("city", custDetails.getMailingCity());
											 dataHashMap.put("state", custDetails.getMailingState());
											 dataHashMap.put("pincode", custDetails.getMailingPinCode());
											 dataHashMap.put("gender", custDetails.getGender());
											 dataHashMap.put("religion", custDetails.getReligion());
											 dataHashMap.put("maritalStatus",custDetails.getMaritalStatus());
											 responseHashMap.put("responseData", dataHashMap);
										}
										catch(Exception ex){
											dataHashMap.put("errorData", ex.getLocalizedMessage());
											responseHashMap.put("success", false);
											responseHashMap.put("responseData", dataHashMap);
										}
									}


										else
											if(dpMethod.equals("getGeographyDetailsForCopyAddr"))
											{
												try{
													Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
													lpcustApplicantData = mapper.convertValue(requestMap.get("lad"),LpcustApplicantData.class);
													
													stGeographyMasterPermAddr = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadState(), lpcustApplicantData.getLadCity());
													
													lpcustApplicantData.setLadPermCityName(stGeographyMasterPermAddr.getSgmCityName());
													lpcustApplicantData.setLadPermDistrictName(stGeographyMasterPermAddr.getSgmDistrictName());
													lpcustApplicantData.setLadPermStateName(stGeographyMasterPermAddr.getSgmStateName());
												    
												     dataHashMap.put("ladDetails",lpcustApplicantData);
													
												     responseHashMap.put("success", true);
													 responseHashMap.put("responseData", dataHashMap);
													
												}catch (Exception e) {
													if (!dataHashMap.containsKey("errorData")) {
												logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
												dataHashMap.put("errorData",new CustomErr(e.getMessage()));
												responseHashMap.put("success", false);
												responseHashMap.put("responseData", dataHashMap);
														}
													}
											}
											else if(dpMethod.equals("getCbsDetailsById")){
												try{
													Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
													String ladCbsId = (String.valueOf( requestMap.get("ladCbsid")));
													custDetails = serviceProvider.getCbsService().findByCifId(ladCbsId);
													 DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
												     String today = formatter.format(custDetails.getCustDob());
												     String phoneNo=custDetails.getMailingPhoneno();
													 String phno=phoneNo.substring(4, 6);
													 String num=phoneNo.substring(7);
													 String phneNum=phno.concat(num);
													 dataHashMap.put("name", custDetails.getName());
													 dataHashMap.put("mailingPhoneno", phneNum);
													 dataHashMap.put("custDob", today);
													 dataHashMap.put("panGirNum", custDetails.getPanGirNum());
													 dataHashMap.put("cifId", custDetails.getCifId());
													 dataHashMap.put("aadharNum", custDetails.getAadharNum());
													 dataHashMap.put("psprtNum", custDetails.getPsprtNum());
													 dataHashMap.put("mailingEmail", custDetails.getMailingEmail());
													 dataHashMap.put("addressLine1", custDetails.getPresentAddress1());
													 dataHashMap.put("addressLine2", custDetails.getPresentAddress2());
													 dataHashMap.put("addressLine3", custDetails.getPresentAddress3());
													 dataHashMap.put("city", custDetails.getPresentCity());
													 dataHashMap.put("state", custDetails.getPresentState());
													 dataHashMap.put("pincode", custDetails.getPresentPinCode());
													 dataHashMap.put("gender", custDetails.getGender());
													 dataHashMap.put("religion", custDetails.getReligion());
													 dataHashMap.put("maritalStatus",custDetails.getMaritalStatus());
									
													 responseHashMap.put("responseData", dataHashMap);
												}
												catch (Exception e) {
													if (!dataHashMap.containsKey("errorData")) {
												logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
												dataHashMap.put("errorData",new CustomErr(e.getMessage()));
												responseHashMap.put("success", false);
												responseHashMap.put("responseData", dataHashMap);
														}
													}
											}
											else if(dpMethod.equals("verificationCheck")){
												try{
													Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
													int id=(int) requestMap.get("id");
													lpcustApplicantData = serviceProvider.getCustomerDetailsService().findByLadId(id);
													String ladCbsId = lpcustApplicantData.getLadCbsid();
													BigDecimal ladOldid=lpcustApplicantData.getLadOldid();
													Map <String,Object> proposalMap;
													List<Map<String,Object>> verificationListMap=new ArrayList<Map<String,Object>>();
													List<LpcustApplicantData> applicantList = serviceProvider.getCustomerDetailsService().findByLadOldid(ladOldid);
													for(LpcustApplicantData appList : applicantList ){
													LpcustAppcustRelation lpcustAppcust= serviceProvider.getApplicationRelation().findByLpcustApplicantData(appList);
													LpcomProposal lpcomproposal = lpcustAppcust.getLpcomProposal();
													if(lpcomproposal.getLpStatus().equals("PR") || lpcomproposal.getLpStatus().equals("CR")){
													proposalMap=new HashMap<String,Object>();
													DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
												    String createdDate = formatter.format(lpcomproposal.getLpCreatedOn());
												    String rejectedDate = formatter.format(lpcomproposal.getLpApprovedDate());
													proposalMap.put("AppNo", lpcomproposal.getLpPropNo());
													proposalMap.put("CreatedDate", createdDate);
													proposalMap.put("Rejecteddate", rejectedDate);
													proposalMap.put("RejectedBy", lpcomproposal.getLpApprovedBy());
													List<LpcustLoanDetail> loanDetail= lpcomproposal.getLpcustLoanDetails();
													for(LpcustLoanDetail loan : loanDetail){
														LpstpProductDet prodDet= serviceProvider.getLpstpProductDetService().findByLpdProdNewId(loan.getLldPrdcode());
														LpstpScheme scheme = serviceProvider.getLpstpSchemeService().findByLsSchemeId(Long.valueOf(prodDet.getLpdPrdSubCat()));
														proposalMap.put("Scheme", scheme.getLsSchemeName());
													}
													BigDecimal orgCode = lpcomproposal.getLpOrgCode();
													LpstpOrganisation lpstpOrganisation=serviceProvider.getLpstpOrganisationService().findByLoOrgId(orgCode.longValue());
													proposalMap.put("Branch", lpstpOrganisation.getLoName());
													verificationListMap.add(proposalMap);
													}
													}
													if(ladCbsId==null){
														dataHashMap.put("cbsflag", "false");
													}
													else{
														dataHashMap.put("cbsflag", "true");
													}
													dataHashMap.put("applicantList",verificationListMap);
													responseHashMap.put("success", true);
													responseHashMap.put("responseData", dataHashMap);
													
												}catch(Exception e){
													if (!dataHashMap.containsKey("errorData")) {
														logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
														dataHashMap.put("errorData",new CustomErr(e.getMessage()));
														responseHashMap.put("success", false);
														responseHashMap.put("responseData", dataHashMap);
																}
												}
											}
		
											else if(dpMethod.equals("deleteApplicant")){
												try{
													Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
													int delLadId=(int) requestMap.get("delLadId");
													LpcustApplicantData lpcustapplicantData =serviceProvider.getCustomerDetailsService().findByLadId(delLadId);
													serviceProvider.getLpcomLiabilitiesService().deleteByLpcustApplicantData(lpcustapplicantData);
													serviceProvider.getLpcomOtherAssetsLiabilityService().deleteByLpcustApplicantData(lpcustapplicantData);
													serviceProvider.getApplicationRelation().deleteByLpcustApplicantData(lpcustapplicantData);
													responseHashMap.put("success", true);
													
												}catch(Exception e){
													if (!dataHashMap.containsKey("errorData")) {
														logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
														dataHashMap.put("errorData",new CustomErr(e.getMessage()));
														responseHashMap.put("success", false);
														responseHashMap.put("responseData", dataHashMap);
																}
												}
												
											}
		
											else if(dpMethod.equals("getBranchList")){
												try{
													LpstpOrganisation lpstpOrganisation = serviceProvider.getLpstpOrganisationService().findByLoOrgId(code.longValue());
													List<LpstpOrganisation> orgNameList = serviceProvider.getLpstpOrganisationService().findAllOrderByName();
//													BigDecimal propNo = new BigDecimal((String) session.getAttribute("LP_COM_PROP_NO").toString());
													if(!((session.getAttribute("LP_COM_PROP_NO").toString()).equals("new"))){
													LpcomProposal lpcomProposalobj=serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString()));
													dataHashMap.put("lpcomProposal", lpcomProposalobj);
													}
													else{
													dataHashMap.put("firstLogin","true");
													}
													dataHashMap.put("orgName", lpstpOrganisation);
													dataHashMap.put("branchList", orgNameList);
													
													responseHashMap.put("responseData",dataHashMap );
												}catch(Exception e){
													if (!dataHashMap.containsKey("errorData")) {
														logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
														dataHashMap.put("errorData",new CustomErr(e.getMessage()));
														responseHashMap.put("success", false);
														responseHashMap.put("responseData", dataHashMap);
																}
												}
											}
		
											else if(dpMethod.equals("getCoappGuar")){
												try{
													Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
													int prdCode= (int) requestMap.get("lldPrdcode");
													BigDecimal lldAmtreqd=new BigDecimal(requestMap.get("lldAmtreqd").toString());
													List<LpstpPrdCoappguacount> coappguar=new ArrayList<>();
													List<LpstpPrdCoappguacount> lpstpCoappGuarList = serviceProvider.getLpstpPrdCoapguarcountService().findByLrcProdIdOrderByLrcRowId(new Long(prdCode));
													for(LpstpPrdCoappguacount coapguar : lpstpCoappGuarList){
														if(lldAmtreqd.compareTo(coapguar.getLrcAmtFrom()) >= 0 && lldAmtreqd.compareTo(coapguar.getLrcAmtTo()) <= 0){
															coappguar.add(coapguar);
														}
													}
													dataHashMap.put("coappguar", coappguar);
													responseHashMap.put("success", true);
													responseHashMap.put("responseData", dataHashMap);
												}catch(Exception e){
													if (!dataHashMap.containsKey("errorData")) {
														logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
														dataHashMap.put("errorData",new CustomErr(e.getMessage()));
														responseHashMap.put("success", false);
														responseHashMap.put("responseData", dataHashMap);
																}
												}
												}
		

//											else if(dpMethod.equals("getCibilScore")){
//												try{
//													 ArrayList<String> relValue = new ArrayList<String>();
//													 ArrayList<String> idList = new ArrayList<String>();
//												     ArrayList<String> idvalueList = new ArrayList<String>();
//												     ArrayList<String> phonenoList = new ArrayList<String>();
//													 ArrayList<String> phoneTypeList = new ArrayList<String>();
//													 HashMap<String,String> hshResult = new HashMap<>();
//													 Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
//													 String strPANNO="",StrRelationName="",strPASSPORT="",strADHAR="",StrIdType="",strMaristat="",strLoantype="",strloanpurpose="",strCbsId="",strMobileNo="",xmlString="";
//													 String strUserId="",strPassword="",Crif_reqUrl="",strAckRequestId="";
//													 String responseXml="",strresponseType="",Crif_resUrl="";
//													 String CHMStatus="",CIBILStatus="",CHMErrorDesc="",CIBILErrorDesc="";
//													 String strKendraName="",strOrgState="",strIfsccode="",strOrganisationName="",strLapsid="",hidAppNo="";
//													 LpmasProperty property;
//													 property=serviceProvider.getLpmasPropertyService().findByLpropDesc("Bureau Username");
//													 strUserId=property.getLpropValue();
//													 property=serviceProvider.getLpmasPropertyService().findByLpropDesc("Bureau Password");
//													 strPassword=property.getLpropValue();
//													 property=serviceProvider.getLpmasPropertyService().findByLpropDesc("Bureau Request URL");
//													 Crif_reqUrl=property.getLpropValue();
//													 property=serviceProvider.getLpmasPropertyService().findByLpropDesc("Bureau Reponse URL");
//													 Crif_resUrl=property.getLpropValue();
//													 LpcustApplicantData lpcustApplicant = mapper.convertValue(requestMap.get("lad"),LpcustApplicantData.class);
//													 lpcustApplicantData  = serviceProvider.getCustomerDetailsService().findByID(lpcustApplicant.getLadId());
//													 lpcustAppcustRelation = serviceProvider.getApplicationRelation().findByLpcustApplicantData(lpcustApplicantData);
//													 lpcomProposal = serviceProvider.getLpcomProposalService().findByLpPropNo(lpcustAppcustRelation.getLpcomProposal().getLpPropNo());
//													 lpcustLoanDetail = serviceProvider.getLoanDetailsService().findByLpcomProposalAndLldSno(lpcomProposal, 1);	
//													 stGeographyMaster = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadState(), lpcustApplicantData.getLadCity());
//													 lpcustApplicantData.setLadCityName(stGeographyMaster.getSgmCityName());
//													 lpcustApplicantData.setLadStateName(stGeographyMaster.getSgmStateName());
//													 LpstpOrganisation organisation = new LpstpOrganisation();
//													 organisation=serviceProvider.getLpstpOrganisationService().findByLoOrgId(lpcomProposal.getLpOrgCode().longValue());
//													 strOrgState=organisation.getLoState();
//													
//													 strIfsccode=organisation.getLoIfscCode();
//													 strOrganisationName=organisation.getLoName();
//													 strKendraName=organisation.getLoName();
//													 ArrayList BureauArray = new ArrayList();
//													 ArrayList RemarkArray = new ArrayList();
//													 ArrayList TypeArray =new ArrayList();
//													 strLapsid=Long.toString(lpcustApplicantData.getLadId());
//													 hidAppNo=lpcomProposal.getLpPropNo().toString();
//													 int age = 0;
//													 Date dob=lpcustApplicantData.getLadDob();
//													 Date now = new Date();  
//													 age=now.getYear()-  dob.getYear();
////													 LocalDate fromDate = dob.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
////													 LocalDate toDate = now.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
////													 age=calculateAge(fromDate,toDate);
//													 strPANNO=lpcustApplicantData.getLadPanno();
//													 strPASSPORT = lpcustApplicantData.getLadPassport();
//													 strADHAR=lpcustApplicantData.getLadaadhar();
//													 strLoantype= lpcustLoanDetail.getLldLoantype();
//													 strloanpurpose=lpcustLoanDetail.getLldPurposeofloan();
//													 strCbsId=lpcustApplicantData.getLadCbsid();
//													 if(strPANNO != null)
//														{
//															idList.add("02");
//															idvalueList.add(strPANNO);
//														}
//														if(strPASSPORT != null)
//														{
//															idList.add("03");
//															idvalueList.add(strPASSPORT);
//														}if(strADHAR!= null)
//														{
//															idList.add("01");
//															idvalueList.add(strADHAR);
//														}
//														
//														strMobileNo=lpcustApplicantData.getLadPhone();
//														phonenoList.add(strMobileNo);
//														 phoneTypeList.add("strMobileNo");
//													 	ObjectFactory factory = new ObjectFactory();
//														REQUESTREQUESTFILE requestFile=new REQUESTREQUESTFILE();
//														
//														HEADERSEGMENT headersegment =new HEADERSEGMENT();
//														headersegment.setPRODUCTTYPE("LOS-PD0011");
//														headersegment.setRESFRMT("XML");
//														headersegment.setLOSNAME("LOS");
//														headersegment.setLOSVENDER("LENDPERFECT");
//														headersegment.setLOSVERSION(new Byte("0"));
//														headersegment.setUSERID("shuganyaravi29@gmail.com");
//														requestFile.setHEADERSEGMENT(headersegment);
//														
//														APPLICANTSEGMENT applicantsegment = new APPLICANTSEGMENT();
//														APPLICANTNAME applicantName = new APPLICANTNAME();
//														applicantName.setNAME1(lpcustApplicantData.getLadFname());
//														applicantName.setNAME2("");
//														applicantName.setNAME3(lpcustApplicantData.getLadLname());
//														applicantName.setNAME4("");
//														applicantName.setNAME5("");
//														applicantsegment.setAPPLICANTNAME(applicantName);
//														
//														DOB dateofbirth = new DOB();
//														dateofbirth.setDOBDATE(lpcustApplicantData.getLadDob().toString());
//														dateofbirth.setAGE((byte) age);
//														dateofbirth.setAGEASON(new Date().toString());
//														applicantsegment.setDOB(dateofbirth);
//														
//														IDS identity = new IDS();
//														List<ID> identityList = new ArrayList<ID>();
//														ID identitydetails = new ID();
//														for(int i=0;i<idList.size();)
//														{
//															identitydetails = new ID();
//															if(idList.get(i).toString().length()==1)
//															{
//																StrIdType="0"+idList.get(i);
//															}
//															else
//															{
//																StrIdType=idList.get(i);
//															}
//														identitydetails.setTYPE(StrIdType);
//														identitydetails.setVALUE(idvalueList.get(i));
//														identityList.add(identitydetails);
//														i++;
//														}
//														identity.setId(identityList);
//														applicantsegment.setIDS(identity);
//														
//														if(!lpcustAppcustRelation.getLarType().equals("A")){
//															relValue.add(lpcustAppcustRelation.getLarRelation());
//															}
//														RELATIONS relations = new RELATIONS();
//														List<RELATION> relationList =new ArrayList<RELATION>();
//														RELATION relationdetails = new RELATION();
//														String strRelType="";
//														for(int k=0;k<relValue.size();)
//														{
//															relationdetails= new RELATION();
//															
//															String strRelation = relValue.get(0);
//															
//															if(strRelation.equalsIgnoreCase("1"))
//															{
//																strRelType="Father";//Father
//															}
//															else if(strRelation.equalsIgnoreCase("2"))
//															{
//																strRelType="Mother";//Mother
//															}
//															else if(strRelation.equalsIgnoreCase("3"))
//															{
//																strRelType="Husband";//Husband
//															}
//														relationdetails.setTYPE(strRelType);
//														relationdetails.setVALUE(StrRelationName);
//														relationList.add(relationdetails);
//														k++;
//														}
//														relations.setRelation(relationList);
//														applicantsegment.setRELATIONS(relations);
//														
//														PHONES phones = new PHONES();
//														List<PHONE> phoneList = new ArrayList<PHONE>();
//														PHONE phonedetails = new PHONE();
//														for(int j=0;j<phonenoList.size();)
//														{
//															phonedetails = new PHONE();
//															String strphone=phonenoList.get(j);
//															String strType=phoneTypeList.get(j);
//															if(strType.equalsIgnoreCase("strMobileNo") && !strphone.equals(""))
//															{
//																strType="01";
//															}
//															else
//															{
//																strType="";
//															}	
//														phonedetails.setTYPE(strType);
//														phonedetails.setVALUE(Long.valueOf(strphone));
//														phoneList.add(phonedetails);
//														j++;
//														}
//														phones.setPhone(phoneList);
//														applicantsegment.setPHONES(phones);
//														
//														EMAILS emaildetails = new EMAILS();
//														emaildetails.setEMAIL(lpcustApplicantData.getLadEmail());
//														applicantsegment.setEMAILS(emaildetails);
//														applicantsegment.setGENDER(serviceProvider.getCustomerDetailsService().findByLlvHeaderAndLlvOptionVal("gender",lpcustApplicantData.getLadSex()));
//														applicantsegment.setMARITALSTATUS(strMaristat);
//														applicantsegment.setENTITYID("eNTITY123");
//														
//														ADDRESSES addressess = new ADDRESSES();
//														List<ADDRESS> addressList = new ArrayList<ADDRESS>();
//														ADDRESS addressdetails = new ADDRESS();
//														addressdetails.setTYPE(serviceProvider.getCustomerDetailsService().findByLlvHeaderAndLlvOptionVal("resident",lpcustApplicantData.getLadResidential()));
//														addressdetails.setADDRESS1(lpcustApplicantData.getLadAddress1());
//														addressdetails.setCITY(lpcustApplicantData.getLadCityName());
//														addressdetails.setSTATE(lpcustApplicantData.getLadStateName());
//														addressdetails.setPINCODE(Integer.parseInt(lpcustApplicantData.getLadZip()));
//														addressList.add(addressdetails);
//														addressess.setAddress(addressList);
//														applicantsegment.setADDRESSES(addressess);
//														requestFile.setAPPLICANTSEGMENT(applicantsegment);
//														
//														APPLICATIONSEGMENT applicationssegment = new APPLICATIONSEGMENT();
//														applicationssegment.setLOANTYPE(strLoantype);
//														applicationssegment.setLOANPURPOSE(strloanpurpose);
//														applicationssegment.setAPPLICATIONDATE(lpcustLoanDetail.getLldCreatedOn().toString());
//														applicationssegment.setAPPLICATIONID(lpcomProposal.getLpPropNo().intValue());
//														applicationssegment.setLOANAMOUNT(Short.parseShort((lpcustLoanDetail.getLldAmtreqd().toString())));
//														if(strCbsId!=null){
//														applicationssegment.setCONSUMERID(Integer.parseInt(strCbsId));
//														}
//														applicationssegment.setBRANCH(strOrganisationName);
//														applicationssegment.setKENDRA(strKendraName);
//														 if(strIfsccode!=null)
//														applicationssegment.setIFSCCODE(Byte.valueOf(strIfsccode));
//														applicationssegment.setBRANCHSTATE(strOrgState);
//														applicationssegment.setOWNERSHIPINDICATOR("OWR");
//														requestFile.setAPPLICATIONSEGMENT(applicationssegment);
//														
//														JAXBContext jaxContext = null;
//														try{
//															 jaxContext = JAXBContext.newInstance("com.sai.lendperfect.cibil");	
//														}
//														catch(Exception e){
//															e.printStackTrace();
//														}
//														Marshaller marshaller = jaxContext.createMarshaller();
//														marshaller.setProperty(marshaller.JAXB_ENCODING,"UTF-8");
//														StringWriter sw = new StringWriter();
//														marshaller.marshal(requestFile, sw);
//														 xmlString = sw.toString().trim();
//														xmlString=xmlString.replaceAll("http://www.w3.org/2001/XMLSchema","");
//														xmlString=xmlString.replaceAll("xmlns:xs","");
//														xmlString=(Helper.replaceAll(xmlString, "=\"\"", "", false));
//														xmlString=xmlString.replaceAll("xs:","" ).trim();
//														xmlString=xmlString.replaceAll("REQUEST-REQUEST-FILE ", "REQUEST-REQUEST-FILE");
////														hshResult.put("xmlString", xmlString);
//														
//														
//														String responseX="";
//														responseX = GetCrifFirstHit(xmlString, strUserId, strPassword,Crif_reqUrl);
//														System.out.print("1st hit completed sucessfully");
//														String strAckStatus="";
//														System.out.println("=====sRespone Before====="+responseX);
//														responseX=responseX.replaceAll("<\\?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"\\?>", "");
//														System.out.println("=====sRespone After====="+responseX);	
//														InputSource is2=new InputSource();
//														is2.setCharacterStream(new StringReader(responseX));
//														JAXBContext jax2=JAXBContext.newInstance("com.sai.lendperfect.ackresponse");
//														Unmarshaller unmar2=jax2.createUnmarshaller();
//														
//														ObjectFactory objfac = new ObjectFactory();
//														
//														REQUESTRESPONSE ackreqresponse = (REQUESTRESPONSE)unmar2.unmarshal(is2);
//														
//														//com.sai.crif.ack.response.REQUESTRESPONSE.ERRORS errors = objfac.createREQUESTRESPONSEERRORS();
//														REQUESTRESPONSE.ERRORS errors = new REQUESTRESPONSE.ERRORS();
//														
//														REQUESTRESPONSE.ERRORS.ERROR errordetails = new REQUESTRESPONSE.ERRORS.ERROR();
//														
//														if(ackreqresponse.getSTATUS().equalsIgnoreCase("SUCCESS"))
//														{
//														strAckStatus=ackreqresponse.getSTATUS();
//														strAckRequestId=ackreqresponse.getREQUESTID();
//														System.out.println("Acknowledgement Request Status : "+ackreqresponse.getSTATUS());
//														System.out.println("Acknowledgement Request id : " +ackreqresponse.getREQUESTID());
//														}
//														else
//														{
//															System.out.println("Acknowledgement in error details description ======:"+ackreqresponse.getERRORS().getERROR().getERRORDESCRIPTION());
//														}
//														responseXml = GetCrifSecondHit(strAckRequestId, strresponseType, strUserId, strPassword,Crif_resUrl);
//														Gson gson = new Gson();
//														ResponsejsonData jsonObject=null;
//														 jsonObject = gson.fromJson(responseXml,ResponsejsonData.class);
//														System.out.println("GSOn strated1");
//														 ArrayList<Status> FullName1 = new ArrayList(jsonObject.getStatus());
//														 System.out.println("GSOn strated2");
//														 for(Status  s :FullName1)
//														 {
//															 BureauArray.add(s.getBureauName());
//															 RemarkArray.add(s.getRemark());
//															 TypeArray.add(s.getType());
//															 System.out.println("BureauArray======>"+BureauArray);
//															 System.out.println("RemarkArray=====>"+RemarkArray);
//															 System.out.println("TypeArray=====>"+TypeArray);
//														 }
//														 
//														 System.out.println("GSOn strated3 Main Block");
//														 ArrayList<BureauResponse> bureauResponse = new ArrayList(jsonObject.getBureauResponse());
//														 String strResponse="",CHMScore="",CIBILScore="",strHtmlResponse="",strXMLResponse="",strBureauNameDesc="",strpdfResponse="";
//														 for(BureauResponse  s1 :bureauResponse)
//														 {
//															 strBureauNameDesc = s1.getBureauName();
//															 //strXMLResponse =s1.getXmlResponse();
//															 strHtmlResponse = s1.getHtmlResponse();
//															 strpdfResponse =s1.getPdfResponse();
//														 }
//												    		
//												    	 System.out.println("strBureauName====="+strBureauNameDesc);
//												    	 System.out.println("JSoup started====\n");
//														  org.jsoup.nodes.Document html = Jsoup.parse(strHtmlResponse);
//														  Elements elements  = html.body().getElementsByClass("dataValue");
//														  for(int i=12;i<elements.size();i++)
//															 {
//															  CHMStatus = elements.get(i).html();
//																 System.out.println("CHMStatus is =============  "+CHMStatus);
//																 i+=2;
//																 CIBILStatus = elements.get(i).html();
//																 System.out.println("CIBILStatus is =============  "+CIBILStatus);
//																 if(CHMStatus.equalsIgnoreCase("ERROR") || CIBILStatus.equalsIgnoreCase("ERROR"))	
//																 {
//																	 if(CHMStatus.equalsIgnoreCase("ERROR"))
//																	 {
//																		 i-=1;
//																		 System.out.println("..............  "+i);
//																		 String Test = elements.get(i).html();
//																		 org.jsoup.nodes.Document jsoupdoc =Jsoup.parse(Test);
//																		 org.jsoup.nodes.Element jsoupele = jsoupdoc.select("table td:eq(0)").first();
//																		 System.out.println("CHMErrorDesc=======>>>>  "+jsoupele.text());
//																		 CHMErrorDesc = jsoupele.text();
//																		 if(CIBILStatus.equalsIgnoreCase("ERROR"))
//																			 i+=1;
//																	 }if(CIBILStatus.equalsIgnoreCase("ERROR"))
//																	 {
//																		 i+=1;
//																		 System.out.println("..............  "+i);
//																		 String Test1 = elements.get(i).html();
//																		 org.jsoup.nodes.Document jsoupdoc1 =Jsoup.parse(Test1);
//																		 org.jsoup.nodes.Element jsoupele1 = jsoupdoc1.select("table td:eq(0)").first();
//																		 System.out.println("CIBILErrorDesc======>>>>  "+jsoupele1.text());
//																		 CIBILErrorDesc = jsoupele1.text();
//																	 }
//																	 break;
//																 }else
//																 {
//																     int j = i;
//																     j=j-1;
//																     String NoHitCheck="";
//																     NoHitCheck = elements.get(j).html();
//																     System.out.println("NoHitCheck value is "+ NoHitCheck);
//																     if(NoHitCheck.length() > 0 )
//																     {
//																	     System.out.println("position..............  "+j);
//																		 String Test = elements.get(j).html();
//																		 org.jsoup.nodes.Document doc =Jsoup.parse(Test);
//																		 org.jsoup.nodes.Element ele = doc.select("table td:eq(0)").first();
//																		 System.out.println((ele.val()));
//																		 NoHitCheck = ele.text();
//																     }
//																	 if(NoHitCheck.equalsIgnoreCase("NO-HIT") && CHMStatus.equalsIgnoreCase("SUCCESS") && CIBILStatus.equalsIgnoreCase("SUCCESS"))
//																	 {
//																		 j+=4;
//																	 	 CHMScore ="0";
//																	 	 System.out.println("CHMScore is by Default of No-HIT=============  "+CHMScore);
//																		 CIBILScore = elements.get(j).html();
//																		 System.out.println("CIBILScore is =============  "+CIBILScore);
//																		 break;
//																	 }
//																	 else
//																	 {
//																		 i+=3;
//																	 	 CHMScore = elements.get(i).html();
//																		 System.out.println("CHMScore is =============  "+CHMScore);
//																		 i+=2;
//																		 CIBILScore = elements.get(i).html();
//																		 System.out.println("CIBILScore is =============  "+CIBILScore);
//																		 break;
//																	 }
//															 
//																 }
//															 } 
//														 	String strFileName="CHM" + strLapsid+"_"+hidAppNo;
//														    String strAbsolutePath="";
//														    String strCibilStatus="SUCCESS";
//														    String strErrorMsg="";
//														    File Directory = null;
//															String strpDFPath = ApplicationParams.getStrCHMPDFPATH();
//															Directory = new File(strpDFPath);
//															if (!Directory.exists())
//															{
//																Directory.mkdirs();
//															}
//															strFileName="CHM" + strLapsid+"_"+hidAppNo;
//															strAbsolutePath = strpDFPath + "/" + strFileName + ".PDF";
//															byte[] bytepdfData = DatatypeConverter.parseBase64Binary(strpdfResponse);
//															RandomAccessFile raf1 = new RandomAccessFile(new File(strAbsolutePath), "rw");
//															raf1.seek(strAbsolutePath.length());
//															
//															raf1.write(bytepdfData);
//															raf1.close();
//															
//															LpcustCibilIndividual lpcustCibilIndividual=new LpcustCibilIndividual();
//															lpcustCibilIndividual.setCiRefnumber(strLapsid);
//															lpcustCibilIndividual.setCiFilenumber(strFileName);
//															lpcustCibilIndividual.setCiReport(strHtmlResponse);
//															lpcustCibilIndividual.setCiStatus(strCibilStatus);
//															lpcustCibilIndividual.setCiCibiltuscr(new BigDecimal(CIBILScore));
//															lpcustCibilIndividual.setCiChmscr(CHMScore);
//															lpcustCibilIndividual.setCiErrormsg(strErrorMsg);
//															lpcustCibilIndividual.setAppno(hidAppNo);
//															lpcustCibilIndividual.setCiGenerateddate(new Date());
//															lpcustCibilIndividual.setCiGeneratedby(userid);
//															lpcustCibilIndividual.setCiPdfreport(bytepdfData);
//															serviceProvider.getLpcustCibilIndividualService().save(lpcustCibilIndividual);
//															
//												}
//												catch(Exception e){
//													e.printStackTrace();
//													if (!dataHashMap.containsKey("errorData")) {
//														logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
//														dataHashMap.put("errorData",new CustomErr(e.getMessage()));
//														responseHashMap.put("success", false);
//														responseHashMap.put("responseData", dataHashMap);
//																}
//												}
//											}

											else if(dpMethod.equals("getCibilScore")){
												try{
													 ArrayList<String> relValue = new ArrayList<String>();
													 ArrayList<String> idList = new ArrayList<String>();
												     ArrayList<String> idvalueList = new ArrayList<String>();
												     ArrayList<String> phonenoList = new ArrayList<String>();
													 ArrayList<String> phoneTypeList = new ArrayList<String>();
													 HashMap<String,String> hshResult = new HashMap<>();
													 Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
													 String strPANNO="",StrRelationName="",strPASSPORT="",strADHAR="",StrIdType="",strMaristat="",strLoantype="",strloanpurpose="",strCbsId="",strMobileNo="",xmlString="";
													 String strUserId="",strPassword="",Crif_reqUrl="",strAckRequestId="";
													 String responseXml="",strresponseType="",Crif_resUrl="";
													 String CHMStatus="",CIBILStatus="",CHMErrorDesc="",CIBILErrorDesc="";
													 String strKendraName="",strOrgState="",strIfsccode="",strOrganisationName="",strLapsid="",hidAppNo="";
													 LpmasProperty property;
													 property=serviceProvider.getLpmasPropertyService().findByLpropDesc("Bureau Username");
													 strUserId=property.getLpropValue();
													 property=serviceProvider.getLpmasPropertyService().findByLpropDesc("Bureau Password");
													 strPassword=property.getLpropValue();
													 property=serviceProvider.getLpmasPropertyService().findByLpropDesc("Bureau Request URL");
													 Crif_reqUrl=property.getLpropValue();
													 property=serviceProvider.getLpmasPropertyService().findByLpropDesc("Bureau Reponse URL");
													 Crif_resUrl=property.getLpropValue();
													 LpcustApplicantData lpcustApplicant = mapper.convertValue(requestMap.get("lad"),LpcustApplicantData.class);
													 lpcustApplicantData  = serviceProvider.getCustomerDetailsService().findByID(lpcustApplicant.getLadId());
													 lpcustAppcustRelation = serviceProvider.getApplicationRelation().findByLpcustApplicantData(lpcustApplicantData);
													 lpcomProposal = serviceProvider.getLpcomProposalService().findByLpPropNo(lpcustAppcustRelation.getLpcomProposal().getLpPropNo());
													 lpcustLoanDetail = serviceProvider.getLoanDetailsService().findByLpcomProposalAndLldSno(lpcomProposal, 1);	
													 stGeographyMaster = serviceProvider.getStGeographyMasterService().findBySgmStateCodeAndSgmCityCode(lpcustApplicantData.getLadState(), lpcustApplicantData.getLadCity());
													 lpcustApplicantData.setLadCityName(stGeographyMaster.getSgmCityName());
													 lpcustApplicantData.setLadStateName(stGeographyMaster.getSgmStateName());
													 LpstpOrganisation organisation = new LpstpOrganisation();
													 organisation=serviceProvider.getLpstpOrganisationService().findByLoOrgId(lpcomProposal.getLpOrgCode().longValue());
													 strOrgState=organisation.getLoState();
													
													 strIfsccode=organisation.getLoIfscCode();
													 strOrganisationName=organisation.getLoName();
													 strKendraName=organisation.getLoName();
													 ArrayList BureauArray = new ArrayList();
													 ArrayList RemarkArray = new ArrayList();
													 ArrayList TypeArray =new ArrayList();
													 strLapsid=Long.toString(lpcustApplicantData.getLadId());
													 hidAppNo=lpcomProposal.getLpPropNo().toString();
													 int age = 0;
													 Date dob=lpcustApplicantData.getLadDob();
													 SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
													 Date now = new Date();  
													 age=now.getYear()-  dob.getYear();
//													 LocalDate fromDate = dob.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//													 LocalDate toDate = now.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
//													 age=calculateAge(fromDate,toDate);
													 strPANNO=lpcustApplicantData.getLadPanno();
													 strPASSPORT = lpcustApplicantData.getLadPassport();
													 strADHAR=lpcustApplicantData.getLadaadhar();
													 strCbsId=lpcustApplicantData.getLadCbsid();
													 long prdCode=lpcustLoanDetail.getLldPrdcode();
													 LpstpProductDet prdDet=serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prdCode);
													 if(prdDet.getLpdPrdType().equals("pH")){
														 strLoantype="Housing Loan";
														 strloanpurpose="Housing Loan";
													 }else if(prdDet.getLpdPrdType().equals("pV")){
														 strLoantype="Vehicle Loan";
														 strloanpurpose="Vehicle Loan";
													 }else if(prdDet.getLpdPrdType().equals("pP")){
														 strLoantype="Personal Loan";
														 strloanpurpose="Personal Loan";
													 }else if(prdDet.getLpdPrdType().equals("pE")){
														 strLoantype="Educational Loan";
														 strloanpurpose="Educational Loan";
													 }else if(prdDet.getLpdPrdType().equals("pM")){
														 strLoantype="Mortgage Loan";
														 strloanpurpose="Mortgage Loan";
													 }
													 if(strPANNO != null)
														{
															idList.add("02");
															idvalueList.add(strPANNO);
														}
														if(strPASSPORT != null)
														{
															idList.add("03");
															idvalueList.add(strPASSPORT);
														}if(strADHAR!= null)
														{
															idList.add("01");
															idvalueList.add(strADHAR);
														}
														
														strMobileNo=lpcustApplicantData.getLadPhone();
														phonenoList.add(strMobileNo);
														 phoneTypeList.add("strMobileNo");
													 	ObjectFactory factory = new ObjectFactory();
														REQUESTREQUESTFILE requestFile=new REQUESTREQUESTFILE();
														
														HEADERSEGMENT headersegment =new HEADERSEGMENT();
														headersegment.setPRODUCTTYPE("LOS-PD0011");
														headersegment.setRESFRMT("XML");
														headersegment.setLOSNAME("LOS");
														headersegment.setLOSVENDER("LENDPERFECT");
														headersegment.setLOSVERSION(new Byte("0"));
														headersegment.setUSERID("shuganyaravi29@gmail.com");
														requestFile.setHEADERSEGMENT(headersegment);
														
														APPLICANTSEGMENT applicantsegment = new APPLICANTSEGMENT();
														APPLICANTNAME applicantName = new APPLICANTNAME();
														applicantName.setNAME1(lpcustApplicantData.getLadFname());
														applicantName.setNAME2("");
														applicantName.setNAME3(lpcustApplicantData.getLadLname());
														applicantName.setNAME4("");
														applicantName.setNAME5("");
														applicantsegment.setAPPLICANTNAME(applicantName);
														
														DOB dateofbirth = new DOB();
														dateofbirth.setDOBDATE(formatter.format(dob));
														dateofbirth.setAGE((byte) age);
														dateofbirth.setAGEASON(formatter.format(now));
														applicantsegment.setDOB(dateofbirth);
														
														IDS identity = new IDS();
														List<ID> identityList = new ArrayList<ID>();
														ID identitydetails = new ID();
														for(int i=0;i<idList.size();)
														{
															identitydetails = new ID();
															if(idList.get(i).toString().length()==1)
															{
																StrIdType="0"+idList.get(i);
															}
															else
															{
																StrIdType=idList.get(i);
															}
														identitydetails.setTYPE(StrIdType);
														identitydetails.setVALUE(idvalueList.get(i));
														identityList.add(identitydetails);
														i++;
														}
														identity.setId(identityList);
														applicantsegment.setIDS(identity);
														
//														if(!lpcustAppcustRelation.getLarType().equals("A")){
															relValue.add(lpcustApplicantData.getLadLname());
//															}
														RELATIONS relations = new RELATIONS();
														List<RELATION> relationList =new ArrayList<RELATION>();
														RELATION relationdetails = new RELATION();
														String strRelType="";
														for(int k=0;k<relValue.size();)
														{
															relationdetails= new RELATION();
															
															String strRelation = relValue.get(0);
															
//															if(strRelation.equalsIgnoreCase(""))
//															{
																strRelType="Father";//Father
//															}
//															else if(strRelation.equalsIgnoreCase("2"))
//															{
//																strRelType="Mother";//Mother
//															}
//															else if(strRelation.equalsIgnoreCase("3"))
//															{
//																strRelType="Husband";//Husband
//															}
														relationdetails.setTYPE(strRelType);
														relationdetails.setVALUE(strRelation);
														relationList.add(relationdetails);
														k++;
														}
														relations.setRelation(relationList);
														applicantsegment.setRELATIONS(relations);
														
														PHONES phones = new PHONES();
														List<PHONE> phoneList = new ArrayList<PHONE>();
														PHONE phonedetails = new PHONE();
														for(int j=0;j<phonenoList.size();)
														{
															phonedetails = new PHONE();
															String strphone=phonenoList.get(j);
															String strType=phoneTypeList.get(j);
															if(strType.equalsIgnoreCase("strMobileNo") && !strphone.equals(""))
															{
																strType="01";
															}
															else
															{
																strType="";
															}	
														phonedetails.setTYPE(strType);
														phonedetails.setVALUE(Long.valueOf(strphone));
														phoneList.add(phonedetails);
														j++;
														}
														phones.setPhone(phoneList);
														applicantsegment.setPHONES(phones);
														
														EMAILS emaildetails = new EMAILS();
														emaildetails.setEMAIL(lpcustApplicantData.getLadEmail());
														applicantsegment.setEMAILS(emaildetails);
														applicantsegment.setGENDER(serviceProvider.getCustomerDetailsService().findByLlvHeaderAndLlvOptionVal("gender",lpcustApplicantData.getLadSex()));
														applicantsegment.setMARITALSTATUS(strMaristat);
														applicantsegment.setENTITYID("eNTITY123");
														
														ADDRESSES addressess = new ADDRESSES();
														List<ADDRESS> addressList = new ArrayList<ADDRESS>();
														ADDRESS addressdetails = new ADDRESS();
														addressdetails.setTYPE("Residence");
														addressdetails.setADDRESS1(lpcustApplicantData.getLadAddress1());
														addressdetails.setCITY(lpcustApplicantData.getLadCityName());
														addressdetails.setSTATE(lpcustApplicantData.getLadStateName());
														addressdetails.setPINCODE(Integer.parseInt(lpcustApplicantData.getLadZip()));
														addressList.add(addressdetails);
														addressess.setAddress(addressList);
														applicantsegment.setADDRESSES(addressess);
														requestFile.setAPPLICANTSEGMENT(applicantsegment);
														Date createdOn=lpcustLoanDetail.getLldCreatedOn();
														
														APPLICATIONSEGMENT applicationssegment = new APPLICATIONSEGMENT();
														String loanAMount=lpcustLoanDetail.getLldAmtreqd().toString();
														applicationssegment.setLOANTYPE(strLoantype);
														applicationssegment.setLOANPURPOSE(strloanpurpose);
														applicationssegment.setAPPLICATIONDATE(formatter.format(createdOn));
														applicationssegment.setAPPLICATIONID((int) lpcustApplicantData.getLadId());
														applicationssegment.setLOANAMOUNT(Integer.parseInt(loanAMount));
														applicationssegment.setCONSUMERID((int) lpcustApplicantData.getLadId());
														applicationssegment.setBRANCH(strOrganisationName);
														applicationssegment.setKENDRA(strKendraName);
														 if(strIfsccode!=null){
														applicationssegment.setIFSCCODE(strIfsccode);
														 }
														applicationssegment.setBRANCHSTATE(strOrgState);
														applicationssegment.setOWNERSHIPINDICATOR("OWR");
														requestFile.setAPPLICATIONSEGMENT(applicationssegment);
														
														JAXBContext jaxContext = null;
														try{
															 jaxContext = JAXBContext.newInstance("com.sai.lendperfect.cibil");	
														}
														catch(Exception e){
															e.printStackTrace();
														}
														Marshaller marshaller = jaxContext.createMarshaller();
														marshaller.setProperty(marshaller.JAXB_ENCODING,"UTF-8");
														StringWriter sw = new StringWriter();
														marshaller.marshal(requestFile, sw);
														xmlString = sw.toString().trim();
														xmlString=xmlString.replaceAll("http://www.w3.org/2001/XMLSchema","");
														xmlString=xmlString.replaceAll("xmlns:xs","");
														xmlString=(Helper.replaceAll(xmlString, "=\"\"", "", false));
														xmlString=xmlString.replaceAll("xs:","" ).trim();
														xmlString=xmlString.replaceAll("REQUEST-REQUEST-FILE ", "REQUEST-REQUEST-FILE");
//														hshResult.put("xmlString", xmlString);
														
														System.out.println("First request=====> "+xmlString);
														String responseX="";
														responseX = GetCrifFirstHit(xmlString, strUserId, strPassword,Crif_reqUrl);
														System.out.print("1st hit completed sucessfully");
														String strAckStatus="";
														System.out.println("=====sRespone Before====="+responseX);
														responseX=responseX.replaceAll("<\\?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"\\?>", "");
														System.out.println("=====sRespone After====="+responseX);	
														InputSource is2=new InputSource();
														is2.setCharacterStream(new StringReader(responseX));
														JAXBContext jax2=JAXBContext.newInstance("com.sai.lendperfect.ackresponse");
														Unmarshaller unmar2=jax2.createUnmarshaller();
														
														ObjectFactory objfac = new ObjectFactory();
														
														REQUESTRESPONSE ackreqresponse = (REQUESTRESPONSE)unmar2.unmarshal(is2);
														System.out.println("First Response========>" +ackreqresponse);
														//com.sai.crif.ack.response.REQUESTRESPONSE.ERRORS errors = objfac.createREQUESTRESPONSEERRORS();
														REQUESTRESPONSE.ERRORS errors = new REQUESTRESPONSE.ERRORS();
														
														REQUESTRESPONSE.ERRORS.ERROR errordetails = new REQUESTRESPONSE.ERRORS.ERROR();
														
														if(ackreqresponse.getSTATUS().equalsIgnoreCase("SUCCESS"))
														{
														strAckStatus=ackreqresponse.getSTATUS();
														strAckRequestId=ackreqresponse.getREQUESTID();
														System.out.println("Acknowledgement Request Status : "+ackreqresponse.getSTATUS());
														System.out.println("Acknowledgement Request id : " +ackreqresponse.getREQUESTID());
														}
														else
														{
															System.out.println("Acknowledgement in error details description ======:"+ackreqresponse.getERRORS().getERROR().getERRORDESCRIPTION());
														}
														responseXml = GetCrifSecondHit(strAckRequestId, strresponseType, strUserId, strPassword,Crif_resUrl);
														Gson gson = new Gson();
														ResponsejsonData jsonObject=null;
														 jsonObject = gson.fromJson(responseXml,ResponsejsonData.class);
														System.out.println("GSOn strated1====> " +jsonObject);
														 ArrayList<Status> FullName1 = new ArrayList(jsonObject.getStatus());
														 System.out.println("GSOn strated=======>2"+FullName1);
														 for(Status  s :FullName1)
														 {
															 BureauArray.add(s.getBureauName());
															 RemarkArray.add(s.getRemark());
															 TypeArray.add(s.getType());
															 System.out.println("BureauArray======>"+BureauArray);
															 System.out.println("RemarkArray=====>"+RemarkArray);
															 System.out.println("TypeArray=====>"+TypeArray);
														 }
														 
														 System.out.println("GSOn strated3 Main Block");
														 ArrayList<BureauResponse> bureauResponse = new ArrayList(jsonObject.getBureauResponse());
														 String strResponse="",CHMScore="",CIBILScore="",strHtmlResponse="",strXMLResponse="",strBureauNameDesc="",strpdfResponse="";
														 for(BureauResponse  s1 :bureauResponse)
														 {
															 strBureauNameDesc = s1.getBureauName();
															 //strXMLResponse =s1.getXmlResponse();
															 strHtmlResponse = s1.getHtmlResponse();
															 strpdfResponse =s1.getPdfResponse();
														 }
														 System.out.println("PDF Response====>"+strpdfResponse);
												    	 System.out.println("strBureauName====="+strBureauNameDesc);
												    	 System.out.println("JSoup started====\n");
														  org.jsoup.nodes.Document html = Jsoup.parse(strHtmlResponse);
														  System.out.println("HTML Reposnse=====>" +html);
														  Elements elements  = html.body().getElementsByClass("dataValue");
														  System.out.println("elements===>" +elements);
														  for(int i=12;i<elements.size();i++)
															 {
															  CHMStatus = elements.get(i).html();
																 System.out.println("CHMStatus is =============  "+CHMStatus);
																 i+=2;
																 CIBILStatus = elements.get(i).html();
																 System.out.println("CIBILStatus is =============  "+CIBILStatus);
																 if(CHMStatus.equalsIgnoreCase("ERROR") || CIBILStatus.equalsIgnoreCase("ERROR"))	
																 {
																	 if(CHMStatus.equalsIgnoreCase("ERROR"))
																	 {
																		 i-=1;
																		 System.out.println("..............  "+i);
																		 String Test = elements.get(i).html();
																		 org.jsoup.nodes.Document jsoupdoc =Jsoup.parse(Test);
																		 org.jsoup.nodes.Element jsoupele = jsoupdoc.select("table td:eq(0)").first();
																		 System.out.println("CHMErrorDesc=======>>>>  "+jsoupele.text());
																		 CHMErrorDesc = jsoupele.text();
																		 if(CIBILStatus.equalsIgnoreCase("ERROR"))
																			 i+=1;
																	 }if(CIBILStatus.equalsIgnoreCase("ERROR"))
																	 {
																		 i+=1;
																		 System.out.println("..............  "+i);
																		 String Test1 = elements.get(i).html();
																		 org.jsoup.nodes.Document jsoupdoc1 =Jsoup.parse(Test1);
																		 org.jsoup.nodes.Element jsoupele1 = jsoupdoc1.select("table td:eq(0)").first();
																		 System.out.println("CIBILErrorDesc======>>>>  "+jsoupele1.text());
																		 CIBILErrorDesc = jsoupele1.text();
																	 }
																	 break;
																 }else
																 {
																     int j = i;
																     j=j-1;
																     String NoHitCheck="";
																     NoHitCheck = elements.get(j).html();
																     System.out.println("NoHitCheck value is "+ NoHitCheck);
																     if(NoHitCheck.length() > 0 )
																     {
																	     System.out.println("position..............  "+j);
																		 String Test = elements.get(j).html();
																		 org.jsoup.nodes.Document doc =Jsoup.parse(Test);
																		 org.jsoup.nodes.Element ele = doc.select("table td:eq(0)").first();
																		 System.out.println((ele.val()));
																		 NoHitCheck = ele.text();
																     }
																	 if(NoHitCheck.equalsIgnoreCase("NO-HIT") && CHMStatus.equalsIgnoreCase("SUCCESS") && CIBILStatus.equalsIgnoreCase("SUCCESS"))
																	 {
																		 j+=4;
																	 	 CHMScore ="0";
																	 	 System.out.println("CHMScore is by Default of No-HIT=============  "+CHMScore);
																		 CIBILScore = elements.get(j).html();
																		 CIBILScore="0";
																		 System.out.println("CIBILScore is =============  "+CIBILScore);
																		 break;
																	 }
																	 else
																	 {
																		 i+=3;
																	 	 CHMScore = elements.get(i).html();
																		 System.out.println("CHMScore is =============  "+CHMScore);
																		 i+=2;
																		 CIBILScore = elements.get(i).html();
																		 System.out.println("CIBILScore is =============  "+CIBILScore);
																		 break;
																	 }
																 }
															 } 
														 	String strFileName="CHM" + strLapsid+"_"+hidAppNo;
														    String strAbsolutePath="";
														    String strCibilStatus="SUCCESS";
														    String strErrorMsg="";
														    File directory = null;
															String strpDFPath ="D:\\fileStorage";
															directory = new File(strpDFPath);
															if (!directory.exists())
															{
																directory.mkdirs();
															}
															strFileName="CHM" + strLapsid+"_"+hidAppNo;
															strAbsolutePath = strpDFPath + "/" + strFileName + ".PDF";
															byte[] bytepdfData = DatatypeConverter.parseBase64Binary(strpdfResponse);
															RandomAccessFile raf1 = new RandomAccessFile(new File(strAbsolutePath), "rw");
															raf1.seek(strAbsolutePath.length());
															
															raf1.write(bytepdfData);
															raf1.close();
															
															if(strCibilStatus.equalsIgnoreCase("SUCCESS"))
															{
															LpcustCibilIndividual lpcustCibilIndividual=new LpcustCibilIndividual();
															lpcustCibilIndividual.setCiRefnumber(strLapsid);
															lpcustCibilIndividual.setCiFilenumber(strFileName);
															lpcustCibilIndividual.setCiReport(strHtmlResponse);
															lpcustCibilIndividual.setCiStatus(strCibilStatus);
															lpcustCibilIndividual.setCiCibiltuscr(new BigDecimal(CIBILScore));
															lpcustCibilIndividual.setCiChmscr(CHMScore);
															lpcustCibilIndividual.setCiErrormsg(strErrorMsg);
															lpcustCibilIndividual.setAppno(hidAppNo);
															lpcustCibilIndividual.setCiGenerateddate(new Date());
															lpcustCibilIndividual.setCiGeneratedby(userid);
															lpcustCibilIndividual.setCiPdfreport(bytepdfData);
															serviceProvider.getLpcustCibilIndividualService().save(lpcustCibilIndividual);
															}
															responseHashMap.put("success",true);
												}
												catch(Exception e){
													e.printStackTrace();
													if (!dataHashMap.containsKey("errorData")) {
														logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
														dataHashMap.put("errorData",new CustomErr(e.getMessage()));
														responseHashMap.put("success", false);
														responseHashMap.put("responseData", dataHashMap);
																}
												}
											}
											else if(dpMethod.equals("viewCibilReport")){
												try{
													Map<String,Object> requestMap=(Map<String,Object>)allRequestParams.get("requestData");
													String FileType=allRequestParams.get("requestData1").toString();
													String ladId=  requestMap.get("ladId").toString();
													HashMap<String,Object> hshRecord=new HashMap<String,Object>();
													LpcustCibilIndividual lpcustCibilIndividual=serviceProvider.getLpcustCibilIndividualService().findByCiRefnumber(ladId);
													LpcomProposal proposal=serviceProvider.getLpcomProposalService().findByLpPropNo(new BigDecimal(lpcustCibilIndividual.getAppno()));
													LpcustLoanDetail loanDetails=serviceProvider.getLoanDetailsService().findByLpcomProposal(proposal);
													LpstpProductDet prdDet=serviceProvider.getLpstpProductDetService().findByLpdProdNewId(loanDetails.getLldPrdcode());
													String strRefNo=lpcustCibilIndividual.getCiRefnumber();
													String report=lpcustCibilIndividual.getCiReport();
													if(FileType.equalsIgnoreCase("html"))
													{
														responseHashMap.put("reportData", report);
													}else
													{
														byte byteImgData[]=null;
														byteImgData =lpcustCibilIndividual.getCiPdfreport();  
														responseHashMap.put("ci_blob",byteImgData);
															if(byteImgData!=null){
																responseHashMap.put("photoimg", byteImgData);
																responseHashMap.put("FILE_STREAM_NAME", strRefNo + ".pdf");
																responseHashMap.put("FILE_STREAM_TYPE", "application/pdf");
																responseHashMap.put("FILE_STREAM", byteImgData);
																responseHashMap.put("FILE_STREAM_DISPOSITION_TYPE","inline");
														}
													}
													responseHashMap.put("strInwardId", lpcustCibilIndividual.getCiRefnumber());
													responseHashMap.put("fileNo", lpcustCibilIndividual.getCiFilenumber());
													responseHashMap.put("hidAppId",lpcustCibilIndividual.getCiRefnumber());
													responseHashMap.put("prdCode", loanDetails.getLldPrdcode());
													responseHashMap.put("prdType", prdDet.getLpdPrdType());
													responseHashMap.put("success", true);
												}
												catch(Exception e){
													e.printStackTrace();
													if (!dataHashMap.containsKey("errorData")) {
														logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
														dataHashMap.put("errorData",new CustomErr(e.getMessage()));
														responseHashMap.put("success", false);
														responseHashMap.put("responseData", dataHashMap);
																}
												}
											}

		
		
		return responseHashMap;
		
		
	}
	 public static int calculateAge(LocalDate birthDate, LocalDate currentDate) {
	        if ((birthDate != null) && (currentDate != null)) {
	            return Period.between(birthDate, currentDate).getYears();
	        } else {
	            return 0;
	        }
}
	 private String GetCrifFirstHit(String xmlString,String strUserId,String strPassword,String crif_resUrl)
	 {
	 	String responseX="";
	 	try
	 	{
	 	HttpClient httpClient = HttpClientBuilder.create().build();
	 	String output=""; 
	 	System.out.println("Webservice call.................................staretd1");
	 	HttpPost getRequest = new HttpPost(crif_resUrl);
	 	System.out.println("Webservice call.................................got the ip address");
	 	getRequest.addHeader("accept", "application/xml"); 
	 	getRequest.setHeader("requestXml",xmlString); // pass request xml 
	 	getRequest.setHeader("userId",strUserId); //pass Bureau link user id
	 	getRequest.setHeader("password",strPassword); //pass bureau link password
	 	System.out.println("inffffffffffooo userid ==  "+strUserId+"password  == "+strPassword);
	 	System.out.println("Webservice call.................................Hitting for 1st time");
	 	HttpResponse response = httpClient.execute(getRequest); 
	 	System.out.println("response is"+response);
	 	if (response.getStatusLine().getStatusCode() != 200) { 
	 	 	throw new RuntimeException("Failed : HTTP error code : " 
	 	 	 	 	+ response.getStatusLine().getStatusCode()); 
	 	 	} 
	 	BufferedReader br2 = new BufferedReader(new InputStreamReader((response.getEntity().getContent()))); 
	 	while ((output = br2.readLine()) != null) { 
	 	 	responseX+=output; 
	 	}  	
	 }catch(Exception e)
	 {
	 	e.printStackTrace();
	 }
	 return responseX;
	 }
	 
	 private String GetCrifSecondHit(String strAckRequestId,String strresponseType,String strUserId,String strPassword,String crif_resUrl)
	 {
	 	HttpClient httpClientIssueXml = HttpClientBuilder.create().build();
	 	String outputResponse=""; 
	 	String responseXml="";
	 	try
	 	{
	 	
	 	System.out.println("Webservice call.................................staretd2");
	 	HttpPost getIssueRequest = new HttpPost(crif_resUrl); 
	 	getIssueRequest.addHeader("accept", "application/json"); 
	 	System.out.println("strAckRequestId is paasing "+ strAckRequestId);
	 	getIssueRequest.setHeader("requestId", strAckRequestId);
	 	//getIssueRequest.setHeader("bureau", strbureau);
	 	getIssueRequest.setHeader("responseType", strresponseType);
	 	getIssueRequest.setHeader("userId",strUserId); //pass Bureau link user id
	 	getIssueRequest.setHeader("password",strPassword); //pass bureau link password
	 	System.out.println("Webservice call.................................Hitting for 2nd time");
	 	System.out.println("inffffffffffooo                userid1 ==  "+strUserId+" password1  == "+strPassword);
	 	HttpResponse responsecrif = httpClientIssueXml.execute(getIssueRequest); 
	 	if (responsecrif.getStatusLine().getStatusCode() != 200) { 
	 	 	throw new RuntimeException("Failed : HTTP error code : " 
	 	 	 	 	+ responsecrif.getStatusLine().getStatusCode()); 
	 	 	} 
	 	// Get-Capture Complete application/xml body response 
	 	BufferedReader br = new BufferedReader(new InputStreamReader((responsecrif.getEntity().getContent()))); 
	 	// Simply iterate through XML response and show on console. 
	 	while ((outputResponse = br.readLine()) != null) { 
	 	 	//System.out.println(output); 
	 		responseXml+=outputResponse; 
	 	} 
	 	//System.out.println("Acknowlege response final for html generation======="+responseXml);
//	 	httpClientIssueXml.getConnectionManager().shutdown(); 
	 	//end of Request
	 	}catch(Exception e)
	 	{
	 		e.printStackTrace();
	 	}
	 	return responseXml;
	 }
}
