package com.sai.lendperfect.app.otherexpenditure;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantIncexpens;
import com.sai.lendperfect.application.model.LpcustApplicantOblicat;
import com.sai.lendperfect.application.model.LpcustApplicantOtherexp;

import com.sai.lendperfect.application.repo.LpcustApplicantOtherexpRepo;



@Service("LpcustApplicantOtherexpService")
@Transactional
public class LpcustApplicantOtherexpServiceImpl implements LpcustApplicantOtherexpService{

	@Autowired
	LpcustApplicantOtherexpRepo lpcustApplicantOtherexpRepo;
	
	public List<LpcustApplicantOtherexp> saveIncomeDetailsList(List<LpcustApplicantOtherexp> lpcustApplicantOtherexp) {
		// TODO Auto-generated method stub
		return lpcustApplicantOtherexpRepo.save(lpcustApplicantOtherexp);
	}

	public void deleteLpcustApplicantOtherIncome(Long lpcustApplicantOtherexp){
		
		lpcustApplicantOtherexpRepo.delete(lpcustApplicantOtherexp);
	}
	
	
	
	@Override
	public LpcustApplicantOtherexp findByLaoeId(Long id) {
		// TODO Auto-generated method stub
		return lpcustApplicantOtherexpRepo.findByLaoeId(id);
	}

	/*@Override
	public LpcustApplicantIncexpens findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		// TODO Auto-generated method stub
		return lpcustApplicantOtherexpRepo.findByLpcustApplicantData(lpcustApplicantData);
	}*/

	@Override
	public void delete(LpcustApplicantOtherexp lpcustApplicantOtherexp) {
		// TODO Auto-generated method stub
		lpcustApplicantOtherexpRepo.delete(lpcustApplicantOtherexp);
	}

	@Override
	public List<LpcustApplicantOtherexp> findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData) {
		// TODO Auto-generated method stub
		 return lpcustApplicantOtherexpRepo.findByLpcustApplicantData(lpcustApplicantData);
	}

	@Override
	public LpcustApplicantOtherexp saveOtherExp(LpcustApplicantOtherexp lpcustApplicantOtherexp) {
		// TODO Auto-generated method stub
		return lpcustApplicantOtherexpRepo.save(lpcustApplicantOtherexp);
	}

	


	
	
}
