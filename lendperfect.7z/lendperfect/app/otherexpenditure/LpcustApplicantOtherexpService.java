package com.sai.lendperfect.app.otherexpenditure;

import java.util.List;

import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.model.LpcustApplicantIncexpens;
import com.sai.lendperfect.application.model.LpcustApplicantOblicat;
import com.sai.lendperfect.application.model.LpcustApplicantOtherexp;



public interface LpcustApplicantOtherexpService {
	
	LpcustApplicantOtherexp saveOtherExp(LpcustApplicantOtherexp lpcustApplicantOtherexp);
	List<LpcustApplicantOtherexp> saveIncomeDetailsList(List<LpcustApplicantOtherexp> lpcustApplicantOtherexp);
	//List<LpcustOtherIncome> findByLadId(LpcustApplicantData lpcustApplicantData);
	
	//void deleteLpcomLiability(LpcustIncExpDetail lpcomLiability);
	
	//List<LpcustApplicantOtherexp> findByLaoeId(Long id);
	//List<LpcustApplicantOtherexp> findByLaoeIdList(Long id);
	LpcustApplicantOtherexp findByLaoeId(Long id);
	List<LpcustApplicantOtherexp> findByLpcustApplicantData(LpcustApplicantData lpcustApplicantData);
	
	void delete(LpcustApplicantOtherexp lpcustApplicantOtherexp);
	}
