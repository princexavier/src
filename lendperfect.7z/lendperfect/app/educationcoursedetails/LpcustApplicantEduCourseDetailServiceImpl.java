package com.sai.lendperfect.app.educationcoursedetails;

import java.math.BigDecimal;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.application.model.LpcustApplicantEduCourseDetail;
import com.sai.lendperfect.application.model.LpcustApplicantEduStudent;
import com.sai.lendperfect.application.repo.LpcustApplicantEduCourseDetailRepo;
import com.sai.lendperfect.application.repo.LpcustApplicantEduStudentRepo;
import com.sai.lendperfect.commodel.LpcomProposal;



@Service("LpcustApplicantEduCourseDetailService")
@Transactional
public class LpcustApplicantEduCourseDetailServiceImpl implements LpcustApplicantEduCourseDetailService {
	
	@Autowired
	LpcustApplicantEduCourseDetailRepo lpcustApplicantEduStudentRepo;
	
	@Override
	public LpcustApplicantEduCourseDetail saveCourseDetail(LpcustApplicantEduCourseDetail lpcustApplicantEduCourseDetail) {
		return lpcustApplicantEduStudentRepo.save(lpcustApplicantEduCourseDetail);
	}

	@Override
	public LpcustApplicantEduCourseDetail findBylpcomProposal(LpcomProposal lpcomProposal) {
		return lpcustApplicantEduStudentRepo.findBylpcomProposal(lpcomProposal);
	}

	
	
}
