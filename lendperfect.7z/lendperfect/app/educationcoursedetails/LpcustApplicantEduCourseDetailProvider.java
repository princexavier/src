package com.sai.lendperfect.app.educationcoursedetails;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustApplicantEduCourseDetail;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.logging.Logging;

public class LpcustApplicantEduCourseDetailProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		Map <String,Object> responseHashMap = new HashMap<String,Object>();
		Map <String,Object> dataHashMap = new HashMap<String,Object>();
		
		LpcustApplicantEduCourseDetail lpcustApplicantEduCourseDetail = new LpcustApplicantEduCourseDetail();
		LpcomProposal lpcomProposal = new LpcomProposal();
		ObjectMapper mapper = new ObjectMapper();
		String userid = (String) session.getAttribute("userid");
		BigDecimal propNo = (BigDecimal) session.getAttribute("LP_COM_PROP_NO");	
		Timestamp sysDate = (Timestamp) Helper.getSystemDate();
		try{
			if(dpMethod.equals("saveCourseDetails"))
			{
 				Map<String,Object> requestMap = (Map<String,Object>)allRequestParams.get("requestData");
 				lpcustApplicantEduCourseDetail = mapper.convertValue(requestMap,LpcustApplicantEduCourseDetail.class);
 				lpcustApplicantEduCourseDetail.setLaelCreatedby(Helper.correctNull(userid));
 				lpcustApplicantEduCourseDetail.setLaelModifieddby(Helper.correctNull(userid));
 				lpcustApplicantEduCourseDetail.setLaelCreateddate(sysDate);
 				lpcustApplicantEduCourseDetail.setLaelModifieddate(sysDate);
				 if(lpcustApplicantEduCourseDetail.getLaescEduLoanId() == 0)
				 {
					 lpcomProposal.setLpPropNo(propNo);
					 lpcustApplicantEduCourseDetail.setLpcomProposal(lpcomProposal);
					 lpcustApplicantEduCourseDetail = serviceProvider.getLpcustApplicantEduCourseDetailService().saveCourseDetail(lpcustApplicantEduCourseDetail);
				 }
				 else{
					 lpcomProposal.setLpPropNo(propNo);
					 lpcustApplicantEduCourseDetail.setLpcomProposal(lpcomProposal);
					 lpcustApplicantEduCourseDetail = serviceProvider.getLpcustApplicantEduCourseDetailService().saveCourseDetail(lpcustApplicantEduCourseDetail);
				 }
				 
				 dataHashMap.put("lpcustApplicantEduCourseDetail",lpcustApplicantEduCourseDetail);
				 responseHashMap.put("success", true);
				 responseHashMap.put("responseData", dataHashMap);
			}
			else if(dpMethod.equals("getCourseDetails"))
			{
				lpcomProposal.setLpPropNo(propNo);
				 lpcustApplicantEduCourseDetail = serviceProvider.getLpcustApplicantEduCourseDetailService().findBylpcomProposal(lpcomProposal);
				 dataHashMap.put("lpcustApplicantEduCourseDetail",lpcustApplicantEduCourseDetail);
				 if(lpcustApplicantEduCourseDetail != null){
					 responseHashMap.put("success", true);
				 }else{
					 responseHashMap.put("success", false);
				 }
				 responseHashMap.put("responseData", dataHashMap);
			}
			 else if(dpMethod.equals("getPropNo")){
					responseHashMap.put("propNo",session.getAttribute("LP_COM_PROP_NO"));
				}
				
			
		}catch(Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
					dataHashMap.put("errorData",new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		return responseHashMap;
	}

}
