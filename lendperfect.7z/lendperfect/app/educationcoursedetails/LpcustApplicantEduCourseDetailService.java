package com.sai.lendperfect.app.educationcoursedetails;

import com.sai.lendperfect.application.model.LpcustApplicantEduCourseDetail;
import com.sai.lendperfect.commodel.LpcomProposal;



public interface LpcustApplicantEduCourseDetailService {

	LpcustApplicantEduCourseDetail saveCourseDetail(LpcustApplicantEduCourseDetail lpcustApplicantEduCourseDetail);

	LpcustApplicantEduCourseDetail findBylpcomProposal(LpcomProposal lpcomProposal);

}
