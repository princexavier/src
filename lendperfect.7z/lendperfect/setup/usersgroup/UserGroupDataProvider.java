package com.sai.lendperfect.setup.usersgroup;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.setupmodel.SetUserGroup;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

public class UserGroupDataProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		SetUserGroup setUserGroup = null;
		responseHashMap.put("success", true);
		Map <String,Object> requestHashMap=new HashMap<String,Object>();
		try {
			if (dpMethod.equals("getUserGroupList")) {
				try {
					dataHashMap.put("usergroupDataList", serviceProvider.getUserGroupService().findAll());
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}

			} else if (dpMethod.equals("saveUserGroupData")) {
				try {
					setUserGroup = new ObjectMapper().convertValue(allRequestParams.get("requestData"),new TypeReference<SetUserGroup>() {});
					if(setUserGroup.getSugGrpId() == 0)
					{
						setUserGroup.setSugCreatedBy(session.getAttribute("userid").toString());
						setUserGroup.setSugCreatedOn(Helper.getSystemDate());
					}
					setUserGroup.setSugModifiedBy(session.getAttribute("userid").toString());
					setUserGroup.setSugModifiedOn(Helper.getSystemDate());
					
					serviceProvider.getUserGroupService().saveUserGroupData(setUserGroup);
					responseHashMap.put("getCurrentSaveRowDetail",serviceProvider.getUserGroupService().findById(setUserGroup.getSugGrpId()));
					
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getBusinessVertical")) {
				try {
					List<LpmasBizVertical> lpmasBizVerticalList = serviceProvider.getLpmasBizVerticalService().findAll();
					responseHashMap.put("getBusinessVertical", lpmasBizVerticalList);
				} catch (Exception ex) {

					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getUserGroupListBysugGrpVertical")) {

				try {

					String sugGrpVertical = null;

					sugGrpVertical = allRequestParams.get("requestData").toString();
					sugGrpVertical = (sugGrpVertical == null) ? "0" : sugGrpVertical;
					responseHashMap.put("usergroupDataListBysugGrpVertical",serviceProvider.getUserGroupService().findBysugGrpVertical(sugGrpVertical));

				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getPageList")) {
				try {
					responseHashMap.put("pageList", serviceProvider.getLpmasPageMasterService().findByLpmPageTypeOrderByLpmPageId("S"));
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} 
			else if (dpMethod.equals("getData")) {
				try {
					requestHashMap = (Map<String, Object>) allRequestParams.get("requestData");
					String sugGrpVertical = (String) requestHashMap.get("bizvalue");
					String lugGrpDept = (String) requestHashMap.get("departmentValue");
					String sugGrpName = (String) requestHashMap.get("lsitOfgrpValue");
					
					responseHashMap.put("responseData", serviceProvider.getUserGroupService().findBySugGrpVerticalAndLugGrpDeptAndSugGrpName(sugGrpVertical, lugGrpDept, sugGrpName));
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} 
			else if (dpMethod.equals("getDataByDepartment")) {
				try {
					
					requestHashMap = (Map<String, Object>) allRequestParams.get("requestData");
					String sugGrpVertical = (String) requestHashMap.get("vertical");
					String lugGrpDept = (String) requestHashMap.get("department");
					
					responseHashMap.put("responseData", serviceProvider.getUserGroupService().findBySugGrpVerticalAndLugGrpDept(sugGrpVertical, lugGrpDept));
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} 
			
			
			
			else {
				dataHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
			return responseHashMap;

		} catch (Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}

		return responseHashMap;

	}
}
