package com.sai.lendperfect.setup.usersgroup;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpUserAccess;
import com.sai.lendperfect.setupmodel.SetUserGroup;

public interface SetUserGroupService {
	
	List<SetUserGroup> findAll();
	List<SetUserGroup> findBysugGrpVertical(String sugGrpVertical );
	List<SetUserGroup> findByActiveGroup(String sugGrpActive );
	SetUserGroup findById(long sugGrpId);
	SetUserGroup saveUserGroupData(SetUserGroup setUserGroup);
	SetUserGroup updateUserGroupData(SetUserGroup setUserGroup);
	void deleteSetUserGroup(SetUserGroup setStaticData);
	SetUserGroup findBySugGrpId(long luaGroup);
	SetUserGroup findBySugGrpVerticalAndLugGrpDeptAndSugGrpName(String sugGrpVertical, String lugGrpDept, String sugGrpName);
	List<SetUserGroup> findBySugGrpVerticalAndLugGrpDept(String sugGrpVertical, String lugGrpDept);
	List<SetUserGroup> findBySugGrpVerticalAndLugGrpDeptAndSugGrpActive(String sugGrpVertical, String lugGrpDept,String sugGrpActive);
	List<SetUserGroup> findBySugGrpVerticalAndLugGrpDeptAndSugGrpId(String grpVertical, String lwfWfType, long grpId);
}
