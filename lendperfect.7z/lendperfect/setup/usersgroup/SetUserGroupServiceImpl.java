package com.sai.lendperfect.setup.usersgroup;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpUserAccess;
import com.sai.lendperfect.setupmodel.SetUserGroup;
import com.sai.lendperfect.setuprepo.SetUserGroupRepo;

@Service("setUserGroupService")
@Transactional
public class SetUserGroupServiceImpl implements SetUserGroupService {
	
	@Autowired
	private SetUserGroupRepo  setUserGroupRepo;
	
	public List<SetUserGroup> findAll() {
		return setUserGroupRepo.findAll();
	}
	
	public List<SetUserGroup> findBysugGrpVertical(String sugGrpVertical) {
		return setUserGroupRepo.findBysugGrpVertical(sugGrpVertical);
	}
	
	public List<SetUserGroup> findByActiveGroup(String sugGrpActive) {
		return setUserGroupRepo.findBysugGrpActive(sugGrpActive);
	}
	
	public SetUserGroup saveUserGroupData(SetUserGroup setUserGroup) {
		return setUserGroupRepo.save(setUserGroup);
	}
	
	public SetUserGroup updateUserGroupData(SetUserGroup setUserGroup) {
		return saveUserGroupData(setUserGroup);
	}
	
	public void deleteSetUserGroup(SetUserGroup setUserGroup) {
		 setUserGroupRepo.delete(setUserGroup);
	}

	public SetUserGroup findById(long sugGrpId) {
		return setUserGroupRepo.findOne(sugGrpId);
	}


	public SetUserGroup findBySugGrpId(long luaGroup) {

	 return setUserGroupRepo.findBySugGrpId(luaGroup);
	}

	public SetUserGroup findBySugGrpVerticalAndLugGrpDeptAndSugGrpName(String sugGrpVertical, String lugGrpDept, String sugGrpName) {
		return setUserGroupRepo.findBySugGrpVerticalAndLugGrpDeptAndSugGrpName(sugGrpVertical, lugGrpDept, sugGrpName);
	}

	public List<SetUserGroup> findBySugGrpVerticalAndLugGrpDept(String sugGrpVertical, String lugGrpDept) {
		return setUserGroupRepo.findBySugGrpVerticalAndLugGrpDept(sugGrpVertical, lugGrpDept);
	}

	public List<SetUserGroup> findBySugGrpVerticalAndLugGrpDeptAndSugGrpActive(String sugGrpVertical, String lugGrpDept,
			String sugGrpActive) {
		return setUserGroupRepo.findBySugGrpVerticalAndLugGrpDeptAndSugGrpActive(sugGrpVertical, lugGrpDept, sugGrpActive);
	}

	@Override
	public List<SetUserGroup> findBySugGrpVerticalAndLugGrpDeptAndSugGrpId(String grpVertical, String lwfWfType,
			long grpId) {
		
		return setUserGroupRepo.findBySugGrpVerticalAndLugGrpDeptAndSugGrpId(grpVertical,lwfWfType,grpId);
	}

}
