package com.sai.lendperfect.setup.financialmaster;

import static org.hamcrest.CoreMatchers.nullValue;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.DVConstraint;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFDataValidation;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddressList;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.hssf.util.Region;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.DateFormatConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpComFinData;
import com.sai.lendperfect.setupmodel.LpComFinDetail;
import com.sai.lendperfect.setupmodel.LpstpCMAMaster;
import com.sai.lendperfect.setupmodel.LpstpCranMaster;
import com.sai.lendperfect.setupmodel.LpstpFinMaster;
import com.sai.lendperfect.setuprepo.LpComFinDataRepo;
import com.sai.lendperfect.setuprepo.LpComFinDetailRepo;
import com.sai.lendperfect.setuprepo.LpstpCMAMasterRepo;
import com.sai.lendperfect.setuprepo.LpstpFinMasterRepo;


@Service("financialMasterService")
@Transactional
public class FinancialMasterServiceImpl implements FinancialMasterService {
@Autowired
private LpComFinDetailRepo lpstpFinDetailRepo;
@Autowired
private LpComFinDataRepo lpstpFinDataRepo;

@Autowired
private LpstpCMAMasterRepo lpstpCMAMasterRepo;

@Autowired
private LpstpFinMasterRepo lpstpFinMasterRepo;


public List<LpComFinDetail> findAllforDetail() {
	return lpstpFinDetailRepo.findAll(new Sort(Sort.Direction.ASC,"lfdRowId"));
}
public LpComFinDetail findByRowIdforDetail(long lfdRowId) {
	return lpstpFinDetailRepo.findOne(lfdRowId);
}

public List<LpComFinDetail> findByRowIdforDetailasList(long lfdRowId) {
	return Arrays.asList(lpstpFinDetailRepo.findOne(lfdRowId));
}
public LpComFinDetail saveDataForDetail(LpComFinDetail modelObject) {
	return lpstpFinDetailRepo.saveAndFlush(modelObject);
}
public void deleteDataForDetail(LpComFinDetail modelObject) {
	lpstpFinDetailRepo.delete(modelObject);
}

public LpComFinDetail updateDataForDetail(LpComFinDetail modelObject) {
	return saveDataForDetail(modelObject);
}

public long maxOfSeqNumByPropNumForDetail(BigDecimal propNum,long customerId ,long finTypeNo) {
	return  lpstpFinDetailRepo.maxOfSeqNumByPropNum((propNum),BigDecimal.valueOf(customerId),BigDecimal.valueOf(finTypeNo));
}
@Transactional
public LpComFinDetail getRowOfMAxDateByAuditType(String auditType, BigDecimal propNum, long customerId ,long finTypeNo) {
	return lpstpFinDetailRepo.getAllRowOfMaxDateByAuditType(auditType,(propNum),BigDecimal.valueOf(customerId),BigDecimal.valueOf(finTypeNo));
}


public List<LpComFinData> findAllforData() {
	return lpstpFinDataRepo.findAll(new Sort(Sort.Direction.ASC,"lfdRowId"));
}
public LpComFinData findByRowIdforData(long lfdRowId) {
	return lpstpFinDataRepo.findOne(lfdRowId);
}
public LpComFinData saveDataForData(LpComFinData modelObject) {
	return  lpstpFinDataRepo.saveAndFlush(modelObject);
}
public void deleteDataForData(LpComFinData modelObject) {
	 lpstpFinDataRepo.delete(modelObject);
}
public Integer updateDataForDatafor1to5(LpComFinData modelObject) {
	return lpstpFinDataRepo.updateyear1to5ByfinRowIdandProNum(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(), modelObject.getLfdYear1(), modelObject.getLfdYear2(), modelObject.getLfdYear3(), modelObject.getLfdYear4(), modelObject.getLfdYear5(), modelObject.getLfdFinRowId(),modelObject.getLfdPropNo(),modelObject.getLfdCustNewId());
}
public Integer updateDataForDatafor6to10(LpComFinData modelObject) {
	return  lpstpFinDataRepo.updateyear6to10ByfinRowIdandProNum(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear6(), modelObject.getLfdYear7(), modelObject.getLfdYear8(), modelObject.getLfdYear9(), modelObject.getLfdYear10(),modelObject.getLfdFinRowId(), modelObject.getLfdPropNo(),modelObject.getLfdCustNewId());
 
}
public Integer updateDataForDatafor11to15(LpComFinData modelObject) {
	return lpstpFinDataRepo.updateyear11to15ByfinRowIdandProNum(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear11(), modelObject.getLfdYear12(), modelObject.getLfdYear13(), modelObject.getLfdYear14(), modelObject.getLfdYear15(), modelObject.getLfdFinRowId(),modelObject.getLfdPropNo(),modelObject.getLfdCustNewId());
	
}
public Integer updateDataForDatafor16to20(LpComFinData modelObject) {
return  lpstpFinDataRepo.updateyear16to20ByfinRowIdandProNum(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear16(), modelObject.getLfdYear17(), modelObject.getLfdYear18(), modelObject.getLfdYear19(), modelObject.getLfdYear20(),modelObject.getLfdFinRowId(), modelObject.getLfdPropNo(),modelObject.getLfdCustNewId());

}
public Integer updateDataForDatafor21to25(LpComFinData modelObject) {
	return lpstpFinDataRepo.updateyear21to25ByfinRowIdandProNum(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear21(), modelObject.getLfdYear22(), modelObject.getLfdYear23(), modelObject.getLfdYear24(), modelObject.getLfdYear25(), modelObject.getLfdFinRowId(),modelObject.getLfdPropNo(),modelObject.getLfdCustNewId());
	
}
public Integer updateDataForDatafor26to30(LpComFinData modelObject) {
	return lpstpFinDataRepo.updateyear26to30ByfinRowIdandProNum(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear26(), modelObject.getLfdYear27(), modelObject.getLfdYear28(), modelObject.getLfdYear29(), modelObject.getLfdYear30(),modelObject.getLfdFinRowId(), modelObject.getLfdPropNo(),modelObject.getLfdCustNewId());
	
}
public List<LpComFinDetail> getRowByPropNumorderBySeqnumForDetail(BigDecimal propNum,long customerId,long finTypeNo) {
	return lpstpFinDetailRepo.getAllRowByPropNumforDetail((propNum),BigDecimal.valueOf(customerId),BigDecimal.valueOf(finTypeNo));
}
public List<BigDecimal> getFinRowIdByPropNumforData(BigDecimal propNum,long customerId,long finTypeNo) {
	return lpstpFinDataRepo.getFinRowIdByPropNumforData((propNum),BigDecimal.valueOf(customerId),BigDecimal.valueOf(finTypeNo));
}
public List<LpComFinData> getAllRowByPropNumforData(BigDecimal propNum,long customerId,long lfdCmaNo) {
	return lpstpFinDataRepo.getAllRowByPropNumforData((propNum),BigDecimal.valueOf(customerId),BigDecimal.valueOf(lfdCmaNo));
}
public List<LpComFinData> getAllRowByPropNumandFinMasterTabNameforData(BigDecimal propNum,String finPage, String finTabName,long customerId,long finTypeNo) {
	return lpstpFinDataRepo.getAllRowByPropNumAndTabNameforData((propNum),finPage , finTabName,BigDecimal.valueOf(customerId),BigDecimal.valueOf(finTypeNo));
	//return lpstpFinDataRepo.getAllRowFilterforData(BigDecimal.valueOf(propNum), finTabName);

}

public Integer updateDataForDatafor1to5ByDataRowId (LpComFinData modelObject ) {
	return lpstpFinDataRepo.updateyear1to5ByLfdRowId(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear1(), modelObject.getLfdYear2(), modelObject.getLfdYear3(), modelObject.getLfdYear4(), modelObject.getLfdYear5(), modelObject.getLfdRowId());
}
public Integer updateDataForDatafor6to10ByDataRowId (LpComFinData modelObject ) {
	return  lpstpFinDataRepo.updateyear6to10ByLfdRowId(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear6(), modelObject.getLfdYear7(), modelObject.getLfdYear8(), modelObject.getLfdYear9(), modelObject.getLfdYear10(),modelObject.getLfdRowId());
 
}
public Integer updateDataForDatafor11to15ByDataRowId (LpComFinData modelObject ) {
	return lpstpFinDataRepo.updateyear11to15ByLfdRowId(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear11(), modelObject.getLfdYear12(), modelObject.getLfdYear13(), modelObject.getLfdYear14(), modelObject.getLfdYear15(), modelObject.getLfdRowId());
	
}
public Integer updateDataForDatafor16to20ByDataRowId (LpComFinData modelObject ) {
return  lpstpFinDataRepo.updateyear16to20ByLfdRowId(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear16(), modelObject.getLfdYear17(), modelObject.getLfdYear18(), modelObject.getLfdYear19(), modelObject.getLfdYear20(),modelObject.getLfdRowId());

}
public Integer updateDataForDatafor21to25ByDataRowId (LpComFinData modelObject ) {
	return lpstpFinDataRepo.updateyear21to25ByLfdRowId(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear21(), modelObject.getLfdYear22(), modelObject.getLfdYear23(), modelObject.getLfdYear24(), modelObject.getLfdYear25(), modelObject.getLfdRowId());
	
}
public Integer updateDataForDatafor26to30ByDataRowId (LpComFinData modelObject ) {
	return lpstpFinDataRepo.updateyear26to30ByLfdRowId(modelObject.getLfdModifiedBy(),modelObject.getLfdModifiedOn(),modelObject.getLfdYear26(), modelObject.getLfdYear27(), modelObject.getLfdYear28(), modelObject.getLfdYear29(), modelObject.getLfdYear30(),modelObject.getLfdRowId());
	
}
public List<LpComFinData> getDatabyPropNumandListOfFinRowId(BigDecimal propNum,List<BigDecimal> finRowId){
	return lpstpFinDataRepo.findByLfdPropNoAndLfdFinRowIdIn((propNum),finRowId);
}
public List<Object[]> getDataRowIdandFormulaValueByListOfDataFinRowId(BigDecimal propNum,long customerId , long finTypeNo , List<BigDecimal> dataFinRowId) {
	return lpstpFinDataRepo.getDataRowIdandFormulaValueByListOfDataFinRowId((propNum),BigDecimal.valueOf(customerId),dataFinRowId  ,BigDecimal.valueOf(finTypeNo));
}
public List<Object[]> getSumofYearCloumnWise(BigDecimal propNum, long customerId , long finTypeNo) {
	return lpstpFinDataRepo.getSumOfYearCloumnWise((propNum),BigDecimal.valueOf(customerId),BigDecimal.valueOf(finTypeNo));
}

public Integer updateyearForCalculatedFieldByRowId(String modifiedUser, BigDecimal[] yearArray, long dataRowId,HttpSession session) {
	String propDenom =session.getAttribute("propDenom").toString();

	return lpstpFinDataRepo.updateyearForCalculatedFieldByRowId(modifiedUser, new Date(),
			Helper.UnitsToActuals(propDenom, yearArray[0] ) , Helper.UnitsToActuals(propDenom, yearArray[1] ) , Helper.UnitsToActuals(propDenom, yearArray[2] ) , 
			Helper.UnitsToActuals(propDenom, yearArray[3] ) , Helper.UnitsToActuals(propDenom, yearArray[4] ) , Helper.UnitsToActuals(propDenom, yearArray[5] ) , 
			Helper.UnitsToActuals(propDenom, yearArray[6] ) , Helper.UnitsToActuals(propDenom, yearArray[7] ) , Helper.UnitsToActuals(propDenom, yearArray[8] ) ,
			Helper.UnitsToActuals(propDenom, yearArray[9] ) , Helper.UnitsToActuals(propDenom, yearArray[10] ) , Helper.UnitsToActuals(propDenom, yearArray[11] ) , 
			Helper.UnitsToActuals(propDenom, yearArray[12] ) , Helper.UnitsToActuals(propDenom, yearArray[13] ) , Helper.UnitsToActuals(propDenom, yearArray[14] ) ,
			Helper.UnitsToActuals(propDenom, yearArray[15] ) , Helper.UnitsToActuals(propDenom,  yearArray[16] ) , Helper.UnitsToActuals(propDenom, yearArray[17] ) , 
			Helper.UnitsToActuals(propDenom, yearArray[18] ) , Helper.UnitsToActuals(propDenom, yearArray[19] ) , Helper.UnitsToActuals(propDenom, yearArray[20] ) ,
			Helper.UnitsToActuals(propDenom, yearArray[21] ) , Helper.UnitsToActuals(propDenom, yearArray[22] ) , Helper.UnitsToActuals(propDenom, yearArray[23] ) ,
			Helper.UnitsToActuals(propDenom, yearArray[24] ) , Helper.UnitsToActuals(propDenom, yearArray[25] ) , Helper.UnitsToActuals(propDenom, yearArray[26] ) ,
			Helper.UnitsToActuals(propDenom, yearArray[27] ) , Helper.UnitsToActuals(propDenom, yearArray[28] ) , Helper.UnitsToActuals(propDenom, yearArray[29]) , 
			dataRowId);
}



public  boolean updateFormulaData(String modifierUserName,Long[] dataRowIdArray,String[] formula, BigDecimal propNum,long customerId, long finTypeNo,ServiceProvider serviceProvider,Logging logging,HttpSession session ) {
boolean flag = false;
	String modifedFormulaString = null;
	@SuppressWarnings("unused")
	List<BigDecimal> dataFinRowId = new ArrayList<BigDecimal>();
	Map<String,Object> hshMap=null;
	BigDecimal[] calcualatefieldValue= new BigDecimal[30];
	BigDecimal[] sumofYearCloumnWise= null;
	String tempStr=null;
	int indexCounter=0;
	int flagCounter=0;
	int z=0;
	//String formulaString =null;
	sumofYearCloumnWise=checkSumOfYear(propNum,customerId,finTypeNo,serviceProvider);
	for (String formulaString : formula) {
		 tempStr=null;
		 modifedFormulaString=null;
//		 sumofYearCloumnWise=null;
		/* flagCounter=50;
		 indexCounter=50;
		 for (int k = 50; k < formula.length; k++) {
		 formulaString=formula[k];
		 */
		hshMap = replaceFormulaandRowIdbyValue(formulaString, propNum, serviceProvider,logging);
		modifedFormulaString = (String) hshMap.get("rowValueString");
	//	dataFinRowId = (ArrayList<BigDecimal>) hshMap.get("listOfdataFinRowId");
		//logging.info("STAGE A
		for (int counter = 0; counter <30; counter++) {
			if(sumofYearCloumnWise[counter].intValue()>0){
		hshMap=getCurrentandPreviousYearListasRowId(propNum,customerId,finTypeNo,serviceProvider,counter+1);
		tempStr=replaceDataRowIdwithYearTpyeByYearValue(modifedFormulaString,hshMap);
		calcualatefieldValue[counter]= getExpressionValue(tempStr, logging );
		}else{
			calcualatefieldValue[counter]=BigDecimal.valueOf(Double.valueOf(0.00));
			}
		}
		//logging.info("STAGE A , flagCounter : {} , indexCounter : {} , formulaString : {} , tempStr: {} ,dataRowId:{} ",flagCounter,indexCounter,formulaString,tempStr,dataRowIdArray[indexCounter] );

		z=serviceProvider.getFinancialMasterService().updateyearForCalculatedFieldByRowId(modifierUserName,calcualatefieldValue,dataRowIdArray[indexCounter],session);
		
		if(z>0){
			flagCounter++;
		}
	//	logging.info("STAGE B, flagCounter : {} , indexCounter : {} , formulaString : {} , tempStr: {} , dataRowId:{} ",flagCounter,indexCounter,formulaString,tempStr,dataRowIdArray[indexCounter] );
		indexCounter++;

	}
	if(flagCounter==formula.length){
		flag = true;
	}
	return flag;
}
public  BigDecimal getExpressionValue(String inputStr,Logging logging ){
	String result ="0.00";
	ScriptEngineManager manager = new ScriptEngineManager();
	ScriptEngine engine = manager.getEngineByName("js");
	try {
		result	= engine.eval(inputStr).toString();
	} catch (ScriptException e) {
		result ="0.00";
		//e.printStackTrace();
	}
	
	if(result.trim().equalsIgnoreCase("NaN")||result.trim().equalsIgnoreCase("Infinity")||result.trim().equalsIgnoreCase("-Infinity")){
		result ="0.00";
	}
	//logging.info(" inputStr: {}  ,result:{}  ",inputStr,result);
	return BigDecimal.valueOf(Double.valueOf(result));
}
public  String replaceDataRowIdwithYearTpyeByYearValue(String inputString,Map<String,Object> hshMap){
	String local = null;
	int localInde = 0;
	int pcIndex = 0;
	StringBuffer inputlocal = new StringBuffer();
	StringBuffer inputStr = new StringBuffer(inputString);
	do {
		inputlocal.delete(0, inputlocal.length());
		localInde = inputStr.indexOf("L");
		if (localInde > -1) {
			pcIndex = inputStr.length();
			if (pcIndex > localInde + 7) {
				pcIndex = localInde + 7;
			}
			if (inputStr.substring(localInde + 1, pcIndex).indexOf("P") > -1) {
				pcIndex = inputStr.indexOf("P", localInde);
				local = inputStr.substring(localInde, pcIndex+1);
				if (hshMap.containsKey(local)) {
					local= hshMap.get(local).toString();
				    } else {
				    	local = inputStr.substring(localInde+1, pcIndex);
				    }
			} else {
				if (inputStr.substring(localInde + 1, pcIndex).indexOf("C") > -1) {
					pcIndex = inputStr.indexOf("C", localInde);
					local = inputStr.substring(localInde, pcIndex+1);
					if (hshMap.containsKey(local)) {
						local= hshMap.get(local).toString();
					    } else {
					    	local = inputStr.substring(localInde+1, pcIndex);
					    }
				}
			}
			inputlocal.append(inputStr.substring(0, localInde) + local + inputStr.substring(pcIndex + 1, inputStr.length()));
			inputStr.delete(0, inputStr.length());
			inputStr.append(inputlocal);
		}
	} while (inputStr.indexOf("L") > -1);
do {
		inputlocal.delete(0, inputlocal.length());
		localInde = inputStr.indexOf("N");
		if (localInde > -1) {
			pcIndex = inputStr.length();
			if (pcIndex > localInde + 7) {
				pcIndex = localInde + 7;
			}
			if (inputStr.substring(localInde + 1, pcIndex).indexOf("P") > -1) {
				pcIndex = inputStr.indexOf("P", localInde);
				    	local = inputStr.substring(localInde+1, pcIndex);
			} else {
				if (inputStr.substring(localInde + 1, pcIndex).indexOf("C") > -1) {
					pcIndex = inputStr.indexOf("C", localInde);
					    	local = inputStr.substring(localInde+1, pcIndex);
				}
			}

			inputlocal.append(inputStr.substring(0, localInde) + local + inputStr.substring(pcIndex + 1, inputStr.length()));

			inputStr.delete(0, inputStr.length());
			inputStr.append(inputlocal);
		}
	} while (inputStr.indexOf("N") > -1);
	inputlocal.delete(0, inputlocal.length());
	return inputStr.toString(); 
}

public  BigDecimal[] checkSumOfYear(BigDecimal propNum,long customerId, long finTypeNo,ServiceProvider serviceProvider ){
	BigDecimal[] longArray= new BigDecimal[30];
	List<Object[]>objList= serviceProvider.getFinancialMasterService().getSumofYearCloumnWise(propNum,customerId,finTypeNo);
	for (int i = 0; i < longArray.length; i++) {
		longArray[i]=(BigDecimal) objList.get(0)[i];
	}
	return  longArray;
}

public  Map<String, Object> getCurrentandPreviousYearListasRowId(BigDecimal propNum,long customerId,long finTypeNo,ServiceProvider serviceProvider, int counter) {
	Map<String, Object> hshMap = new HashMap<String, Object>();
	List<LpComFinData> DataAllrowList = new ArrayList<LpComFinData>();
	DataAllrowList = serviceProvider.getFinancialMasterService().getAllRowByPropNumforData(propNum ,customerId,finTypeNo);
	if (counter == 1) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear1()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", "0.00");
			hshMap.put("L"+dataObj.getLfdRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear1()));
			hshMap.put("L"+dataObj.getLfdRowId()+"P", "0.00");
		}
	} else if (counter == 2) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear2()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear1()));
			
			hshMap.put("L"+dataObj.getLfdRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear2()));
			hshMap.put("L"+dataObj.getLfdRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear1()));	
		}
	} else if (counter == 3) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear3()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear2()));
			hshMap.put("L"+dataObj.getLfdRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear3()));
			hshMap.put("L"+dataObj.getLfdRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear2()));
		}
	} else if (counter == 4) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear4()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear3()));
			hshMap.put("L"+dataObj.getLfdRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear4()));
			hshMap.put("L"+dataObj.getLfdRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear3()));
		}
	} else if (counter == 5) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear5()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear4()));
			hshMap.put("L"+dataObj.getLfdRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear5()));
			hshMap.put("L"+dataObj.getLfdRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear4()));
		}
	} else if (counter == 6) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear6()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear5()));
			hshMap.put("L"+dataObj.getLfdRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear6()));
			hshMap.put("L"+dataObj.getLfdRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear5()));
		}
	} else if (counter == 7) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear7()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear6()));
			hshMap.put("L"+dataObj.getLfdRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear7()));
			hshMap.put("L"+dataObj.getLfdRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear6()));
		}
	} else if (counter == 8) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear8()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear7()));
			
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear8()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear7()));
		}
	}	else if (counter == 9) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear9()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear8()));
			
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear9()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear8()));
			
		}
	}	else if (counter == 10) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear10()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear9()));
			
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear10()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear9()));
			
		}
	}else if (counter == 11) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear11()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear10()));	
			
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear11()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear10()));
		}
	} else if (counter == 12) {

		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear12()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear11()));	
		}
	} else if (counter == 13) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear13()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear12()));
		}
	} else if (counter == 14) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear14()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear13()));
		}
	} else if (counter == 15) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear15()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear14()));
		}
	} else if (counter == 16) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear16()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear15()));
		}
	} else if (counter == 17) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear17()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear16()));
		}
	} else if (counter == 18) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear18()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear17()));
		}
	}	else if (counter == 19) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear19()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear18()));
		}
	}	else if (counter == 20) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear20()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear19()));
		}
	}	else	if (counter == 21) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear21()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear20()));	
		}
	} else if (counter == 22) {

		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear22()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear21()));	
		}
	} else if (counter == 23) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear23()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear22()));
		}
	} else if (counter == 24) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear24()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear23()));
		}
	} else if (counter == 25) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear25()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear24()));
		}
	} else if (counter == 26) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear26()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear25()));
		}
	} else if (counter == 27) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear27()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear26()));
		}
	} else if (counter == 28) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear28()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear27()));
		}
	}	else if (counter == 29) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear29()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear28()));
		}
	}	else if (counter == 30) {
		for (LpComFinData dataObj : DataAllrowList) {
			hshMap.put("L"+dataObj.getLfdFinRowId()+"C", Helper.correctNullForNum(dataObj.getLfdYear30()));
			hshMap.put("L"+dataObj.getLfdFinRowId()+"P", Helper.correctNullForNum(dataObj.getLfdYear29()));
		}
	}		
	return hshMap;
}

public  Map<String, Object> replaceFormulaandRowIdbyValue(String inputString, BigDecimal propNum,ServiceProvider serviceProvider,Logging logging)  {
	String local = null;
	int localInde = 0;
	int pcIndex = 0;
	StringBuffer inputlocal = new StringBuffer();
	StringBuffer inputStr = new StringBuffer(inputString);
	Map<String, Object> hshMap = new HashMap<String, Object>();
	ArrayList<BigDecimal> listOfDataFinRowId = new ArrayList<BigDecimal>();
	do {
		inputlocal.delete(0, inputlocal.length());
		localInde = inputStr.indexOf("F");
		if (localInde > -1) {
			pcIndex = inputStr.length();
			if (pcIndex > localInde + 7) {
				pcIndex = localInde + 7;
			}
			if (inputStr.substring(localInde + 1, pcIndex).indexOf("P") > -1) {
				pcIndex = inputStr.indexOf("P", localInde);
				local = inputStr.substring(localInde + 1, pcIndex);
			} else {
				if (inputStr.substring(localInde + 1, pcIndex).indexOf("C") > -1) {
					pcIndex = inputStr.indexOf("C", localInde);
					local = inputStr.substring(localInde + 1, pcIndex);
				}
			}
			local = serviceProvider.getLpstpFinFormulaService().getFormulaValueByRowId(Long.valueOf(local));
			inputlocal.append(inputStr.substring(0, localInde) +"("+ local+")"
					+ inputStr.substring(pcIndex + 1, inputStr.length()));
			inputStr.delete(0, inputStr.length());
			inputStr.append(inputlocal);
		}
		
	} while (inputStr.indexOf("F") > -1);
	inputlocal.delete(0, inputlocal.length());

/*		do {
		inputlocal.delete(0, inputlocal.length());

		localInde = inputStr.indexOf("L");
		if (localInde > -1) {
			pcIndex = inputStr.length();

			if (pcIndex > localInde + 7) {
				pcIndex = localInde + 7;
			}
			if (inputStr.substring(localInde + 1, pcIndex).indexOf("P") > -1) {
				pcIndex = inputStr.indexOf("P", localInde);
				local = inputStr.substring(localInde + 1, pcIndex);
			} else {
				if (inputStr.substring(localInde + 1, pcIndex).indexOf("C") > -1) {
					pcIndex = inputStr.indexOf("C", localInde);
					local = inputStr.substring(localInde + 1, pcIndex);

				}
			}

			inputlocal.append(
					inputStr.substring(0, localInde) + "N" + inputStr.substring(localInde + 1, inputStr.length()));

			inputStr.delete(0, inputStr.length());
			inputStr.append(inputlocal);
			listOfDataFinRowId.add(BigDecimal.valueOf(Long.valueOf(local)));
		}

	} while (inputlocal.indexOf("L") > -1);*/
	// inputStr.delete(0, inputStr.length());
	//logging.info("Formula Replace : inputString : {} , outputString: {} ",inputString.toString(),inputStr.toString() );
	hshMap.put("rowValueString", inputStr.toString());
	hshMap.put("listOfdataFinRowId", listOfDataFinRowId);

	/*
	 * List<LpstpFinData>currentDataList=new ArrayList<LpstpFinData>();
	 * currentDataList= serviceProvider.getFinancialMasterService().
	 * getDatabyPropNumandListOfFinRowId(propNum, listOfDataFinRowId);
	 * //+local+inputStr.substring(pcIndex+1),inputStr.length().toString())
	 * ; do { inputlocal.delete(0, inputlocal.length());
	 * 
	 * localInde=inputStr.indexOf("N"); if(localInde>-1){
	 * pcIndex=inputStr.length();
	 * 
	 * if(pcIndex>localInde+7){ pcIndex=localInde+7; }
	 * if(inputStr.substring(localInde+1,pcIndex).indexOf("P")>-1){
	 * pcIndex=inputStr.indexOf("P",localInde); //
	 * local=inputStr.substring(localInde+1,pcIndex); for(LpstpFinData
	 * dataElement : currentDataList){
	 * 
	 * if(listOfDataFinRowId.contains(dataElement.getLfdFinRowId())){
	 * 
	 * } } }else{
	 * if(inputStr.substring(localInde+1,pcIndex).indexOf("C")>-1){
	 * pcIndex=inputStr.indexOf("C",localInde);
	 * //local=inputStr.substring(localInde+1,pcIndex); for(LpstpFinData
	 * dataElement : currentDataList){
	 * 
	 * if(listOfDataFinRowId.contains(dataElement.getLfdFinRowId())){
	 * 
	 * } }
	 * 
	 * } }
	 * 
	 * 
	 * inputlocal.append(inputStr.substring(0,localInde)+"N"+inputStr.
	 * substring(localInde+1,inputStr.length()));
	 * 
	 * inputStr.delete(0, inputStr.length()); inputStr.append(inputlocal);
	 * listOfDataFinRowId.add(BigDecimal.valueOf(Long.valueOf(local))); }
	 * 
	 * } while(inputlocal.indexOf("N")>-1);
	 */

	return hshMap;
}
public List<BigDecimal> getFinRowIdByPropNumAndRowTypeforData(BigDecimal propNum, long customerId,long finTypeNo, String rowType,String finTabName) {
	//List<Object> obj= lpstpFinDataRepo.getFinRowIdByPropNumforData(BigDecimal.valueOf(propNum),BigDecimal.valueOf(customerId));
	return  lpstpFinDataRepo.getFinRowIdByPropNumAndCustomerIdAndFinRowType((propNum),BigDecimal.valueOf(customerId),rowType,finTabName,BigDecimal.valueOf(finTypeNo));

}
@Transactional
//@Async
public boolean saveFieldforDatabyFinPageType(BigDecimal PropNum, long customerId, long finTypeNo,String finPageName,String modifiedBy ,Date modifiedOn,  ServiceProvider serviceProvider) {
	boolean flag = false;
	try{
		List<String> rowTypeList= new ArrayList<String>();
		//rowTypeList.add("E");
		rowTypeList.add("C");
		rowTypeList.add("H");
		List<LpstpFinMaster> listOfFinMasterRowId = serviceProvider.getSetFinMasterService().findByfinPageAndFinRowTypeIn(finPageName,rowTypeList);
	List<BigDecimal> listOfFinRowId = new ArrayList<BigDecimal>();
	LpComFinData dataModelObject=null ; 
	int counterforIndex =0;
	for (LpstpFinMaster obj : listOfFinMasterRowId) {
/*		listOfFinRowId.add(BigDecimal.valueOf(obj.getFinRowid()));
	}
	for (BigDecimal bigDecimal : listOfFinRowId) {*/
		dataModelObject = new LpComFinData();
		dataModelObject.setLfdRowId(0);
		dataModelObject.setLfdPropNo((PropNum));
		dataModelObject.setLfdCustNewId((BigDecimal.valueOf(customerId)));
		dataModelObject.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));

		dataModelObject.setLfdCreatedBy(modifiedBy);
		dataModelObject.setLfdCreatedOn(modifiedOn);
		dataModelObject.setLfdModifiedBy(null);
		dataModelObject.setLfdModifiedOn(null);
		dataModelObject.setLfdFinRowId(BigDecimal.valueOf(obj.getFinRowid()));
		 serviceProvider.getFinancialMasterService().saveDataForData(dataModelObject);
		 counterforIndex++;
	}
	if(counterforIndex ==listOfFinMasterRowId.size() ){
		flag = true;
	}
	}catch (Exception e) {
		flag = false;
		
	}
	 return flag;
}
@Override
public List<LpComFinData> getFinancialYear(String finPage, String finTabName, BigDecimal propNum, BigDecimal customerId){
	
	return lpstpFinDataRepo.getFinancialYear(finPage,finTabName,propNum,customerId);
}
/*@Override
public List<LpComFinData> getRecordByPropNoandCustoemrIdandFinRowIdOfData(long propNum, long customerId,
		List<BigDecimal> finRowId) {
	// TODO Auto-generated method stub
	return lpstpFinDataRepo.findByLfdPropNoAndLfdCustNewIdAndLfdFinRowIdIn(BigDecimal.valueOf(propNum),BigDecimal.valueOf(customerId), finRowId);
}*/


@Override
public Map downloadFinanicalFormat(BigDecimal propNum, long customerId, long cmano, String finpage) {

	int currentrow = 0;
	HSSFWorkbook wb = new HSSFWorkbook();
	Map result = new HashMap();
	
	LpstpCMAMaster lpstpCMAMaster = lpstpCMAMasterRepo.findByCmaNo(new BigDecimal(cmano));
	
	String sheetname =Helper.correctNull(lpstpCMAMaster.getCmaFormatDesc()).replaceAll(":"," ");
	sheetname = sheetname.replaceAll("-"," ");
	sheetname = sheetname.length()>30?sheetname.substring(0,30):sheetname;
	
	HSSFFont font = getFont(wb, "Arial", HSSFColor.BLACK.index, 10, 4, false);
	HSSFSheet sheet = wb.createSheet(sheetname);
	sheet.protectSheet("123");
	sheet.createFreezePane(3, 4);
	sheet.setColumnWidth((short)0,(short)(1));
	sheet.setColumnWidth((short)1,(short)(256*30));
	sheet.setColumnWidth((short)2,(short)(256*60));
	
	
	ArrayList row = new ArrayList();
	
	row = new ArrayList();
	row.add("Start Date and End Date Format is dd/MM/yyyy");
	addRowForYear(wb, sheet, row, ++currentrow, 1,font);
	sheet.addMergedRegion(new Region(currentrow, (short) 1, currentrow, (short) (3 - 1)));
	
	
	row = new ArrayList();
	row.add("Start Date");
	for(int i=0;i<30;i++)
	{
		row.add("");
	}
	addRowForYear(wb, sheet, row, ++currentrow, 1,font);
	sheet.addMergedRegion(new Region(currentrow, (short) 1, currentrow, (short) (3 - 1)));
	
	row = new ArrayList();
	row.add("End Date");
	for(int i=0;i<30;i++)
	{
		row.add("");
	}
	addRowForYear(wb, sheet, row, ++currentrow, 1,font);
	sheet.addMergedRegion(new Region(currentrow, (short) 1, currentrow, (short) (3 - 1)));
	
	row = new ArrayList();
	row.add("Financial Type");
	for(int i=0;i<30;i++)
	{
		row.add("");
	}
	  addRowForYear(wb, sheet, row, ++currentrow, 1,font);
	  sheet.addMergedRegion(new Region(currentrow, (short) 1, currentrow, (short) (3 - 1)));
	  CellRangeAddressList addressList = new CellRangeAddressList(3,3, 2, 30);
	  font = getFont(wb, "Arial", HSSFColor.BLACK.index, 14, 4, false);
	  DVConstraint dvConstraint = DVConstraint.createExplicitListConstraint(
			new String[]{"Audited","UnAudited","Estimated","Projection"});
	  DataValidation dataValidation = new HSSFDataValidation
			    (addressList, dvConstraint);
	  dataValidation.setSuppressDropDownArrow(false);
	  sheet.addValidationData(dataValidation);
	  
	  List<LpstpFinMaster> lpstpFinMasterList =   lpstpFinMasterRepo.findByFinCmaNoAndFinPageOrderByFinTabnameAscFinSnoAsc(new BigDecimal(cmano),finpage);
	 
	  HashMap hshmap = new HashMap();
	  for(LpstpFinMaster lpstpFinMaster : lpstpFinMasterList)
	  {
		  font = getFont(wb, "Arial", HSSFColor.BLACK.index, 10, 4, false);
		  if(!hshmap.containsKey(lpstpFinMaster.getFinTabname()))
		  {
			  hshmap.put(lpstpFinMaster.getFinTabname(), lpstpFinMaster.getFinTabname());
			  row = new ArrayList();
			  row.add(String.valueOf(0));
			  row.add(lpstpFinMaster.getFinTabname());
			  for(int i=0;i<30;i++)
			  {
				row.add("");
			  }
			  addRowByValue(wb, sheet, row, ++currentrow, 0,"TAB");
			  sheet.addMergedRegion(new Region(currentrow, (short) 1, currentrow, (short) (3 - 1)));
		  }
		  row = new ArrayList();
		  row.add(String.valueOf(lpstpFinMaster.getFinRowid()));
		  row.add(lpstpFinMaster.getFinRowdesc());
		  for(int i=0;i<30;i++)
		  {
			row.add("");
		  }
		  addRowByValue(wb, sheet, row, ++currentrow, 0,lpstpFinMaster.getFinRowtype());
		  sheet.addMergedRegion(new Region(currentrow, (short) 1, currentrow, (short) (3 - 1)));
	  }
	  
	ByteArrayOutputStream bos = new ByteArrayOutputStream();
	try {
		wb.write(bos);
	} catch (IOException e) {
		e.printStackTrace();
	} finally {
	    try {
			bos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
}

	String mimeType = "application/octet-stream";
	byte[] bytes = bos.toByteArray();
	
	result.put("data","data:"+mimeType+";base64," + new String(Base64.getEncoder().encode(bytes)));
	
	result.put("workbook", wb);
	return result;
}
public HSSFFont getFont(HSSFWorkbook wb, String fontName, short clrindex, int fontheight, int boldweight, boolean isitalic) {
	HSSFFont font = wb.createFont();
	font.setFontHeightInPoints((short) fontheight);
	font.setFontName(fontName);
	font.setColor(clrindex);
	font.setBoldweight((short) boldweight);
	font.setItalic(isitalic);
	return font;
}

public void addRowForYear(HSSFWorkbook wb, HSSFSheet sheet, ArrayList cols, int startingrow, int startingcol, HSSFFont font) {
	HSSFRow row = sheet.createRow((short) startingrow);
	HSSFCellStyle style = wb.createCellStyle();
	HSSFPalette palette = wb.getCustomPalette();
	for (int i = 0; i < cols.size(); i++) {
		HSSFCell cellj = row.createCell((short) (startingcol + i), HSSFCellStyle.ALIGN_FILL);
		style = wb.createCellStyle();
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		if(i == 0){
			style.setFillForegroundColor(HSSFColor.WHITE.index);
			font = getFont(wb, "Arial", HSSFColor.RED.index, 10, 8, false);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			style.setBorderLeft(CellStyle.BORDER_MEDIUM);
			style.setBorderTop(CellStyle.BORDER_MEDIUM);
			style.setBorderBottom(CellStyle.BORDER_MEDIUM);
			style.setWrapText(true);
			style.setLocked(true);
			style.setFont(font);
			cellj.setCellStyle(style);
		}else{
			font = getFont(wb, "Arial", HSSFColor.GREEN.index, 10, 4, false);
		}
		if(i >= 2){
			if(startingrow==1 || startingrow==2)
			{
				Short df = wb.createDataFormat().getFormat("dd/MM/yyyy");
				style.setDataFormat(df);
				sheet.setColumnWidth(startingcol + i,(short)(256*20));
			}
			style.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
			font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			style.setFont(font);
			style.setWrapText(true);
			style.setBorderLeft(CellStyle.BORDER_MEDIUM);
			style.setBorderTop(CellStyle.BORDER_MEDIUM);
			style.setBorderBottom(CellStyle.BORDER_MEDIUM);
			style.setLocked(false);
			cellj.setCellStyle(style);
		}
		cellj.setCellValue(Helper.correctNull((String) cols.get(i)));	
		
	}

}

	public void addRowByValue(HSSFWorkbook wb, HSSFSheet sheet, ArrayList cols, int startingrow, int startingcol,String itemtype) {
	HSSFRow row = sheet.createRow((short) startingrow);
	HSSFFont font = getFont(wb, "Arial", HSSFColor.BLACK.index, 8, 4, false);
	HSSFCellStyle style = wb.createCellStyle();
	HSSFPalette palette = wb.getCustomPalette();
	style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	if(itemtype.equalsIgnoreCase("TAB")){
		style.setLocked(true);
		style.setFillForegroundColor(HSSFColor.DARK_BLUE.index);
		font = getFont(wb, "Arial", HSSFColor.WHITE.index, 10, HSSFFont.BOLDWEIGHT_BOLD, false);
	}else if(itemtype.equalsIgnoreCase("H")){
		style.setLocked(true);
		style.setFillForegroundColor(HSSFColor.DARK_BLUE.index);
		font = getFont(wb, "Arial", HSSFColor.WHITE.index, 10, HSSFFont.BOLDWEIGHT_BOLD, false);
	}else if(itemtype.equalsIgnoreCase("C")){
		style.setLocked(true);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		palette.setColorAtIndex(HSSFColor.LIME.index,(byte) 199, (byte) 227, (byte) 233);
		style.setFillForegroundColor(HSSFColor.LIME.index);
	}else if(itemtype.equalsIgnoreCase("E")){
		
		style.setLocked(false);
		palette.setColorAtIndex(HSSFColor.CORAL.index,(byte) 229, (byte) 234, (byte) 243);
		style.setFillForegroundColor(HSSFColor.CORAL.index);
	}
	style.setFont(font);
	style.setBorderTop(CellStyle.BORDER_THIN);
	style.setBorderRight(CellStyle.BORDER_THIN);
		for (int i = 0; i < cols.size(); i++) {
			HSSFCell celli = row.createCell((short) (startingcol + i), HSSFCellStyle.ALIGN_FILL);
			if (cols.get(i) instanceof Double && itemtype.equalsIgnoreCase("C")) {
				celli.setCellValue(((Double) cols.get(i)).doubleValue());
			} else {
				celli.setCellValue((String) cols.get(i));				
			}
			celli.setCellStyle(style);
		}

}
@Override
	public boolean uploadFinanicalFormat(HSSFWorkbook workbook, Map hshMap) {
	HSSFCell cell = null;
	HSSFCell startCell = null;
	HSSFCell endCell = null;
	HSSFCell finTypeCell = null;
	HSSFCell currentcell = null;
	HSSFSheet sheet = workbook.getSheetAt(0);
	HSSFRow currentRow = null;
	HSSFRow startRow = null;
	HSSFRow endRow = null;
	HSSFRow finTypeRow = null;
	HashMap<Integer ,ArrayList> hashMap = new HashMap();
	HashMap<Integer ,ArrayList> hashMapForYears = new HashMap();
	ArrayList arrayList = new ArrayList();
	ArrayList arrayListForYears = new ArrayList();
	try
	{
		for(int i=4;i<=sheet.getPhysicalNumberOfRows();i++)
		{
			currentRow=sheet.getRow(i);
			startRow=sheet.getRow(1);
			endRow=sheet.getRow(2);
			finTypeRow=sheet.getRow(3);
			int finMasterId=0;
			cell = (currentRow.getCell((short) 0));
			if(cell.getCellType()==1)
			{
				finMasterId=Integer.parseInt(cell.getStringCellValue());
			}else if(cell.getCellType()==3)
			{
				finMasterId=Integer.parseInt(String.valueOf(cell.getNumericCellValue()));
			}
			if(finMasterId>0)
			{
				arrayList = new ArrayList();
				arrayListForYears = new ArrayList();
				for(int j=3;j<currentRow.getPhysicalNumberOfCells();j++)
				{		
					startCell= (startRow.getCell((short) j));
					endCell= (endRow.getCell((short) j));
					finTypeCell= (finTypeRow.getCell((short) j));
					String startYear="";
					String endYear="";
					String finType="";
					if(startCell != null && endCell!=null && finTypeCell!=null)
					{
						if(startCell.getCellType()==0)
						{
							startYear=startCell.getDateCellValue().toString();
						}else
						{
							startYear=startCell.getStringCellValue().toString();
						}
						
						if(endCell.getCellType()==0)
						{
							endYear=endCell.getDateCellValue().toString();
						}else
						{
							endYear=endCell.getStringCellValue().toString();
						}
						if(finTypeCell.getCellType()==0)
						{
							finType=finTypeCell.getDateCellValue().toString();
						}else
						{
							finType=finTypeCell.getStringCellValue().toString();
						}
						if(!(Helper.correctNull(startYear)).equals("") && !(Helper.correctNull(endYear)).equals("")  && !(Helper.correctNull(finType)).equals(""))
						{
							String yearValue ="";
							currentcell = (currentRow.getCell((short) j));
							if(currentcell.getCellType()==1)
							{
								yearValue= currentcell.getStringCellValue();
							}else if(currentcell.getCellType()==0)
							{
								yearValue=String.valueOf(currentcell.getNumericCellValue());
							}else if(currentcell.getCellType()==3)
							{
								yearValue=String.valueOf(currentcell.getNumericCellValue());
							}
							System.out.println("yearValue------------" +yearValue);
							arrayList.add(yearValue);
							arrayListForYears.add(startYear);
							arrayListForYears.add(endYear);
							arrayListForYears.add(finType);
							if(!hashMapForYears.containsKey(j-2))
							{
								hashMapForYears.put((j-2), arrayListForYears);
							}
						}
					}
				
				}
				hashMap.put(finMasterId, arrayList);
			}
		}
		List<LpComFinData> lpComFinDataList = new ArrayList();
		for (Map.Entry<Integer,ArrayList> entry : hashMap.entrySet()) 
		{
			ArrayList cellList = entry.getValue();
			Integer key = entry.getKey();
			LpComFinData lpComFinData = new LpComFinData();
			for(int i=0,size=cellList.size();i<size;i++)
			{
				lpComFinData.setLfdPropNo(new BigDecimal(hshMap.get("propNum").toString()));
				lpComFinData.setLfdCustNewId(new BigDecimal(hshMap.get("customerId").toString()));
				lpComFinData.setLfdFinRowId(new BigDecimal(key));
				lpComFinData.setLfdCmaNo(new BigDecimal(hshMap.get("cmano").toString()));
				lpComFinData.setLfdCreatedBy("abi");
				lpComFinData.setLfdCreatedOn(Helper.getSystemDate());
				Class[] paramTypes = new Class[1];
				paramTypes[0] = BigDecimal.class;
				try
				{
					Method method = lpComFinData.getClass().getDeclaredMethod("setLfdYear"+(i+1),paramTypes);
					method.invoke(lpComFinData,new BigDecimal((String)cellList.get(i)));	
				}catch (Exception e) {
					e.printStackTrace();
				}
				
			}
			lpComFinDataList.add(lpComFinData);
			
		}
		List<LpComFinDetail> LpComFinDetailList = new ArrayList();
		for (Map.Entry<Integer,ArrayList> entry : hashMapForYears.entrySet()) 
		{
			ArrayList cellList = entry.getValue();
			Integer key = entry.getKey();
			LpComFinDetail lpComFinDetail = new LpComFinDetail();
			for(int i=0,size=cellList.size();i<size;i++)
			{
				lpComFinDetail.setLfdPropNo(new BigDecimal(hshMap.get("propNum").toString()));
				lpComFinDetail.setLfdCustNewId(new BigDecimal(hshMap.get("customerId").toString()));
				lpComFinDetail.setLfdCreatedBy("abi");
				lpComFinDetail.setLfdCreatedOn(Helper.getSystemDate());
				lpComFinDetail.setLfdYearSeqNo(new BigDecimal(key));
				lpComFinDetail.setLfdCmaNo(new BigDecimal(hshMap.get("cmano").toString()));
				if(i==0)
				{
					String dateStr =(String)cellList.get(i);
					DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
					Date date = (Date)formatter.parse(dateStr);

					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					String formatedDate = cal.get(Calendar.DATE) + "/" + (cal.get(Calendar.MONTH) + 1) + "/" +         cal.get(Calendar.YEAR);
					
					lpComFinDetail.setLfdStartDate(Helper.convertStringToDate(formatedDate));
					
				}else if(i==1)
				{
					String dateStr =(String)cellList.get(i);
					DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
					Date date = (Date)formatter.parse(dateStr);				
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					String formatedDate = cal.get(Calendar.DATE) + "/" + (cal.get(Calendar.MONTH) + 1) + "/" +         cal.get(Calendar.YEAR);		
					
					lpComFinDetail.setLfdEndDate(Helper.convertStringToDate(formatedDate));	
				}else if(i==2)
				{
					
					lpComFinDetail.setLfdAuditType(Helper.correctNull((String)cellList.get(i)).equalsIgnoreCase("Audited") ? "A"
							: Helper.correctNull((String)cellList.get(i)).equalsIgnoreCase("UnAudited")? "U" : Helper.correctNull((String)cellList.get(i)).equalsIgnoreCase("Estimated")?"E": Helper.correctNull((String)cellList.get(i)).equalsIgnoreCase("Projection")?"P":"");	
				}
			}
			LpComFinDetailList.add(lpComFinDetail);
		}
		
		
		if(!lpComFinDataList.isEmpty())
		{
			List<LpComFinData> lpcomfinDataList = lpstpFinDataRepo.findByLfdPropNoAndLfdCmaNoAndLfdCustNewId(new BigDecimal(hshMap.get("propNum").toString()),new BigDecimal(hshMap.get("cmano").toString()),new BigDecimal(hshMap.get("customerId").toString()));
			lpstpFinDataRepo.delete(lpcomfinDataList);
			lpstpFinDataRepo.save(lpComFinDataList);
		}
		if(!LpComFinDetailList.isEmpty())
		{
			List<LpComFinDetail> lpstpFinDetailList = lpstpFinDetailRepo.findByLfdPropNoAndLfdCmaNoAndLfdCustNewId(new BigDecimal(hshMap.get("propNum").toString()),new BigDecimal(hshMap.get("cmano").toString()),new BigDecimal(hshMap.get("customerId").toString()));
			lpstpFinDetailRepo.delete(lpstpFinDetailList);
			lpstpFinDetailRepo.save(LpComFinDetailList);
		}
		
		
		return true;
	}catch (Exception e) {
		return false;
	}


}


public List<Object[]> getDistinctCusrtomerIDandCMANo(BigDecimal propNum) {
	return lpstpFinDetailRepo.getDistinctCustomerIdandCMANo((propNum));
}
public void deleteAllRowOfDetailandDataByPropNoandCustomerIdAndCmaNo(BigDecimal propNum, long customerId, long finType) {
	lpstpFinDetailRepo.deleteByLfdPropNoAndLfdCustNewIdAndLfdCmaNo((propNum ), BigDecimal.valueOf(customerId),BigDecimal.valueOf( finType));
	lpstpFinDataRepo.deleteByLfdPropNoAndLfdCustNewIdAndLfdCmaNo((propNum ), BigDecimal.valueOf(customerId),BigDecimal.valueOf( finType));
	
}
public List<LpComFinDetail> findByLfdPropNoAndLfdCustNewId(BigDecimal lfdPropNo, BigDecimal lfdCustNewId) {
	return lpstpFinDetailRepo.findByLfdPropNoAndLfdCustNewId(lfdPropNo, lfdCustNewId);
}




}
