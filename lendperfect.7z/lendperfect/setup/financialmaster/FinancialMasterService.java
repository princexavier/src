package com.sai.lendperfect.setup.financialmaster;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpComFinData;
import com.sai.lendperfect.setupmodel.LpComFinDetail;


public interface FinancialMasterService {

	List<LpComFinDetail> findAllforDetail();
	LpComFinDetail findByRowIdforDetail(long lfdRowId);
	List<LpComFinDetail> findByRowIdforDetailasList(long lfdRowId);

	//List<LpstpFinDetail> findBy(long lfdRowId);
	LpComFinDetail saveDataForDetail(LpComFinDetail modelObject );
	void deleteDataForDetail(LpComFinDetail modelObject );
	LpComFinDetail updateDataForDetail(LpComFinDetail modelObject );
	long maxOfSeqNumByPropNumForDetail(BigDecimal propNum,long customerId,long finTypeNo);
	List<LpComFinDetail> getRowByPropNumorderBySeqnumForDetail(BigDecimal propNum,long customerId,long finTypeNo);
	LpComFinDetail getRowOfMAxDateByAuditType(String auditType,BigDecimal propNum,long customerId ,long finTypeNo);

	List<BigDecimal> getFinRowIdByPropNumAndRowTypeforData(BigDecimal propNum,long customerId,long finTypeNo,String rowType,String finTabName);
boolean	 saveFieldforDatabyFinPageType(BigDecimal PropNum,long customerId, long finTypeNo,String finPageName,String modifiedBy ,Date modifiedOn,  ServiceProvider serviceProvider) ;
	// for Data table 
	 LpComFinData findByRowIdforData(long lfdRowId) ;
	 List<LpComFinData> findAllforData();	
	List<BigDecimal> getFinRowIdByPropNumforData(BigDecimal propNum,long customerId,long lfdCmaNo);
	List<LpComFinData> getAllRowByPropNumforData(BigDecimal propNum,long customerId,long lfdCmaNo);
	
	List<LpComFinData> getAllRowByPropNumandFinMasterTabNameforData(BigDecimal propNum,String finPage,String finTabName,long customerId,long lfdCmaNo);
	
	LpComFinData saveDataForData(LpComFinData modelObject );
	void deleteDataForData(LpComFinData modelObject );

	Integer updateDataForDatafor1to5(LpComFinData modelObject );
	Integer updateDataForDatafor6to10(LpComFinData modelObject );
	Integer updateDataForDatafor11to15(LpComFinData modelObject );
	Integer updateDataForDatafor16to20(LpComFinData modelObject );
	Integer updateDataForDatafor21to25(LpComFinData modelObject );
	Integer updateDataForDatafor26to30(LpComFinData modelObject );
	
	Integer updateDataForDatafor1to5ByDataRowId(LpComFinData modelObject );
	Integer updateDataForDatafor6to10ByDataRowId(LpComFinData modelObject );
	Integer updateDataForDatafor11to15ByDataRowId(LpComFinData modelObject );
	Integer updateDataForDatafor16to20ByDataRowId(LpComFinData modelObject );
	Integer updateDataForDatafor21to25ByDataRowId(LpComFinData modelObject );
	Integer updateDataForDatafor26to30ByDataRowId(LpComFinData modelObject );
	
	List<LpComFinData> getDatabyPropNumandListOfFinRowId(BigDecimal propNum,List<BigDecimal> finRowId);
	List<Object[]> getDataRowIdandFormulaValueByListOfDataFinRowId(BigDecimal propNum,long customerId,long finTypeNo ,List<BigDecimal> dataFinRowId);
	List<Object[]> getSumofYearCloumnWise(BigDecimal propNum,long customerId, long finTypeNo);
	Integer updateyearForCalculatedFieldByRowId(String ModifiedUser,BigDecimal[] yearArray,long DataRowId,HttpSession session);
	boolean updateFormulaData(String modifierUserName,Long[] dataRowIdArray,String[] formula, BigDecimal propNum,long customerId,long finTypeNo, ServiceProvider serviceProvider,Logging logging,HttpSession session) ;
	BigDecimal getExpressionValue(String inputStr,Logging logging);
	String replaceDataRowIdwithYearTpyeByYearValue(String inputString,Map<String,Object> hshMap);
	BigDecimal[] checkSumOfYear(BigDecimal propNum,long customerId,long finTypeNo,ServiceProvider serviceProvider );
	 Map<String, Object> getCurrentandPreviousYearListasRowId(BigDecimal propNum,long customerId,long finTypeNo,ServiceProvider serviceProvider, int counter);
	 Map<String, Object> replaceFormulaandRowIdbyValue(String inputString, BigDecimal propNum,ServiceProvider serviceProvider,Logging logging) ;
	List<LpComFinData> getFinancialYear(String finPage, String finTabName, BigDecimal propNum, BigDecimal customerId);
//	List<LpComFinData> getRecordByPropNoandCustoemrIdandFinRowIdOfData(long propNum,long customerId,List<BigDecimal> finRowId) ;
	
	Map downloadFinanicalFormat(BigDecimal propNum, long customerId, long cmano, String finpage);
	boolean uploadFinanicalFormat(HSSFWorkbook workbook, Map hshMap);
	
	List<Object[]> getDistinctCusrtomerIDandCMANo(BigDecimal propNum); 
	
	void deleteAllRowOfDetailandDataByPropNoandCustomerIdAndCmaNo(BigDecimal propNum, long customerId, long finType);
	
	List<LpComFinDetail>  findByLfdPropNoAndLfdCustNewId(BigDecimal lfdPropNo,
			BigDecimal lfdCustNewId);
}
