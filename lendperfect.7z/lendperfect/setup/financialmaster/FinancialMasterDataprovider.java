package com.sai.lendperfect.setup.financialmaster;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomCustInfo;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpFinMaster;
import com.sai.lendperfect.setupmodel.LpComFinData;
import com.sai.lendperfect.setupmodel.LpComFinDetail;

public class FinancialMasterDataprovider {
	@SuppressWarnings({ "unchecked", "unused", "rawtypes" })
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		LpComFinDetail lpstpFinDetail=null;
		List<LpComFinDetail> listOfLpstpFinDetail=null;

		LpComFinData lpstpFinData=null;
		List<LpComFinData> listOfLpstpFinData=null;
		List<Long> listOfFinRowId=null;
		List<LpcomCustInfo> listOfLpcomCustInfo=null;
		List<BigDecimal> listOfBigDecimal = null;
		Map<String,Object> hshMap = null;
		String propDenom =null;// session.getAttribute("propDenom").toString();
		responseHashMap.put("success", true);
		logging.info("dpMethod:{}  ,",dpMethod);
		try {
			if (dpMethod.equals("saveData")) {
				try {
					
					Map<String, Object> temphshMap=(Map<String, Object>) allRequestParams.get("requestData");
				//	String[] lfdRowIdArray = temphshMap.get("lpstpDetailRowId").toString().trim().split("^");
				//   DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
			    //   SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");

					
					String[] finRowIdArray = temphshMap.get("finRowId").toString().trim().split("\\^");
					String[] startDateArray = temphshMap.get("startDate").toString().trim().split("\\^");
					String[] endDateArray = temphshMap.get("endDate").toString().trim().split("\\^");
					String[] auditType = temphshMap.get("auditType").toString().trim().split("\\^");
					int counterMax=Integer.parseInt(temphshMap.get("currentMaxCount").toString());
					String modifiedBy=temphshMap.get("modifiedBy").toString().trim();
					//Date modifiedOn=Helper.convertStringToDate(temphshMap.get("modifiedOn").toString().trim());
					Date modifiedOn=new Date();
					BigDecimal PropNum=(BigDecimal) (temphshMap.get("PropNum"));
					long customerId=Long.parseLong(temphshMap.get("customerId").toString());
					long finTypeNo=Long.valueOf(temphshMap.get("finTypeNo").toString());
					String[] y1Array = temphshMap.get("y1").toString().trim().split("\\^");
					String[] y2Array = temphshMap.get("y2").toString().trim().split("\\^");
					String[] y3Array = temphshMap.get("y3").toString().trim().split("\\^");
					String[] y4Array = temphshMap.get("y4").toString().trim().split("\\^");
					String[] y5Array = temphshMap.get("y5").toString().trim().split("\\^");
					propDenom = session.getAttribute("propDenom").toString();
				if(counterMax==1){
						counterMax=0;
					}
					int  length = counterMax+startDateArray.length;
					int counterforIndex =0;
					 long num =0;
					 if(finRowIdArray.length==0){
						 length=0;
						 counterMax=99;
					 }
					for(int i=counterMax;i<length;i++){
						num =0;
						lpstpFinDetail = new LpComFinDetail();
						lpstpFinDetail.setLfdRowId(0);
						lpstpFinDetail.setLfdPropNo((PropNum));
						lpstpFinDetail.setLfdCustNewId((BigDecimal.valueOf(customerId)));
						lpstpFinDetail.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
						if(counterforIndex==0){
							if(counterMax==0){
								num=i+1;
								}else{
									num=i;	
							}
						}else{
							
							if(counterMax==0){
								num=i+1;
								}else{
									num=i;	
							}
								
							}
						
						lpstpFinDetail.setLfdYearSeqNo(BigDecimal.valueOf(num ));
						if(!startDateArray[counterforIndex].trim().equalsIgnoreCase("*")){
						lpstpFinDetail.setLfdStartDate(Helper.convertStringToDate(startDateArray[counterforIndex].trim().replaceAll("-", "/")));
						lpstpFinDetail.setLfdEndDate(Helper.convertStringToDate(endDateArray[counterforIndex].trim().replaceAll("-", "/")));
						lpstpFinDetail.setLfdAuditType(auditType[counterforIndex]);
						}else{
							lpstpFinDetail.setLfdStartDate(null);
							lpstpFinDetail.setLfdEndDate(null);
							lpstpFinDetail.setLfdAuditType("");

						}
						 lpstpFinDetail.setLfdPrintReq("Y");
						 lpstpFinDetail.setLfdCreatedBy(modifiedBy);
						 lpstpFinDetail.setLfdCreatedOn(modifiedOn);
						 lpstpFinDetail.setLfdModifiedBy(modifiedBy);
						 lpstpFinDetail.setLfdModifiedOn(modifiedOn);
						 serviceProvider.getFinancialMasterService().saveDataForDetail(lpstpFinDetail);
						 counterforIndex++;
					}
					length=0;
					counterforIndex=0;
 					if(counterMax==0){
						 length = counterMax+finRowIdArray.length;
						 counterforIndex=0;
						for(int i=counterMax;i<length;i++){
							lpstpFinData = new LpComFinData();
							lpstpFinData.setLfdRowId(0);
							lpstpFinData.setLfdPropNo((PropNum));
							lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
							lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
							lpstpFinData.setLfdCreatedBy(modifiedBy);
							lpstpFinData.setLfdCreatedOn(modifiedOn);
							lpstpFinData.setLfdModifiedBy(modifiedBy);
							lpstpFinData.setLfdModifiedOn(modifiedOn);
							lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
							if(!y1Array[counterforIndex].trim().contains("*")){
								lpstpFinData.setLfdYear1(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
							}else{
								lpstpFinData.setLfdYear1(null);
							}

							if(!y2Array[counterforIndex].trim().contains("*")){
								lpstpFinData.setLfdYear2(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
							}else{
								lpstpFinData.setLfdYear2(null);
							}
							if(!y3Array[counterforIndex].trim().contains("*")){
								lpstpFinData.setLfdYear3(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
							}else{
								lpstpFinData.setLfdYear3(null);
							}
							if(!y4Array[counterforIndex].trim().contains("*")){
								lpstpFinData.setLfdYear4(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
							}else{
								lpstpFinData.setLfdYear4(null);
							}
							if(!y5Array[counterforIndex].trim().contains("*")){
								lpstpFinData.setLfdYear5(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
							}else{
								lpstpFinData.setLfdYear5(null);
							}
						
							 serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);
							 counterforIndex++;

						}
					}
					else
						if(counterMax==6){
							 length = counterMax+finRowIdArray.length;
							 counterforIndex=0;
							for(int i=counterMax;i<length;i++){
								lpstpFinData = new LpComFinData();
								lpstpFinData.setLfdRowId(0);
								lpstpFinData.setLfdPropNo((PropNum));
								lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
								lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
								lpstpFinData.setLfdCreatedBy(modifiedBy);
								lpstpFinData.setLfdCreatedOn(modifiedOn);
								lpstpFinData.setLfdModifiedBy(modifiedBy);
								lpstpFinData.setLfdModifiedOn(modifiedOn);
								lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
 								if(!y1Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear6(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear6(null);
								}

								if(!y2Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear7(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear7(null);
								}
								if(!y3Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear8(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear8(null);
								}
								if(!y4Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear9(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear9(null);
								}
								if(!y5Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear10(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear10(null);
								}
								 serviceProvider.getFinancialMasterService().updateDataForDatafor6to10(lpstpFinData);
								// serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);

								 counterforIndex++;
							}
						}
						else
							if(counterMax==11){
								 length = counterMax+finRowIdArray.length;
								 counterforIndex=0;
								for(int i=counterMax;i<length;i++){
									lpstpFinData = new LpComFinData();
									lpstpFinData.setLfdRowId(0);
									lpstpFinData.setLfdPropNo((PropNum));
									lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
									lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
									lpstpFinData.setLfdCreatedBy(modifiedBy);
									lpstpFinData.setLfdCreatedOn(modifiedOn);
									lpstpFinData.setLfdModifiedBy(modifiedBy);
									lpstpFinData.setLfdModifiedOn(modifiedOn);
									lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
									if(!y1Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear11(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear11(null);
									}

									if(!y2Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear12(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear12(null);
									}
									if(!y3Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear13(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear13(null);
									}
									if(!y4Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear14(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear14(null);
									}
									if(!y5Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear15(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear15(null);
									}
									 serviceProvider.getFinancialMasterService().updateDataForDatafor11to15(lpstpFinData);
									// serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);

									 counterforIndex++;

								}
							}
							else
								if(counterMax==16){
									 length = counterMax+finRowIdArray.length;
									 counterforIndex=0;
									for(int i=counterMax;i<length;i++){
										lpstpFinData = new LpComFinData();
										lpstpFinData.setLfdRowId(0);
										lpstpFinData.setLfdPropNo((PropNum));
										lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
										lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
										lpstpFinData.setLfdCreatedBy(modifiedBy);
										lpstpFinData.setLfdCreatedOn(modifiedOn);
										lpstpFinData.setLfdModifiedBy(modifiedBy);
										lpstpFinData.setLfdModifiedOn(modifiedOn);
										lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
										if(!y1Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear16(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear16(null);
										}

										if(!y2Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear17(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear17(null);
										}
										if(!y3Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear18(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear18(null);
										}
										if(!y4Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear19(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear19(null);
										}
										if(!y5Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear20(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear20(null);
										}
										serviceProvider.getFinancialMasterService().updateDataForDatafor16to20(lpstpFinData);
										// serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);

										 counterforIndex++;

									}
								}
								else
									if(counterMax==21){
										 length = counterMax+finRowIdArray.length;
										 counterforIndex=0;
										for(int i=counterMax;i<length;i++){
											lpstpFinData = new LpComFinData();
											lpstpFinData.setLfdRowId(0);
											lpstpFinData.setLfdPropNo((PropNum));
											lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
											lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
											lpstpFinData.setLfdCreatedBy(modifiedBy);
											lpstpFinData.setLfdCreatedOn(modifiedOn);
											lpstpFinData.setLfdModifiedBy(modifiedBy);
											lpstpFinData.setLfdModifiedOn(modifiedOn);
											lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
											if(!y1Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear21(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear21(null);
											}

											if(!y2Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear22(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear22(null);
											}
											if(!y3Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear23(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear23(null);
											}
											if(!y4Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear24(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear24(null);
											}
											if(!y5Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear25(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear25(null);
											}
											 serviceProvider.getFinancialMasterService().updateDataForDatafor21to25(lpstpFinData);
											// serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);

											 counterforIndex++;

										}
									}
									else
										if(counterMax==26){
											 length = counterMax+finRowIdArray.length;
											 counterforIndex=0;
											for(int i=counterMax;i<length;i++){
												lpstpFinData = new LpComFinData();
												lpstpFinData.setLfdRowId(0);
												lpstpFinData.setLfdPropNo((PropNum));
												lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
												lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
												lpstpFinData.setLfdCreatedBy(modifiedBy);
												lpstpFinData.setLfdCreatedOn(modifiedOn);
												lpstpFinData.setLfdModifiedBy(modifiedBy);
												lpstpFinData.setLfdModifiedOn(modifiedOn);
												lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Double.parseDouble(finRowIdArray[counterforIndex].trim())));
												if(!y1Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear26(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear26(null);
												}

												if(!y2Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear27(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear27(null);
												}
												if(!y3Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear28(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear28(null);
												}
												if(!y4Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear29(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear29(null);
												}
												if(!y5Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear30(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear30(null);
												}
												 serviceProvider.getFinancialMasterService().updateDataForDatafor26to30(lpstpFinData);
												// serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);
												 counterforIndex++;

											}
										}
					if(! serviceProvider.getFinancialMasterService().saveFieldforDatabyFinPageType( PropNum, customerId,finTypeNo,"RA",modifiedBy,modifiedOn,serviceProvider)){
					 if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, "RATIO DOES NOT GOT SAVE ");
							dataHashMap.put("errorData",new CustomErr("RATIO DOESNOT GOT SAVE "));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
							
						}
					
				}
				}catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}}
				else if (dpMethod.equals("getFinMasterDataByPAGE_ID")) {
					try {
						//String[] finPage= (allRequestParams.get("requestData").toString().split(":"));3
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
						String finPage=hshMap.get("finPage").toString().trim();
						String finTabName=hshMap.get("finTabName").toString().trim();
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());

						responseHashMap.put("finmasterDataBypageId",serviceProvider.getSetFinMasterService().findByCategoryandTabNameandOrderByFinSno(finPage,finTabName,finTypeNo));
					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				else if (dpMethod.equals("getCounterMaxByPropersalNum")) {
					try {
						//long  propNum= Long.parseLong((allRequestParams.get("requestData").toString()));
						/*String[] dataArry= (allRequestParams.get("requestData").toString().split(":"));
						long  propNum= Long.parseLong(dataArry[0]);
						long customerId=Long.parseLong(dataArry[1]);	*/
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
						BigDecimal propNum=(BigDecimal) (hshMap.get("propNum"));
						long customerId=Long.valueOf(hshMap.get("customerId").toString());
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());
						
						responseHashMap.put("lpsDetailCounterMax", serviceProvider.getFinancialMasterService().maxOfSeqNumByPropNumForDetail(propNum,customerId,finTypeNo));

					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}else if (dpMethod.equals("getAllRowOfDetailandDataformDB")) {
					try {
						/*String[] dataArry= (allRequestParams.get("requestData").toString().split(":"));
						
						
						long  propNum= Long.parseLong(dataArry[0]);
						long customerId=Long.parseLong(dataArry[3]);*/	
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
 						BigDecimal propNum=new BigDecimal(hshMap.get("propNum").toString().trim());
						long customerId=Long.valueOf(hshMap.get("customerId").toString().trim());
						String finTabName=hshMap.get("finTabName").toString().trim();
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());
						String finPage =hshMap.get("finPage").toString().trim();
						List<LpstpFinMaster> listOfFinMasterRowId = serviceProvider.getSetFinMasterService().findByCategoryandTabNameandOrderByFinSno(finPage,finTabName,finTypeNo);
						
						List<BigDecimal> rowIdOFFinMaster= new ArrayList<BigDecimal>();
						for (LpstpFinMaster obj : listOfFinMasterRowId) {
							rowIdOFFinMaster.add(BigDecimal.valueOf(obj.getFinRowid()));
						}
						listOfLpstpFinDetail = 	 serviceProvider.getFinancialMasterService().getRowByPropNumorderBySeqnumForDetail(propNum,customerId,finTypeNo);
						
						if(listOfLpstpFinDetail!=null && !listOfLpstpFinDetail.isEmpty()){
							List<BigDecimal> obj=serviceProvider.getFinancialMasterService().getFinRowIdByPropNumforData(propNum,customerId,finTypeNo);
							listOfFinRowId = obj.stream().map(BigDecimal::longValue).collect(Collectors.toList());

							listOfLpstpFinData = serviceProvider.getFinancialMasterService().getAllRowByPropNumandFinMasterTabNameforData(propNum,finPage, finTabName,customerId,finTypeNo);
							if(!listOfLpstpFinData.isEmpty()){
								List<LpComFinDetail> listOfLpstpFinDetail2= new ArrayList<LpComFinDetail>();

								if(!(listOfLpstpFinDetail.size()%5==0)){
									for (int i = 0; i < 5-(listOfLpstpFinDetail.size()%5); i++) {
										lpstpFinDetail=new LpComFinDetail();
										lpstpFinDetail.setLfdRowId(0);
										lpstpFinDetail.setLfdPropNo(listOfLpstpFinDetail.get(listOfLpstpFinDetail.size()-1).getLfdPropNo());
										lpstpFinDetail.setLfdCustNewId(listOfLpstpFinDetail.get(listOfLpstpFinDetail.size()-1).getLfdCustNewId());
										lpstpFinDetail.setLfdCmaNo(listOfLpstpFinDetail.get(listOfLpstpFinDetail.size()-1).getLfdCmaNo());
										lpstpFinDetail.setLfdYearSeqNo(listOfLpstpFinDetail.get(listOfLpstpFinDetail.size()-1).getLfdCmaNo().add(new BigDecimal((i+1))));
										lpstpFinDetail.setLfdStartDate(null);
										lpstpFinDetail.setLfdEndDate(null);
										lpstpFinDetail.setLfdPrintReq("Y");
										lpstpFinDetail.setLfdCreatedBy(null);
										lpstpFinDetail.setLfdCreatedOn(null);
										lpstpFinDetail.setLfdModifiedBy(null);
										lpstpFinDetail.setLfdModifiedOn(null);
										lpstpFinDetail.setLfdAuditType("");
										listOfLpstpFinDetail2.add(lpstpFinDetail);
									}
									listOfLpstpFinDetail.addAll(listOfLpstpFinDetail2);
								}
								//listOfLpstpFinData = serviceProvider.getFinancialMasterService().getAllRowByPropNumforData(propNum);
								listOfFinMasterRowId=serviceProvider.getSetFinMasterService().getAlldataByListOfRowId(rowIdOFFinMaster.stream().map(BigDecimal::longValue).collect(Collectors.toList()));
								responseHashMap.put("finmasterDataBypageId",listOfFinMasterRowId);
								responseHashMap.put("allRowOfDetail",listOfLpstpFinDetail);
								responseHashMap.put("allRowOfData",listOfLpstpFinData);
								responseHashMap.put("listOfCustomerAndFinType",serviceProvider.getFinancialMasterService().getDistinctCusrtomerIDandCMANo(propNum));
								responseHashMap.put("propDenom",session.getAttribute("propDenom").toString());
							}else{
								responseHashMap.put("finmasterDataBypageId", new ArrayList<LpstpFinMaster>());
								responseHashMap.put("allRowOfDetail", new ArrayList<LpComFinDetail>());
								responseHashMap.put("allRowOfData", new ArrayList<LpComFinData>());
								responseHashMap.put("listOfCustomerAndFinType",serviceProvider.getFinancialMasterService().getDistinctCusrtomerIDandCMANo(propNum));
								responseHashMap.put("propDenom",session.getAttribute("propDenom").toString());
							}
							
							
						}else{
							responseHashMap.put("finmasterDataBypageId", new ArrayList<LpstpFinMaster>());
							responseHashMap.put("allRowOfDetail", new ArrayList<LpComFinDetail>());
							responseHashMap.put("allRowOfData", new ArrayList<LpComFinData>());
							responseHashMap.put("listOfCustomerAndFinType",serviceProvider.getFinancialMasterService().getDistinctCusrtomerIDandCMANo(propNum));
							responseHashMap.put("propDenom",session.getAttribute("propDenom").toString());
						}


					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);	
						}
					}
				}else if (dpMethod.equals("updateData")) {
					try {
						@SuppressWarnings("unchecked")
						Map<String, Object> temphshMap=(Map<String, Object>) allRequestParams.get("requestData");
						
				//		String[] lfdRowIdArray = temphshMap.get("lpstpDetailRowId").toString().trim().split("^");
					//	DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
				       // SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");

						
						String[] finRowIdArray = temphshMap.get("finRowId").toString().trim().split("\\^");
						String[] startDateArray = temphshMap.get("startDate").toString().trim().split("\\^");
						String[] endDateArray = temphshMap.get("endDate").toString().trim().split("\\^");
						String[] auditType = temphshMap.get("auditType").toString().trim().split("\\^");
						String[] detailRowId = temphshMap.get("hidDetailRowId").toString().trim().split("\\^");
						String hidDataRowIdString = temphshMap.get("hidDataRowId").toString().trim();
						long finTypeNo=Long.valueOf(temphshMap.get("finTypeNo").toString());
						String[] hidDataRowId=null;
						if(!hidDataRowIdString.equalsIgnoreCase("")){
						hidDataRowId=hidDataRowIdString.split("\\^");
						}
						String[] detailSeqNum = temphshMap.get("hidDetailSeqNum").toString().trim().split("\\^");
						String modifiedBy=temphshMap.get("modifiedBy").toString().trim();
						//Date modifiedOn=Helper.convertStringToDate(temphshMap.get("modifiedOn").toString().trim());
						Date modifiedOn= new Date();
						int counterMax=Integer.parseInt(temphshMap.get("currentMaxCount").toString());
						BigDecimal PropNum=(BigDecimal) (temphshMap.get("PropNum"));
						long	customerId=Long.parseLong(temphshMap.get("customerId").toString());
						String[] y1Array = temphshMap.get("y1").toString().trim().split("\\^");
						String[] y2Array = temphshMap.get("y2").toString().trim().split("\\^");
						String[] y3Array = temphshMap.get("y3").toString().trim().split("\\^");
						String[] y4Array = temphshMap.get("y4").toString().trim().split("\\^");
						String[] y5Array = temphshMap.get("y5").toString().trim().split("\\^");
						int  length = counterMax+startDateArray.length;
						int counterforIndex =0;
						 if(finRowIdArray.length==0 ||detailRowId.length==0){
							 length=0;
							 counterMax=99;
						 }
						 propDenom = session.getAttribute("propDenom").toString();
						for(int i=counterMax;i<length;i++){
							
							lpstpFinDetail = new LpComFinDetail();
							lpstpFinDetail.setLfdRowId(Long.parseLong(detailRowId[counterforIndex]));
							lpstpFinDetail.setLfdPropNo((PropNum));
							lpstpFinDetail.setLfdCustNewId((BigDecimal.valueOf(customerId)));
							lpstpFinDetail.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
							lpstpFinDetail.setLfdYearSeqNo(BigDecimal.valueOf(Long.parseLong(detailSeqNum[counterforIndex] )));
							if(!startDateArray[counterforIndex].trim().equalsIgnoreCase("*")){
								lpstpFinDetail.setLfdStartDate(Helper.convertStringToDate(startDateArray[counterforIndex].trim().replaceAll("-", "/")));
								lpstpFinDetail.setLfdEndDate(Helper.convertStringToDate(endDateArray[counterforIndex].trim().replaceAll("-", "/")));
								lpstpFinDetail.setLfdAuditType(auditType[counterforIndex]);
								}else{
									lpstpFinDetail.setLfdStartDate(null);
									lpstpFinDetail.setLfdEndDate(null);
									lpstpFinDetail.setLfdAuditType(null);

								}

							
							lpstpFinDetail.setLfdPrintReq("Y");
							lpstpFinDetail.setLfdCreatedBy(null);
							lpstpFinDetail.setLfdCreatedOn(null);
							lpstpFinDetail.setLfdModifiedBy(modifiedBy);
							lpstpFinDetail.setLfdModifiedOn(modifiedOn);
							serviceProvider.getFinancialMasterService().saveDataForDetail(lpstpFinDetail);
							 counterforIndex++;
						}
						length=0;
						counterforIndex=0;
						if(hidDataRowId!=null && hidDataRowId.length>0){
						if(counterMax==1){
							 counterforIndex=0;
							 counterMax=0;
							 length = counterMax+finRowIdArray.length;
							for(int i=counterMax;i<length;i++){
								lpstpFinData = new LpComFinData();
								lpstpFinData.setLfdRowId(Long.parseLong(hidDataRowId[counterforIndex]));
								lpstpFinData.setLfdPropNo((PropNum));
								//lpstpFinData.setLfdCreatedBy(null);
								//lpstpFinData.setLfdCreatedOn(null);
								lpstpFinData.setLfdModifiedBy(modifiedBy);
								lpstpFinData.setLfdModifiedOn(modifiedOn);
								lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
								if(!y1Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear1(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear1(null);
								}

								if(!y2Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear2(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear2(null);
								}
								if(!y3Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear3(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear3(null);
								}
								if(!y4Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear4(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear4(null);
								}
								if(!y5Array[counterforIndex].trim().contains("*")){
									lpstpFinData.setLfdYear5(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
								}else{
									lpstpFinData.setLfdYear5(null);
								}
							
								 serviceProvider.getFinancialMasterService().updateDataForDatafor1to5ByDataRowId(lpstpFinData);
								 counterforIndex++;

							}
						}
						else
							if(counterMax==6){
								 length = counterMax+finRowIdArray.length;
								 counterforIndex=0;
								for(int i=counterMax;i<length;i++){
									lpstpFinData = new LpComFinData();
									lpstpFinData.setLfdRowId(Long.parseLong(hidDataRowId[counterforIndex]));
									lpstpFinData.setLfdPropNo((PropNum));
									//lpstpFinData.setLfdCreatedBy(null);
									//lpstpFinData.setLfdCreatedOn(null);
									lpstpFinData.setLfdModifiedBy(modifiedBy);
									lpstpFinData.setLfdModifiedOn(modifiedOn);
									lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
	 								if(!y1Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear6(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear6(null);
									}

									if(!y2Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear7(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear7(null);
									}
									if(!y3Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear8(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear8(null);
									}
									if(!y4Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear9(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear9(null);
									}
									if(!y5Array[counterforIndex].trim().contains("*")){
										lpstpFinData.setLfdYear10(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
									}else{
										lpstpFinData.setLfdYear10(null);
									}
									 serviceProvider.getFinancialMasterService().updateDataForDatafor6to10ByDataRowId(lpstpFinData);
									 counterforIndex++;
								}
							}
							else
								if(counterMax==11){
									 length = counterMax+finRowIdArray.length;
									 counterforIndex=0;
									for(int i=counterMax;i<length;i++){
										lpstpFinData = new LpComFinData();
										lpstpFinData.setLfdRowId(Long.parseLong(hidDataRowId[counterforIndex]));	
										lpstpFinData.setLfdPropNo((PropNum));
										//lpstpFinData.setLfdCreatedBy(null);
										//lpstpFinData.setLfdCreatedOn(null);
										lpstpFinData.setLfdModifiedBy(modifiedBy);
										lpstpFinData.setLfdModifiedOn(modifiedOn);
										lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
										if(!y1Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear11(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear11(null);
										}

										if(!y2Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear12(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear12(null);
										}
										if(!y3Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear13(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear13(null);
										}
										if(!y4Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear14(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear14(null);
										}
										if(!y5Array[counterforIndex].trim().contains("*")){
											lpstpFinData.setLfdYear15(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
										}else{
											lpstpFinData.setLfdYear15(null);
										}
										 serviceProvider.getFinancialMasterService().updateDataForDatafor11to15ByDataRowId(lpstpFinData);
										 
										 counterforIndex++;

									}
								}
								else
									if(counterMax==16){
										 length = counterMax+finRowIdArray.length;
										 counterforIndex=0;
										for(int i=counterMax;i<length;i++){
											lpstpFinData = new LpComFinData();
											lpstpFinData.setLfdRowId(Long.parseLong(hidDataRowId[counterforIndex]));	
											lpstpFinData.setLfdPropNo((PropNum));
											//lpstpFinData.setLfdCreatedBy(null);
											//lpstpFinData.setLfdCreatedOn(null);
											lpstpFinData.setLfdModifiedBy(modifiedBy);
											lpstpFinData.setLfdModifiedOn(modifiedOn);
											lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
											if(!y1Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear16(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear16(null);
											}

											if(!y2Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear17(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear17(null);
											}
											if(!y3Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear18(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear18(null);
											}
											if(!y4Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear19(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear19(null);
											}
											if(!y5Array[counterforIndex].trim().contains("*")){
												lpstpFinData.setLfdYear20(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
											}else{
												lpstpFinData.setLfdYear20(null);
											}
											 serviceProvider.getFinancialMasterService().updateDataForDatafor16to20ByDataRowId(lpstpFinData);
											 counterforIndex++;

										}
									}
									else
										if(counterMax==21){
											 length = counterMax+finRowIdArray.length;
											 counterforIndex=0;
											for(int i=counterMax;i<length;i++){
												lpstpFinData = new LpComFinData();
												lpstpFinData.setLfdRowId(Long.parseLong(hidDataRowId[counterforIndex]));
												lpstpFinData.setLfdPropNo((PropNum));
												//lpstpFinData.setLfdCreatedBy(null);
												//lpstpFinData.setLfdCreatedOn(null);
												lpstpFinData.setLfdModifiedBy(modifiedBy);
												lpstpFinData.setLfdModifiedOn(modifiedOn);
												lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
												if(!y1Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear21(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear21(null);
												}

												if(!y2Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear22(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear22(null);
												}
												if(!y3Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear23(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear23(null);
												}
												if(!y4Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear24(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear24(null);
												}
												if(!y5Array[counterforIndex].trim().contains("*")){
													lpstpFinData.setLfdYear25(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
												}else{
													lpstpFinData.setLfdYear25(null);
												}
												 serviceProvider.getFinancialMasterService().updateDataForDatafor21to25ByDataRowId(lpstpFinData);
												 counterforIndex++;

											}
										}
										else
											if(counterMax==26){
												 length = counterMax+finRowIdArray.length;
												 counterforIndex=0;
												for(int i=counterMax;i<length;i++){
													lpstpFinData = new LpComFinData();
													lpstpFinData.setLfdRowId(Long.parseLong(hidDataRowId[counterforIndex]));	
													lpstpFinData.setLfdPropNo((PropNum));
													//lpstpFinData.setLfdCreatedBy(null);
													//lpstpFinData.setLfdCreatedOn(null);
													lpstpFinData.setLfdModifiedBy(modifiedBy);
													lpstpFinData.setLfdModifiedOn(modifiedOn);
													lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
													if(!y1Array[counterforIndex].trim().contains("*")){
														lpstpFinData.setLfdYear26(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
													}else{
														lpstpFinData.setLfdYear26(null);
													}

													if(!y2Array[counterforIndex].trim().contains("*")){
														lpstpFinData.setLfdYear27(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
													}else{
														lpstpFinData.setLfdYear27(null);
													}
													if(!y3Array[counterforIndex].trim().contains("*")){
														lpstpFinData.setLfdYear28(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
													}else{
														lpstpFinData.setLfdYear28(null);
													}
													if(!y4Array[counterforIndex].trim().contains("*")){
														lpstpFinData.setLfdYear29(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
													}else{
														lpstpFinData.setLfdYear29(null);
													}
													if(!y5Array[counterforIndex].trim().contains("*")){
														lpstpFinData.setLfdYear30(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
													}else{
														lpstpFinData.setLfdYear30(null);
													}
													 serviceProvider.getFinancialMasterService().updateDataForDatafor26to30ByDataRowId(lpstpFinData);
													 counterforIndex++;

													}
												}
											}else{
												length=0;
												counterforIndex=0;
												if(counterMax==1){
													 counterforIndex=0;
													 counterMax=0;
													 length = counterMax+finRowIdArray.length;
													 counterforIndex=0;
													for(int i=counterMax;i<length;i++){
														lpstpFinData = new LpComFinData();
														lpstpFinData.setLfdRowId(0);
														lpstpFinData.setLfdPropNo((PropNum));
														lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
														lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
														lpstpFinData.setLfdCreatedBy(modifiedBy);
														lpstpFinData.setLfdCreatedOn(modifiedOn);
														lpstpFinData.setLfdModifiedBy(null);
														lpstpFinData.setLfdModifiedOn(null);
														lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
														if(!y1Array[counterforIndex].trim().contains("*")){
															lpstpFinData.setLfdYear1(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
														}else{
															lpstpFinData.setLfdYear1(null);
														}

														if(!y2Array[counterforIndex].trim().contains("*")){
															lpstpFinData.setLfdYear2(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
														}else{
															lpstpFinData.setLfdYear2(null);
														}
														if(!y3Array[counterforIndex].trim().contains("*")){
															lpstpFinData.setLfdYear3(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
														}else{
															lpstpFinData.setLfdYear3(null);
														}
														if(!y4Array[counterforIndex].trim().contains("*")){
															lpstpFinData.setLfdYear4(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
														}else{
															lpstpFinData.setLfdYear4(null);
														}
														if(!y5Array[counterforIndex].trim().contains("*")){
															lpstpFinData.setLfdYear5(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
														}else{
															lpstpFinData.setLfdYear5(null);
														}
													
														 serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);
														 counterforIndex++;

													}
												}
												else
													if(counterMax==6){
														 length = counterMax+finRowIdArray.length;
														 counterforIndex=0;
														for(int i=counterMax;i<length;i++){
															lpstpFinData = new LpComFinData();
															lpstpFinData.setLfdRowId(0);
															lpstpFinData.setLfdPropNo((PropNum));
															lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
															lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
															lpstpFinData.setLfdCreatedBy(modifiedBy);
															lpstpFinData.setLfdCreatedOn(modifiedOn);
															lpstpFinData.setLfdModifiedBy(null);
															lpstpFinData.setLfdModifiedOn(null);
															lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
							 								if(!y1Array[counterforIndex].trim().contains("*")){
																lpstpFinData.setLfdYear6(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
															}else{
																lpstpFinData.setLfdYear6(null);
															}

															if(!y2Array[counterforIndex].trim().contains("*")){
																lpstpFinData.setLfdYear7(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
															}else{
																lpstpFinData.setLfdYear7(null);
															}
															if(!y3Array[counterforIndex].trim().contains("*")){
																lpstpFinData.setLfdYear8(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
															}else{
																lpstpFinData.setLfdYear8(null);
															}
															if(!y4Array[counterforIndex].trim().contains("*")){
																lpstpFinData.setLfdYear9(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
															}else{
																lpstpFinData.setLfdYear9(null);
															}
															if(!y5Array[counterforIndex].trim().contains("*")){
																lpstpFinData.setLfdYear10(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
															}else{
																lpstpFinData.setLfdYear10(null);
															}
															// serviceProvider.getFinancialMasterService().updateDataForDatafor6to10(lpstpFinData);
															 serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);

															 counterforIndex++;
														}
													}
													else
														if(counterMax==11){
															 length = counterMax+finRowIdArray.length;
															 counterforIndex=0;
															for(int i=counterMax;i<length;i++){
																lpstpFinData = new LpComFinData();
																lpstpFinData.setLfdRowId(0);
																lpstpFinData.setLfdPropNo((PropNum));
																lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
																lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
																lpstpFinData.setLfdCreatedBy(modifiedBy);
																lpstpFinData.setLfdCreatedOn(modifiedOn);
																lpstpFinData.setLfdModifiedBy(null);
																lpstpFinData.setLfdModifiedOn(null);
																lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
																if(!y1Array[counterforIndex].trim().contains("*")){
																	lpstpFinData.setLfdYear11(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
																}else{
																	lpstpFinData.setLfdYear11(null);
																}

																if(!y2Array[counterforIndex].trim().contains("*")){
																	lpstpFinData.setLfdYear12(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
																}else{
																	lpstpFinData.setLfdYear12(null);
																}
																if(!y3Array[counterforIndex].trim().contains("*")){
																	lpstpFinData.setLfdYear13(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
																}else{
																	lpstpFinData.setLfdYear13(null);
																}
																if(!y4Array[counterforIndex].trim().contains("*")){
																	lpstpFinData.setLfdYear14(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
																}else{
																	lpstpFinData.setLfdYear14(null);
																}
																if(!y5Array[counterforIndex].trim().contains("*")){
																	lpstpFinData.setLfdYear15(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
																}else{
																	lpstpFinData.setLfdYear15(null);
																}
																// serviceProvider.getFinancialMasterService().updateDataForDatafor11to15(lpstpFinData);
																 serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);

																 counterforIndex++;

															}
														}
														else
															if(counterMax==16){
																 length = counterMax+finRowIdArray.length;
																 counterforIndex=0;
																for(int i=counterMax;i<length;i++){
																	lpstpFinData = new LpComFinData();
																	lpstpFinData.setLfdRowId(0);
																	lpstpFinData.setLfdPropNo((PropNum));
																	lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
																	lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
																	lpstpFinData.setLfdCreatedBy(modifiedBy);
																	lpstpFinData.setLfdCreatedOn(modifiedOn);
																	lpstpFinData.setLfdModifiedBy(null);
																	lpstpFinData.setLfdModifiedOn(null);
																	lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
																	if(!y1Array[counterforIndex].trim().contains("*")){
																		lpstpFinData.setLfdYear16(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
																	}else{
																		lpstpFinData.setLfdYear16(null);
																	}

																	if(!y2Array[counterforIndex].trim().contains("*")){
																		lpstpFinData.setLfdYear17(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
																	}else{
																		lpstpFinData.setLfdYear17(null);
																	}
																	if(!y3Array[counterforIndex].trim().contains("*")){
																		lpstpFinData.setLfdYear18(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
																	}else{
																		lpstpFinData.setLfdYear18(null);
																	}
																	if(!y4Array[counterforIndex].trim().contains("*")){
																		lpstpFinData.setLfdYear19(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
																	}else{
																		lpstpFinData.setLfdYear19(null);
																	}
																	if(!y5Array[counterforIndex].trim().contains("*")){
																		lpstpFinData.setLfdYear20(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
																	}else{
																		lpstpFinData.setLfdYear20(null);
																	}
																	// serviceProvider.getFinancialMasterService().updateDataForDatafor16to20(lpstpFinData);
																	 serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);

																	 counterforIndex++;

																}
															}
															else
																if(counterMax==21){
																	 length = counterMax+finRowIdArray.length;
																	 counterforIndex=0;
																	for(int i=counterMax;i<length;i++){
																		lpstpFinData = new LpComFinData();
																		lpstpFinData.setLfdRowId(0);
																		lpstpFinData.setLfdPropNo((PropNum));
																		lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
																		lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
																		lpstpFinData.setLfdCreatedBy(modifiedBy);
																		lpstpFinData.setLfdCreatedOn(modifiedOn);
																		lpstpFinData.setLfdModifiedBy(null);
																		lpstpFinData.setLfdModifiedOn(null);
																		lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Long.parseLong(finRowIdArray[counterforIndex].trim())));
																		if(!y1Array[counterforIndex].trim().contains("*")){
																			lpstpFinData.setLfdYear21(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
																		}else{
																			lpstpFinData.setLfdYear21(null);
																		}

																		if(!y2Array[counterforIndex].trim().contains("*")){
																			lpstpFinData.setLfdYear22(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
																		}else{
																			lpstpFinData.setLfdYear22(null);
																		}
																		if(!y3Array[counterforIndex].trim().contains("*")){
																			lpstpFinData.setLfdYear23(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
																		}else{
																			lpstpFinData.setLfdYear23(null);
																		}
																		if(!y4Array[counterforIndex].trim().contains("*")){
																			lpstpFinData.setLfdYear24(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
																		}else{
																			lpstpFinData.setLfdYear24(null);
																		}
																		if(!y5Array[counterforIndex].trim().contains("*")){
																			lpstpFinData.setLfdYear25(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
																		}else{
																			lpstpFinData.setLfdYear25(null);
																		}
																		// serviceProvider.getFinancialMasterService().updateDataForDatafor21to25(lpstpFinData);
																		 serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);

																		 counterforIndex++;

																	}
																}
																else
																	if(counterMax==26){
																		 length = counterMax+finRowIdArray.length;
																		 counterforIndex=0;
																		for(int i=counterMax;i<length;i++){
																			lpstpFinData = new LpComFinData();
																			lpstpFinData.setLfdRowId(0);
																			lpstpFinData.setLfdPropNo((PropNum));
																			lpstpFinData.setLfdCustNewId((BigDecimal.valueOf(customerId)));
																			lpstpFinData.setLfdCmaNo((BigDecimal.valueOf(finTypeNo)));
																			lpstpFinData.setLfdCreatedBy(modifiedBy);
																			lpstpFinData.setLfdCreatedOn(modifiedOn);
																			lpstpFinData.setLfdModifiedBy(null);
																			lpstpFinData.setLfdModifiedOn(null);
																			lpstpFinData.setLfdFinRowId(BigDecimal.valueOf(Double.parseDouble(finRowIdArray[counterforIndex].trim())));
																			if(!y1Array[counterforIndex].trim().contains("*")){
																				lpstpFinData.setLfdYear26(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y1Array[counterforIndex].trim()))));
																			}else{
																				lpstpFinData.setLfdYear26(null);
																			}

																			if(!y2Array[counterforIndex].trim().contains("*")){
																				lpstpFinData.setLfdYear27(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y2Array[counterforIndex].trim()))));
																			}else{
																				lpstpFinData.setLfdYear27(null);
																			}
																			if(!y3Array[counterforIndex].trim().contains("*")){
																				lpstpFinData.setLfdYear28(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y3Array[counterforIndex].trim()))));
																			}else{
																				lpstpFinData.setLfdYear28(null);
																			}
																			if(!y4Array[counterforIndex].trim().contains("*")){
																				lpstpFinData.setLfdYear29(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y4Array[counterforIndex].trim()))));
																			}else{
																				lpstpFinData.setLfdYear29(null);
																			}
																			if(!y5Array[counterforIndex].trim().contains("*")){
																				lpstpFinData.setLfdYear30(Helper.UnitsToActuals(propDenom,BigDecimal.valueOf(Double.parseDouble(y5Array[counterforIndex].trim()))));
																			}else{
																				lpstpFinData.setLfdYear30(null);
																			}
																			 //serviceProvider.getFinancialMasterService().updateDataForDatafor26to30(lpstpFinData);
																			 serviceProvider.getFinancialMasterService().saveDataForData(lpstpFinData);
																			 counterforIndex++;

																		}
																	}
												if(! serviceProvider.getFinancialMasterService().saveFieldforDatabyFinPageType( PropNum, customerId,finTypeNo,"RA",modifiedBy,modifiedOn,serviceProvider)){
													 if (!dataHashMap.containsKey("errorData")) {
															logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, "RATIO DOESNOT GOT SAVE ");
															dataHashMap.put("errorData",new CustomErr("RATIO DOESNOT GOT SAVE "));
															responseHashMap.put("success", false);
															responseHashMap.put("responseData", dataHashMap);
															
														}
													 }
											}
					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				else if (dpMethod.equals("getDistinctTabOrderByName")) {
					try {
					//	String[] dataArry= (allRequestParams.get("requestData").toString().split(":"));
						//long  propNum= Long.parseLong(dataArry[0]);
						//long customerId=Long.parseLong(dataArry[3]);	
					//	String finTabName=dataArry[1];
						hshMap=(HashMap)allRequestParams.get("requestData");
						String finTabName=hshMap.get("finPage").toString();
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());
						responseHashMap.put("distinctTabOrderByName", serviceProvider.getSetFinMasterService().getDistinctTabNameOrderByTabName(finTabName,finTypeNo));

					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				else if (dpMethod.equals("getDateAndAduitTypeforSelectededTab")) {
					try {
						//long  propNum= Long.parseLong((allRequestParams.get("requestData").toString()));
						/*String[] dataArry= (allRequestParams.get("requestData").toString().split(":"));
						long  propNum= Long.parseLong(dataArry[0]);
						long customerId=Long.parseLong(dataArry[1]);*/
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
						BigDecimal propNum=new BigDecimal(hshMap.get("propNum").toString().trim());
						long customerId=Long.valueOf(hshMap.get("customerId").toString().trim());
					//	String finTabName=hshMap.get("finTabName").toString().trim();
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());
						listOfLpstpFinDetail = 	 serviceProvider.getFinancialMasterService().getRowByPropNumorderBySeqnumForDetail(propNum,customerId,finTypeNo);
						List<LpComFinDetail> listOfLpstpFinDetail2= new ArrayList<LpComFinDetail>();
						if(!(listOfLpstpFinDetail.size()%5==0)){
						for (int i = 0; i < 5-(listOfLpstpFinDetail.size()%5); i++) {
						lpstpFinDetail=new LpComFinDetail();
						lpstpFinDetail.setLfdRowId(0);
						lpstpFinDetail.setLfdPropNo(listOfLpstpFinDetail.get(listOfLpstpFinDetail.size()-1).getLfdPropNo());
						lpstpFinDetail.setLfdCustNewId(listOfLpstpFinDetail.get(listOfLpstpFinDetail.size()-1).getLfdCustNewId());
						lpstpFinDetail.setLfdCmaNo(listOfLpstpFinDetail.get(listOfLpstpFinDetail.size()-1).getLfdCmaNo());
						lpstpFinDetail.setLfdYearSeqNo(listOfLpstpFinDetail.get(listOfLpstpFinDetail.size()-1).getLfdCmaNo().add(new BigDecimal((i+1))));
						lpstpFinDetail.setLfdStartDate(null);
						lpstpFinDetail.setLfdEndDate(null);
						lpstpFinDetail.setLfdPrintReq("Y");
						lpstpFinDetail.setLfdCreatedBy(null);
						lpstpFinDetail.setLfdCreatedOn(null);
						lpstpFinDetail.setLfdModifiedBy(null);
						lpstpFinDetail.setLfdModifiedOn(null);
						lpstpFinDetail.setLfdAuditType("");
						listOfLpstpFinDetail2.add(lpstpFinDetail);
						}
						listOfLpstpFinDetail.addAll(listOfLpstpFinDetail2);
						}
						if(listOfLpstpFinDetail!=null && !listOfLpstpFinDetail.isEmpty()){
							responseHashMap.put("allRowOfData", listOfLpstpFinDetail);
							responseHashMap.put("listOfCustomerAndFinType",serviceProvider.getFinancialMasterService().getDistinctCusrtomerIDandCMANo(propNum));
							responseHashMap.put("propDenom",session.getAttribute("propDenom").toString());
						}else{
							responseHashMap.put("allRowOfData", new ArrayList<LpComFinData>());
							responseHashMap.put("listOfCustomerAndFinType",serviceProvider.getFinancialMasterService().getDistinctCusrtomerIDandCMANo(propNum));
							responseHashMap.put("propDenom",session.getAttribute("propDenom").toString());
						}
					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				else if (dpMethod.equals("updateCalculatedField")) {
					try {
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
					//	List<Integer>  lpstpFinRowIDTypeC= (ArrayList<Integer>) hshMap.get("arrayOfDataFinId");
						BigDecimal propNum= (BigDecimal) (hshMap.get("propNum"));
						long customerId= Long.parseLong(hshMap.get("customerId").toString());
						String finTabName= hshMap.get("finTabName").toString();
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());

						List<BigDecimal>listOfDataFinRowId=  serviceProvider.getFinancialMasterService().getFinRowIdByPropNumAndRowTypeforData(propNum,customerId,finTypeNo,"C", finTabName)  ;
						/* for (Integer iterator : lpstpFinRowIDTypeC) {
							 listOfDataFinRowId.add(BigDecimal.valueOf(Long.valueOf(iterator)));
						}*/
						String[] formulaArray= null;
						Long[] dataRowIdArray= null;
						String modifierUserName=hshMap.get("userId").toString();
						List<Object[]>objList=  serviceProvider.getFinancialMasterService().
								getDataRowIdandFormulaValueByListOfDataFinRowId(propNum,customerId,finTypeNo ,listOfDataFinRowId);
						formulaArray= new String[objList.size()];
						dataRowIdArray= new Long[objList.size()];
						int counter=0;
						for (Object[] object  : objList) {
							dataRowIdArray[counter]=Long.valueOf(object[0].toString());
							formulaArray[counter]=(String) object[1];
							counter++;
						}
						responseHashMap.put("successMessage", "Field  updatation got Field , Kindly ReLoad the Page");
						if(serviceProvider.getFinancialMasterService().updateFormulaData(modifierUserName,dataRowIdArray,formulaArray,propNum,customerId,finTypeNo,serviceProvider, logging,session)){
						
							responseHashMap.put("successMessage", "Field Got Update ReLoad the Page");
						}else{

							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, "CHANGE DOESNOT TAKE PALCE");
								dataHashMap.put("errorData",new CustomErr( "Field  updatation got Field , Kindly ReLoad the Page"));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
							
						}
						
						
					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				else if (dpMethod.equals("getNonIndivialCustomerListByPropNum")) {
					try {
			
						BigDecimal propNum= new BigDecimal(allRequestParams.get("requestData").toString());
						 LpcomProposal propNumObject = serviceProvider.getLpcomProposalService().findByLpPropNo(propNum);
						 if(propNumObject !=null){
								responseHashMap.put("nonIndivialCustomerListByPropNum", serviceProvider.getLpcomCustInfoService().fetchRowbyPropNoandCusTypeMappingInPropParties("N", propNumObject));
						 }else{
							 responseHashMap.put("nonIndivialCustomerListByPropNum", new ArrayList<LpcomCustInfo>());
						 }
						 
						//List<Map<String,Object>> LpagriLandDetailMapList=new ArrayList<Map<String,Object>>();
						//LpagriLandDetailMapList=serviceProvider.getLpagriLandDetailService().getCustomerNameAndId(BigDecimal.valueOf(propNum));
						
/*						responseHashMap.put("nonIndivialCustomerListByPropNum", serviceProvider.getLpcomCustDataNindService().fetchRowbyPropNoandCusTypeMappingInPropParties("N", propNum));
*/						
 					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				else if(dpMethod.equals("getDifference")){
					try{
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
						BigDecimal propNumberValue= new BigDecimal(hshMap.get("propNum").toString());
						long customerId= Long.parseLong(hshMap.get("customerId").toString());
						String finTabName= hshMap.get("finTabName").toString();
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());

					//	BigDecimal propNumberValue =new BigDecimal(session.getAttribute("LP_COM_PROP_NO").toString());
					List<LpComFinData> differenceList=serviceProvider.getFinancialMasterService().getFinancialYear("FI",finTabName,(propNumberValue),new BigDecimal(customerId));
					List<LpComFinDetail> auditedFields=serviceProvider.getFinancialMasterService().getRowByPropNumorderBySeqnumForDetail(propNumberValue, customerId,finTypeNo);
					List<LpstpFinMaster> lineitems=serviceProvider.getSetFinMasterService().findByCategoryandTabNameandOrderByFinSno("FI",finTabName,finTypeNo);
					responseHashMap.put("success", true);
					responseHashMap.put("auditedFields", auditedFields);
					responseHashMap.put("lineitems", lineitems);
					responseHashMap.put("differenceList", differenceList);
					}catch (Exception e) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
							dataHashMap.put("errorData",new CustomErr(e.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
					}
					}
					
				}
				else if (dpMethod.equals("getGolbalFinancialMaster")) {
					try {
			
					//	long propNum= Long.parseLong(allRequestParams.get("requestData").toString());
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
						BigDecimal propNum=new BigDecimal(hshMap.get("propNum").toString().trim());
						//long customerId=Long.valueOf(hshMap.get("customerId").toString().trim());
					//	String finTabName=hshMap.get("finTabName").toString().trim();
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());
/*						listOfLpcomCustDataNind= serviceProvider.getLpcomCustDataNindService().fetchRowbyPropNoandCusTypeMappingInPropParties("N", propNum);
*/						 LpcomProposal propNumObject = serviceProvider.getLpcomProposalService().findByLpPropNo(propNum);
if(propNumObject !=null){
	listOfLpcomCustInfo= serviceProvider.getLpcomCustInfoService().fetchRowbyPropNoandCusTypeMappingInPropParties("N", propNumObject);
}else{
	listOfLpcomCustInfo=  new ArrayList<LpcomCustInfo>();
}
						List<List<LpComFinData>> listOfParentOfLpstpFinData= new ArrayList<List<LpComFinData>>();
						if(!listOfLpcomCustInfo.isEmpty()){
							
							//listOfLpcomCustDataNind
							listOfBigDecimal= new ArrayList<BigDecimal>();
							for (LpcomCustInfo obj : listOfLpcomCustInfo) {
  								listOfBigDecimal.add(obj.getLciCustId());
							} 
					/*		Long[] arry = {(long) 2200,(long) 2201,(long) 2202,(long) 2204,( long) 2205};
							for (Long arryObj:arry){
								listOfBigDecimal.add(BigDecimal.valueOf(arryObj));
							}
							*/
							listOfLpstpFinDetail = new ArrayList<LpComFinDetail>();
							for (BigDecimal obj : listOfBigDecimal) {
								lpstpFinDetail = serviceProvider.getFinancialMasterService().getRowOfMAxDateByAuditType("A", propNum, obj.longValue(),finTypeNo);
								listOfLpstpFinData= serviceProvider.getFinancialMasterService().getAllRowByPropNumforData(propNum,obj.longValue(),finTypeNo);
								if(lpstpFinDetail!=null && (!listOfLpstpFinData.isEmpty()) ){
									listOfLpstpFinDetail.add(lpstpFinDetail);
									listOfParentOfLpstpFinData.add(listOfLpstpFinData);
								}
							}
						/*	List<LpstpFinMaster> listOfFinMasterRowId =	serviceProvider.getSetFinMasterService().findByCategoryAndCMANoOrderByFinSno("FI",finTypeNo);
							List<BigDecimal> rowIdOFFinMaster= new ArrayList<BigDecimal>();
							for (LpstpFinMaster obj : listOfFinMasterRowId) {
								rowIdOFFinMaster.add(BigDecimal.valueOf(obj.getFinRowid()));
							}*/
							List<BigDecimal> obj=serviceProvider.getFinancialMasterService().getFinRowIdByPropNumforData(propNum,listOfBigDecimal.get(0).longValue(),finTypeNo);
							listOfFinRowId = obj.stream().map(BigDecimal::longValue).collect(Collectors.toList());
											
							if(!listOfFinRowId.isEmpty()){
							responseHashMap.put("finmasterDataBypageId",serviceProvider.getSetFinMasterService().getAlldataByListOfRowId(listOfFinRowId));
							responseHashMap.put("allRowOfDetail",listOfLpstpFinDetail);
							responseHashMap.put("allRowOfParentData",listOfParentOfLpstpFinData);
							responseHashMap.put("listOfLpcomCustInfo", listOfLpcomCustInfo);
							}	else{
								/*if (!dataHashMap.containsKey("errorData")) {
									logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, "No  Line item is present for given Propusal Number:"+propNum);
									dataHashMap.put("errorData",new CustomErr("No user is Present for given Propusal Number:"+propNum));
									responseHashMap.put("success", false);
									responseHashMap.put("responseData", dataHashMap);
								}	*/
									responseHashMap.put("finmasterDataBypageId", new ArrayList<LpstpFinMaster>());
									responseHashMap.put("allRowOfDetail", new ArrayList<LpComFinDetail>());
									responseHashMap.put("allRowOfData", new ArrayList<LpComFinData>());
								
							}
						//responseHashMap.put("listOfParentLpstpFinData",listOfParentLpstpFinData);
						//	responseHashMap.put("listOfLpcomCustDataNind", listOfLpcomCustDataNind);
						//	responseHashMap.put("lpstpFinDetail", listOfLpstpFinData);
						}else{
							/*if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, "No user is Present for given Propusal Number:"+propNum);
								dataHashMap.put("errorData",new CustomErr("No user is Present for given Propusal Number:"+propNum));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}	*/
							responseHashMap.put("finmasterDataBypageId", new ArrayList<LpstpFinMaster>());
							responseHashMap.put("allRowOfDetail", new ArrayList<LpComFinDetail>());
							responseHashMap.put("allRowOfData", new ArrayList<LpComFinData>());
							
						}
						
						
						
 					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				else if(dpMethod.equals("getPropNumber")){
					try{
						String propNumberValue = session.getAttribute("LP_COM_PROP_NO").toString();
						String userid =session.getAttribute("userid").toString();
						if(propNumberValue!=null && (!propNumberValue.equalsIgnoreCase(""))){
							
							responseHashMap.put("propNumberValue",propNumberValue);
							responseHashMap.put("userid",userid);
						}else{
							responseHashMap.put("propNumberValue",-1);
							responseHashMap.put("userid",userid);
													
						}
					}catch (Exception e) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
							dataHashMap.put("errorData",new CustomErr(e.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
					}
					}
					
				}
				else if(dpMethod.equals("getPageAccess")){
					try {
				/*		 responseHashMap.put("pageAccess",serviceProvider.getLpmasPageMasterService()
								 .getPageAcessByPageIdforProposalType("1001",new BigDecimal( session.getAttribute("LP_COM_PROP_NO").toString()),serviceProvider,session) ); 
*/					 responseHashMap.put("pageAccess","W");
					}
				catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
				}	 }
				else if(dpMethod.equals("getListOfFinancialType")){
					try {
				 
					 responseHashMap.put("listOfFinancialType", serviceProvider.getSetCMAMasterService().fetchAllDataOrderByName());

					}
				catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
				}	 }else if (dpMethod.equals("downloadFinanicalFormatByCmaNo")) {
					try {
					
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
						BigDecimal propNum=(BigDecimal) hshMap.get("propNum");
						long customerId=Long.valueOf(hshMap.get("customerId").toString());
						long cmano=Long.valueOf(hshMap.get("cmano").toString());
						String finpage=Helper.correctNull((String)hshMap.get("finPage").toString());
						Map result = serviceProvider.getFinancialMasterService().downloadFinanicalFormat(propNum,customerId,cmano,finpage);
						
						responseHashMap.put("responseData", result);
						
						responseHashMap.put("success", true);
						

					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				
			
				else if (dpMethod.equals("updateCalculatedFieldforRatios")) {
					try {
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
					//	List<Integer>  lpstpFinRowIDTypeC= (ArrayList<Integer>) hshMap.get("arrayOfDataFinId");
						BigDecimal propNum= (BigDecimal) (hshMap.get("propNum"));
						long customerId= Long.parseLong(hshMap.get("customerId").toString());
						String finTabName= hshMap.get("finTabName").toString();
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());

						List<BigDecimal>listOfDataFinRowId=  serviceProvider.getFinancialMasterService().getFinRowIdByPropNumAndRowTypeforData(propNum,customerId,finTypeNo,"C", finTabName)  ;
						/* for (Integer iterator : lpstpFinRowIDTypeC) {
							 listOfDataFinRowId.add(BigDecimal.valueOf(Long.valueOf(iterator)));
						}*/
						String[] formulaArray= null;
						Long[] dataRowIdArray= null;
						String modifierUserName=hshMap.get("userId").toString();
						List<Object[]>objList =new ArrayList<Object[]>();
						if(!listOfDataFinRowId.isEmpty()){
						objList=  serviceProvider.getFinancialMasterService().
								getDataRowIdandFormulaValueByListOfDataFinRowId(propNum,customerId,finTypeNo ,listOfDataFinRowId);
						}
						formulaArray= new String[objList.size()];
						dataRowIdArray= new Long[objList.size()];
						int counter=0;
						for (Object[] object  : objList) {
							dataRowIdArray[counter]=Long.valueOf(object[0].toString());
							formulaArray[counter]=(String) object[1];
							counter++;
						}
						responseHashMap.put("successMessage", "Field  updatation got Field , Kindly ReLoad the Page");
						if(formulaArray.length>0){
						if(serviceProvider.getFinancialMasterService().updateFormulaData(modifierUserName,dataRowIdArray,formulaArray,propNum,customerId,finTypeNo,serviceProvider, logging,session)){
						
							responseHashMap.put("successMessage", "Field Got Update ReLoad the Page");
						}else{

							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, "CHANGE DOESNOT TAKE PALCE");
								dataHashMap.put("errorData",new CustomErr( "Field  updatation got Field , Kindly ReLoad the Page"));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
							
						}
						
						
					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
				else if(dpMethod.equals("getListOfFinancialType2")){
					try {
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
						BigDecimal propNum=new BigDecimal(hshMap.get("propNum").toString());
					 responseHashMap.put("listOfFinancialType", serviceProvider.getSetCMAMasterService().fetchAllDataOrderByName());
					 responseHashMap.put("listOfCustomerAndFinType",serviceProvider.getFinancialMasterService().getDistinctCusrtomerIDandCMANo(propNum));
					}
				catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
				}	 }
				else if(dpMethod.equals("getDeleteRecordBoth")){
					try {
						hshMap=(Map<String,Object>)allRequestParams.get("requestData");
						BigDecimal propNum=(BigDecimal) (hshMap.get("propNum"));
						long customerId=Long.valueOf(hshMap.get("customerId").toString());
						long finTypeNo=Long.valueOf(hshMap.get("finTypeNo").toString());
						serviceProvider.getFinancialMasterService().deleteAllRowOfDetailandDataByPropNoandCustomerIdAndCmaNo(propNum, customerId, finTypeNo);
					}
				catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
				}	 }
				else{
					dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
		
				}
			
			
		}
		
	
		
		catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		}
			}
		//logging.info("dpMethod:{}  ,OutputMAp:{} ",dpMethod,responseHashMap);
		return responseHashMap;
	}
}
