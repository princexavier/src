package com.sai.lendperfect.setup.documenttemplate;
import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.mastermodel.LpmasKeyParameter;
import com.sai.lendperfect.setupmodel.LpstpDocumentTemplate;



public interface LpstpDocumentTemplateService {
	
	List<LpmasKeyParameter> findAllKeyParameter();

	void deleteKeyParameter(LpmasKeyParameter lpmasKeyParameter1);

	LpmasKeyParameter saveKeyParameter(LpmasKeyParameter lpmasKeyParameter);

	LpstpDocumentTemplate saveDocumentTemplate(LpstpDocumentTemplate lpstpDocumentTemplate);

	List<LpstpDocumentTemplate> findAll();

	void deleteDocumentTemplate(List<LpstpDocumentTemplate> lpstpDocumentTemplate);
	
	 List<LpstpDocumentTemplate> saveAllDocumentTemplate(List<LpstpDocumentTemplate> lpstpDocumentTemplate);

	 LpstpDocumentTemplate findByLdtTemplateTitle(String string);

	 LpstpDocumentTemplate findByldtRowId( BigDecimal lmtRowId);
	 
	 public LpmasKeyParameter findLkpKeyValue(String lkpKeyValue);
	 
	 public List<Object> findDocumentData(String query);
	 
	 public List<Object[]> findDocumentDataWithMultiCol(String query);
	 
	 
		
}


