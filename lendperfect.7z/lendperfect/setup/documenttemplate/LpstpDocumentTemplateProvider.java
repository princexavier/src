package com.sai.lendperfect.setup.documenttemplate;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.io.FileSystemResource;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpDocumentTemplate;
;

public class LpstpDocumentTemplateProvider {
	
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging) 
	{
		
		logging.setLoggerClass(LpstpDocumentTemplateProvider.class);		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		if(dpMethod.equals("getKeyWordList"))
		{
			Map <String,Object> dataHashMap=new HashMap<String,Object>();
			dataHashMap.put("documentlist",serviceProvider.getLpstpDocumentService().findAllByLdDocTypeAndLdDocActive("B", "Y"));
			dataHashMap.put("keywordList",serviceProvider.getDocumentTemplateService().findAllKeyParameter());
			dataHashMap.put("documentTemplateList",serviceProvider.getDocumentTemplateService().findAll());
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else if(dpMethod.equals("saveDocumentTemplate"))
		{			
			serviceProvider.getDocumentTemplateService().saveDocumentTemplate(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpDocumentTemplate>() { }));
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("documentTemplateList",serviceProvider.getDocumentTemplateService().findAll());
			/*
			File file = new File("C://Users//Abirami.N//Desktop//kotTest.xlsx");
			List<LpstpMailTemplate> list = (List<LpstpMailTemplate>)(List<?>) serviceProvider.getFileUploadManager().fileUpload(file);
			serviceProvider.getMailTemplateService().saveAllMailTemplate(list);*/
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}else if(dpMethod.equals("deleteDocumentTemplate"))
		{		
			List<LpstpDocumentTemplate> lpstpDocumentTemplateList=new ArrayList<>(); 		
			LpstpDocumentTemplate lpstpDocumentTemplate = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpDocumentTemplate>() { });
			lpstpDocumentTemplateList.add(lpstpDocumentTemplate);
			serviceProvider.getDocumentTemplateService().deleteDocumentTemplate(lpstpDocumentTemplateList);
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("mailTemplateList",serviceProvider.getDocumentTemplateService().findAll());
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else
		{
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
		
		
	}

}
