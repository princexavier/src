package com.sai.lendperfect.setup.documenttemplate;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.mastermodel.LpmasKeyParameter;
import com.sai.lendperfect.masterrepo.LpMasKeyParameterRepo;
import com.sai.lendperfect.setupmodel.LpstpDocumentTemplate;
import com.sai.lendperfect.setuprepo.LpStpDocumentTemplateRepo;




@Service("documentTemplateService")
@Transactional
public class LpstpDocumentTemplateServiceImpl implements LpstpDocumentTemplateService{

	
	@Autowired
	private LpMasKeyParameterRepo lpmasKeyParameterRepo;
	
	@Autowired
	private LpStpDocumentTemplateRepo lpStpDocumentTemplateRepo;
	

	@PersistenceContext
	private EntityManager entityManager;
	

	
	public List<LpmasKeyParameter> findAllKeyParameter() {
		return lpmasKeyParameterRepo.findAll();
	}

	@Override
	public void deleteKeyParameter(LpmasKeyParameter lpmasKeyParameter1) {
		lpmasKeyParameterRepo.delete(lpmasKeyParameter1);
	}

	@Override
	public LpmasKeyParameter saveKeyParameter(LpmasKeyParameter lpmasKeyParameter) {
		return  lpmasKeyParameterRepo.save(lpmasKeyParameter);
	}

	@Override
	public LpstpDocumentTemplate saveDocumentTemplate(LpstpDocumentTemplate lpstpDocumentTemplate) {
		return lpStpDocumentTemplateRepo.saveAndFlush(lpstpDocumentTemplate);
		
	}

	
	@Override
	public List<LpstpDocumentTemplate> saveAllDocumentTemplate(List<LpstpDocumentTemplate> lpstpDocumentTemplateList) {
		return lpStpDocumentTemplateRepo.save(lpstpDocumentTemplateList);
		
	}
	
	@Override
	public List<LpstpDocumentTemplate> findAll() {
		return lpStpDocumentTemplateRepo.findAll();
	}

	@Override
	public void deleteDocumentTemplate(List<LpstpDocumentTemplate> lpstpDocumentTemplateList) {
		lpStpDocumentTemplateRepo.delete(lpstpDocumentTemplateList);
	}

	@Override
	public LpstpDocumentTemplate findByLdtTemplateTitle(String title) {
		return lpStpDocumentTemplateRepo.findByLdtTemplateTitle(title);
	}

	public LpstpDocumentTemplate findByldtRowId(BigDecimal ldtRowId) {
		return lpStpDocumentTemplateRepo.findByldtRowId(ldtRowId);
	}

	public LpmasKeyParameter findLkpKeyValue(String lkpKeyValue)
	{
		return lpmasKeyParameterRepo.findByLkpKeyValue(lkpKeyValue);
	}


	@SuppressWarnings("unchecked")
	public List<Object> findDocumentData(String query) {
		return entityManager.createQuery(query).getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> findDocumentDataWithMultiCol(String query) {
		return entityManager.createQuery(query).getResultList();
	}
	
	


}
