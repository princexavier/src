package com.sai.lendperfect.setup.workflowmaster;


import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpWfFlow;
import com.sai.lendperfect.setuprepo.LpstpWfFlowRepo;

@Service("LpstpWfFlowService")
@Transactional
public class LpstpWfFlowServiceImpl implements LpstpWfFlowService {
	
	@Autowired
	LpstpWfFlowRepo lpstpWfFlowRepo;
	
	
	public List<LpstpWfFlow> findAll() {
		// TODO Auto-generated method stub
		return lpstpWfFlowRepo.findAll();
	}

	@Override
	public LpstpWfFlow saveLpstpWfFlow(LpstpWfFlow lpstpWfFlow) {
		// TODO Auto-generated method stub
		return lpstpWfFlowRepo.save(lpstpWfFlow);
	}

	@Override
	public void deleteAllByLwfFlowpointId(Long lwfFlowpointId) {
		// TODO Auto-generated method stub
		lpstpWfFlowRepo.deleteAllByLwfFlowpointId(lwfFlowpointId);
	}

	@Override
	public List<LpstpWfFlow> findAllByLwfWorkflowId(Long lwfWorkflowId) {
		// TODO Auto-generated method stub
		return lpstpWfFlowRepo.findAllByLwfWorkflowIdOrderByLwfWorkflowId(lwfWorkflowId);
	}

	@Override
	public List<LpstpWfFlow> findAllByLwfFlowpointId(Long lwfFlowpointId) {
		// TODO Auto-generated method stub
		return lpstpWfFlowRepo.findAllByLwfFlowpointId(lwfFlowpointId);
	}

	@Override
	public List<LpstpWfFlow> findAllByLwfWorkflowIdAndLwfWfType(Long lsWfProcessId, String type) {
		
		return lpstpWfFlowRepo.findAllByLwfWorkflowIdAndLwfWfType(lsWfProcessId,type);
	}

	@Override
	public  LpstpWfFlow findAllByLwfWorkflowIdAndLwfWfTypeAndLwfFlowpoint(BigDecimal workflowId, String type,
			Long lmFlowId) {
		return lpstpWfFlowRepo.findAllByLwfWorkflowIdAndLwfWfTypeAndLwfFlowpoint(workflowId,type,lmFlowId);
	}

	@Override
	public List<Object[]> getUserId(String lwfUserGrp, BigDecimal bizVertical) {
		// TODO Auto-generated method stub
		return lpstpWfFlowRepo.getUserId(lwfUserGrp,bizVertical);
	}

	@Override
	public LpstpWfFlow findAllByLwfWorkflowIdAndLwfWfTypeAndLwfFlowpointId(Long flowId, String type,
			long id) {
		return lpstpWfFlowRepo.findAllByLwfWorkflowIdAndLwfWfTypeAndLwfFlowpointId(flowId,type,id);
	}

	@Override
	public LpstpWfFlow findByLwfFlowpointId(long lwfFlowpointId) {
		return lpstpWfFlowRepo.findByLwfFlowpointId(lwfFlowpointId);
	}

	@Override
	public List<LpstpWfFlow> findByLwfWorkflowIdOrderByLwfCreatedOn(Long flowId) {
		// TODO Auto-generated method stub
		return lpstpWfFlowRepo.findByLwfWorkflowIdOrderByLwfCreatedOn(flowId);
	}

	@Override
	public List<LpstpWfFlow> findByLwfWorkflowIdOrderByLwfFlowpoint(Long flowId) {
		// TODO Auto-generated method stub
		return lpstpWfFlowRepo.findByLwfWorkflowIdOrderByLwfFlowpoint(flowId);
	}

	

}
