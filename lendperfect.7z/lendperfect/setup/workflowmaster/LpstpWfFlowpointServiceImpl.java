package com.sai.lendperfect.setup.workflowmaster;

import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpWfFlowpoint;
import com.sai.lendperfect.setuprepo.LpstpWfFlowpointRepo;

@Service("LpstpWfFlowpointService")
@Transactional

public class LpstpWfFlowpointServiceImpl implements LpstpWfFlowpointService {
	
	@Autowired
	LpstpWfFlowpointRepo lpstpWfFlowpointRepo;
	
	public List<LpstpWfFlowpoint> findAll() {
		// TODO Auto-generated method stub
		return lpstpWfFlowpointRepo.findAll();
	}

	@Override
	public LpstpWfFlowpoint saveLpstpWfFlowpoint(LpstpWfFlowpoint lpstpWfFlowpoint) {
		// TODO Auto-generated method stub
		return lpstpWfFlowpointRepo.save(lpstpWfFlowpoint);
	}

	@Override
	public List<LpstpWfFlowpoint> findAllByLwfFlowDepartment(String lwfFlowDepartment) {
		// TODO Auto-generated method stub
		return lpstpWfFlowpointRepo.findAllByLwfFlowDepartmentOrderByLwfFlowId(lwfFlowDepartment);
	}

	@Override
	public void deleteAllByLwfFlowId(BigDecimal lwfFlowId) {
		// TODO Auto-generated method stub
		lpstpWfFlowpointRepo.deleteAllByLwfFlowId(lwfFlowId);
	}

	@Override
	public List<LpstpWfFlowpoint> findAllOrderByLwfFlowId() {
		// TODO Auto-generated method stub
		return lpstpWfFlowpointRepo.findAllByOrderByLwfFlowId();
	}

	@Override
	public LpstpWfFlowpoint findByLwfFlowId(BigDecimal lwfFlowpoint) {
		return lpstpWfFlowpointRepo.findByLwfFlowId(lwfFlowpoint);
	}


	public LpstpWfFlowpoint findByLwfFlowIdAndLwfFlowDepartment(BigDecimal lwfFlowpoint, String lwfWfType) {
		return lpstpWfFlowpointRepo.findByLwfFlowIdAndLwfFlowDepartment(lwfFlowpoint,lwfWfType);
	}




}
