package com.sai.lendperfect.setup.workflowmaster;

import static org.junit.Assert.assertNotNull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.DecimalMax;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpWorkflow;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.setupmodel.LpstpWfFlow;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.mastermodel.LpmasPageMaster;
import com.sai.lendperfect.setupmodel.LpstpWfPagelist;
import com.sai.lendperfect.setupmodel.LpstpWfFlowpoint;
import com.sai.lendperfect.setupmodel.SetUserGroup;



public class LpstpWorkflowDataProvider {
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpWorkflowDataProvider.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map <String,Object> modelMap=new HashMap<String,Object>();	
		
		 List<LpmasPageMaster> lpmasPageMaster	=	new ArrayList<LpmasPageMaster>();
		 LpmasPageMaster lpmasPageMasterobj	=	new LpmasPageMaster();
		 Map <String,Object> workflowPageMap=new HashMap<String,Object>();	
		 ArrayList<Map<String, Object>> workflowPageMapnew = new ArrayList<Map <String, Object>>();
		 String lpmPageType="";
		try
		{
			
			if(dpMethod.equals("getWorkflowtmatser"))
			{
			try {
					BigDecimal lwWfBizVertical=new BigDecimal((String)requestHashMap.get("lwWfBizVertical").toString());
				    List<LpstpWorkflow> lpstpWorkflowlist	=	new ArrayList<LpstpWorkflow>();
				    ArrayList<Map<String, Object>> workflowlist = new ArrayList<Map <String, Object>>();
				    lpstpWorkflowlist=serviceProvider.getLpstpWorkflowService().findAllByLwWfBizVertical(lwWfBizVertical);
				    dataHashMap.put("workflowlist",lpstpWorkflowlist);
				    responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			else if(dpMethod.equals("saveworkflowmatser")){	
				try {
					LpstpWorkflow lpstpWorkflow=new ObjectMapper()
							.convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpWorkflow>() {});
					lpstpWorkflow.setLwCreatedBy("mrd");
					lpstpWorkflow.setLwModifiedBy("mrd");
					lpstpWorkflow.setLwCreatedOn(new Date());
					lpstpWorkflow.setLwModifiedOn(new Date());
					serviceProvider.getLpstpWorkflowService().saveLpstpWorkflow(lpstpWorkflow);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			
			else if(dpMethod.equals("saveWorkflowPoint")){	
				try {
					LpstpWfFlow lpstpWfFlow=new ObjectMapper()
							.convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpWfFlow>() {});
					lpstpWfFlow.setLwfCreatedBy("mrd");
					lpstpWfFlow.setLwfModifiedBy("mrd");
					lpstpWfFlow.setLwfCreatedOn(new Date());
					lpstpWfFlow.setLwfModifiedOn(new Date());
					serviceProvider.getLpstpWfFlowService().saveLpstpWfFlow(lpstpWfFlow);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("getworkflowpointlist"))
			{
			try {
				    List<LpstpWfFlow> lpstpWfFlowlist	=	new ArrayList<LpstpWfFlow>();
				    Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					Long  lwfWorkflowId=Long.valueOf(String.valueOf(requestHashMapnew.get("lwWfId")));
 				    lpstpWfFlowlist=serviceProvider.getLpstpWfFlowService().findAllByLwfWorkflowId(lwfWorkflowId);
				    dataHashMap.put("workflowpointlist",lpstpWfFlowlist);
				    responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			else if(dpMethod.equals("getworkflowpagelist"))
			{
			try {
				   
				   
				    String active="Y";
				    Long lwpFlowpointId=new Long((String)requestHashMap.get("lwpFlowpointId"));
				    lpmPageType=serviceProvider.getLpstpWorkflowService().getworkflowtype(lwpFlowpointId);
				    if(lpmPageType.equals("P")||lpmPageType.equals("L"))
				    	lpmasPageMaster=serviceProvider.getLpmasPageMasterService().findByLpmPageActiveAndLpmPageTypeInOrderByLpmPageId(active, lpmPageType, "C");
				    else
				    	lpmasPageMaster=serviceProvider.getLpmasPageMasterService().findByLpmPageActiveAndLpmPageTypeOrderByLpmPageId(active, lpmPageType);

				    for (int i=0;i<lpmasPageMaster.size();i++)
					{
						
				    	lpmasPageMasterobj=lpmasPageMaster.get(i);
				    	workflowPageMap=new HashMap();
						workflowPageMap.put("lwpPageId", lpmasPageMasterobj.getLpmPageId());
						workflowPageMap.put("lwpPagename", lpmasPageMasterobj.getLpmPageName().toString());
						workflowPageMapnew.add(workflowPageMap);
						}
				    dataHashMap.put("pagelist",workflowPageMapnew);
				    responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			else if(dpMethod.equals("saveWorkflowPageList")){	
				try {
							BigDecimal lwpFlowpointId=new BigDecimal((String)requestHashMap.get("lwpFlowpointId"));
							workflowPageMapnew=new ArrayList<Map<String, Object>>();
							serviceProvider.getLpstpWfPagelistService().deleteAllByLwpFlowpointId(lwpFlowpointId);
							List<Map<String,Object>> PageList=(List<Map<String, Object>>) requestHashMap.get("optionalarry");
							Iterator<Map<String,Object>> PageListItr=PageList.iterator();
							while(PageListItr.hasNext())
							{
								Map<String,Object> modelsales=PageListItr.next();
									workflowPageMap=new HashMap();
								workflowPageMap.put("lwpPageId", modelsales.get("lwpPageId"));
								workflowPageMap.put("lwpPagelistId",new BigDecimal(0) );
								workflowPageMap.put("lwpPageAccess", modelsales.get("lwpPageAccess"));
								workflowPageMap.put("lwpFlowpointId",lwpFlowpointId);
								workflowPageMap.put("lwpCreatedBy","mrd");
								workflowPageMap.put("lwpModifiedBy", "mrd");
								workflowPageMap.put("lwpCreatedOn", new Date());
								workflowPageMap.put("lwpModifiedOn", new Date());
								workflowPageMapnew.add(workflowPageMap);
								
							}
							
							List<LpstpWfPagelist> lpstpWfPagelistList=new ObjectMapper()
									.convertValue(workflowPageMapnew,new TypeReference<List<LpstpWfPagelist>>() {});
							serviceProvider.getLpstpWfPagelistService().saveLpstpWfPagelist(lpstpWfPagelistList);
							responseHashMap.put("success", true);
							responseHashMap.put("responseData", dataHashMap);	
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			
			else if(dpMethod.equals("deleteflowpointandpagelist")){	
				try {
					BigDecimal  lwfWorkflowId=new BigDecimal((String)allRequestParams.get("workid").toString());
					BigDecimal  lwfFlowpointId=new BigDecimal((String)allRequestParams.get("flowid").toString());
					Long  lwfFlowpointIdlong=new Long((String)allRequestParams.get("flowid").toString());
					serviceProvider.getLpstpWfFlowService().deleteAllByLwfFlowpointId(lwfFlowpointIdlong);
					serviceProvider.getLpstpWfPagelistService().deleteAllByLwpFlowpointId(lwfFlowpointId);
					responseHashMap.put("responseData", dataHashMap);
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("saveWorkflowPointmaster")){	
				try {
					LpstpWfFlowpoint lpstpWfFlowpoint=new ObjectMapper()
							.convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpWfFlowpoint>() {});
					lpstpWfFlowpoint.setLwfCreatedBy("mrd");
					lpstpWfFlowpoint.setLwfModifiedBy("mrd");
					lpstpWfFlowpoint.setLwfCreatedOn(new Date());
					lpstpWfFlowpoint.setLwfModifiedOn(new Date());
					serviceProvider.getLpstpWfFlowpointService().saveLpstpWfFlowpoint(lpstpWfFlowpoint);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			
			else if(dpMethod.equals("getflowpointmaster")){	
				try{
					 List<LpstpWfFlowpoint> lpstpWfFlowpointlist	=	new ArrayList<LpstpWfFlowpoint>();
					 Long lwWfId=new Long((String)requestHashMap.get("lwfWorkflowId"));
					 lpmPageType=serviceProvider.getLpstpWorkflowService().getworkmastertype(lwWfId);
					 lpstpWfFlowpointlist=serviceProvider.getLpstpWfFlowpointService().findAllByLwfFlowDepartment(lpmPageType);
					 dataHashMap.put("listflowpointmaster",lpstpWfFlowpointlist);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("getworkflowgroup")){	
				try{
					 List<SetUserGroup> lpstpUserlist	=	new ArrayList<SetUserGroup>();
					 String sugGrpActive="Y";
					 String vertical="";
					 Long lwWfId=new Long((String)requestHashMap.get("lwfWorkflowId"));
					 lpmPageType=serviceProvider.getLpstpWorkflowService().getworkmastertype(lwWfId);
					 vertical=serviceProvider.getLpstpWorkflowService().getworkmastervertical(lwWfId);
					 if(lpmPageType.equals("P"))
					 {
						 String dep1="C",dep2="S";
						 List<Object[]>userList=serviceProvider.getLpstpWorkflowService().getusergroup(vertical, dep1, dep2);
						 Map <String,Object> userMap=new HashMap<String,Object>();
						 List<Object> lpstpUserlistNew= null;
						 lpstpUserlistNew = new ArrayList<Object>(); 
							for(Object[] object : userList)
						     {
								
					    	    userMap = new HashMap<String,Object>();
						    	userMap.put("sugGrpId",object[0]);
						    	userMap.put("sugGrpName", object[1]);
						    	lpstpUserlistNew.add(userMap);
						    	
								
								}
						 dataHashMap.put("usergrouplist",lpstpUserlistNew); 
					 }
					 else
					 {
						lpstpUserlist=serviceProvider.getUserGroupService().findBySugGrpVerticalAndLugGrpDeptAndSugGrpActive(vertical, lpmPageType, sugGrpActive);
					    dataHashMap.put("usergrouplist",lpstpUserlist); 
					 }
					 
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("getflowpointdescList")){	
				try{
					 List<LpstpWfFlowpoint> lpstpWfFlowpointdesclist	=	new ArrayList<LpstpWfFlowpoint>();
					 Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					 String lwfFlowDepartment=(String)requestHashMapnew.get("lwfFlowDepartment");
					 lpstpWfFlowpointdesclist=serviceProvider.getLpstpWfFlowpointService().findAllByLwfFlowDepartment(lwfFlowDepartment);
					 dataHashMap.put("flowdescList",lpstpWfFlowpointdesclist);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("deleteflowpointlistmodel")){	
				try{
					 Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					 BigDecimal lwfFlowId=new BigDecimal((String)requestHashMapnew.get("lwfFlowId").toString());
					 serviceProvider.getLpstpWfFlowpointService().deleteAllByLwfFlowId(lwfFlowId);
						responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("getchecklist")){	
				try{
					 List<LpstpWfPagelist> lpstpWfPagelistlist	=	new ArrayList<LpstpWfPagelist>();
					 Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					 BigDecimal lwpFlowpointId=new BigDecimal((String)requestHashMapnew.get("lwpFlowpointId").toString());
					 lpstpWfPagelistlist=serviceProvider.getLpstpWfPagelistService().findAllBylwpFlowpointId(lwpFlowpointId);
					 LpstpWfPagelist lpstpWfPagelistobj	=	new LpstpWfPagelist();
					 Map <String,Object> pagelistMap=new HashMap<String,Object>();	
					 ArrayList<Map<String, Object>> pagelistMapnew = new ArrayList<Map <String, Object>>();
					 for (int i=0;i<lpstpWfPagelistlist.size();i++)
						{
							
						    lpstpWfPagelistobj=lpstpWfPagelistlist.get(i);
					    	pagelistMap=new HashMap();
					    	pagelistMap.put("lwpPageId", lpstpWfPagelistobj.getLwpPageId());
					    	pagelistMap.put("lwpPageAccess", lpstpWfPagelistobj.getLwpPageAccess());
							
					    	pagelistMapnew.add(pagelistMap);
							}
					 
					 dataHashMap.put("checklist",pagelistMapnew);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("getsingleflowlevel")){	
				try{
					 List<LpstpWfFlow> lpstpWfFlowList	=	new ArrayList<LpstpWfFlow>();
					 Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					 Long  lwfFlowpointId=new Long((String)requestHashMapnew.get("lwfFlowpointId").toString());
					 lpstpWfFlowList=serviceProvider.getLpstpWfFlowService().findAllByLwfFlowpointId(lwfFlowpointId);
					 dataHashMap.put("flowlevelList",lpstpWfFlowList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("getPageId")){	
				try{
					String pageName=allRequestParams.get("requestdata").toString();
					LpmasPageMaster LpmasPageMasterObj=serviceProvider.getLpmasPageMasterService().findByLpmLinkName(pageName);
					 dataHashMap.put("LpmasPageMasterObj",LpmasPageMasterObj);
					responseHashMap.put("success", true);
					dataHashMap.put("pageId", LpmasPageMasterObj.getLpmPageId());
					dataHashMap.put("pagename", LpmasPageMasterObj.getLpmPageName());
					dataHashMap.put("pagelink", LpmasPageMasterObj.getLpmLinkName());
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			
			else if(dpMethod.equals("getChildPages")){	
				try{
					
					List<LpmasPageMaster> LpmasPageMasterObj=serviceProvider.getLpmasPageMasterService().getlpmParentLink();
					 dataHashMap.put("childPages",LpmasPageMasterObj);
					 responseHashMap.put("responseData", dataHashMap);		
					responseHashMap.put("success", true);
				
								
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if (dpMethod.equals("getBusinessVertical"))
			{
					List<LpmasBizVertical> workflowverticalList=serviceProvider.getLpmasBizVerticalService().findAll();
					dataHashMap.put("BizverticalList", workflowverticalList);
					responseHashMap.put("responseData", dataHashMap);
					
			}
		}
		
		
		catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		return responseHashMap;
	}

}
