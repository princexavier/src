package com.sai.lendperfect.setup.workflowmaster;


import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpWorkflow;
import com.sai.lendperfect.setuprepo.LpstpWorkflowRepo;


@Service("LpstpWorkflowService")
@Transactional

public class LpstpWorkflowServiceImpl implements LpstpWorkflowService {
	
	@Autowired
	LpstpWorkflowRepo lpstpWorkflowRepo;

	
	public List<LpstpWorkflow> findAll() {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.findAll();
	}

	@Override
	public LpstpWorkflow findById(Long lwWfId) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.findOne(lwWfId);
	}

	@Override
	public List<LpstpWorkflow> saveLpstpWorkflowList(List<LpstpWorkflow> lpstpWorkflowlist) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.save(lpstpWorkflowlist);
	}

	@Override
	public LpstpWorkflow saveLpstpWorkflow(LpstpWorkflow lpstpWorkflow) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.saveAndFlush(lpstpWorkflow);
	}

	@Override
	public List<LpstpWorkflow> findAllDistinct() {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.findAllDistinct();
	}

	@Override
	public List<LpstpWorkflow> findAllByLwWfType(String lwWfType) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.findAllByLwWfType(lwWfType);
	}

	@Override
	public LpstpWorkflow findByLwWfIdAndLwWfType(long lsWfProcessId, String type) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.findByLwWfIdAndLwWfType(lsWfProcessId,type);
	}

	@Override
	public String getworkflowtype(Long lwfFlowpointId) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.getworkflowtype(lwfFlowpointId);
	}

	@Override
	public List<LpstpWorkflow> findAllByLwWfBizVertical(BigDecimal lwWfBizVertical) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.findAllByLwWfBizVertical(lwWfBizVertical);
	}

	@Override
	public String getworkmastertype(Long lwWfId) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.getworkmastertype(lwWfId);
	}

	@Override
	public String getworkmastervertical(Long lwWfId) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.getworkmastervertical(lwWfId);
	}

	@Override
	public List<Object[]> getusergroup(String vertical, String dep1, String dep2) {
		// TODO Auto-generated method stub
		return lpstpWorkflowRepo.getusergroup(vertical, dep1, dep2);
	}

	@Override
	public List<Object[]> verticalpagelist(BigDecimal flwid) {
		return lpstpWorkflowRepo.verticalpagelist(flwid);
	}

}
