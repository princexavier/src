package com.sai.lendperfect.setup.workflowmaster;

import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpWfPagelist;
import com.sai.lendperfect.setuprepo.LpstpWfPagelistRepo;


@Service("LpstpWfPagelistService")
@Transactional
public class LpstpWfPagelistServiceImpl implements LpstpWfPagelistService {
 
	@Autowired
	LpstpWfPagelistRepo lpstpWfPagelistRepo;
	


	@Override
	public List<LpstpWfPagelist> saveLpstpWfPagelist(List<LpstpWfPagelist> saveLpstpWfPagelist) {
		// TODO Auto-generated method stub
		return lpstpWfPagelistRepo.save(saveLpstpWfPagelist);
	}



	@Override
	public void deleteAllByLwpFlowpointId(BigDecimal lwpFlowpointId) {
		// TODO Auto-generated method stub
		lpstpWfPagelistRepo.deleteAllByLwpFlowpointId(lwpFlowpointId);
	}



	@Override
	public List<LpstpWfPagelist> findAllBylwpFlowpointId(BigDecimal lwpFlowpointId) {
		// TODO Auto-generated method stub
		return lpstpWfPagelistRepo.findAllBylwpFlowpointId(lwpFlowpointId);
	}

}
