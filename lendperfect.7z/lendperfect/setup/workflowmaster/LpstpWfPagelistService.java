package com.sai.lendperfect.setup.workflowmaster;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpWfPagelist;

public interface LpstpWfPagelistService {
	
	List<LpstpWfPagelist> saveLpstpWfPagelist(List<LpstpWfPagelist> saveLpstpWfPagelist);
	void deleteAllByLwpFlowpointId(BigDecimal lwpFlowpointId);
	List<LpstpWfPagelist> findAllBylwpFlowpointId(BigDecimal lwpFlowpointId);

}
