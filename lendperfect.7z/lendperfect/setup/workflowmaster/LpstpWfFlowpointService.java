package com.sai.lendperfect.setup.workflowmaster;


import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpWfFlowpoint;

public interface LpstpWfFlowpointService {
	
	LpstpWfFlowpoint saveLpstpWfFlowpoint(LpstpWfFlowpoint lpstpWfFlowpoint);
	List<LpstpWfFlowpoint> findAll();
	List<LpstpWfFlowpoint> findAllByLwfFlowDepartment(String lwfFlowDepartment);
	void deleteAllByLwfFlowId(BigDecimal lwfFlowId);
	List<LpstpWfFlowpoint>findAllOrderByLwfFlowId();
	LpstpWfFlowpoint findByLwfFlowId(BigDecimal lwfFlowpoint);
	LpstpWfFlowpoint findByLwfFlowIdAndLwfFlowDepartment(BigDecimal lwfFlowpoint, String lwfWfType);

}
