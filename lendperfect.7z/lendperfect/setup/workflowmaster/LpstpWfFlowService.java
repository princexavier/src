package com.sai.lendperfect.setup.workflowmaster;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpWfFlow;

public interface LpstpWfFlowService {
	
	List<LpstpWfFlow> findAll();
	LpstpWfFlow saveLpstpWfFlow(LpstpWfFlow lpstpWfFlow);
	List<LpstpWfFlow> findAllByLwfWorkflowId(Long lwfWorkflowId);
	void deleteAllByLwfFlowpointId(Long lwfFlowpointIdlong);
	List<LpstpWfFlow> findAllByLwfFlowpointId(Long lwfFlowpointId);
	List<LpstpWfFlow> findAllByLwfWorkflowIdAndLwfWfType(Long lsWfProcessId, String type);
	LpstpWfFlow findAllByLwfWorkflowIdAndLwfWfTypeAndLwfFlowpoint(BigDecimal workflowId,String type,
			Long lmFlowId);
	List<Object[]> getUserId(String lwfUserGrp, BigDecimal bigDecimal2);
	LpstpWfFlow findAllByLwfWorkflowIdAndLwfWfTypeAndLwfFlowpointId(Long bigDecimal, String string,
			long parseLong);
	LpstpWfFlow findByLwfFlowpointId(long lwfFlowpointId);
	List<LpstpWfFlow> findByLwfWorkflowIdOrderByLwfCreatedOn(Long flowId);
	List<LpstpWfFlow> findByLwfWorkflowIdOrderByLwfFlowpoint(Long flowId);


}
