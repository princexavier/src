package com.sai.lendperfect.setup.workflowmaster;


import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpWorkflow;

public interface LpstpWorkflowService {
	
	List<LpstpWorkflow> findAll();
	LpstpWorkflow findById(Long  lwWfId);
	List<LpstpWorkflow> saveLpstpWorkflowList(List<LpstpWorkflow> lpstpWorkflowlist);
	LpstpWorkflow saveLpstpWorkflow(LpstpWorkflow lpstpWorkflow);
	List<LpstpWorkflow> findAllDistinct();
	List<LpstpWorkflow> findAllByLwWfType(String lwWfType);
	LpstpWorkflow findByLwWfIdAndLwWfType(long lsWfProcessId, String string);
	String getworkflowtype(Long lwfFlowpointId);
	List<LpstpWorkflow> findAllByLwWfBizVertical(BigDecimal lwWfBizVertical);
	String getworkmastertype(Long lwWfId);
	String getworkmastervertical(Long lwWfId);
	List<Object[]> getusergroup(String  vertical,String dep1,String dep2);
	List<Object[]> verticalpagelist(BigDecimal flwid);
    
}
