package com.sai.lendperfect.setup.schememaster;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.setupmodel.LpstpCranMaster;
import com.sai.lendperfect.setupmodel.LpstpFacility;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.LpstpScheme;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.setupmodel.LpstpWorkflow;

public class LpstpSchemeDataProvider {
	
	@SuppressWarnings({ "unused", "unchecked", "rawtypes" })
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpSchemeDataProvider.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map <String,Object> modelMap=new HashMap<String,Object>();	
		LpstpFacility lpstpFacility = new LpstpFacility();
		try
		{
			
			if(dpMethod.equals("getschemematser"))
			{
			try {
				
				LpstpScheme lpstpScheme= new LpstpScheme();
				Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
				String lsSchemeName =(String)requestHashMapnew.get("lsSchemeName").toString();
					dataHashMap.put("schememaster",serviceProvider.getLpstpSchemeService().findAllByLsSchemeName(lsSchemeName));
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			else if(dpMethod.equals("getschemeList"))
			{
			try {
				    List<LpstpScheme> lpstpSchemelist	=	new ArrayList<LpstpScheme>();
				    ArrayList<Map<String, Object>> schemelist = new ArrayList<Map <String, Object>>();
				    BigDecimal lsBizVertical=new BigDecimal((String)requestHashMap.get("lsBizVertical").toString());
				    lpstpSchemelist=serviceProvider.getLpstpSchemeService().findAllByLsBizVerticalOrderByLsSchemeId(lsBizVertical);
				    dataHashMap.put("schemeList",lpstpSchemelist);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			else if(dpMethod.equals("saveschemematser")){	
				try {
					
					LpstpScheme lpstpScheme=new ObjectMapper()
							.convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpScheme>() {});
					String schemeName = lpstpScheme.getLsSchemeName();
					lpstpFacility = serviceProvider.getLpstpFacilityService().findByLsfFacDesc(schemeName);
					lpstpScheme.setLsSubFacility(Long.valueOf(lpstpFacility.getLsfFacId()));
					lpstpScheme.setLsCreatedBy("mrd");
					lpstpScheme.setLsModifiedBy("mrd");
					lpstpScheme.setLsCreatedOn(new Date());
					lpstpScheme.setLsModifiedOn(new Date());
					dataHashMap.put("schemeList",serviceProvider.getLpstpSchemeService().saveLpstpScheme(lpstpScheme));
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("deleteschemematser")){	
				try {
					Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					BigDecimal  lsSchemeId=BigDecimal.valueOf(Long.valueOf((String)requestHashMapnew.get("SchemeId").toString()));
					serviceProvider.getLpstpSchemeService().deleteAllByLsSchemeId(lsSchemeId);
					responseHashMap.put("responseData", dataHashMap);
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			
			else if (dpMethod.equals("getBusinessVertical"))
			{
				try {
					
					List<LpmasBizVertical> TermBizverticalList=serviceProvider.getLpmasBizVerticalService().findAll();
					dataHashMap.put("BizverticalList", TermBizverticalList);
					responseHashMap.put("responseData", dataHashMap);
					
							}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
			}
			else if (dpMethod.equals("getschemeWorflowlist"))
			{
				try {
					String tech="T";
					String legal="L";
					String RCU="R";
					String process="P";
					
					List<LpstpWorkflow> LpstpWorkflowprocess=serviceProvider.getLpstpWorkflowService().findAllByLwWfType(process);
					List<LpstpWorkflow> LpstpWorkflowRCU=serviceProvider.getLpstpWorkflowService().findAllByLwWfType(RCU);
					List<LpstpWorkflow> LpstpWorkflowlegal=serviceProvider.getLpstpWorkflowService().findAllByLwWfType(legal);
					List<LpstpWorkflow> LpstpWorkflowtech=serviceProvider.getLpstpWorkflowService().findAllByLwWfType(tech);
					
					dataHashMap.put("ProcessList", LpstpWorkflowprocess);
					dataHashMap.put("RCUList", LpstpWorkflowRCU);
					dataHashMap.put("LegalList", LpstpWorkflowlegal);
					dataHashMap.put("TechList", LpstpWorkflowtech);
					responseHashMap.put("responseData", dataHashMap);
					
							}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
			}
			else if (dpMethod.equals("getcranList"))
			{
				try {
					
					List<LpstpCranMaster> lpCranMasterlist = new ArrayList<LpstpCranMaster>();
					// serviceProvider.getLpstpCranMasterService().findAll();
					List<Object[]> objectList =serviceProvider.getLpstpCranMasterService().getDistinctCranIdandTitle();
					LpstpCranMaster	modelObject=null;
					for (Object[] objects : objectList) {
						modelObject = new LpstpCranMaster();
						modelObject.setLcmCranId(new BigDecimal(objects[0].toString()));
						modelObject.setLcmCranTitle(objects[1].toString());
						lpCranMasterlist.add(modelObject);
					}
					dataHashMap.put("cranList", lpCranMasterlist);
					responseHashMap.put("responseData", dataHashMap);
					
							}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
			}
			
		}
		catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		return responseHashMap;
	}


}
