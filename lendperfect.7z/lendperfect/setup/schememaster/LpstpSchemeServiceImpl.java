package com.sai.lendperfect.setup.schememaster;

import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpScheme;
import com.sai.lendperfect.setuprepo.LpstpSchemeRepo;


@Service("LpstpSchemeService")
@Transactional

public class LpstpSchemeServiceImpl implements LpstpSchemeService{
	
	
	@Autowired
	LpstpSchemeRepo lpstpSchemeRepo;
	

	@Override
	public LpstpScheme saveLpstpScheme(LpstpScheme lpstpScheme) {
		// TODO Auto-generated method stub
		return lpstpSchemeRepo.save(lpstpScheme);
	}

	@Override
	public List<LpstpScheme> findAllByLsSchemeName(String lsSchemeName) {
		// TODO Auto-generated method stub
		return lpstpSchemeRepo.findAllByLsSchemeName(lsSchemeName);
	}

	
	public List<LpstpScheme> findAllDistinct() {
		return lpstpSchemeRepo.findAllDistinct();
	}

	@Override
	public void deleteAllByLsSchemeId(BigDecimal lsSchemeId) {
		// TODO Auto-generated method stub
		lpstpSchemeRepo.deleteAllByLsSchemeId(lsSchemeId);
		
	}

	@Override
	public List<LpstpScheme> findAllByOrderByLsSchemeId() {
		// TODO Auto-generated method stub
		return lpstpSchemeRepo.findAllByOrderByLsSchemeId();
	}

	@Override
	public List<LpstpScheme> findAllByLsBizVerticalOrderByLsSchemeId(BigDecimal lsBizVertical) {
		// TODO Auto-generated method stub
		return lpstpSchemeRepo.findAllByLsBizVerticalOrderByLsSchemeId(lsBizVertical);
	}


	@Override
	public LpstpScheme findByLsSchemeId(BigDecimal bigDecimal) {
		
		return lpstpSchemeRepo.findByLsSchemeId(bigDecimal);
	}

	public List<LpstpScheme> findAllByLsBizVerticalAndLsActiveOrderByLsSchemeId(BigDecimal lsBizVertical,
			String lsActive) {
		return lpstpSchemeRepo.findAllByLsBizVerticalAndLsActiveOrderByLsSchemeId(lsBizVertical, lsActive);
	}

	@Override
	public LpstpScheme findByLsSchemeId(Long lsSchemeId) {
		// TODO Auto-generated method stub
		return lpstpSchemeRepo.findOne(lsSchemeId);
	}

	@Override
	public LpstpScheme findByLsSubFacility(Long lsSubFacility) {
		return lpstpSchemeRepo.findByLsSubFacility(lsSubFacility);
	}

	
	
	

}
