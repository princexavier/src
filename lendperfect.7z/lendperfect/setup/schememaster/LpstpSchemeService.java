package com.sai.lendperfect.setup.schememaster;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpScheme;

public interface LpstpSchemeService {
	
	LpstpScheme saveLpstpScheme(LpstpScheme lpstpScheme);
	List <LpstpScheme> findAllByLsSchemeName(String lsSchemeName);
	List<LpstpScheme> findAllDistinct();
	void deleteAllByLsSchemeId(BigDecimal lsSchemeId);
	List<LpstpScheme> findAllByOrderByLsSchemeId();
	List<LpstpScheme> findAllByLsBizVerticalOrderByLsSchemeId(BigDecimal lsBizVertical);
	LpstpScheme findByLsSchemeId(BigDecimal lsSchemeId);
	List<LpstpScheme> findAllByLsBizVerticalAndLsActiveOrderByLsSchemeId(BigDecimal lsBizVertical,String lsActive);
	LpstpScheme findByLsSchemeId(Long lsSchemeId);
	LpstpScheme findByLsSubFacility(Long lsSubFacility);

}
