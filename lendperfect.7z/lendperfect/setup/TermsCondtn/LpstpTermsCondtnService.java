package com.sai.lendperfect.setup.TermsCondtn;
import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpTermsCondtn;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;

public interface LpstpTermsCondtnService {
	
	List<LpstpTermsCondtn> findAll();
	LpstpTermsCondtn findById(BigDecimal  ltcId);
	LpstpTermsCondtn saveLpstpTermsCondtn(LpstpTermsCondtn lpstpTermsCondtnlist);
	List<LpstpTermsCondtn> saveLpstpTermsCondtnList(List<LpstpTermsCondtn> lpstpTermsCondtnlist);
	void deleteLpstpTermsCondtn(LpstpTermsCondtn lpstpTermsCondtn);
	List<LpstpTermsCondtn> findAllByLtcTcType(String ltcTcType);

}
