package com.sai.lendperfect.setup.TermsCondtn;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpTermsCondtn;
import com.sai.lendperfect.setuprepo.LpstpTermsCondtnRepo;


@Service("LpstpTermsCondtnService")
@Transactional
public class LpstpTermsCondtnServiceImpl implements LpstpTermsCondtnService {
	
	@Autowired
	LpstpTermsCondtnRepo lpstpTermsCondtnRepo;

	public List<LpstpTermsCondtn> findAll() {
		// TODO Auto-generated method stub
		return lpstpTermsCondtnRepo.findAll();
	}

	@Override
	public LpstpTermsCondtn findById(BigDecimal ltcId) {
		// TODO Auto-generated method stub
		return lpstpTermsCondtnRepo.findOne(ltcId);
	}

	@Override
	public LpstpTermsCondtn saveLpstpTermsCondtn(LpstpTermsCondtn lpstpTermsCondtnlist) {
		// TODO Auto-generated method stub
		return lpstpTermsCondtnRepo.save(lpstpTermsCondtnlist);
	}

	@Override
	public List<LpstpTermsCondtn> saveLpstpTermsCondtnList(List<LpstpTermsCondtn> lpstpTermsCondtnlist) {
		// TODO Auto-generated method stub
		return lpstpTermsCondtnRepo.save(lpstpTermsCondtnlist);
	}

	@Override
	public void deleteLpstpTermsCondtn(LpstpTermsCondtn lpstpTermsCondtn) {
		// TODO Auto-generated method stub
		lpstpTermsCondtnRepo.delete(lpstpTermsCondtn);
		
	}

	@Override
	public List<LpstpTermsCondtn> findAllByLtcTcType(String ltcTcType) {
		// TODO Auto-generated method stub
		return lpstpTermsCondtnRepo.findAllByLtcTcType(ltcTcType);
	}

}
