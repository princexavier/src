package com.sai.lendperfect.setup.TermsCondtn;

import static org.junit.Assert.assertNotNull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.DecimalMax;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpTermsCondtn;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;

public class LpstpTermsCondtnDataProvider {
	
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpTermsCondtnDataProvider.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		try
		{
			
			if(dpMethod.equals("getTermsmatser"))
			{
			try {
				
				LpstpTermsCondtn lpstpTermsCondtn= new LpstpTermsCondtn();
				Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
				String  ltcTcType=(String)requestHashMapnew.get("ltcTcType").toString();
					dataHashMap.put("termsmaster",serviceProvider.getLpstpTermsCondtnService().findAllByLtcTcType(ltcTcType));
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			else if(dpMethod.equals("saveTermsmatser")){	
				try {
					LpstpTermsCondtn lpstpTermsCondtn=new ObjectMapper()
							.convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpTermsCondtn>() {});
					lpstpTermsCondtn.setLpCreatedBy(session.getAttribute("userid").toString());
					lpstpTermsCondtn.setLpModifiedBy(session.getAttribute("userid").toString());
					lpstpTermsCondtn.setLpCreatedOn(new Date());
					lpstpTermsCondtn.setLpModifiedOn(new Date());
					serviceProvider.getLpstpTermsCondtnService().saveLpstpTermsCondtn(lpstpTermsCondtn);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if(dpMethod.equals("deleteTermsmatser")){	
				try {
					Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					LpstpTermsCondtn lpstpTermsCondtn=new LpstpTermsCondtn();
					BigDecimal  ltcId=BigDecimal.valueOf(Long.valueOf((String)requestHashMapnew.get("RowId").toString()));
					lpstpTermsCondtn=serviceProvider.getLpstpTermsCondtnService().findById(ltcId);
					lpstpTermsCondtn.getLtcId();
					serviceProvider.getLpstpTermsCondtnService().deleteLpstpTermsCondtn(lpstpTermsCondtn);
					responseHashMap.put("responseData", dataHashMap);
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			else if (dpMethod.equals("getBusinessVertical"))
			{
				try {
					
					List<LpmasBizVertical> TermBizverticalList=serviceProvider.getLpmasBizVerticalService().findAll();
					dataHashMap.put("BizverticalList", TermBizverticalList);
					responseHashMap.put("responseData", dataHashMap);
					
							}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
			}
			
		}
		catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		return responseHashMap;
	}

}
