package com.sai.lendperfect.setup.scorecardbusinessrule;

//import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpRiskBusinessrule;
import com.sai.lendperfect.setupmodel.LpstpRiskruleCutoffrange;

public interface LpstpRiskruleCutoffrangeService {
	List<LpstpRiskruleCutoffrange> save(List<LpstpRiskruleCutoffrange> lpstpRiskruleCutoffrange) ;	
	List<LpstpRiskruleCutoffrange> findByLpstpRiskBusinessrule(LpstpRiskBusinessrule lpstpRiskBusinessrule);
	void remove(LpstpRiskruleCutoffrange lpstpRiskruleCutoffrange);
}