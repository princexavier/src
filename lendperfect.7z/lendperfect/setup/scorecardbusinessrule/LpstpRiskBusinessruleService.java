package com.sai.lendperfect.setup.scorecardbusinessrule;

import com.sai.lendperfect.setupmodel.LpstpRiskBusinessrule;
import java.util.List;

public interface LpstpRiskBusinessruleService {	
	 List<LpstpRiskBusinessrule> findAll();
	 LpstpRiskBusinessrule findById(Long seqNo);
	 LpstpRiskBusinessrule save(LpstpRiskBusinessrule lpstpRiskBusinessrule);
 }