package com.sai.lendperfect.setup.scorecardbusinessrule;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpRiskBusinessrule;
import com.sai.lendperfect.setupmodel.LpstpRiskruleCutoffrange;
import com.sai.lendperfect.setuprepo.LpstpRiskruleCutoffrangeRepo;

@Service("lpstpRiskruleCutoffrangeService")
@Transactional
public class LpstpRiskruleCutoffrangeServiceImpl implements  LpstpRiskruleCutoffrangeService {
	@Autowired
	LpstpRiskruleCutoffrangeRepo lpstpRiskruleCutoffrangeRepo;

	@Override
	public List<LpstpRiskruleCutoffrange> save(List<LpstpRiskruleCutoffrange> lpstpRiskruleCutoffrange) {
		return lpstpRiskruleCutoffrangeRepo.save(lpstpRiskruleCutoffrange);
	}

	@Override
	public List<LpstpRiskruleCutoffrange> findByLpstpRiskBusinessrule(LpstpRiskBusinessrule lpstpRiskBusinessrule) {		
		return lpstpRiskruleCutoffrangeRepo.findByLpstpRiskBusinessrule(lpstpRiskBusinessrule);
	}

	@Override
	public void remove(LpstpRiskruleCutoffrange lpstpRiskruleCutoffrange) {
		lpstpRiskruleCutoffrangeRepo.delete(lpstpRiskruleCutoffrange);		
	}

	
	
}