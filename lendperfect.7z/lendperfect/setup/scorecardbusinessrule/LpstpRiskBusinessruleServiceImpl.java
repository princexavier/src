package com.sai.lendperfect.setup.scorecardbusinessrule;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpRiskBusinessrule;
import com.sai.lendperfect.setuprepo.LpstpRiskBusinessruleRepo;

@Service("lpstpRiskBusinessruleService")
@Transactional
public class LpstpRiskBusinessruleServiceImpl implements LpstpRiskBusinessruleService{
   
	@Autowired
	private LpstpRiskBusinessruleRepo lpstpRiskBusinessruleRepo;
	
	@Override
	public LpstpRiskBusinessrule save(LpstpRiskBusinessrule lpstpRiskBusinessrule) {		
		return lpstpRiskBusinessruleRepo.save(lpstpRiskBusinessrule);
	}

	@Override
	public List<LpstpRiskBusinessrule> findAll() {		
		return lpstpRiskBusinessruleRepo.findAll();
	}

	@Override
	public LpstpRiskBusinessrule findById(Long seqNo) {		
		return lpstpRiskBusinessruleRepo.findOne(seqNo);
	}

}

