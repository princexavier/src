package com.sai.lendperfect.setup.scorecardbusinessrule;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpRiskBusinessrule;
import com.sai.lendperfect.setupmodel.LpstpRiskruleCutoffrange;
//import com.sai.lendperfect.setupmodel.LpstpScorecardOptionMaster;

public class ScoreCardBusinessRuleDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData, ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		logging.info("method:{}", dpMethod);

		try {
			if (dpMethod.equals("getAllBusinessRules")) {
				try {
					List<LpstpRiskBusinessrule> lpstpRiskBusinessruleList = serviceProvider.getLpstpRiskBusinessruleService().findAll();
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", lpstpRiskBusinessruleList);
				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("saveBusinessRuleData")) {
				try {
					LpstpRiskBusinessrule lpstpRiskBusinessrule;
					List<LpstpRiskruleCutoffrange> lpstpRiskruleCutoffrangelist = new ArrayList<>();
					Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");

					lpstpRiskBusinessrule = new ObjectMapper().convertValue(requestMap.get("master"), new TypeReference<LpstpRiskBusinessrule>() {
					});

					if (lpstpRiskBusinessrule.getLrbSeqNo() == 0) {
						lpstpRiskBusinessrule.setLrbCreatedBy(session.getAttribute("userid").toString());
						lpstpRiskBusinessrule.setLrbCreatedOn(new Date());
						lpstpRiskBusinessrule.setLrbModifiedOn(lpstpRiskBusinessrule.getLrbCreatedOn());
						lpstpRiskBusinessrule.setLrbModifiedBy((session.getAttribute("userid").toString()));
					} else {
						lpstpRiskBusinessrule.setLrbModifiedOn(new Date());
						lpstpRiskBusinessrule.setLrbModifiedBy((session.getAttribute("userid").toString()));
					}
					lpstpRiskBusinessrule = serviceProvider.getLpstpRiskBusinessruleService().save(lpstpRiskBusinessrule);

					List<Map<String, Object>> rangesList = (List<Map<String, Object>>) requestMap.get("cutOffRanges");

					if (rangesList != null && !rangesList.isEmpty()) {
						for (Map<String, Object> inputMap : rangesList) {
							LpstpRiskruleCutoffrange range = new ObjectMapper().convertValue(inputMap, new TypeReference<LpstpRiskruleCutoffrange>() {
							});
							if (range != null) {
								range.setLpstpRiskBusinessrule(lpstpRiskBusinessrule);
								if (range.getLrcSeqNo() == 0) {
									range.setLrcCreatedBy(session.getAttribute("userid").toString());
									range.setLrcCreatedOn(new Date());
									range.setLrcModifiedOn(range.getLrcCreatedOn());
									range.setLrcModifiedBy(session.getAttribute("userid").toString());
								} else {
									range.setLrcModifiedBy(session.getAttribute("userid").toString());
									range.setLrcModifiedOn(new Date());
								}
							}
							lpstpRiskruleCutoffrangelist.add(range);
						}
					}

					lpstpRiskruleCutoffrangelist = serviceProvider.getLpstpRiskruleCutoffrangeService().save(lpstpRiskruleCutoffrangelist);

					responseHashMap.put("success", true);
				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getBusinessRuleById")) {
				try {
					Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");
					Long seqNo = Long.parseLong(requestMap.get("id").toString());
					LpstpRiskBusinessrule lpstpRiskBusinessrule = serviceProvider.getLpstpRiskBusinessruleService().findById(seqNo);
					List<LpstpRiskruleCutoffrange> lpstpRiskruleCutoffrangelist = serviceProvider.getLpstpRiskruleCutoffrangeService().findByLpstpRiskBusinessrule(lpstpRiskBusinessrule);
					responseHashMap.put("success", true);
					responseHashMap.put("master", lpstpRiskBusinessrule);
					responseHashMap.put("ranges", lpstpRiskruleCutoffrangelist);

				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("deleteRange")) {
				try {
					LpstpRiskruleCutoffrange lpstpRiskruleCutoffrange = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpRiskruleCutoffrange>() {
					});
					serviceProvider.getLpstpRiskruleCutoffrangeService().remove(lpstpRiskruleCutoffrange);
					responseHashMap.put("success", true);
				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else {
				dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		} catch (Exception e) {
			e.printStackTrace();
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}
		return responseHashMap;
	}
}
