package com.sai.lendperfect.setup.PrdDocument;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpPrdDoc;

public interface LpstpPrdDocService {
	
	List<LpstpPrdDoc> findAll();
	LpstpPrdDoc findById(BigDecimal lpdRowId);
	List<LpstpPrdDoc> saveLpstpPrdDocList(List<LpstpPrdDoc> lpstpPrdDocList);
	List<LpstpPrdDoc> findAllByLpdProdId(BigDecimal lpdProdId);
	void deleteAllByLpdProdId(BigDecimal lpdProdId);
	void deleteAllByLpdProdIdAndLpdDocId(BigDecimal lpdProdId,String lpdDocId);
	
	List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocId(BigDecimal lpdProdId,BigDecimal lpdDocId);
	List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocType(BigDecimal lpdProdId,String lpdDocType);
	void deleteLpstpPrdDoc(LpstpPrdDoc lpstpPrdDoc);
	List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocTypeAndLpdDocFor(BigDecimal lpdProdId,String lpdDocType,String lpdDocFor);
	List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocFor(BigDecimal bigDecimal, String string);
	List<LpstpPrdDoc> findAllByLpdDocType(String lpdDocType);

}
