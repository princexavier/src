package com.sai.lendperfect.setup.PrdDocument;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdDoc;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ServiceProvider;

public class LpstpPrdDocDataProvider {

	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpPrdDocDataProvider.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		BigDecimal  lpdProdId=new BigDecimal((String) requestHashMap.get("prdid").toString());
		String  lpdDocFor=(String) requestHashMap.get("lptcTermsFor");
		
		String lpdDocType="";
		try{
			if(dpMethod.equals("getprddocument"))
			{
			try {
				lpdDocType="B";
				dataHashMap.put("prddocumentlistbank",responseHashMap.put("prddocumentlistbank", serviceProvider.getLpstpPrdDocService().findAllByLpdProdIdAndLpdDocTypeAndLpdDocFor(lpdProdId, lpdDocType, lpdDocFor)));
				lpdDocType="C";
				dataHashMap.put("prddocumentlistcustomer",responseHashMap.put("prddocumentlistcustomer", serviceProvider.getLpstpPrdDocService().findAllByLpdProdIdAndLpdDocTypeAndLpdDocFor(lpdProdId, lpdDocType, lpdDocFor)));
				responseHashMap.put("lpdProdId", lpdProdId);	
				responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			else if(dpMethod.equals("saveprddocsearch")){	
				try {
					Map<String, Object> modelMap = new HashMap<String, Object>();
					List<Map<String,Object>> lpstpPrdDocList=(List<Map<String, Object>>) requestHashMap.get("SearchAlllist");
					Iterator<Map<String,Object>> lpstpPrdDocListItr=lpstpPrdDocList.iterator();
					ArrayList<Map<String, Object>> lpstpPrdDocListnew = new ArrayList<Map <String, Object>>();
					while(lpstpPrdDocListItr.hasNext())
					{
						Map<String,Object> documents=lpstpPrdDocListItr.next();
						modelMap=new HashMap();
						modelMap.put("lpdDocId", documents.get("CommonVal"));
						modelMap.put("lpdDocType", documents.get("Commontype"));
						modelMap.put("lpdDocDesc", documents.get("CommonDesc"));
						modelMap.put("lpdCompleted","S");
 						modelMap.put("lpdCreatedBy","mrd");
						modelMap.put("lpdModifiedBy", "mrd");
						modelMap.put("lpdCreatedOn", new Date());
						modelMap.put("lpdModifiedOn", new Date());
						modelMap.put("lpdProdId", lpdProdId);
						modelMap.put("lpdDocFor",lpdDocFor);
						
						lpstpPrdDocListnew.add(modelMap);
						
						
					}
					List<LpstpPrdDoc> lpstpPrdDoc=new ObjectMapper()
							.convertValue(lpstpPrdDocListnew,new TypeReference<List<LpstpPrdDoc>>() {});
					serviceProvider.getLpstpPrdDocService().saveLpstpPrdDocList(lpstpPrdDoc);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			
			else if(dpMethod.equals("saveprddocument")){	
				try {
					
					List<LpstpPrdDoc> lpstpPrdDocListbank=new ObjectMapper()
							.convertValue(requestHashMap.get("optionsFieldArraybank"),new TypeReference<List<LpstpPrdDoc>>() {});
					List<LpstpPrdDoc> lpstpPrdDocListcustomer=new ObjectMapper()
							.convertValue(requestHashMap.get("optionsFieldArraycustomer"),new TypeReference<List<LpstpPrdDoc>>() {});
					
					Iterator<LpstpPrdDoc> lpstpPrdDocListbankItr= lpstpPrdDocListbank.iterator();
					Iterator<LpstpPrdDoc> lpstpPrdDocListcustomerItr= lpstpPrdDocListcustomer.iterator();
					
					while(lpstpPrdDocListbankItr.hasNext())
					{
						LpstpPrdDoc lpstpPrdDocbank=lpstpPrdDocListbankItr.next();
						lpstpPrdDocbank.setLpdCreatedBy("sysetm");
						lpstpPrdDocbank.setLpdModifiedBy("sysetm");
						lpstpPrdDocbank.setLpdCreatedOn(new Date());
						lpstpPrdDocbank.setLpdModifiedOn(new Date());
						lpstpPrdDocbank.setLpdProdId(lpdProdId);
						
					}
					while(lpstpPrdDocListcustomerItr.hasNext())
					{
						LpstpPrdDoc lpstpPrdDoccustomer=lpstpPrdDocListcustomerItr.next();
						lpstpPrdDoccustomer.setLpdCreatedBy("sysetm");
						lpstpPrdDoccustomer.setLpdModifiedBy("sysetm");
						lpstpPrdDoccustomer.setLpdCreatedOn(new Date());
						lpstpPrdDoccustomer.setLpdModifiedOn(new Date());
						lpstpPrdDoccustomer.setLpdProdId(lpdProdId);
						
					}
					
					
					serviceProvider.getLpstpPrdDocService().saveLpstpPrdDocList(lpstpPrdDocListbank);
					serviceProvider.getLpstpPrdDocService().saveLpstpPrdDocList(lpstpPrdDocListcustomer);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			 //delete all
			else if(dpMethod.equals("deleteAllprddocument")){	
					try {
						serviceProvider.getLpstpPrdDocService().deleteAllByLpdProdId(lpdProdId);
						responseHashMap.put("responseData", dataHashMap);
					}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
			 //delete single reference
			else if(dpMethod.equals("deleteprddocument")){	
					try {
						Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
						BigDecimal  lpdRowId=BigDecimal.valueOf(Long.valueOf((String)requestHashMapnew.get("RowId").toString()));
						BigDecimal  lpdDocId=BigDecimal.valueOf(Long.valueOf((String)requestHashMapnew.get("DocId").toString()));
						LpstpPrdDoc lpstpPrdDoc=new LpstpPrdDoc();
						lpstpPrdDoc=serviceProvider.getLpstpPrdDocService().findById(lpdRowId);
						serviceProvider.getLpstpPrdDocService().deleteLpstpPrdDoc(lpstpPrdDoc);
						responseHashMap.put("responseData", dataHashMap);
					}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
	return responseHashMap;
	}
}
