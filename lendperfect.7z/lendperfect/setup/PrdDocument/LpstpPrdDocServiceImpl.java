package com.sai.lendperfect.setup.PrdDocument;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpPrdDoc;
import com.sai.lendperfect.setuprepo.LpstpPrdDocRepo;

@Service("LpstpPrdDocService")
@Transactional

public class LpstpPrdDocServiceImpl implements LpstpPrdDocService {

	@Autowired
	LpstpPrdDocRepo lpstpPrdDocRepo;
	
	public List<LpstpPrdDoc> findAll() {
		// TODO Auto-generated method stub
		return lpstpPrdDocRepo.findAll();
	}

	@Override
	public LpstpPrdDoc findById(BigDecimal lpdRowId) {
		// TODO Auto-generated method stub
		return lpstpPrdDocRepo.findOne(lpdRowId);
	}

	@Override
	public List<LpstpPrdDoc> saveLpstpPrdDocList(List<LpstpPrdDoc> lpstpPrdDocList) {
		// TODO Auto-generated method stub
		return lpstpPrdDocRepo.save(lpstpPrdDocList);
	}

	@Override
	public List<LpstpPrdDoc> findAllByLpdProdId(BigDecimal lpdProdId) {
		// TODO Auto-generated method stub
		return lpstpPrdDocRepo.findAllByLpdProdId(lpdProdId);
	}

	@Override
	public void deleteAllByLpdProdId(BigDecimal lpdProdId) {
		// TODO Auto-generated method stub
		lpstpPrdDocRepo.deleteAllByLpdProdId(lpdProdId);
		
	}

	@Override
	public void deleteAllByLpdProdIdAndLpdDocId(BigDecimal lpdProdId, String lpdDocId) {
		// TODO Auto-generated method stub
		lpstpPrdDocRepo.deleteAllByLpdProdIdAndLpdDocId(lpdProdId,lpdDocId);
		
	}

	@Override
	public List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocId(BigDecimal lpdProdId, BigDecimal lpdDocId) {
		// TODO Auto-generated method stub
		return lpstpPrdDocRepo.findAllByLpdProdIdAndLpdDocId(lpdProdId,lpdDocId);
	}

	@Override
	public List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocType(BigDecimal lpdProdId, String lpdDocType) {
		// TODO Auto-generated method stub
		return lpstpPrdDocRepo.findAllByLpdProdIdAndLpdDocType(lpdProdId,lpdDocType);
	}

	@Override
	public void deleteLpstpPrdDoc(LpstpPrdDoc lpstpPrdDoc) {
		// TODO Auto-generated method stub
		lpstpPrdDocRepo.delete(lpstpPrdDoc);
	}

	@Override
	public List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocTypeAndLpdDocFor(BigDecimal lpdProdId, String lpdDocType,
			String lpdDocFor) {
		// TODO Auto-generated method stub
		return lpstpPrdDocRepo.findAllByLpdProdIdAndLpdDocTypeAndLpdDocFor(lpdProdId, lpdDocType, lpdDocFor);
	}

	@Override
	public List<LpstpPrdDoc> findAllByLpdProdIdAndLpdDocFor(BigDecimal bigDecimal, String string) {
		// TODO Auto-generated method stub
		return lpstpPrdDocRepo.findAllByLpdProdIdAndLpdDocFor(bigDecimal,string);
	}

	public List<LpstpPrdDoc> findAllByLpdDocType(String lpdDocType){
		return lpstpPrdDocRepo.findAllByLpdDocType(lpdDocType);
	}
}
