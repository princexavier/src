package com.sai.lendperfect.setup.deviation;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpCranMaster;
import com.sai.lendperfect.setupmodel.LpstpDeviation;


public interface LpstpDeviationService {

	List<LpstpDeviation> findAllByLdSchemeIdOrderByLdRuleId(BigDecimal buzId);

	void saveDeviation(LpstpDeviation lpstpDeviation);

	List<LpstpDeviation> findByLdSchemeIdOrderByLdRuleId(BigDecimal buzId);
}
