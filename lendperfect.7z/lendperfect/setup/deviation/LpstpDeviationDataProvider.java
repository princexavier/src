package com.sai.lendperfect.setup.deviation;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.mastermodel.LpmasGlobalVariable;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.setupmodel.LpstpDeviation;
import com.sai.lendperfect.setupmodel.LpstpFinFormula;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.LpstpScheme;

public class LpstpDeviationDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		try {
			if (dpMethod.equals("getAllDeviationPageData")) {
				try    
				{
					List<LpmasBizVertical> lpmasBizVerticalsList = serviceProvider.getLpmasBizVerticalService().findByLbvActive("Y");
					List<LpmasGlobalVariable> lpcomGlobalVariableList =serviceProvider.getLpstpGlobalVariableService().findAll();
					List<LpmasListofvalue> lpmasListofvalueList =serviceProvider.getLpmasListofvalueService().findByLlvHeaderAndLlvActive("USER_CLASS", "Y");
					dataHashMap.put("globalVariableDataList",lpcomGlobalVariableList);
					dataHashMap.put("businessVerticalList",lpmasBizVerticalsList);
					dataHashMap.put("listofvalueList",lpmasListofvalueList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);
				}catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,
								ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}else if(dpMethod.equals("getListOfValues"))
			{
				try
				{
					long lgvId  = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<Long>() { });
					LpmasGlobalVariable lpmasGlobalVariable=serviceProvider.getLpstpGlobalVariableService().findByLgvId(Helper.convertLong(lgvId));
					List<LpmasListofvalue> lpmasListofvaluesList = new ArrayList();
					if(lpmasGlobalVariable!=null)
					{
						lpmasListofvaluesList =serviceProvider.getLpmasListofvalueService().findByLlvHeader(Helper.correctNull(lpmasGlobalVariable.getLgvLovRef()));
					}
					List<LpmasGlobalVariable> lpcomGlobalVariableList =serviceProvider.getLpstpGlobalVariableService().findAll();
					dataHashMap.put("globalVariableDataList",lpcomGlobalVariableList);
					dataHashMap.put("listOfValues",lpmasListofvaluesList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap); 
				}catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,
								ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}else if(dpMethod.equals("getProductList"))
			{
				try
				{
//					BigDecimal buzId  = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<BigDecimal>() { });
//					
//					List<LpstpScheme> lpstpSchemeList = serviceProvider.getLpstpSchemeService().findAllByLsBizVerticalOrderByLsSchemeId(buzId);
//					dataHashMap.put("productList",lpstpSchemeList);
					List<LpstpProductDet> lpstpProductDetlist = serviceProvider.getLpstpProductDetService().findAllByLpdActiveAndLpdComplete("Y", "Y");
					dataHashMap.put("productList",lpstpProductDetlist);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap); 
				}catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,
								ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}else if(dpMethod.equals("getDeviationList"))
			{
				try
				{
					BigDecimal buzId  = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<BigDecimal>() { });
					List<LpstpDeviation> lpstpDeviationList = serviceProvider.getLpstpDeviationService().findAllByLdSchemeIdOrderByLdRuleId(buzId);
					dataHashMap.put("deviationList",lpstpDeviationList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap); 
				}catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,
								ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}else if(dpMethod.equals("saveDeviation"))
			{
				try
				{
					LpstpDeviation lpstpDeviation=new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpDeviation>() {});
					lpstpDeviation.setLdCreatedBy("ssk");
					lpstpDeviation.setLdCreatedOn(Helper.getSystemDate());
					lpstpDeviation.setLdModifiedBy("ssk");
					lpstpDeviation.setLdModifedOn(Helper.getSystemDate());
					serviceProvider.getLpstpDeviationService().saveDeviation(lpstpDeviation);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap); 
				}catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,
								ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
		} catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,
						ex.getMessage());
				dataHashMap.put("errorData", new CustomErr(ex.getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
		}
		return responseHashMap;
	}
}
