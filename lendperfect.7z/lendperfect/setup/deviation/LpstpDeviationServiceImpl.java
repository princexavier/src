package com.sai.lendperfect.setup.deviation;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpCranMaster;
import com.sai.lendperfect.setupmodel.LpstpCranTemplate;
import com.sai.lendperfect.setupmodel.LpstpDeviation;
import com.sai.lendperfect.setuprepo.LpstpCranMasterRepo;
import com.sai.lendperfect.setuprepo.LpstpCranTemplateRepo;
import com.sai.lendperfect.setuprepo.LpstpDeviationRepo;


@Service("LpstpDeviationService")
@Transactional
public class LpstpDeviationServiceImpl implements LpstpDeviationService{

	@Autowired
	LpstpDeviationRepo lpstpDeviationRepo;


	@Override
	public List<LpstpDeviation> findAllByLdSchemeIdOrderByLdRuleId(BigDecimal buzId) {
		return lpstpDeviationRepo.findAllByLdSchemeIdOrderByLdRuleId(buzId);
	}

	@Override
	public List<LpstpDeviation> findByLdSchemeIdOrderByLdRuleId(BigDecimal buzId) {
		return lpstpDeviationRepo.findByLdSchemeIdOrderByLdRuleId(buzId);
	}


	@Override
	public void saveDeviation(LpstpDeviation lpstpDeviation) {
		lpstpDeviationRepo.saveAndFlush(lpstpDeviation);
		
	}
	
	


}
