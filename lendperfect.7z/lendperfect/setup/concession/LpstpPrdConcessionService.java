package com.sai.lendperfect.setup.concession;
import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPrdConcession;
import com.sai.lendperfect.setupmodel.SetOrgLevel;

public interface LpstpPrdConcessionService {

    LpstpPrdConcession savePrdConcession(LpstpPrdConcession lpstpPrdConcession);

	LpstpPrdConcession findAll();

	LpstpPrdConcession findByLpcProdId(long lpdProdId);

	List<LpstpPrdConcession> findByLpcProdIdOrderByLpcRowId(Long lpcProdId);

}
