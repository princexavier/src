package com.sai.lendperfect.setup.concession;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustApplicantEduCourseExp;
//import com.google.gson.Gson;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdConcession;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public class LpstpPrdConcessionDataProvider {
	
	@SuppressWarnings("rawtypes")
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		String userid = (String) session.getAttribute("userid");
		LpstpPrdConcession lpstpPrdConcession=new LpstpPrdConcession();
		
	   if(dpMethod.equals("getPrdConcession"))
		{
		   BigDecimal lpdProdId=new BigDecimal(allRequestParams.get("requestData").toString());
		   LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(lpdProdId.longValue()));
		   if(lpstpProductDetfromDB!=null)
		   {
			   LpstpPrdConcession lpstpPrdConcession1 =serviceProvider.getLpstpPrdConcessionService().findByLpcProdId(lpdProdId.longValue());
			   LpstpPrdConcession lpstpPrdConcession2 = new ObjectMapper().convertValue(lpstpPrdConcession1, LpstpPrdConcession.class);
			   dataHashMap.put("lpstpPrdConcession",lpstpPrdConcession2);
			   responseHashMap.put("success", true);
			   responseHashMap.put("responseData", dataHashMap);
		   }else
		   {
			   	dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		   }
		  
		}

	   else	if(dpMethod.equals("savePrdConcession"))
	    {	
		  
		   LpstpPrdConcession lpstpPrdConcession1 = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpPrdConcession>() { });
		   	 if(lpstpPrdConcession1.getLpcRowId()==0)
		   	 {
		   		lpstpPrdConcession1.setLpcCreatedBy(session.getAttribute("userid").toString());
				lpstpPrdConcession1.setLpcCreatedOn(Helper.getSystemDate());	 
		   	 }
			lpstpPrdConcession1.setLpcModifedBy(session.getAttribute("userid").toString());
			lpstpPrdConcession1.setLpcModifiedOn(Helper.getSystemDate());
			lpstpPrdConcession1.setLpcRowId(lpstpPrdConcession1.getLpcRowId());
			
			responseHashMap.put("responseData", serviceProvider.getLpstpPrdConcessionService().savePrdConcession(lpstpPrdConcession1));
			responseHashMap.put("success", true);
		}

		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}

}
