package com.sai.lendperfect.setup.concession;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setuprepo.LpstpPrdConcessionRepo;
import com.sai.lendperfect.setup.concession.LpstpPrdConcessionService;
import com.sai.lendperfect.setupmodel.LpstpPrdConcession;




@Service("lpstpPrdConcessionService")
@Transactional
public class LpstpPrdConcessionServiceImpl implements LpstpPrdConcessionService{

	@Autowired
	LpstpPrdConcessionRepo lpstpPrdConcessionRepo;

	@Override
	public LpstpPrdConcession savePrdConcession(LpstpPrdConcession lpstpPrdConcession) {
		 return lpstpPrdConcessionRepo.save(lpstpPrdConcession);
	}

	@Override
	public LpstpPrdConcession findAll() {
		return (LpstpPrdConcession) lpstpPrdConcessionRepo.findAll();
	}

	@Override
	public LpstpPrdConcession findByLpcProdId(long lpdProdId) {
		// TODO Auto-generated method stub
		return lpstpPrdConcessionRepo.findByLpcProdId(lpdProdId);
	}


//	@Override
//	public void deletePrdProfee(List<LpstpPrdConcession> lpstpPrdDocFee1) {
//		lpstpPrdDocFeeRepo.delete(lpstpPrdDocFee1);
//	}
//
	@Override
	public List<LpstpPrdConcession> findByLpcProdIdOrderByLpcRowId(Long lpfProdId) {
		return lpstpPrdConcessionRepo.findByLpcProdIdOrderByLpcRowId(lpfProdId);
	}
//
//	@Override
//	public 	List<LpstpPrdProFee> getIntRateByPrdId(Long prdId) {
//		return lpstpPrdDocFeeRepo.findByLpfProdIdOrderByLpfRowId(prdId);
//	}


	
}
