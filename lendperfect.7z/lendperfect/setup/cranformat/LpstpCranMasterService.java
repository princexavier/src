package com.sai.lendperfect.setup.cranformat;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpCranMaster;


public interface LpstpCranMasterService {

	List getCranMasterData(String verticalName,BigDecimal cranId);

	void saveCranMasterList(List<LpstpCranMaster> lpstpCranMasterList);

	void deleteCranMasterByVertial(List<LpstpCranMaster> lpstpCranMasterList);
	
	public List<LpstpCranMaster> getCranMasterByVertialAndCranId(BigDecimal verticalName,BigDecimal cranId);

	List getCranMasterByVerticalName(String verticalName);

	List getCranTitleList(BigDecimal verticalName);
	
	List findAll();

	BigDecimal getMaxCranId();

	List<LpstpCranMaster> findByLcmCranIdOrderByLcmTempSeq(BigDecimal lsCranId);
	List<Object[]> getDistinctCranIdandTitle();
}
