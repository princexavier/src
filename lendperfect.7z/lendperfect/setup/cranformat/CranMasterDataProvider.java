package com.sai.lendperfect.setup.cranformat;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpCranMaster;
import com.sai.lendperfect.setupmodel.LpstpCranTemplate;

public class CranMasterDataProvider {
	
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
			
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
	   
		
	if(dpMethod.equals("getCranMasterData"))
	   {
		    String verticalName = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<String>() { });
		    String cranId = new ObjectMapper().convertValue(allRequestParams.get("requestData1"), new TypeReference<String>() { });
		    cranId= cranId.substring(0, cranId.trim().indexOf("-"));
		    List lpCranMasterlist = serviceProvider.getLpstpCranMasterService().getCranMasterData(verticalName,new BigDecimal(cranId));
		    dataHashMap.put("lpCranMasterListBasedOnTitle",lpCranMasterlist);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	   
	   else if(dpMethod.equals("getCranMasterDataByVerticalName"))
	   {
		    String verticalName = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<String>() { });
		    List lpCranMasterlist = serviceProvider.getLpstpCranMasterService().getCranMasterByVerticalName(verticalName);
		    List titleList = serviceProvider.getLpstpCranMasterService().getCranTitleList(new BigDecimal(verticalName));
		    dataHashMap.put("lpCranMasterList",lpCranMasterlist);
		    dataHashMap.put("titleList",titleList);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	   
	   else if(dpMethod.equals("saveCranMasterData"))
		{
			LpstpCranMaster lpstpCranMaster = new ObjectMapper().convertValue(allRequestParams.get("requestData1"), new TypeReference<LpstpCranMaster>() {});
			//List<Object[]> templateList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<Object[]>>() {});
			String actionName = new ObjectMapper().convertValue(allRequestParams.get("requestData2"), new TypeReference<String>() { });
			List<LpstpCranMaster> lpstpCranMasterList=new ArrayList();
		
			if(actionName.equalsIgnoreCase("Edit"))
			{    
				 String dPart = Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).substring(0, Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).trim().indexOf("-"));
				 List<LpstpCranMaster> lpCranMasterlist = serviceProvider.getLpstpCranMasterService().getCranMasterByVertialAndCranId(lpstpCranMaster.getLcmVertical(),new BigDecimal(dPart));
				 serviceProvider.getLpstpCranMasterService().deleteCranMasterByVertial(lpCranMasterlist);
			}else
			{
				
			}
			BigDecimal cranId= serviceProvider.getLpstpCranMasterService().getMaxCranId();
			
			List<Map<String,Object>> lpCranlistMap=(List<Map<String,Object>>)allRequestParams.get("requestData");
			 
			Iterator lpCranlistMapItr=lpCranlistMap.iterator();
			
			while(lpCranlistMapItr.hasNext())
			{
				Map<String,Object> lpcranMap=(Map<String,Object>)lpCranlistMapItr.next();
				LpstpCranTemplate lpstpCranTemplate = new LpstpCranTemplate();
				LpstpCranMaster lpstpCranMast=new LpstpCranMaster();
				lpstpCranTemplate.setLctTempId(((Integer)lpcranMap.get("temp_id")));
				lpstpCranTemplate.setLctTempCompnt(lpcranMap.get("temp_component").toString());
				lpstpCranTemplate.setLctTempDesc(lpcranMap.get("temp_desc").toString());
				lpstpCranTemplate.setLctTempVertical(lpcranMap.get("temp_vertical").toString());
				lpstpCranMast.setLcmTempSeq(new BigDecimal(lpcranMap.get("temp_seq").toString()));
				lpstpCranMast.setLpstpCranTemplate(lpstpCranTemplate);
				lpstpCranMast.setLcmCreatedBy("abi");
				lpstpCranMast.setLcmCranId(cranId);
				lpstpCranMast.setLcmCreatedOn(Helper.getSystemDate());
				lpstpCranMast.setLcmModifiedBy("abi");
				lpstpCranMast.setLcmModifiedOn(Helper.getSystemDate());
				if(actionName.equalsIgnoreCase("Edit"))
				{
					 String dPart = Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).substring(
							 Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).trim().indexOf("-") + 1, Helper.correctNull(lpstpCranMaster.getLcmCranTitle())
			                    .trim().length());
					
					lpstpCranMast.setLcmCranTitle(dPart);
				}else
				{
					lpstpCranMast.setLcmCranTitle(lpstpCranMaster.getLcmCranTitle());
				}
				lpstpCranMast.setLcmVertical(lpstpCranMaster.getLcmVertical());
				lpstpCranMasterList.add(lpstpCranMast);
				
			}
			
			
		//
//			for(int i = 0 ;i<templateList.size();i++)
//			{
//				Object[] objlist = templateList.get(i);
//				if(!Helper.correctNull(String.valueOf(objlist[6])).equalsIgnoreCase(""))
//				{
//					if(objlist[6] instanceof Boolean)
//					{
//						if((String.valueOf(objlist[6])).equalsIgnoreCase("true"))
//						{
//							LpstpCranTemplate lpstpCranTemplate = new LpstpCranTemplate();
//							LpstpCranMaster lpstpCranMast=new LpstpCranMaster();
//							lpstpCranTemplate.setLctTempId(((Integer)objlist[1]).longValue());
//							lpstpCranTemplate.setLctTempCompnt((String)objlist[3]);
//							lpstpCranTemplate.setLctTempDesc((String)objlist[2]);
//							lpstpCranTemplate.setLctTempVertical(String.valueOf(objlist[1]));
//							lpstpCranMast.setLcmTempSeq(new BigDecimal(String.valueOf(objlist[7])));
//							lpstpCranMast.setLpstpCranTemplate(lpstpCranTemplate);
//							lpstpCranMast.setLcmCreatedBy("abi");
//							lpstpCranMast.setLcmCranId(cranId);
//							lpstpCranMast.setLcmCreatedOn(Helper.getSystemDate());
//							lpstpCranMast.setLcmModifiedBy("abi");
//							lpstpCranMast.setLcmModifiedOn(Helper.getSystemDate());
//							if(actionName.equalsIgnoreCase("Edit"))
//							{
//								 String dPart = Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).substring(
//										 Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).trim().indexOf("-") + 1, Helper.correctNull(lpstpCranMaster.getLcmCranTitle())
//						                    .trim().length());
//								lpstpCranMast.setLcmCranTitle(dPart);
//							}else
//							{
//								lpstpCranMast.setLcmCranTitle(lpstpCranMaster.getLcmCranTitle());
//							}
//							lpstpCranMast.setLcmVertical(lpstpCranMaster.getLcmVertical());
//							lpstpCranMasterList.add(lpstpCranMast);
//						}
//					}else
//					{
//						 if(((Integer)objlist[6]).longValue()>0)
//						{
//							LpstpCranTemplate lpstpCranTemplate = new LpstpCranTemplate();
//							LpstpCranMaster lpstpCranMast=new LpstpCranMaster();
//							lpstpCranTemplate.setLctTempId(((Integer)objlist[1]).longValue());
//							lpstpCranTemplate.setLctTempCompnt((String)objlist[3]);
//							lpstpCranTemplate.setLctTempDesc((String)objlist[2]);
//							lpstpCranTemplate.setLctTempVertical(String.valueOf(objlist[1]));
//							lpstpCranMast.setLcmTempSeq(new BigDecimal(String.valueOf(objlist[7])));
//							lpstpCranMast.setLpstpCranTemplate(lpstpCranTemplate);
//							lpstpCranMast.setLcmCreatedBy("abi");
//							lpstpCranMast.setLcmCranId(cranId);
//							lpstpCranMast.setLcmCreatedOn(Helper.getSystemDate());
//							lpstpCranMast.setLcmModifiedBy("abi");
//							lpstpCranMast.setLcmModifiedOn(Helper.getSystemDate());
//							if(actionName.equalsIgnoreCase("Edit"))
//							{
//								 String dPart = Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).substring(
//										 Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).trim().indexOf("-") + 1, Helper.correctNull(lpstpCranMaster.getLcmCranTitle())
//						                    .trim().length());
//								lpstpCranMast.setLcmCranTitle(dPart);
//							}else
//							{
//								lpstpCranMast.setLcmCranTitle(lpstpCranMaster.getLcmCranTitle());
//							}
//							lpstpCranMast.setLcmVertical(lpstpCranMaster.getLcmVertical());
//							lpstpCranMasterList.add(lpstpCranMast);
//						}
//					}
//				}		
//			}
			serviceProvider.getLpstpCranMasterService().saveCranMasterList(lpstpCranMasterList);
			
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", lpstpCranMasterList);
		}
	   
//	   else if(dpMethod.equals("deleteCranMasterData"))
//		{
//			LpstpCranMaster lpstpCranMaster = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpCranMaster>() {});
//			String dPart = Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).substring(0, Helper.correctNull(lpstpCranMaster.getLcmCranTitle()).trim().indexOf("-"));
//			List<LpstpCranMaster> lpCranMasterlist = serviceProvider.getLpstpCranMasterService().getCranMasterByVertialAndCranId(lpstpCranMaster.getLcmVertical(),new BigDecimal(dPart));
//			serviceProvider.getLpstpCranMasterService().deleteCranMasterByVertial(lpCranMasterlist);
//			responseHashMap.put("success", true);
//			responseHashMap.put("responseData", dataHashMap);
//		}
	
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
		
		
	}
	
	

}
