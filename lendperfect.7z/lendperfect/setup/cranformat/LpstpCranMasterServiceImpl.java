package com.sai.lendperfect.setup.cranformat;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpCranMaster;
import com.sai.lendperfect.setupmodel.LpstpCranTemplate;
import com.sai.lendperfect.setuprepo.LpstpCranMasterRepo;
import com.sai.lendperfect.setuprepo.LpstpCranTemplateRepo;


@Service("LpstpCranMasterService")
@Transactional
public class LpstpCranMasterServiceImpl implements LpstpCranMasterService{

	@Autowired
	LpstpCranMasterRepo lpstpCranMasterRepo;
	
	@Autowired
	LpstpCranTemplateRepo lpstpCranTemplateRepo;
	
	@Override
	public List getCranMasterData(String verticalName,BigDecimal cranId) {
		return lpstpCranTemplateRepo.getCranMasterData(verticalName,cranId);
	}

	@Override
	public void saveCranMasterList(List<LpstpCranMaster> lpstpCranMasterList) {
		 lpstpCranMasterRepo.save(lpstpCranMasterList);
	}

	@Override
	public void deleteCranMasterByVertial(List<LpstpCranMaster> lpstpCranMasterList) {
		 lpstpCranMasterRepo.delete(lpstpCranMasterList);
	}
	@Override
	public List<LpstpCranMaster> getCranMasterByVertialAndCranId(BigDecimal verticalName,BigDecimal cranId) {
		return lpstpCranMasterRepo.findByLcmVerticalAndLcmCranId(verticalName,cranId);
	}

	@Override
	public List getCranMasterByVerticalName(String verticalName) {
		return lpstpCranTemplateRepo.getCranMasterByVerticalName(verticalName);
	}

	@Override
	public List getCranTitleList(BigDecimal verticalName) {
		return lpstpCranMasterRepo.getCranTitleList(verticalName);
	}
	@Override
	public BigDecimal getMaxCranId() {
		return lpstpCranMasterRepo.getMaxCranId();
	}
	
	@Override
	public List findAll() {
		return lpstpCranMasterRepo.findAll();
	}

	@Override
	public List<LpstpCranMaster> findByLcmCranIdOrderByLcmTempSeq(BigDecimal lsCranId) {
		return lpstpCranMasterRepo.findByLcmCranIdOrderByLcmTempSeq(lsCranId);
	}

	@Override
	public List<Object[]> getDistinctCranIdandTitle() {
		return lpstpCranMasterRepo.getDistinctCranIdandTitle();
	}


}
