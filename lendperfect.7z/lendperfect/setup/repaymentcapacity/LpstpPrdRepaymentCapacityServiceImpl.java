package com.sai.lendperfect.setup.repaymentcapacity;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setuprepo.LpstpPrdRepayCapacityRepo;
import com.sai.lendperfect.setup.repaymentcapacity.LpstpPrdRepaymentCapacityService;
import com.sai.lendperfect.setupmodel.LpstpPrdRepayCapacity;




@Service("lpstpPrdRepayCapacityService")
@Transactional
public class LpstpPrdRepaymentCapacityServiceImpl implements LpstpPrdRepaymentCapacityService{

	@Autowired
	LpstpPrdRepayCapacityRepo lpstpPrdRepayCapacityRepo;

	@Override
	public List<LpstpPrdRepayCapacity> savePrdRepaymentcapacity(List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacity) {
		 return lpstpPrdRepayCapacityRepo.save(lpstpPrdRepayCapacity);
	}

	@Override
	public List<LpstpPrdRepayCapacity> findAll() {
		return lpstpPrdRepayCapacityRepo.findAll();
	}

	@Override
	public void deletePrdRepaymentcapacity(List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacity1) {
		lpstpPrdRepayCapacityRepo.delete(lpstpPrdRepayCapacity1);
	}

	@Override
	public List<LpstpPrdRepayCapacity> findByLrcProdIdOrderByLrcRowId(Long lrcProdId) {
		return lpstpPrdRepayCapacityRepo.findByLrcProdIdOrderByLrcRowId(lrcProdId);
	}

	@Override
	public 	List<LpstpPrdRepayCapacity> getRepayCapacityByPrdId(Long  prdId) {
		return lpstpPrdRepayCapacityRepo.findByLrcProdIdOrderByLrcRowId(prdId);
	}

	@Override
	public String findRepayCapacityPerc(long prdCode, BigDecimal finalNetIncome) {
		
		return lpstpPrdRepayCapacityRepo.findRepayCapacityPerc(prdCode, finalNetIncome);
	}


	
}
