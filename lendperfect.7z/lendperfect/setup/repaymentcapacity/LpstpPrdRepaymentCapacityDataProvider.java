package com.sai.lendperfect.setup.repaymentcapacity;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONObject;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdCoappguacount;
import com.sai.lendperfect.setupmodel.LpstpPrdRepayCapacity;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public class LpstpPrdRepaymentCapacityDataProvider {
	
	@SuppressWarnings("rawtypes")
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		String userid = (String) session.getAttribute("userid");
	   if(dpMethod.equals("getPrdRepaymentCapacity"))
		{
		   BigDecimal lpdProdId=new BigDecimal(allRequestParams.get("requestData").toString());
		  // LpstpProductDet lpstpProductDet= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpProductDet>() { });
		   LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(lpdProdId.longValue()));
		   
		   if(lpstpProductDetfromDB!=null)
		   {
			   List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacity =serviceProvider.getLpstpPrdRepaymentCapacityService().findByLrcProdIdOrderByLrcRowId(lpdProdId.longValue());
			   dataHashMap.put("lpstpPrdRepaymentCapacity",lpstpPrdRepayCapacity);
			   responseHashMap.put("success", true);
			   responseHashMap.put("responseData", dataHashMap);
		   }else
		   {
			   	dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		   }
		  
		}
	   
	    else if(dpMethod.equals("savePrdRepaymentcapacity"))
	    {
	    	
	    	List RepaymentCapacitylist = (List) allRequestParams.get("requestData");
	    	for(int i=0;i<RepaymentCapacitylist.size();i++)
	    	{
		    	    List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacity= new ObjectMapper().convertValue(RepaymentCapacitylist.get(i), new TypeReference<List<LpstpPrdRepayCapacity>>() { });
		    	    List<LpstpPrdRepayCapacity> lpstpPrdDocFeedel= serviceProvider.getLpstpPrdRepaymentCapacityService().findByLrcProdIdOrderByLrcRowId(lpstpPrdRepayCapacity.get(0).getLrcProdId());   
		    		serviceProvider.getLpstpPrdRepaymentCapacityService().deletePrdRepaymentcapacity(lpstpPrdDocFeedel);
		    		
		    		lpstpPrdRepayCapacity.forEach(lpstpPrdRepayCapacitylist1->{
	    			lpstpPrdRepayCapacitylist1.setLrcCreatedOn(Helper.getSystemDate());
	    			lpstpPrdRepayCapacitylist1.setLrcCreatedBy(userid);
	    			lpstpPrdRepayCapacitylist1.setLrcModifedBy(userid);
	    			lpstpPrdRepayCapacitylist1.setLrcComplete("N");
			    	lpstpPrdRepayCapacitylist1.setLrcModifiedOn(Helper.getSystemDate());
		    	});
		    	
		    	List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacitySaved = serviceProvider.getLpstpPrdRepaymentCapacityService().savePrdRepaymentcapacity(lpstpPrdRepayCapacity);
		    	Long l =(long) 0;
		    	Long prdId = (long) 0;
		    	for (LpstpPrdRepayCapacity lpstpPrdIntDoc :lpstpPrdRepayCapacitySaved)
		    	{
		    		prdId = new Long(lpstpPrdIntDoc.getLrcProdId());
		    	}
		    	 
		    
		    	List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacitysave  = serviceProvider.getLpstpPrdRepaymentCapacityService().getRepayCapacityByPrdId(prdId);
		    	
				LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prdId);
		    	if(lpstpPrdRepayCapacitysave !=null)
		    	{
		    		lpstpProductDetfromDB.setLpdComplete("N");
		    		lpstpProductDetfromDB=serviceProvider.getLpstpProductDetService().updateProductDetails(lpstpProductDetfromDB);
		    	}
		    	
		    	dataHashMap.put("lpstpProductDet",lpstpProductDetfromDB);
				dataHashMap.put("lpstpPrdRepaycapacitysave",lpstpPrdRepayCapacitysave);
	    	}
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	    
	    else if(dpMethod.equals("deletePrdRepaymentcapacity"))
	    {
			List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacitysave= new ArrayList();
			lpstpPrdRepayCapacitysave.add(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpPrdRepayCapacity>() { }));
		
			lpstpPrdRepayCapacitysave.forEach(lpstpPrdRepayCapacitydelete->{
				lpstpPrdRepayCapacitydelete.setLrcCreatedOn(Helper.getSystemDate());
	    		lpstpPrdRepayCapacitydelete.setLrcCreatedBy(userid);
	    		lpstpPrdRepayCapacitydelete.setLrcModifedBy(userid);
	    		lpstpPrdRepayCapacitydelete.setLrcComplete("N");
		    	lpstpPrdRepayCapacitydelete.setLrcModifiedOn(Helper.getSystemDate());
	    	});
			
	    	serviceProvider.getLpstpPrdRepaymentCapacityService().deletePrdRepaymentcapacity(lpstpPrdRepayCapacitysave);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	   
	   
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}

}
