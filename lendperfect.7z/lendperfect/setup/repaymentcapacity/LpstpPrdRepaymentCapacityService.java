package com.sai.lendperfect.setup.repaymentcapacity;
import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPrdRepayCapacity;

public interface LpstpPrdRepaymentCapacityService {

	List<LpstpPrdRepayCapacity> savePrdRepaymentcapacity(List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacity);

	List<LpstpPrdRepayCapacity> findAll();

	void deletePrdRepaymentcapacity(List<LpstpPrdRepayCapacity> lpstpPrdRepayCapacity1);

	List<LpstpPrdRepayCapacity> findByLrcProdIdOrderByLrcRowId(Long lrcProdId);
								

	List<LpstpPrdRepayCapacity> getRepayCapacityByPrdId(Long prdId);
	
	String findRepayCapacityPerc(long prdCode,BigDecimal finalNetIncome);

	
}
