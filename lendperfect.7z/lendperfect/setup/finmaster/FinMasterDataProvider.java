package com.sai.lendperfect.setup.finmaster;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.setupmodel.LpstpCMAMaster;
import com.sai.lendperfect.setupmodel.LpstpFinMaster;
/*import com.sai.lendperfect.model.SetStaticData;
*/import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;

public class FinMasterDataProvider {

	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{	
		logging.setLoggerClass(this.getClass());	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		responseHashMap.put("success", true);
		try{
		if(dpMethod.equals("getFinMasterDataList"))
		{			
			try {
				//responseHashMap.put("allAIMDataList", serviceProvider.getSetAssestmentItemMasterService().findAll());
				responseHashMap.put("finMasterDataListAll",serviceProvider.getSetFinMasterService().findAll());

			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}

		}
		
		else if(dpMethod.equals("saveFinMasterData"))
		{		
			try {
			LpstpFinMaster setFinMaster= serviceProvider.getSetFinMasterService().saveFinMasterData(new ObjectMapper()
					.convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpFinMaster>() {}));
			responseHashMap.put("getCurrentSavedUserByid",Arrays.asList(serviceProvider.getSetFinMasterService().findById(setFinMaster.getFinRowid())));
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			}
			
		}
		
		
		else if(dpMethod.equals("getDataListBycategory"))
		{		
			try {
			String finPage= (allRequestParams.get("requestData").toString());
			responseHashMap.put("dataListBycategory",serviceProvider.getSetFinMasterService().findByCategory(finPage));
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
		    }
		}
		
		else if(dpMethod.equals("getFinIndexDataList"))
		{	
			try {
			responseHashMap.put("cmaDataList",serviceProvider.getSetCMAMasterService().findAll());
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			    }
		}

		else if(dpMethod.equals("getAllFormulaDataList"))
		{			
			try {
				responseHashMap.put("allFormulaDataList",serviceProvider.getLpstpFinFormulaService().fetchAllDataOrderByRowId());
			} catch (Exception ex) {

				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
				}
		}
		else if(dpMethod.equals("getValueOfHeaderFromListOfValueMaster")){
			try {
			String[] header=allRequestParams.get("requestData").toString().split(":");
			if(header.length==2){
			responseHashMap.put("listOfValueOfHeader",serviceProvider.getListOfValuesService().getOptionList(header[0], header[1]));
			}else{
				responseHashMap.put("listOfValueOfHeader", new ArrayList<LpmasListofvalue>()	);
			}
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		else if(dpMethod.equals("getAllDistinctTabName"))
		{			
			try {
				responseHashMap.put("allDistinctTabName",serviceProvider.getSetFinMasterService().getDistinctTabNameOrderByTabName());
			} catch (Exception ex) {

				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
				}
		}
		else if(dpMethod.equals("getAllDistinctRowName"))
		{			
			try {
				responseHashMap.put("allDistinctRowName",serviceProvider.getSetFinMasterService().getDistinctRowNameOrderByRowId());
			} catch (Exception ex) {

				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
				}
		}
		

		else if(dpMethod.equals("getDataListByCategory_INDEXandTABNAME"))
		{		
			try {
			@SuppressWarnings("rawtypes")
			HashMap hshMap=(HashMap)allRequestParams.get("requestData");
			String  finPage=hshMap.get("finPage").toString();
			long finCmaNo=Long.valueOf(hshMap.get("finCmaNo").toString());
			String finTabname=hshMap.get("finTabname").toString();
			if(finPage!=null && (!finPage.equalsIgnoreCase(""))){
			responseHashMap.put("dataListByCategoryIndexandTabName",serviceProvider.getSetFinMasterService().findByCategory_CMANoandTabName(finPage, finCmaNo, finTabname));
			}else{
				responseHashMap.put("dataListByCategoryIndexandTabName",new ArrayList<LpstpFinMaster>());
			}
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
		    }
		}
		else if(dpMethod.equals("getFormulaDataByCMATypeAndFormulaFor")){		
			try {
				@SuppressWarnings("rawtypes")
				HashMap hshMap=(HashMap)allRequestParams.get("requestData");
				long cmaType=Long.valueOf(hshMap.get("cmaType").toString());
				String fromulaFor=hshMap.get("formulaFor").toString();
				responseHashMap.put("formulaDataByCMATypeandFormulaFor",serviceProvider.getLpstpFinFormulaService().fetchformulaDataByCmaTypeandformulaFor(cmaType,fromulaFor));
		
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			}
			}
		else if(dpMethod.equals("saveFinTypeData"))
		{		
			try {
				HashMap hshMap=(HashMap)allRequestParams.get("requestData");
				String cmaName=hshMap.get("cmaName").toString();
				BigDecimal indCode=new BigDecimal(hshMap.get("indCode").toString());
				LpstpCMAMaster modelObject= new LpstpCMAMaster();
				modelObject.setCmaFormatDesc(cmaName);
				modelObject.setIndCode(indCode);
				modelObject=	serviceProvider.getSetCMAMasterService().saveData(modelObject);
				responseHashMap.put("cmaMasterAllDataOrderByName", serviceProvider.getSetCMAMasterService().fetchAllDataOrderByName());
				
			
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			}
	}else if(dpMethod.equals("getPageAccess"))
	 {
		try {
		 responseHashMap.put("pageAccess",serviceProvider.getLpmasPageMasterService().getPageAcessByPageId("404",serviceProvider,session) ); 
	///	 responseHashMap.put("pageAccess","R");
		}
	catch (Exception ex) {
	if (!dataHashMap.containsKey("errorData")) {
		logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
		dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
		responseHashMap.put("success", false);
		responseHashMap.put("responseData", dataHashMap);
	}
	}	 }
	
		/*
		else if(dpMethod.equals("getSetStaticDataListBySsdValueId"))
		{
			try {
			long SsdValueId=Long.parseLong(allRequestParams.get("requestData").toString());
			@SuppressWarnings("unchecked")
			List<SetStaticData> setStaticDataList=(ArrayList<SetStaticData>)masterData;			
			List<SetStaticData> setStaticDataListBySsdValueId=new ArrayList<SetStaticData>();
			Iterator<SetStaticData> itr=setStaticDataList.iterator();
			while(itr.hasNext())
			{
				SetStaticData setStaticData=itr.next();
				if(setStaticData.getSsdValueId().longValue()==SsdValueId)
					setStaticDataListBySsdValueId.add(setStaticData);				
			}
		
	
			responseHashMap.put("setStaticDataListBySsdValueId",setStaticDataListBySsdValueId);	
		} catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		} */else{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		return responseHashMap;
		}
	}

