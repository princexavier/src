package com.sai.lendperfect.setup.finmaster;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpFinMaster;
import com.sai.lendperfect.setuprepo.LpstpFinMasterRepo;

@Service("setFinMasterService")
@Transactional
public class LpstpFinMasterServiceImpl implements LpstpFinMasterService {
	
	@Autowired
	private LpstpFinMasterRepo setFinMasterRepo;
	
	public 	List<LpstpFinMaster> findAll() {
		return setFinMasterRepo.findAll();
	}
	
	public List<LpstpFinMaster> findByIDasList(long finRowid) {
		return setFinMasterRepo.findByfinRowid(finRowid);
	}
	
	public LpstpFinMaster findById(long finRowid) {
		return setFinMasterRepo.findOne(finRowid);
	}
	
	
	public LpstpFinMaster saveFinMasterData(LpstpFinMaster setFinMaster) {
		return setFinMasterRepo.save(setFinMaster);
		
	}

	public LpstpFinMaster updateFinMasterData(LpstpFinMaster setFinMaster) {
		return saveFinMasterData(setFinMaster);
	}

	public void deleteFinMasterData(LpstpFinMaster setFinMaster) {
		setFinMasterRepo.delete(setFinMaster);
	}

	public List<LpstpFinMaster> getElemntByfinCmaNo(BigDecimal finCmaNo) {
		return setFinMasterRepo.findAllFinMasterByfinCmaNo(finCmaNo);
	}

	public List<LpstpFinMaster> findByCategory(String finPage) {
		return setFinMasterRepo.findByfinPage(finPage);
	}

	public List<LpstpFinMaster> findByCategoryandTabNameandOrderByFinSno(String finPage,String finTabName,long finCmaNo) {
		//return setFinMasterRepo.findByfinPageAndFinTabnameOrderByFinRowidFinSnoAsc(finPage,finTabName);
		return  setFinMasterRepo.getDataByFinaTabandFinPage(finPage,finTabName,BigDecimal.valueOf(finCmaNo));
	}

	public List<LpstpFinMaster> getAlldataByListOfRowId(List<Long> finRowid) {
		return  setFinMasterRepo.getAlldataByListOfRowId(finRowid);
	}

	public String[] getDistinctTabNameOrderByTabName( String  finPage,long finCmaNo)  {
		return setFinMasterRepo.getDistinctTabName(finPage,BigDecimal.valueOf(finCmaNo));
	}
	public String[] getDistinctTabNameOrderByTabName(){
		return setFinMasterRepo.getDistinctTabName2();
	}
	public List<LpstpFinMaster> fetchAllDataOrderByName() {
		return setFinMasterRepo.findAll(new Sort(Sort.Direction.ASC, "finRowdesc"));
	}

	public List<LpstpFinMaster> fetchAllDataRowTypeAsEntryOrderByName() {
		return setFinMasterRepo.getAllDataRowTypeAsEntry();
	}

	public String[] getDistinctRowNameOrderByRowId() {
		return  setFinMasterRepo.getDistinctRowName();
	}


	public List<LpstpFinMaster> findByCategory_CMANoandTabName(String finPage, long finCmaNo, String tabName) {
		return setFinMasterRepo.findByfinPageAndFinCmaNoAndFinTabnameOrderByFinRowidDesc(finPage,BigDecimal.valueOf(finCmaNo),tabName);
	}

	public List<LpstpFinMaster> findAllByFinPageOrderByfinSno(String finPage) {
		return setFinMasterRepo.findAllByFinPageOrderByFinSno(finPage);
	}

	public List<LpstpFinMaster> findByfinPageAndFinRowTypeIn(String finPage, List<String> finRowType) {
		return setFinMasterRepo.findByFinPageAndFinRowtypeIn(finPage,finRowType);
	}

	public List<LpstpFinMaster> findByCategoryAndCMANoOrderByFinSno(String finPage, long finCmaNo) {
		return setFinMasterRepo.findByFinPageAndFinCmaNo(finPage, BigDecimal.valueOf(finCmaNo));
	}

			
	
}
