package com.sai.lendperfect.setup.finmaster;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpFinMaster;

public interface LpstpFinMasterService  {
	
	List<LpstpFinMaster> findAll();
	List<LpstpFinMaster> findByIDasList(long finRowid);
	List<LpstpFinMaster> findByCategory(String finPage);
	List<LpstpFinMaster> findByfinPageAndFinRowTypeIn(String finPage, List<String> finRowType);

	LpstpFinMaster findById(long finRowId);
	
	LpstpFinMaster saveFinMasterData(LpstpFinMaster setFinMaster);
	LpstpFinMaster updateFinMasterData(LpstpFinMaster setFinMaster);
	void deleteFinMasterData(LpstpFinMaster setFinMaster);	
	String[] getDistinctTabNameOrderByTabName();
	List<LpstpFinMaster> getElemntByfinCmaNo(BigDecimal finCmaNo);
	List<LpstpFinMaster> findByCategoryandTabNameandOrderByFinSno(String finPage,String finTabName,long finCmaNo);
	List<LpstpFinMaster> getAlldataByListOfRowId(List<Long>  finRowid);
	String[] getDistinctTabNameOrderByTabName( String  finPage,long finCmaNo) ;
	String[] getDistinctRowNameOrderByRowId();
	List<LpstpFinMaster> fetchAllDataOrderByName();
	List<LpstpFinMaster> fetchAllDataRowTypeAsEntryOrderByName();
	List<LpstpFinMaster> findByCategory_CMANoandTabName(String finPage,long finCmaNo,String tabName);
	List<LpstpFinMaster> findAllByFinPageOrderByfinSno(String finPage);
	List<LpstpFinMaster> findByCategoryAndCMANoOrderByFinSno(String finPage,long finCmaNo);
} 