package com.sai.lendperfect.setup.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpDocument;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ServiceProvider;

public class LpstpDocumentDataProvider {
	

	
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpDocumentDataProvider.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map <String,Object> modelMap=new HashMap<String,Object>();	
		try
		{
			
			if(dpMethod.equals("getDocumentmatser"))
			{
			try {
			
			Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
			requestHashMapnew.remove("Documentlist");
			
				LpstpDocument lpstpDocument=new ObjectMapper()
						.convertValue(requestHashMapnew, new TypeReference<LpstpDocument>() {});
				
				  List<LpstpDocument> lpstpDocumentGridDetail	=	new ArrayList<LpstpDocument>();
				
			       lpstpDocumentGridDetail=serviceProvider.getLpstpDocumentService().findAllByldDocType(lpstpDocument.getLdDocType());
		  
				    responseHashMap.put("success", true);
					responseHashMap.put("responseData",lpstpDocumentGridDetail);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			
			else if(dpMethod.equals("saveDocumentmatser")){	
				try {
					Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					requestHashMapnew.remove("Documentlist");
					
					LpstpDocument lpstpDocument=new ObjectMapper()
							.convertValue(requestHashMapnew, new TypeReference<LpstpDocument>() {});
					
					lpstpDocument.setLdCreatedBy(session.getAttribute("userid").toString());
					lpstpDocument.setLdModifiedBy(session.getAttribute("userid").toString());
					
					lpstpDocument.setLdCreatedOn(new Date());
					lpstpDocument.setLdModifiedOn(new Date());
					serviceProvider.getLpstpDocumentService().saveLpstpDocument(lpstpDocument);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
		
			
		}
		catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		return responseHashMap;
	}

}
