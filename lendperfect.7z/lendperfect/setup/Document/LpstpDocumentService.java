package com.sai.lendperfect.setup.Document;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpDocument;


public interface LpstpDocumentService {
	
	List<LpstpDocument> findAll();
	LpstpDocument findById(BigDecimal  ldDocId);
	List<LpstpDocument> saveLpstpDocumentList(List<LpstpDocument> lpstpDocumentlist);
	LpstpDocument saveLpstpDocument(LpstpDocument lpstpDocument);
	void deleteLpstpDocument(LpstpDocument lpstpDocument);
	List <LpstpDocument> findAllByLdDocDesc(String ldDocDesc);
	List <LpstpDocument> findDistinctByLdDocDesc(String ldDocDesc);
	List<LpstpDocument> findAllDistinct();
	List <LpstpDocument> findAllByLdDocDescIgnoreCaseContainingAndLdDocType(String ldDocDesc,String ldDocType);
	List<LpstpDocument> findAllByLdDocActive(String ldDocActive);
	List<LpstpDocument> findAllByldDocType(String ldDocType);
	 List<LpstpDocument> findAllByLdDocTypeAndLdDocActive(String ldDocType ,String ldDocActive);
	 List<LpstpDocument> findAllByLdDocId(BigDecimal ldDocId);
}
