package com.sai.lendperfect.setup.Document;

import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpDocument;
import com.sai.lendperfect.setuprepo.LpstpDocumentRepo;


@Service("LpstpDocumentService")
@Transactional
public class LpstpDocumentServiceImpl implements  LpstpDocumentService{

	@Autowired
	LpstpDocumentRepo lpstpDocumentRepo;
	
	public List<LpstpDocument> findAll() {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.findAll();
	}

	@Override
	public List<LpstpDocument> saveLpstpDocumentList(List<LpstpDocument> lpstpDocumentlist) {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.save(lpstpDocumentlist);
	}

	@Override
	public void deleteLpstpDocument(LpstpDocument lpstpDocument) {
		// TODO Auto-generated method stub
		lpstpDocumentRepo.delete(lpstpDocument);
	}

	@Override
	public List<LpstpDocument> findAllByLdDocDesc(String ldDocDesc) {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.findAllByLdDocDesc(ldDocDesc);
	}

	@Override
	public List<LpstpDocument> findDistinctByLdDocDesc(String ldDocDesc) {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.findDistinctByLdDocDescNotIn(ldDocDesc);
	}

	@Override
	public LpstpDocument saveLpstpDocument(LpstpDocument lpstpDocument) {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.save(lpstpDocument);
	}

	@Override
	public LpstpDocument findById(BigDecimal ldDocId) {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.findOne(ldDocId);
	}

	@Override
	public List<LpstpDocument> findAllDistinct() {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.findAllDistinct();
	}

	@Override
	public List<LpstpDocument> findAllByLdDocDescIgnoreCaseContainingAndLdDocType(String ldDocDesc, String ldDocType) {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.findAllByLdDocDescIgnoreCaseContainingAndLdDocType(ldDocDesc, ldDocType);
	}

	@Override
	public List<LpstpDocument> findAllByLdDocActive(String ldDocActive) {
		// TODO Auto-generated method stub
		return lpstpDocumentRepo.findAllByLdDocActive(ldDocActive);
	}

	@Override
	public List<LpstpDocument> findAllByldDocType(String ldDocType) {
		
		return lpstpDocumentRepo.findAllByldDocType(ldDocType);
	}
	
public List<LpstpDocument> findAllByLdDocTypeAndLdDocActive(String ldDocType ,String ldDocActive) {
		
		return lpstpDocumentRepo.findAllByLdDocTypeAndLdDocActive(ldDocType,ldDocActive);
	}
public  List<LpstpDocument> findAllByLdDocId(BigDecimal ldDocId){
	return lpstpDocumentRepo.findAllByLdDocId(ldDocId);
}

}
