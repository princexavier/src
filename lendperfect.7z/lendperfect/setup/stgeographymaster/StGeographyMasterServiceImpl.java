/**
 * 
 */
package com.sai.lendperfect.setup.stgeographymaster;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.StGeographyMaster;
import com.sai.lendperfect.setuprepo.StGeographyMasterRepo;

/**
 * @author pawananjay.r
 *
 */

@Service("stGeographyMasterService")
@Transactional
public class StGeographyMasterServiceImpl implements StGeographyMasterService {

	@Autowired
	StGeographyMasterRepo stGeographyMasterRepo;

	public StGeographyMaster saveStGeographyMasterData(StGeographyMaster stGeographyMaster) {
		return stGeographyMasterRepo.save(stGeographyMaster);
	}

	
	public List<StGeographyMaster> getdistinctState() {
		return stGeographyMasterRepo.getdistinctState();
	}

	public List<Object> getdistinctCityByStateCode(String sgmStateCode,BigDecimal sgmParentId) {
		return stGeographyMasterRepo.getdistinctCityByStateCode(sgmStateCode, sgmParentId);
	}

	public List<Object> getdistinctDistrictByCityCodeAndStateCode(String sgmCityCode, String sgmStateCode, BigDecimal sgmParentId ) {
		return stGeographyMasterRepo.getdistinctDistrictByCityCodeAndStateCode(sgmCityCode, sgmStateCode, sgmParentId);
	}

	public List<StGeographyMaster> getAllStGeographyMasterData() {
		return stGeographyMasterRepo.findAll( new Sort(Sort.Direction.ASC , "sgmRowId"));
	}



	public List<Object[]> findAllDistrict() {
		return stGeographyMasterRepo.findAllDistrict();
	}


	public List<StGeographyMaster> getAllByCityandState(String sgmCityCode, String sgmStateCode) {

	
		return stGeographyMasterRepo.findBySgmCityCodeAndSgmStateCode(sgmCityCode, sgmStateCode);
	}


	public List<Object[]> findAllStates() {
		return stGeographyMasterRepo.findAllStates();
	}

	


	public List<StGeographyMaster> findAll() {
		return stGeographyMasterRepo.findAll();
	}

	public void deleteStGeographyMaster(StGeographyMaster stGeographyMaster)
	{
		stGeographyMasterRepo.delete(stGeographyMaster);
	}

	public StGeographyMaster findBySgmRowId(long sgmRowId) {
		return stGeographyMasterRepo.findOne(sgmRowId);
	}

	public List<Object> getDistinctDistrictByStateCode(String sgmStateCode) {
		return stGeographyMasterRepo.getDistinctDistrictByStateCode(sgmStateCode);
	}


	public List<StGeographyMaster> findAllBySgmParentIdAndSgmStateCodeIgnoreCaseContainingOrderBySgmStateNameAsc(BigDecimal sgmParentId,String sgmStateCode) {
		return stGeographyMasterRepo.findAllBySgmParentIdAndSgmStateCodeIgnoreCaseContainingOrderBySgmStateNameAsc(sgmParentId,sgmStateCode);
	}


	public List<StGeographyMaster> findAllBySgmParentIdAndSgmStateNameIgnoreCaseContainingOrderBySgmStateNameAsc(BigDecimal sgmParentId,String sgmStateName){
		return stGeographyMasterRepo.findAllBySgmParentIdAndSgmStateNameIgnoreCaseContainingOrderBySgmStateNameAsc(sgmParentId, sgmStateName);
	}


	public List<StGeographyMaster> findAllBysgmDistrictCodeIgnoreCaseContaining(String sgmDistrictCode){
		return stGeographyMasterRepo.findAllBysgmDistrictCodeIgnoreCaseContaining(sgmDistrictCode);
	}
	public List<StGeographyMaster> findAllBysgmDistrictNameIgnoreCaseContaining(String sgmDistrictName){
		return stGeographyMasterRepo.findAllBysgmDistrictNameIgnoreCaseContaining(sgmDistrictName);
	}




	public List<StGeographyMaster> findAllBySgmCityCodeIgnoreCaseContaining(String sgmCityCode) {
		return stGeographyMasterRepo.findAllBySgmCityCodeIgnoreCaseContaining(sgmCityCode);
	}


	public List<StGeographyMaster> findAllBySgmCityNameIgnoreCaseContaining(String sgmCityName) {
		return stGeographyMasterRepo.findAllBySgmCityNameIgnoreCaseContaining(sgmCityName);
	}
	
	
	public List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContaining(String sgmStateCode,String sgmCityCode){
		return stGeographyMasterRepo.findBySgmStateCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContaining(sgmStateCode, sgmCityCode);
	}

	public List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContaining(String sgmStateCode,String sgmCityName){
		return stGeographyMasterRepo.findBySgmStateCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContaining(sgmStateCode, sgmCityName);
	}


	@Override
	public List<StGeographyMaster> findBySgmCityCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContaining(
			String sgmCityCode, String sgmDistrictCode) {
		
		return stGeographyMasterRepo.findBySgmCityCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContaining(sgmCityCode,sgmDistrictCode);
	}


	@Override
	public List<StGeographyMaster> findBySgmCityCodeIgnoreCaseContainingAndSgmDistrictNameIgnoreCaseContaining(
			String sgmCityCode, String sgmDistrictName) {
		
		return stGeographyMasterRepo.findBySgmCityCodeIgnoreCaseContainingAndSgmDistrictNameIgnoreCaseContaining(sgmCityCode,sgmDistrictName);
	}


	@Override
	public List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContaining(
			String sgmStateCode, String sgmDistrictCode) {
		
		return stGeographyMasterRepo.findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContaining(sgmStateCode,sgmDistrictCode);
	}


	@Override
	public List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictNameIgnoreCaseContaining(
			String sgmStateCode, String sgmDistrictName) {
		
		return stGeographyMasterRepo.findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictNameIgnoreCaseContaining(sgmStateCode,sgmDistrictName);
	}


	@Override
	public List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContaining(
			String sgmStateCode, String sgmDistrictCode, String sgmCityCode) {
		
		return stGeographyMasterRepo.findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContaining(sgmStateCode,sgmDistrictCode,sgmCityCode);
	}


	@Override
	public List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContaining(
			String sgmStateCode, String sgmDistrictCode, String sgmCityName) {
		
		return stGeographyMasterRepo.findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContaining(sgmStateCode, sgmDistrictCode,  sgmCityName);
	}


	@Override
	public List<Object[]> getStatesByCity(String sgmCityCode, String sgmCityName) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public StGeographyMaster findBySgmStateCodeAndSgmCityCode(String sgmStateCode, String sgmCityName) {
		return stGeographyMasterRepo.findBySgmStateCodeAndSgmCityCode(sgmStateCode,sgmCityName);
	}


	@Override
	public String findstatemaxid() {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.findstatemaxid();
	}


	@Override
	public String findcitymaxid() {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.findcitymaxid();
	}


	@Override
	public String finddistrictmaxid() {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.finddistrictmaxid();
	}


	@Override
	public String getsaveflage(String state) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.getsaveflage(state);
	}


	@Override
	public String getcityflage(String state, String city) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.getcityflage(state, city);
	}


	@Override
	public String getdistflage(String state, String city, String dist) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.getdistflage(state, city, dist);
	}


	@Override
	public List<StGeographyMaster> findBySgmParentIdOrderBySgmStateCode(BigDecimal parentId) {
		return stGeographyMasterRepo.findBySgmParentIdOrderBySgmStateCode(parentId);
	}


	public StGeographyMaster findBySgmStateCodeAndSgmCityCodeAndSgmDistrictCode(String sgmStateCode, String sgmCityCode,
			String sgmDistrictCode) {
		return stGeographyMasterRepo.findBySgmStateCodeAndSgmCityCodeAndSgmDistrictCode(sgmStateCode, sgmCityCode, sgmDistrictCode);
	}


	public List<Object[]> findAllCity() {
		return stGeographyMasterRepo.findAllCity();
	}


	public List<Object> findSgmStateCodeAndSgmCityCodeAndSgmPincode(String sgmCityCode, String sgmStateCode, BigDecimal sgmPincode) {
		return stGeographyMasterRepo.findSgmStateCodeAndSgmCityCodeAndSgmPincode(sgmCityCode, sgmStateCode, sgmPincode);
	}

	@Override
	public List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContainingAndsgmDistrictCode(
			String sgmStateCode, String sgmCityName, String sgmDistrictCode) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.findBySgmStateCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContainingAndSgmDistrictCode(sgmStateCode,sgmCityName,sgmDistrictCode);
	}


	@Override
	public List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContainingAndsgmDistrictCode(
			String sgmStateCode, String sgmCityCode, String sgmDistrictCode) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.findBySgmStateCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContainingAndSgmDistrictCode(sgmStateCode,sgmCityCode,sgmDistrictCode);
	}


	@Override
	public List<StGeographyMaster> findAllBySgmCityCodeIgnoreCaseContainingAndSgmDistrictCode(String sgmCityCode,
			String sgmDistrictCode) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.findAllBySgmCityCodeIgnoreCaseContainingAndSgmDistrictCode(sgmCityCode,sgmDistrictCode);
	}


	@Override
	public List<StGeographyMaster> findAllBySgmCityNameIgnoreCaseContainingAndSgmDistrictCode(String sgmCityName,
			String sgmDistrictCode) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.findAllBySgmCityNameIgnoreCaseContainingAndSgmDistrictCode(sgmCityName,sgmDistrictCode);
	}


	public StGeographyMaster findBySgmDistrictCode(String sgmDistrictCode) {
		return stGeographyMasterRepo.findBySgmDistrictCode(sgmDistrictCode);
	}

	public StGeographyMaster findBySgmCityCodeAndSgmDistrictCode(String sgmCityCode, String sgmDistrictCode) {
		return stGeographyMasterRepo.findBySgmCityCodeAndSgmDistrictCode(sgmCityCode, sgmDistrictCode);
	}


	public long rowIdGeneratorofGeoGraphyMaster() {
		return stGeographyMasterRepo.newRowGeneratorforGeographyMaster();
	}

//
//	@Override
//	public List<StGeographyMaster> findAllBySgmParentIdAndLgmDeviationAndSgmStateCodeIgnoreCaseContainingOrderBySgmStateNameAsc(
//			BigDecimal sgmParentId, String lgmDeviation, String sgmStateCode) {
//		return stGeographyMasterRepo.findAllBySgmParentIdAndLgmDeviationAndSgmStateCodeIgnoreCaseContainingOrderBySgmStateNameAsc(sgmParentId, lgmDeviation, sgmStateCode);
//	}


//	@Override
//	public List<StGeographyMaster> findAllBySgmParentIdAndLgmDeviationAndSgmStateNameIgnoreCaseContainingOrderBySgmStateNameAsc(
//			BigDecimal sgmParentId, String lgmDeviation, String sgmStateName) {
//		return stGeographyMasterRepo.findAllBySgmParentIdAndLgmDeviationAndSgmStateNameIgnoreCaseContainingOrderBySgmStateNameAsc(sgmParentId, lgmDeviation, sgmStateName);
//	}


	@Override
	public StGeographyMaster findBystateCodeAndCityCodefirstRow(String sgmStateCode,String sgmCityCode) {
		return stGeographyMasterRepo.findFirstBySgmStateCodeAndSgmCityCodeAndSgmPincodeIsNotNullOrderBySgmPincode(sgmStateCode,sgmCityCode);
	}
	@Override
	public List[] findDistinctSgmStateName() {
		
		return stGeographyMasterRepo.findDistinctSgmStateName();
	}

	public List<StGeographyMaster> findBySgmStateCode(String sgmStateCode) {
		return stGeographyMasterRepo.findBySgmStateCode(sgmStateCode);
	}
	public List<StGeographyMaster> findAllBySgmStateNameIgnoreCaseContaining(String sgmStateName) {
		return stGeographyMasterRepo.findAllBySgmStateNameIgnoreCaseContaining(sgmStateName);
	}
	public List<StGeographyMaster> findAllBySgmStateCodeIgnoreCaseContaining(String sgmStateCode) {
		return stGeographyMasterRepo.findAllBySgmStateCodeIgnoreCaseContaining(sgmStateCode);
	}


	@Override
	public StGeographyMaster findBysgmCityCode(String sgmCityCode) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.findBysgmCityCode(sgmCityCode);
	}


	@Override
	public List[] findDistinctSgmCityCode(String sgmStateCode) {
		return stGeographyMasterRepo.findDistinctSgmCityCode(sgmStateCode);
	}


	@Override
	public StGeographyMaster findBysgmStateCode(String sgmStateCode) {
		// TODO Auto-generated method stub
		return stGeographyMasterRepo.findBysgmStateCode(sgmStateCode);
	}
	
	

	
}
