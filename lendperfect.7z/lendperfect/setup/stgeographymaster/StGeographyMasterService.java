/**
 * 
 */
package com.sai.lendperfect.setup.stgeographymaster;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.StGeographyMaster;

/**
 * @author pawananjay.r
 *
 */

public interface StGeographyMasterService {

	StGeographyMaster saveStGeographyMasterData(StGeographyMaster stGeographyMaster);

	List<StGeographyMaster> getdistinctState();

	List<Object> getdistinctCityByStateCode(String sgmStateCode, BigDecimal sgmParentId);

	List<Object> getdistinctDistrictByCityCodeAndStateCode(String sgmCityCode, String sgmStateCode ,BigDecimal sgmParentId);

	List<StGeographyMaster> getAllStGeographyMasterData();
	
	List<StGeographyMaster> getAllByCityandState(String sgmCityCode, String sgmStateCode);
	
	List<Object[]> findAllStates();
	List<Object[]> findAllCity();
	List<Object[]> findAllDistrict();
	

	
	StGeographyMaster findBysgmCityCode(String sgmCityCode);
	
	public List<StGeographyMaster> findAll();
	
	public void deleteStGeographyMaster(StGeographyMaster stGeographyMaster);
	
	public StGeographyMaster findBySgmRowId(long sgmRowId);
	
	public List<Object> getDistinctDistrictByStateCode(String sgmStateCode);
	
	List<StGeographyMaster> findAllBySgmParentIdAndSgmStateCodeIgnoreCaseContainingOrderBySgmStateNameAsc(BigDecimal sgmParentId,String sgmStateCode);
	List<StGeographyMaster> findAllBySgmParentIdAndSgmStateNameIgnoreCaseContainingOrderBySgmStateNameAsc(BigDecimal sgmParentId,String sgmStateName);
	
	
	 public List<Object[]> getStatesByCity(String sgmCityCode,String sgmCityName);
	 
	List<StGeographyMaster> findAllBysgmDistrictCodeIgnoreCaseContaining(String sgmDistrictCode);
	List<StGeographyMaster> findAllBysgmDistrictNameIgnoreCaseContaining(String sgmDistrictName);
	 
	List<StGeographyMaster> findAllBySgmCityCodeIgnoreCaseContaining(String sgmCityCode);
	List<StGeographyMaster> findAllBySgmCityNameIgnoreCaseContaining(String sgmCityName);
		
	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContaining(String sgmStateCode,String sgmCityCode);
	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContaining(String sgmStateCode,String sgmCityName);
	
	List<StGeographyMaster> findBySgmCityCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContaining(String sgmCityCode,String sgmDistrictCode);
	List<StGeographyMaster> findBySgmCityCodeIgnoreCaseContainingAndSgmDistrictNameIgnoreCaseContaining(String sgmCityCode,String sgmDistrictName);
	
	
	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContaining(String sgmStateCode,String sgmDistrictCode);
	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictNameIgnoreCaseContaining(String sgmStateCode,String sgmDistrictName);
	
	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContaining(String sgmStateCode,String sgmDistrictCode,String sgmCityCode);
	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmDistrictCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContaining(String sgmStateCode,String sgmDistrictCode,String sgmCityName);
	
	StGeographyMaster findBySgmStateCodeAndSgmCityCode(String sgmStateCode,String sgmCityName);
	
	String findstatemaxid ();
	String findcitymaxid ();
	String finddistrictmaxid ();
	String getsaveflage(String state);
	String getcityflage(String state,String city);
	String getdistflage(String state,String city,String dist);

	List<StGeographyMaster> findBySgmParentIdOrderBySgmStateCode(BigDecimal bigDecimal);

	StGeographyMaster findBySgmStateCodeAndSgmCityCodeAndSgmDistrictCode(String sgmStateCode,String sgmCityCode,String sgmDistrictCode);
	List<Object> findSgmStateCodeAndSgmCityCodeAndSgmPincode(String sgmStateCode,String sgmCityName, BigDecimal sgmPincode);
	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityNameIgnoreCaseContainingAndsgmDistrictCode(String sgmStateCode,String sgmCityName,String sgmDistrictCode);
	List<StGeographyMaster> findBySgmStateCodeIgnoreCaseContainingAndSgmCityCodeIgnoreCaseContainingAndsgmDistrictCode(String sgmStateCode,String sgmCityCode,String sgmDistrictCode);
	List<StGeographyMaster> findAllBySgmCityCodeIgnoreCaseContainingAndSgmDistrictCode(String sgmCityCode,String sgmDistrictCode);
	List<StGeographyMaster> findAllBySgmCityNameIgnoreCaseContainingAndSgmDistrictCode(String sgmCityName,String sgmDistrictCode);
	StGeographyMaster findBySgmDistrictCode(String sgmDistrictCode);
	StGeographyMaster findBySgmCityCodeAndSgmDistrictCode(String sgmCityCode,String sgmDistrictCode);
	public long rowIdGeneratorofGeoGraphyMaster();  
	 
//	List<StGeographyMaster> findAllBySgmParentIdAndLgmDeviationAndSgmStateCodeIgnoreCaseContainingOrderBySgmStateNameAsc(BigDecimal sgmParentId,String lgmDeviation,String sgmStateCode);
//	List<StGeographyMaster> findAllBySgmParentIdAndLgmDeviationAndSgmStateNameIgnoreCaseContainingOrderBySgmStateNameAsc(BigDecimal sgmParentId,String lgmDeviation,String sgmStateName);
	StGeographyMaster findBystateCodeAndCityCodefirstRow(String sgmCityCode,String sgmDistrictCode);
	List[] findDistinctSgmStateName();
	List<StGeographyMaster> findBySgmStateCode(String sgmStateCode);
	List<StGeographyMaster> findAllBySgmStateNameIgnoreCaseContaining(String sgmStateName);
	List<StGeographyMaster> findAllBySgmStateCodeIgnoreCaseContaining(String sgmStateCode);
	
	List[] findDistinctSgmCityCode(String sgmStateCode);
	StGeographyMaster findBysgmStateCode(String sgmStateCode);
}
