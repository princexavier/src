package com.sai.lendperfect.setup.stgeographymaster;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasPageMaster;
import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setupmodel.LpstpUser;
import com.sai.lendperfect.setupmodel.StGeographyMaster;

public class StGeographyMasterDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		StGeographyMaster stGeographyMaster=null;
		responseHashMap.put("success", true);
		try {
			if(dpMethod.equals("saveStGeographyMasterData")){	
				try {
					
					String sgmStateCode="",sgmCityCode="",sgmDistrictCode="";

					stGeographyMaster=new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<StGeographyMaster>() {});
					String desc=stGeographyMaster.getSgmStateName();
					String desc1=stGeographyMaster.getSgmCityName();
					String desc2=stGeographyMaster.getSgmDistrictName();
					if(!Helper.correctNull(desc).equals(""))
					{
					desc= desc.toUpperCase();
					desc= desc.replaceAll(" ", "");
					stGeographyMaster.setSgmStateName(desc);
					}
					if(!Helper.correctNull(desc1).equals(""))
					{
					desc1= desc1.toUpperCase();
					desc1= desc1.replaceAll(" ", "");
					stGeographyMaster.setSgmCityName(desc1);
					}
					if(!Helper.correctNull(desc2).equals(""))
					{
					desc2= desc2.toUpperCase();
					desc2= desc2.replaceAll(" ", "");
					stGeographyMaster.setSgmDistrictName(desc2);
					}
					String statecode=stGeographyMaster.getSgmStateCode();
					String citycode=stGeographyMaster.getSgmCityCode();
					if(Helper.correctNull(String.valueOf(stGeographyMaster.getSgmStateCode())).equalsIgnoreCase(""))
					{
					sgmStateCode= serviceProvider.getStGeographyMasterService().findstatemaxid();
					stGeographyMaster.setSgmStateCode(sgmStateCode);
					}
					if(Helper.correctNull(String.valueOf(stGeographyMaster.getSgmCityCode())).equalsIgnoreCase("") && !Helper.correctNull(String.valueOf(statecode)).equalsIgnoreCase(""))
					{
					sgmCityCode= serviceProvider.getStGeographyMasterService().findcitymaxid();
					stGeographyMaster.setSgmCityCode(sgmCityCode);
					}
					if(Helper.correctNull(String.valueOf(stGeographyMaster.getSgmDistrictCode())).equalsIgnoreCase(""));
					{
					 if(!Helper.correctNull(statecode).equalsIgnoreCase("") && !Helper.correctNull(citycode).equalsIgnoreCase("")){
					sgmDistrictCode=serviceProvider.getStGeographyMasterService().finddistrictmaxid();
					stGeographyMaster.setSgmDistrictCode(sgmDistrictCode);}
					}
					if(stGeographyMaster.getSgmRowId()==0){
						stGeographyMaster.setSgmRowId(serviceProvider.getStGeographyMasterService().rowIdGeneratorofGeoGraphyMaster());
						stGeographyMaster.setSgmCreatedBy(session.getAttribute("userid").toString());
						stGeographyMaster.setSgmModifiedBy((stGeographyMaster.getSgmCreatedBy()));
						stGeographyMaster.setSgmCreatedOn(new Date());
						stGeographyMaster.setSgmModifiedOn(stGeographyMaster.getSgmCreatedOn());
					}else{
						StGeographyMaster tempStGeographyMaster=	serviceProvider.getStGeographyMasterService().findBySgmRowId(stGeographyMaster.getSgmRowId());
						stGeographyMaster.setSgmCreatedBy(tempStGeographyMaster.getSgmCreatedBy());
						stGeographyMaster.setSgmCreatedOn(tempStGeographyMaster.getSgmCreatedOn());
						stGeographyMaster.setSgmModifiedBy(session.getAttribute("userid").toString());
						stGeographyMaster.setSgmModifiedOn(new Date());
					}
					
					stGeographyMaster= serviceProvider.getStGeographyMasterService().saveStGeographyMasterData(stGeographyMaster);
					responseHashMap.put("getAllDataList", serviceProvider.getStGeographyMasterService().getAllStGeographyMasterData());
				}catch (Exception ex) {
					ex.printStackTrace();
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				
				} else if(dpMethod.equals("getAllStGeographyMasterData")){	
					try {
						responseHashMap.put("getAllDataList", serviceProvider.getStGeographyMasterService().getAllStGeographyMasterData());
					}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
						
					}			
		
				else
			if (dpMethod.equals("districtonly")){	
				List<Map<String,String>> districtList=new ArrayList<Map<String,String>>();
				List<String> districtValueList=new ArrayList<String>();
				List<Object[]> districtObjects=serviceProvider.getStGeographyMasterService().findAllDistrict();
				Iterator<Object[]> stGeographyMasterItr=districtObjects.iterator();
				while(stGeographyMasterItr.hasNext())
				{
					Object districtObj[]=stGeographyMasterItr.next();
					Map<String,String> districtData=new HashMap<String,String>();
					
					districtValueList.add((String)districtObj[0]);
					
					districtData.put("districtValue",((String)districtObj[0]));
					districtData.put("districtDescription", (String)districtObj[1]);
					if(districtData.get("districtValue")!=null && districtData.get("districtDescription")!=null)
					{
						districtList.add(districtData);
						districtData.put("districtValue",districtObj[0].toString());
					}
					
				}
				dataHashMap.put("district", districtList);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
		
			else if (dpMethod.equals("getLovMasterValues")) {
						try {
							
							responseHashMap.put("success", true);
							dataHashMap.put("title",serviceProvider.getLpmasListofvalueService().findByLlvHeader("title"));
							dataHashMap.put("gender",serviceProvider.getLpmasListofvalueService().findByLlvHeader("gender"));
							dataHashMap.put("addresstype",serviceProvider.getLpmasListofvalueService().findByLlvHeader("addresstype"));
							dataHashMap.put("constitution",serviceProvider.getLpmasListofvalueService().findByLlvHeader("constitution"));
							dataHashMap.put("customerriskcategory",serviceProvider.getLpmasListofvalueService().findByLlvHeader("customerriskcategory"));
							dataHashMap.put("borrowerrelation",serviceProvider.getLpmasListofvalueService().findByLlvHeader("borrowerrelation"));
							dataHashMap.put("maritalstatus",serviceProvider.getLpmasListofvalueService().findByLlvHeader("maritalstatus"));
							dataHashMap.put("religioncategory",serviceProvider.getLpmasListofvalueService().findByLlvHeader("religioncategory"));
							dataHashMap.put("category",serviceProvider.getLpmasListofvalueService().findByLlvHeader("category"));
							dataHashMap.put("caste",serviceProvider.getLpmasListofvalueService().findByLlvHeader("caste"));
							dataHashMap.put("educationlevel",serviceProvider.getLpmasListofvalueService().findByLlvHeader("educationlevel"));
							dataHashMap.put("employmenttype",serviceProvider.getLpmasListofvalueService().findByLlvHeader("employmenttype"));
							dataHashMap.put("ittype",serviceProvider.getLpmasListofvalueService().findByLlvHeader("ittype"));
							
							dataHashMap.put("cersaiupdate",serviceProvider.getLpmasListofvalueService().findByLlvHeader("cersaiupdate"));
							dataHashMap.put("identityproof",serviceProvider.getLpmasListofvalueService().findByLlvHeader("identityproof"));
							dataHashMap.put("addressproof",serviceProvider.getLpmasListofvalueService().findByLlvHeader("addressproof"));
							dataHashMap.put("classificationcategory",serviceProvider.getLpmasListofvalueService().findByLlvHeader("classificationcategory"));
							dataHashMap.put("subclassificationcategory",serviceProvider.getLpmasListofvalueService().findByLlvHeader("subclassificationcategory"));
							dataHashMap.put("customersegment",serviceProvider.getLpmasListofvalueService().findByLlvHeader("customersegment"));
							dataHashMap.put("riskprofile",serviceProvider.getLpmasListofvalueService().findByLlvHeader("riskprofile"));
							dataHashMap.put("cersaiaccounttype",serviceProvider.getLpmasListofvalueService().findByLlvHeader("cersaiaccounttype"));
							dataHashMap.put("customerlob",serviceProvider.getLpmasListofvalueService().findByLlvHeader("customerlob"));
							dataHashMap.put("nationality",serviceProvider.getLpmasListofvalueService().findByLlvHeader("nationality"));
							dataHashMap.put("incomeslab",serviceProvider.getLpmasListofvalueService().findByLlvHeader("incomeslab"));
							dataHashMap.put("preferredlanguage",serviceProvider.getLpmasListofvalueService().findByLlvHeader("preferredlanguage"));
							dataHashMap.put("typeofaccomadation",serviceProvider.getLpmasListofvalueService().findByLlvHeader("typeofaccomadation"));
							dataHashMap.put("ownershipstatus",serviceProvider.getLpmasListofvalueService().findByLlvHeader("ownershipstatus"));
							dataHashMap.put("orglevel",serviceProvider.getLpstpOrganisationService().findByLoOrgLevel("1"));
							String userId=session.getAttribute("userid").toString();
							if(!userId.equals(""))
							{
							LpstpUser lpstpUserObj=serviceProvider.getLpstpUserService().findBysuRowId(userId);
							if(lpstpUserObj!=null)
							dataHashMap.put("userName",lpstpUserObj.getSuFirstName());
							else
								dataHashMap.put("userName","");	
							}
							dataHashMap.put("userId",userId);
							
							List<Map<String,String>> cityList=new ArrayList<Map<String,String>>();
							List<Object[]> cityObjects=serviceProvider.getStGeographyMasterService().findAllCity();
							Iterator<Object[]> stGeographyMasterItr=cityObjects.iterator();
							while(stGeographyMasterItr.hasNext())
							{
								Object cityObj[]=stGeographyMasterItr.next();
								Map<String,String> cityDataMap=new HashMap<String,String>();
								cityDataMap.put("locationValue",((String)cityObj[0]));
								cityDataMap.put("locationDescription", (String)cityObj[1]);
								if(cityDataMap.get("locationValue")!=null && cityDataMap.get("locationDescription")!=null)
								{
									cityList.add(cityDataMap);
								}
								
							}
							dataHashMap.put("distinctCity", cityList);
							responseHashMap.put("responseData", dataHashMap);
						}
						catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
					}
			}
			
			else if(dpMethod.equals("cityBasedOnStates"))
			{
//				try {
//					List<Map<String,String>> cityList=new ArrayList<Map<String,String>>();
//				
//					Map <String,Object>  statedataMap=(Map<String, Object>) allRequestParams.get("requestData");
//					String sgmStateCode=statedataMap.get("sgmState").toString();
//					List<StGeographyMaster> stGeographyMasterList=serviceProvider.getStGeographyMasterService().findDistinctSgmCityCode(sgmStateCode);
//					Iterator<StGeographyMaster> stGeographyMasterItr=stGeographyMasterList.iterator();
//					while(stGeographyMasterItr.hasNext())
//					{
//						StGeographyMaster StGeographyMasterobj=stGeographyMasterItr.next();
//						Map<String,String> stateData=new HashMap<String,String>();
//						stateData.put("cityValue",StGeographyMasterobj.getSgmCityCode());
//						stateData.put("cityDescription",StGeographyMasterobj.getSgmCityName());
//						if(stateData.get("cityValue")!=null && stateData.get("cityDescription")!=null)
//						{
//							cityList.add(stateData);
//						}
//						
//					}
//					dataHashMap.put("city",cityList);
//					responseHashMap.put("success",true);
//					responseHashMap.put("responseData", dataHashMap);
//				}
//				catch (Exception ex) {
//					if (!dataHashMap.containsKey("errorData")) {
//						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
//						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
//						responseHashMap.put("success", false);
//						responseHashMap.put("responseData", dataHashMap);
//					}
//			}
			}
			else if(dpMethod.equals("distinctCity"))
			{
				try
				{
					List<Map<String,String>> cityList=new ArrayList<Map<String,String>>();
					List<Object[]> cityObjects=serviceProvider.getStGeographyMasterService().findAllCity();
					Iterator<Object[]> stGeographyMasterItr=cityObjects.iterator();
					while(stGeographyMasterItr.hasNext())
					{
						Object cityObj[]=stGeographyMasterItr.next();
						Map<String,String> cityDataMap=new HashMap<String,String>();
						cityDataMap.put("locationValue",((String)cityObj[0]));
						cityDataMap.put("locationDescription", (String)cityObj[1]);
						if(cityDataMap.get("locationValue")!=null && cityDataMap.get("locationDescription")!=null)
						{
							cityList.add(cityDataMap);
							
						}
						
					}
					dataHashMap.put("distinctCity", cityList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);

				}
				catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
			}
			}
			else if(dpMethod.equals("getdistinctState")){	
				try {
				
				responseHashMap.put("stGeographyMasterStateDataList", serviceProvider.getStGeographyMasterService().getdistinctState());
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
																																																																																																																																																																																																																																						
			} 
			else if(dpMethod.equals("getdistinctCityByStateCode")){	
				try {
					String[]  sgmCityCode=(String[]) allRequestParams.get("requestData").toString().split(":");
					if(sgmCityCode.length==2){
					String stateCode = sgmCityCode[0];
					BigDecimal sgmParentId = new BigDecimal(Long.parseLong((String) sgmCityCode[1]));

					dataHashMap.put("distinctCityListAsStateCode", serviceProvider.getStGeographyMasterService().getdistinctCityByStateCode(stateCode,sgmParentId));
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);
					}else{
						responseHashMap.put("distinctCityListAsStateCode", null);
					}
				
				}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
				
			} else if(dpMethod.equals("getdistinctDistrictByCityCodeAndStateCode")){	
				try {
					 String[]  sgmCityCodeArray=(String[]) allRequestParams.get("requestData").toString().split(":");
						if(sgmCityCodeArray.length==3){
						String sgmCityCode=sgmCityCodeArray[0];
						String stateCode = sgmCityCodeArray[1];
						long sgmParentId = Long.parseLong(sgmCityCodeArray[2]);
						 responseHashMap.put("distinctCityListAsStateCode", serviceProvider.getStGeographyMasterService().getdistinctDistrictByCityCodeAndStateCode(sgmCityCode, stateCode,BigDecimal.valueOf( sgmParentId)));

						}else{
							 responseHashMap.put("distinctCityListAsStateCode",null);
						}
					 
						
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
				
		}else if(dpMethod.equals("getDistinctDistrictByStateCode")){	
			try {
					 responseHashMap.put("distinctDistrictByStateCode", serviceProvider.getStGeographyMasterService().getDistinctDistrictByStateCode((String) allRequestParams.get("requestData")));
				}
			catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
		}
			
	} else if(dpMethod.equals("getPageAccess"))
	 {
		try {
	//	 LpmasPageMaster lpmasPageMaster=serviceProvider.getLpmasPageMasterService().findByLpmPageName("Geography Master");
		 //String pageAccess=Helper.pageAccessRights(lpmasPageMaster.getLpmPageType(),new BigDecimal((lpmasPageMaster.getLpmPageId())), new BigDecimal(0),serviceProvider,session);
		 responseHashMap.put("pageAccess",serviceProvider.getLpmasPageMasterService().getPageAcessByPageId("201",serviceProvider,session) ); 
		// responseHashMap.put("pageAccess","R");
		}
	catch (Exception ex) {
	if (!dataHashMap.containsKey("errorData")) {
		logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
		dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
		responseHashMap.put("success", false);
		responseHashMap.put("responseData", dataHashMap);
	}
	}	 }
	else if(dpMethod.equals("getsavefalge"))
	 {
		responseHashMap=(Map<String, Object>) allRequestParams.get("requestData");
		String state=(String) responseHashMap.get("sgmStateName").toString();
		String count=serviceProvider.getStGeographyMasterService().getsaveflage(state);
		if(count.equals("0"))
		{
			responseHashMap.put("flag", true);
		}
		else
		{
			responseHashMap.put("flag", false);
		}
	 }
	else if(dpMethod.equals("getcityfalge"))
	 {
		responseHashMap=(Map<String, Object>) allRequestParams.get("requestData");
		String state=(String) responseHashMap.get("sgmStateName").toString();
		String city=(String) responseHashMap.get("sgmCityName").toString();
		String count=serviceProvider.getStGeographyMasterService().getcityflage(state, city);
		if(count.equals("0"))
		{
			responseHashMap.put("flag", true);
		}
		else
		{
			responseHashMap.put("flag", false);
		}
	 }
	else if(dpMethod.equals("getdistfalge"))
	 {
		responseHashMap=(Map<String, Object>) allRequestParams.get("requestData");
		String state=(String) responseHashMap.get("sgmStateName").toString();
		String city=(String) responseHashMap.get("sgmCityName").toString();
		String dist=(String) responseHashMap.get("sgmDistrictName").toString();
		String count=serviceProvider.getStGeographyMasterService().getdistflage(state, city, dist);
		if(count.equals("0"))
		{
			responseHashMap.put("flag", true);
		}
		else
		{
			responseHashMap.put("flag", false);
		}
	 }
	else if (dpMethod.equals("distinctStates")) {
		try {
			List<Map<String,String>> stateList=new ArrayList<Map<String,String>>();
			List<String> stateValueList=new ArrayList<String>();
			List<Object[]> stGeographyMasterList=serviceProvider.getStGeographyMasterService().findAllStates();
			Iterator<Object[]> stGeographyMasterItr=stGeographyMasterList.iterator();
			while(stGeographyMasterItr.hasNext())
			{
				Object stateObj[]=stGeographyMasterItr.next();
				Map<String,String> stateData=new HashMap<String,String>();
				stateData.put("stateValue",(stateObj[0].toString()));
				stateData.put("stateDescription", (String)stateObj[1]);
				if(stateData.get("stateValue")!=null && stateData.get("stateDescription")!=null)
				{
				stateList.add(stateData);
				}
				
			}
			dataHashMap.put("states", stateList);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
	}
}
		else {
				dataHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
			return responseHashMap;

		} catch (Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}

		return responseHashMap;

	}

}
