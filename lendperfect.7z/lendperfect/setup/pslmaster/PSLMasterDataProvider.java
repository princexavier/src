package com.sai.lendperfect.setup.pslmaster;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpMasPslLov;
import com.sai.lendperfect.setupmodel.LpstpPSLMaster;

public class PSLMasterDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		Map<String,Object> hshMap = null;
		responseHashMap.put("success", true);
		LpstpPSLMaster modelObject = null;
		List<LpstpPSLMaster> modelObjectList= null ;
		logging.info("dpMethod:{}  ,",dpMethod);
		try {
			if(dpMethod.equals("getRecordByBizVertical")){
				try{
					String bizVertical = allRequestParams.get("requestData").toString();

					responseHashMap.put("arryOfRecordByBizVertical", serviceProvider.getLpstpPSLMasterService().getRecordByBizVerticalId(new BigDecimal(bizVertical)));
				}catch (Exception e) {
					if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
				dataHashMap.put("errorData",new CustomErr(e.getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
			}
			else 
				if(dpMethod.equals("getRecordOfPSLLovMasterByHeader")){
				try{
					String headerValue = allRequestParams.get("requestData").toString();
					responseHashMap.put("arryOfRecordOfPSLLOVByHeader", serviceProvider.getLpMasPslLovService().getRecordByHeader(headerValue));
				
				}catch (Exception e) {
					if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
				dataHashMap.put("errorData",new CustomErr(e.getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
						}
					}
				}

			else 
				if(dpMethod.equals("getBizVerticalList")){
				try{
					responseHashMap.put("arryOfBizVerticalList", serviceProvider.getLpmasBizVerticalService().findAll());				
				}catch (Exception e) {
					if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
					dataHashMap.put("errorData",new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
				else 
					if(dpMethod.equals("saveRecord")){
					try{
						modelObject=new ObjectMapper().convertValue(allRequestParams.get("requestData"),new TypeReference<LpstpPSLMaster>() {});
						modelObject= serviceProvider.getLpstpPSLMasterService().saveRecord(modelObject);
						if(modelObject!=null ){
							responseHashMap.put("arryOfRecordByBizVertical", serviceProvider.getLpstpPSLMasterService().getRecordByBizVerticalId(modelObject.getLpmBizVertical()));
						}else{
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod,"No Record found given detail");
								dataHashMap.put("errorData",new CustomErr("No Record found given detail"));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
										}
									
							
						}
					
					}catch (Exception e) {
						if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, e.getMessage());
					dataHashMap.put("errorData",new CustomErr(e.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
					else if(dpMethod.equals("getPageAccess"))
					 {
						try {
						 responseHashMap.put("pageAccess",serviceProvider.getLpmasPageMasterService().getPageAcessByPageId("417",serviceProvider,session) ); 
						// responseHashMap.put("pageAccess","R");
						}
					catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
					}	 }else{
						dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
			
					}
			
			
			
			
			}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
					}
			}			
		
		
		

return responseHashMap;
}	


}
