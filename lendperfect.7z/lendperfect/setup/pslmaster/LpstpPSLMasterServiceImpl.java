package com.sai.lendperfect.setup.pslmaster;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.setupmodel.LpstpPSLMaster;
import com.sai.lendperfect.setuprepo.LpstpPSLMasterRepo;

@Service("lpstpPSLMasterService")
public class LpstpPSLMasterServiceImpl  implements LpstpPSLMasterService{
@Autowired
private LpstpPSLMasterRepo lpstpPSLMasterRepo ;
	
	public List<LpstpPSLMaster> getRecordByBizVerticalId(BigDecimal bizVerticalId ) {
		return lpstpPSLMasterRepo.findByLpmBizVerticalOrderByLpmRowIdAsc(bizVerticalId);
	}

	public LpstpPSLMaster saveRecord(LpstpPSLMaster modelObject) {
		return lpstpPSLMasterRepo.saveAndFlush(modelObject);
	}

	public void deleteRecord(LpstpPSLMaster modelObject) {
		lpstpPSLMasterRepo.delete(modelObject);
	}

	public List<LpstpPSLMaster> getRecordByValidUptoDateAndActiveStatus(Date LpmRuleEffUpto ,String LpmActive,BigDecimal bizVerticalCode) {
		return lpstpPSLMasterRepo.findByLpmRuleEffUptoGreaterThanAndLpmActiveAndLpmBizVerticalOrderByLpmRowIdAsc(LpmRuleEffUpto, LpmActive,bizVerticalCode);
		
	}

	public List<LpstpPSLMaster> findAll() {
		return lpstpPSLMasterRepo.findAll(new Sort(Sort.Direction.ASC, "lpmBizVertical"));
	}

}
