package com.sai.lendperfect.setup.pslmaster;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPSLMaster;

public interface LpstpPSLMasterService {

	List<LpstpPSLMaster> findAll();
	List<LpstpPSLMaster> getRecordByBizVerticalId(BigDecimal bizVerticalId );
	List<LpstpPSLMaster> getRecordByValidUptoDateAndActiveStatus(Date LpmRuleEffUpto ,String LpmActive,BigDecimal bizVerticalCode);
	LpstpPSLMaster saveRecord(LpstpPSLMaster modelObject);
	void deleteRecord(LpstpPSLMaster modelObject);
}
