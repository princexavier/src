package com.sai.lendperfect.setup.securitymaster;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpSecurity;

public interface LpstpSecurityService {

	List<LpstpSecurity> findAll();

	LpstpSecurity saveLpstpSecurity(LpstpSecurity lpstpSecurity);

	void deleteLpstpSecurity(LpstpSecurity lpstpSecurity);

	LpstpSecurity findBylsSecClassiId(long lsSecClassiId);

	LpstpSecurity findByLsSecDesc(String lsSecDesc);

	List<LpstpSecurity> findByLsParentId(BigDecimal lsParentId);

	LpstpSecurity findBylsSecClassiIdAndlsParentId(long lsSecClassiId, BigDecimal lsParentId);

}
