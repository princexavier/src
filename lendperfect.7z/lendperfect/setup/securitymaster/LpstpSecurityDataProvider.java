package com.sai.lendperfect.setup.securitymaster;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpSecurity;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

public class LpstpSecurityDataProvider {
	

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
 		Map <String,Object> dpHashMap=new HashMap<String,Object>();	
 		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
 		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
 		
 			
		if(dpMethod.equals("saveSecurityMaster"))
		{		
			try
			{
				
			LpstpSecurity  lpstpSecurity = new LpstpSecurity();
			
			lpstpSecurity= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpSecurity>(){});	
			
			if(lpstpSecurity.getLsSecClassiId()==0)
			{
			lpstpSecurity.setLsCreatedOn(Helper.getSystemDate());
			lpstpSecurity.setLsCreatedBy(session.getAttribute("userid").toString());
			}
			lpstpSecurity.setLsModifedBy(session.getAttribute("userid").toString());
			lpstpSecurity.setLsModifiedOn(Helper.getSystemDate());
		
			serviceProvider.getLpstpSecurityService().saveLpstpSecurity(lpstpSecurity);
			dataHashMap.put("SecurityMaster",lpstpSecurity);	
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
			}
			catch (Exception e) {
				e.printStackTrace();
				logging.error("Provider : LpstpSecurityDataProvider /n saveSecurityMaster : {} /n Exception : ",dpMethod, e);
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
				responseHashMap.put("responseData", dataHashMap);
			}
			
		} 
		
		else if(dpMethod.equals("getSecurityType"))
		{	
			try
			{

				
				dataHashMap.put("securityMasterData",serviceProvider.getLpstpSecurityService().findAll());
			 responseHashMap.put("success", true);
			 responseHashMap.put("responseData", dataHashMap);
			}
			catch (Exception e) {
				e.printStackTrace();
				logging.error("Provider : LpstpSecurityDataProvider /n getSecurityType : {} /n Exception : ",dpMethod, e);
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
				
				responseHashMap.put("responseData", dataHashMap);
			}
		}
		
		
		else if(dpMethod.equals("getSecClassificationSubType"))
		{
			try
			{
				BigDecimal secId=new BigDecimal(Long.parseLong(allRequestParams.get("requestData").toString()));
				dataHashMap.put("secClassificationSubType",serviceProvider.getLpstpSecurityService().findByLsParentId(secId));
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
			catch (Exception e) {
				e.printStackTrace();
				logging.error("Provider : LpstpSecurityDataProvider /n getSecClassification : {} /n Exception : ",dpMethod, e);
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
				responseHashMap.put("responseData", dataHashMap);
			}
		} else if(dpMethod.equals("getSecClassificationList"))
		{
			try
			{
				long secClassifyId = Long.parseLong(allRequestParams.get("requestData").toString());
			 dataHashMap.put("SecClassificationData",serviceProvider.getLpstpSecurityService().findBylsSecClassiId(secClassifyId));
			 responseHashMap.put("success", true);
			 responseHashMap.put("responseData", dataHashMap);
			}
			catch (Exception e) {
				e.printStackTrace();
				logging.error("Provider : LpstpSecurityDataProvider /n getSecClassificationList : {} /n Exception : ",dpMethod, e);
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
				responseHashMap.put("responseData", dataHashMap);
			}
		}
		
		else
		{
			responseHashMap.put("errorData", new CustomErr(ErrConstants.sessionExpiredErrCode,ErrConstants.sessionExpiredErrMessage));
			responseHashMap.put("success",false);
			
		}
 		
		
 		return responseHashMap;
	}


}
