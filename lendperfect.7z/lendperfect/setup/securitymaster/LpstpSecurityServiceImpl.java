package com.sai.lendperfect.setup.securitymaster;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpSecurity;
import com.sai.lendperfect.setuprepo.LpstpSecurityRepo;

@Service("LpstpSecurityService")
@Transactional
public class LpstpSecurityServiceImpl implements LpstpSecurityService {

	@Autowired
	private LpstpSecurityRepo lpstpSecurityRepo;

	@Override
	public List<LpstpSecurity> findAll() {
		// TODO Auto-generated method stub
		return lpstpSecurityRepo.findAll();
	}

	@Override
	public LpstpSecurity saveLpstpSecurity(LpstpSecurity lpstpSecurity) {
		// TODO Auto-generated method stub
		return lpstpSecurityRepo.save(lpstpSecurity);
	}

	@Override
	public void deleteLpstpSecurity(LpstpSecurity lpstpSecurity) {
		// TODO Auto-generated method stub
		lpstpSecurityRepo.delete(lpstpSecurity);
	}

	@Override
	public LpstpSecurity findBylsSecClassiId(long lsSecClassiId) {
		// TODO Auto-generated method stub
		return lpstpSecurityRepo.findBylsSecClassiId(lsSecClassiId);
	}

	@Override
	public LpstpSecurity findByLsSecDesc(String lsSecDesc) {
		// TODO Auto-generated method stub
		return lpstpSecurityRepo.findByLsSecDesc(lsSecDesc);
	}

	@Override
	public List<LpstpSecurity> findByLsParentId(BigDecimal lsParentId) {
		return lpstpSecurityRepo.findByLsParentId(lsParentId);
	}

	@Override
	public LpstpSecurity findBylsSecClassiIdAndlsParentId(long lsSecClassiId, BigDecimal lsParentId) {
		// TODO Auto-generated method stub
		return lpstpSecurityRepo.findByLsSecClassiIdAndLsParentId(lsSecClassiId, lsParentId);
	}

}
