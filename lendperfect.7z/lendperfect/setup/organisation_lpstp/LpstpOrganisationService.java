package com.sai.lendperfect.setup.organisation_lpstp;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setupmodel.SetOrganisation;

public interface LpstpOrganisationService {

	List<LpstpOrganisation> findAllOrderByName();
	LpstpOrganisation saveLpstpOrganisation(LpstpOrganisation lpstpOrganisation);
	LpstpOrganisation findByLoOrgId(long loOrgId);
	List<LpstpOrganisation> findByLoOrgLevel(String loOrgLevel);
	LpstpOrganisation findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndLoOrgId(String loOrgBizVertical, String loOrgDepartment, String loOrgLevel, long loOrgId);
	List<LpstpOrganisation> findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(String loOrgBizVertical, String loOrgDepartment, String loOrgLevel);
	LpstpOrganisation findByloOrgLevel(String loOrgLevel);
	LpstpOrganisation findByLoName(String loName);

}
