package com.sai.lendperfect.setup.organisation_lpstp;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpOrgMapping;
import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setupmodel.LpstpUser;

public class LpstpOrganisationDataProvider {
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpOrganisationDataProvider.class);		
		Map <String,Object> dpHashMap=new HashMap<String,Object>();	
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> requestHashMap=new HashMap<String,Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		responseHashMap.put("success", false);
		
		if(dpMethod.equals("getBranches"))
		{
			try {
				String loOrgLevel = allRequestParams.get("requestData").toString();
				dpHashMap.put("unitList",serviceProvider.getLpstpOrganisationService().findByLoOrgLevel(loOrgLevel));
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dpHashMap);
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		
		
		else if(dpMethod.equals("getBranchesCheck"))
		{
			try {
				//String loOrgLevel = allRequestParams.get("requestData").toString();
				dpHashMap.put("unitList",serviceProvider.getLpstpOrganisationService().findAllOrderByName());
				//dpHashMap.put("unitList",serviceProvider.getLpstpOrganisationService().findByLoOrgLevel(loOrgLevel));
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dpHashMap);
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		
		else if(dpMethod.equals("getUnitList"))
		{
			try {
			requestHashMap = (Map<String, Object>) allRequestParams.get("requestData");
			String loOrgBizVertical = requestHashMap.get("vertical").toString();
			String loOrgDepartment = (String) requestHashMap.get("dept");
			String loOrgLevel = (String) requestHashMap.get("orgLevel");
			
			List<LpstpOrgMapping> lpstpOrgMappingList = serviceProvider.getLpstpOrgMappingService().findByLomBizVerticalAndLomDepartment(loOrgBizVertical, loOrgDepartment);
			 
			List<LpstpOrganisation> lpstpOrganisationExistingList = new ArrayList<LpstpOrganisation>();
			dpHashMap.put("unitNameList",serviceProvider.getLpstpOrganisationService().findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(loOrgBizVertical, loOrgDepartment, loOrgLevel));
			Iterator lpstpOrgMappingListItr = lpstpOrgMappingList.iterator();
			
			while(lpstpOrgMappingListItr.hasNext())
			{
				LpstpOrgMapping lpstpOrgMapping = (LpstpOrgMapping) lpstpOrgMappingListItr.next();
				LpstpOrganisation lpstpOrganisation =  lpstpOrgMapping.getLpstpOrganisation();
				lpstpOrganisationExistingList.add(lpstpOrganisation);
			}
			
			dpHashMap.put("existingList", lpstpOrganisationExistingList);
			responseHashMap.put("success", true);
	        responseHashMap.put("responseData", dpHashMap);
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		else if(dpMethod.equals("getOrgHead"))
		{
			try {
			List<LpstpUser>	lpstpUserList=serviceProvider.getLpstpUserService().findAll();	
			dpHashMap.put("lpstpUserList",lpstpUserList);
			responseHashMap.put("success", true);
	        responseHashMap.put("responseData", dpHashMap);
		} catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
		}
		}
		
		else{
			dpHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
		responseHashMap.put("success", false);
        responseHashMap.put("responseData", dpHashMap);
		}
		return responseHashMap;
	}
}
