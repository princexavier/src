package com.sai.lendperfect.setup.organisation_lpstp;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setuprepo.LpstpOrganisationRepo;

@Service("lpstpOrganisationService")
public class LpstpOrganisationServiceImpl implements LpstpOrganisationService {
	@Autowired
	public LpstpOrganisationRepo lpstpOrganisationRepo;
 
	public List<LpstpOrganisation> findAllOrderByName() {
		return lpstpOrganisationRepo.findAll(new Sort(Sort.Direction.ASC,"loOrgLevel"));
	}
	
	public LpstpOrganisation saveLpstpOrganisation(LpstpOrganisation lpstpOrganisation) {
		return lpstpOrganisationRepo.save(lpstpOrganisation);
	}

	public LpstpOrganisation findByLoOrgId(long loOrgId) {
		return lpstpOrganisationRepo.findByLoOrgId(loOrgId);
	}

	public LpstpOrganisation findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndLoOrgId(String loOrgBizVertical, String loOrgDepartment, String loOrgLevel, long loOrgId) {
		return lpstpOrganisationRepo.findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndLoOrgId(loOrgBizVertical, loOrgDepartment, loOrgLevel, loOrgId);
	}

	public List<LpstpOrganisation> findByLoOrgLevel(String loOrgLevel) {
		return lpstpOrganisationRepo.findByLoOrgLevelOrderByLoName(loOrgLevel);
	}

	@Override
	public LpstpOrganisation findByloOrgLevel(String loOrgLevel) {
		// TODO Auto-generated method stub
		return lpstpOrganisationRepo.findByLoOrgLevel(loOrgLevel);
	}

	@Override
	public List<LpstpOrganisation> findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(String loOrgBizVertical,
			String loOrgDepartment, String loOrgLevel) {
		// TODO Auto-generated method stub
		return lpstpOrganisationRepo.findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(loOrgBizVertical, loOrgDepartment, loOrgLevel);
	}

	@Override
	public LpstpOrganisation findByLoName(String loName) {
		// TODO Auto-generated method stub
		return lpstpOrganisationRepo.findByLoName(loName);
	}

	

}
