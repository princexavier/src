package com.sai.lendperfect.setup.prdassessment;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setup.prdassessment.LpstpPrdAssmentDataProvider;
import com.sai.lendperfect.setupmodel.LpstpPrdAssment;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ServiceProvider;

public class LpstpPrdAssmentDataProvider {
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpPrdAssmentDataProvider.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		BigDecimal  lpaProdId=new BigDecimal((String) requestHashMap.get("prdid").toString());
		String assType = "I%";
		String assType1 = "F%";
		try
		{

			if(dpMethod.equals("getprdassmnt"))
			{
			try {
				dataHashMap.put("prdassmntInprinclist",responseHashMap.put("prdassmntInprinclist",  serviceProvider.getLpstpPrdAssmentService().findByLpaProdIdAndLpaAssmntTypeLike(lpaProdId,assType.trim())));
				dataHashMap.put("prdassmntfinalSanclist",responseHashMap.put("prdassmntfinalSanclist",  serviceProvider.getLpstpPrdAssmentService().findByLpaProdIdAndLpaAssmntTypeLike(lpaProdId,assType1.trim())));
				responseHashMap.put("lpaProdId",lpaProdId);	
				responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);	
						}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
			}
			else if(dpMethod.equals("saveprdassmnt")){	
				try {
					Map<String, Object> modelMap = new HashMap<String, Object>();
					List<Map<String,Object>> lpstpPrdAssmentList=(List<Map<String, Object>>) requestHashMap.get("SearchAlllist");
					Iterator<Map<String,Object>> lpstpPrdAssmentListItr=lpstpPrdAssmentList.iterator();
					ArrayList<Map<String, Object>> lpstpPrdAssmentListnew = new ArrayList<Map <String, Object>>();
					String lpaAssmntType  =  (String) requestHashMap.get("assType");
					while(lpstpPrdAssmentListItr.hasNext())
					{
						Map<String,Object> asssessment=lpstpPrdAssmentListItr.next();
						modelMap=new HashMap();
						modelMap.put("lpaAssmntId", asssessment.get("CommonVal"));
						modelMap.put("lpaAssmntName", asssessment.get("CommonDesc"));
						modelMap.put("lpaCreatedBy","mrd");
						modelMap.put("lpaModifiedBy", "mrd");
						modelMap.put("lpaCreatedOn", new Date());
						modelMap.put("lpaModifiedOn", new Date());
						modelMap.put("lpaProdId", lpaProdId);
						modelMap.put("lpaAssmntType",lpaAssmntType);
						lpstpPrdAssmentListnew.add(modelMap);
						
					}
					
					List<LpstpPrdAssment> lpstpPrdAssment=new ObjectMapper()
							.convertValue(lpstpPrdAssmentListnew,new TypeReference<List<LpstpPrdAssment>>() {});
					
					serviceProvider.getLpstpPrdAssmentService().saveLpstpPrdAssmentList(lpstpPrdAssment);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			
			else if(dpMethod.equals("saveprdassessment")){	
				try {
					
					List<LpstpPrdAssment> lpstpPrdAssmentList=new ObjectMapper()
							.convertValue(requestHashMap.get("optionsFieldArray"),new TypeReference<List<LpstpPrdAssment>>() {});
					
					Iterator<LpstpPrdAssment> lpstpPrdAssmentListItr= lpstpPrdAssmentList.iterator();
					while(lpstpPrdAssmentListItr.hasNext())
					{
						LpstpPrdAssment lpstpPrdAssment=lpstpPrdAssmentListItr.next();
						lpstpPrdAssment.setLpaCreatedBy("sysetm");
						lpstpPrdAssment.setLpaModifiedBy("sysetm");
						lpstpPrdAssment.setLpaCreatedOn(new Date());
						lpstpPrdAssment.setLpaModifiedOn(new Date());
						lpstpPrdAssment.setLpaProdId(lpaProdId);
						
					}
					serviceProvider.getLpstpPrdAssmentService().saveLpstpPrdAssmentList(lpstpPrdAssmentList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);					
				
				}catch (Exception ex) {
						if (!dataHashMap.containsKey("errorData")) {
							logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
							dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
							responseHashMap.put("success", false);
							responseHashMap.put("responseData", dataHashMap);
						}
					}
				}
			 //delete all
			else if(dpMethod.equals("deleteAllprdassmnt")){	
					try {
						serviceProvider.getLpstpPrdAssmentService().deleteAllByLpaProdId(lpaProdId);
						responseHashMap.put("responseData", dataHashMap);
					}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
			 //delete single reference
			else if(dpMethod.equals("deleteprdassmnt")){	
					try {
						Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
						BigDecimal  lpaAssmntId=new BigDecimal((String)requestHashMapnew.get("AssessmentId").toString());
						serviceProvider.getLpstpPrdAssmentService().deleteAllByLpaProdIdAndLpaAssmntId(lpaProdId, lpaAssmntId);
						responseHashMap.put("responseData", dataHashMap);
					}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
		
		}
		catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		
 		return responseHashMap;
	}

}
