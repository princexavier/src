package com.sai.lendperfect.setup.prdassessment;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpPrdAssment;

public interface LpstpPrdAssmentService {
	
	LpstpPrdAssment findById(BigDecimal lpaAssmntId);
	List<LpstpPrdAssment> saveLpstpPrdAssmentList(List<LpstpPrdAssment> lpstpPrdAssmentList);
	List<LpstpPrdAssment> findAllByLpaProdId(BigDecimal lpaProdId);
	void deleteAllByLpaProdId(BigDecimal lpaProdId);
	void deleteAllByLpaProdIdAndLpaAssmntId(BigDecimal lpaProdId,BigDecimal lpaAssmntId);
	LpstpPrdAssment saveLpstpPrdAssment(LpstpPrdAssment lpstpPrdAssment);
	//List<LpstpPrdAssment> findByLpaProdIdAndLpaAssmntType(BigDecimal lpaProdId, char lpaAssmntType);
	List<LpstpPrdAssment> findByLpaProdIdAndLpaAssmntTypeLike(BigDecimal lpaProdId, String lpaAssmntType);

}
