package com.sai.lendperfect.setup.prdassessment;


import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpPrdAssment;
import com.sai.lendperfect.setuprepo.LpstpPrdAssmentRepo;

@Service("LpstpPrdAssmentService")
@Transactional

public class LpstpPrdAssmentServiceImpl implements LpstpPrdAssmentService {

	@Autowired
	LpstpPrdAssmentRepo lpstpPrdAssmentRepo;

	@Override
	public LpstpPrdAssment findById(BigDecimal lpaAssmntId) {
		// TODO Auto-generated method stub
		return lpstpPrdAssmentRepo.findOne(lpaAssmntId);
	}

	@Override
	public List<LpstpPrdAssment> saveLpstpPrdAssmentList(List<LpstpPrdAssment> lpstpPrdAssmentList) {
		// TODO Auto-generated method stub
		return lpstpPrdAssmentRepo.save(lpstpPrdAssmentList);
	}

	@Override
	public List<LpstpPrdAssment> findAllByLpaProdId(BigDecimal lpaProdId) {
		// TODO Auto-generated method stub
		return lpstpPrdAssmentRepo.findAllByLpaProdId(lpaProdId);
	}

	@Override
	public void deleteAllByLpaProdId(BigDecimal lpaProdId) {
		// TODO Auto-generated method stub
		lpstpPrdAssmentRepo.deleteAllByLpaProdId(lpaProdId);
	}

	@Override
	public void deleteAllByLpaProdIdAndLpaAssmntId(BigDecimal lpaProdId, BigDecimal lpaAssmntId) {
		// TODO Auto-generated method stub
		lpstpPrdAssmentRepo.deleteAllByLpaProdIdAndLpaAssmntId(lpaProdId, lpaAssmntId);
	}

	@Override
	public LpstpPrdAssment saveLpstpPrdAssment(LpstpPrdAssment lpstpPrdAssment) {
		// TODO Auto-generated method stub
		return lpstpPrdAssmentRepo.save(lpstpPrdAssment);
	}

	/*@Override
	public List<LpstpPrdAssment> findByLpaProdIdAndLpaAssmntType(BigDecimal lpaProdId, char lpaAssmntType) {
		// TODO Auto-generated method stub
		return lpstpPrdAssmentRepo.findByLpaProdIdAndLpaAssmntType(lpaProdId,lpaAssmntType);
	}*/
	
	@Override
	public List<LpstpPrdAssment> findByLpaProdIdAndLpaAssmntTypeLike(BigDecimal lpaProdId, String lpaAssmntType) {
		// TODO Auto-generated method stub
		return lpstpPrdAssmentRepo.findByLpaProdIdAndLpaAssmntTypeLike(lpaProdId,lpaAssmntType);
	}
	

}
