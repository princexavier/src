package com.sai.lendperfect.setup.organization;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.repository.query.Param;

import com.sai.lendperfect.setupmodel.SetOrganisation;;

public interface SetOrganisationService {
	List<SetOrganisation> findAll();
	SetOrganisation findById(long ssdRowId);
	SetOrganisation saveSetOrganisation(SetOrganisation setOrganisation);
	SetOrganisation updateSetOrganisation(SetOrganisation setOrganisation);
	void deleteSetOrganisation(SetOrganisation setOrganisation);
	SetOrganisation findBysoName(String soName);
	SetOrganisation findBysoOrgId(long soOrgId);
	List<SetOrganisation> findAllOrderByName();
	SetOrganisation findBysoOrgId(BigDecimal suLocation);
	List<SetOrganisation> findByLoOrgLevel(String loOrgLevel);
	List<SetOrganisation> findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(String loOrgBizVertical, String loOrgDepartment, String loOrgLevel);
	SetOrganisation findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndSoOrgId(BigDecimal loOrgBizVertical, String loOrgDepartment, String loOrgLevel, long soOrgId);
	List<Object> findDistinctLevel(String loOrgBizVertical,String loOrgDepartment);
	List<SetOrganisation> findByLoOrgLevelAndLoOrgBizVertical(String string, BigDecimal bigDecimal);
}

