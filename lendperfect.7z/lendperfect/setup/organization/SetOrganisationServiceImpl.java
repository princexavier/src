package com.sai.lendperfect.setup.organization;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.SetOrganisation;
import com.sai.lendperfect.setuprepo.SetOrganisationRepo;

@Service("SetOrganisationService")
@Transactional
public class SetOrganisationServiceImpl  implements SetOrganisationService{
	
	@Autowired
	private SetOrganisationRepo setOrganisationRepo;

	public List<SetOrganisation> findAll() {

		return setOrganisationRepo.findAll();
	}

	public SetOrganisation findById(long ssdRowId) {
		return setOrganisationRepo.findOne(ssdRowId);
	}

	public SetOrganisation saveSetOrganisation(SetOrganisation setOrganisation) {
		return setOrganisationRepo.save(setOrganisation);
	}

	public SetOrganisation updateSetOrganisation(SetOrganisation setOrganisation) {
		return saveSetOrganisation(setOrganisation);
	}

	public void deleteSetOrganisation(SetOrganisation setOrganisation) {
		setOrganisationRepo.delete(setOrganisation);
	}

	
	public SetOrganisation findBysoName(String soName) {
		
		return setOrganisationRepo.findBysoName(soName);
	}

	
	public SetOrganisation findBysoOrgId(long soOrgId) {
		
		return setOrganisationRepo.findBysoOrgId(soOrgId);
	}

	public List<SetOrganisation> findAllOrderByName() {
		return setOrganisationRepo.findAllByOrderBySoName();
	}


	public SetOrganisation findBysoOrgId(BigDecimal suLocation) {
	
		return setOrganisationRepo.findBysoOrgId(suLocation);
	}

	public List<SetOrganisation> findByLoOrgLevel(String loOrgLevel) {
		return setOrganisationRepo.findByLoOrgLevelOrderBySoName(loOrgLevel);
	}

	public List<SetOrganisation> findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(String loOrgBizVertical, String loOrgDepartment, String loOrgLevel) {
		return setOrganisationRepo.findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(loOrgBizVertical, loOrgDepartment, loOrgLevel);
	}

	public SetOrganisation findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndSoOrgId(BigDecimal loOrgBizVertical, String loOrgDepartment, String loOrgLevel, long soOrgId) {
		return setOrganisationRepo.findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndSoOrgId(loOrgBizVertical, loOrgDepartment, loOrgLevel, soOrgId);
	}


	public List<Object> findDistinctLevel(String loOrgBizVertical, String loOrgDepartment) {
		return setOrganisationRepo.findDistinctLevel(loOrgBizVertical, loOrgDepartment);
	}


	public List<SetOrganisation> findByLoOrgLevelAndLoOrgBizVertical(String orglevel, BigDecimal bizVertical) {
		return setOrganisationRepo.findByLoOrgLevelAndLoOrgBizVertical(orglevel,bizVertical);
	}

}
