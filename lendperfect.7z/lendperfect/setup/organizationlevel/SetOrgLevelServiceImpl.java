package com.sai.lendperfect.setup.organizationlevel;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.SetOrgLevel;
import com.sai.lendperfect.setuprepo.SetOrgLevelRepo;

@Service("SetOrgLevelService")
@Transactional

public class SetOrgLevelServiceImpl implements SetOrgLevelService {
	@Autowired
	private SetOrgLevelRepo setOrganisationRepo;

	public SetOrgLevel saveSetOrgLevel(SetOrgLevel setOrgLevel) {
		
		return setOrganisationRepo.save(setOrgLevel);
	}

	public SetOrgLevel updateSetOrgLevel(SetOrgLevel setOrgLevel) {
		
		return setOrganisationRepo.save(setOrgLevel);
	}

	
	public List<SetOrgLevel> findAll() {
		
		return setOrganisationRepo.findAll();
	}

	@Override
	public void deleteSetOrgLevel(SetOrgLevel setOrgLevel) {
		setOrganisationRepo.delete(setOrgLevel);
	}

	@Override
	public SetOrgLevel findById(long solRowId) {
		return setOrganisationRepo.findOne(solRowId);
	}
}
