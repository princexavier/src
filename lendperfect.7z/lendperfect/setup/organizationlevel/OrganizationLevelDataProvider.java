package com.sai.lendperfect.setup.organizationlevel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.SetOrgLevel;

public class OrganizationLevelDataProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
         		Map <String,Object> dpHashMap=new HashMap<String,Object>();	
         		Map <String,Object> responseHashMap=new HashMap<String,Object>();	

		if(dpMethod.equals("getSetOrgLevel"))
		{	
			dpHashMap.put("orglevel", serviceProvider.getSetOrgLevel().findAll());	
			responseHashMap.put("success", true);
	        responseHashMap.put("responseData", dpHashMap);
		}
		else if(dpMethod.equals("saveSetOrgLevel"))
		{			
			SetOrgLevel setOrgLevel = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<SetOrgLevel>() { });
			if(setOrgLevel.getSolRowId() == 0)
			{
				setOrgLevel.setSolCreatedBy(session.getAttribute("userid").toString());
				setOrgLevel.setSolCreatedOn(Helper.getSystemDate());
			}	
			setOrgLevel.setSolModifiedBy(session.getAttribute("userid").toString());
			setOrgLevel.setSolModifiedOn(Helper.getSystemDate());
			
			responseHashMap.put("responseData", serviceProvider.getSetOrgLevel().saveSetOrgLevel(setOrgLevel));
			responseHashMap.put("success", true);
				 
		}
		return responseHashMap;
	}

}
