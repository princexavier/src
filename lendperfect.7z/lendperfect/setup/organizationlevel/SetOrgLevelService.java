package com.sai.lendperfect.setup.organizationlevel;

import java.util.List;

import com.sai.lendperfect.setupmodel.SetOrgLevel;




public interface SetOrgLevelService {
	List<SetOrgLevel> findAll();
	SetOrgLevel findById(long solRowId);
	SetOrgLevel saveSetOrgLevel(SetOrgLevel setOrgLevel);
	SetOrgLevel updateSetOrgLevel(SetOrgLevel setOrgLevel);
	void deleteSetOrgLevel(SetOrgLevel setOrgLevel);

}

