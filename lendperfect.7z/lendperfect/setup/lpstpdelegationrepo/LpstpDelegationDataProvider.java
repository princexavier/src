package com.sai.lendperfect.setup.lpstpdelegationrepo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.setupmodel.LpstpDelegation;
import com.sai.lendperfect.setupmodel.LpstpScheme;
import com.sai.lendperfect.logging.Logging;

public class LpstpDelegationDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		Map <String,Object> requestHashMap=new HashMap<String,Object>();
		
		try {
			if (dpMethod.equals("getUserClasses")) {
				try {
					responseHashMap.put("success", true);
					String ldpDelecationFor=((String)allRequestParams.get("requestData").toString());
					responseHashMap.put("responseData", serviceProvider.getLpstpUserClassService().findByLucDepartmentAndLucActiveOrderByLucClassCode(ldpDelecationFor,"Y"));
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("saveLpstpDelegation")) {
				try {
					requestHashMap = (Map<String, Object>) allRequestParams.get("requestData"); 
					List<LpstpDelegation> lpstpDelegationList = new ObjectMapper().convertValue(requestHashMap.get("delegation"), new TypeReference<List<LpstpDelegation>>() {});
					Long schemeId=new Long(requestHashMap.get("schemeId").toString());
					String ldpDelecationFor=((String)requestHashMap.get("delecationfor").toString());
					LpstpScheme lpstpScheme = serviceProvider.getLpstpSchemeService().findByLsSchemeId(schemeId);
					
					Iterator lpstpDelegationListItr = lpstpDelegationList.iterator(); 
					while(lpstpDelegationListItr.hasNext())
					{
						LpstpDelegation lpstpDelegation = (LpstpDelegation) lpstpDelegationListItr.next();
						lpstpDelegation.setLdpCreatedBy(session.getAttribute("userid").toString());
						lpstpDelegation.setLdpCreatedOn(Helper.getSystemDate());
						lpstpDelegation.setLdpModifeidBy(session.getAttribute("userid").toString());
						lpstpDelegation.setLdpModifiedOn(Helper.getSystemDate());
						lpstpDelegation.setLdpDelecationFor(ldpDelecationFor);
						lpstpDelegation.setLpstpScheme(lpstpScheme);
					}
					List<LpstpDelegation> lpstpDelegationListForResponse = serviceProvider.getLpstpDelegationService().saveLpstpDelegation(lpstpDelegationList);
					dataHashMap.put("savedDelegationDetails",lpstpDelegationListForResponse);
					responseHashMap.put("responseData", dataHashMap);
					responseHashMap.put("success", true);
					
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getDelegationDetails")) {
				try {
					Map <String,Object>  stateCityDataMap=(Map<String, Object>) allRequestParams.get("requestData");
					String state = stateCityDataMap.get("state").toString();
					String city = stateCityDataMap.get("city").toString();
					Long schemeId=new Long(stateCityDataMap.get("schemeId").toString());
					LpstpScheme lpstpScheme = serviceProvider.getLpstpSchemeService().findByLsSchemeId(schemeId);
					dataHashMap.put("delegationDetails",serviceProvider.getLpstpDelegationService().findByLdpStateIdAndLdpCityIdAndLpstpSchemeOrderByLdpRowId(state, city, lpstpScheme));
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			else {
				dataHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
			return responseHashMap;
		}
		catch (Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}
		return responseHashMap;
	}
}
