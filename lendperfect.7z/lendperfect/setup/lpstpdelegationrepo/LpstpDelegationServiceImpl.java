package com.sai.lendperfect.setup.lpstpdelegationrepo;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpDelegation;
import com.sai.lendperfect.setupmodel.LpstpScheme;
import com.sai.lendperfect.setuprepo.LpstpDelegationRepo;

@Service("lpstpDelegationService")
@Transactional
public class LpstpDelegationServiceImpl implements LpstpDelegationService{

	@Autowired
	private LpstpDelegationRepo  lpstpDelegationRepo;

	public List<LpstpDelegation> saveLpstpDelegation(List<LpstpDelegation> lpstpDelegation) {
		return lpstpDelegationRepo.save(lpstpDelegation);
	}

	public List<LpstpDelegation> findAllByOrderByLdpRowId() {
		return lpstpDelegationRepo.findAllByOrderByLdpRowId();
	}

	public List<LpstpDelegation> findByLdpStateIdAndLdpCityIdOrderByLdpRowId(String ldpStateId, String ldpCityId) {
		return lpstpDelegationRepo.findByLdpStateIdAndLdpCityIdOrderByLdpRowId(ldpStateId, ldpCityId);
	}

	public List<LpstpDelegation> findByLdpStateIdAndLdpCityIdAndLpstpSchemeOrderByLdpRowId(String ldpStateId,String ldpCityId, LpstpScheme lpstpScheme) {
		return lpstpDelegationRepo.findByLdpStateIdAndLdpCityIdAndLpstpSchemeOrderByLdpRowId(ldpStateId, ldpCityId, lpstpScheme);
	}

	@Override
	public List<LpstpDelegation> findBylpstpScheme(LpstpScheme lpstpScheme) {
		return lpstpDelegationRepo.findBylpstpScheme(lpstpScheme);
	}

	

}
