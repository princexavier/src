package com.sai.lendperfect.setup.lpstpdelegationrepo;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpDelegation;
import com.sai.lendperfect.setupmodel.LpstpScheme;

public interface LpstpDelegationService {
	List<LpstpDelegation> findAllByOrderByLdpRowId();
	List<LpstpDelegation> saveLpstpDelegation(List<LpstpDelegation> lpstpDelegation);
	List<LpstpDelegation> findByLdpStateIdAndLdpCityIdOrderByLdpRowId(String ldpStateId, String ldpCityId);
	List<LpstpDelegation> findByLdpStateIdAndLdpCityIdAndLpstpSchemeOrderByLdpRowId(String ldpStateId, String ldpCityId,LpstpScheme lpstpScheme);
	List<LpstpDelegation> findBylpstpScheme(LpstpScheme lpstpScheme);
}
