package com.sai.lendperfect.setup.annexuremaster;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpAnnexMaster;

public class LpstpAnnexMasterDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData, ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		responseHashMap.put("success", true);
		try {
			if (dpMethod.equals("saveLpstpAnnexMaster")) {
				try {
					LpstpAnnexMaster lpstpAnnexMaster = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpAnnexMaster>() {
					});
					if (lpstpAnnexMaster.getLamRowId() == null) {
						lpstpAnnexMaster.setLamCreatedBy(session.getAttribute("userid").toString());
						lpstpAnnexMaster.setLamCreatedOn(new Date(System.currentTimeMillis()));
					} else if (lpstpAnnexMaster.getLamRowId() != null) {
						lpstpAnnexMaster.setLamModifiedBy(session.getAttribute("userid").toString());
						lpstpAnnexMaster.setLamModifiedOn(new Date(System.currentTimeMillis()));
					}
					serviceProvider.getLpstpAnnexMasterService().saveLpstpAnnexMaster(lpstpAnnexMaster);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", lpstpAnnexMaster);

				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getLpstpAnnexMaster")) {
				try {
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", serviceProvider.getLpstpAnnexMasterService().findAll());
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getLpstpAnnexMasterHeadings")) {
				try {
					responseHashMap.put("success", true);
					String type = (String) allRequestParams.get("requestData");
					responseHashMap.put("responseData", serviceProvider.getLpstpAnnexMasterService().findByLamAnnexTypeAndLamParentIdOrderByLamRowId(type, new BigDecimal(0)));
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getLpstpAnnexMasterContents")) {
				try {
					responseHashMap.put("success", true);
					BigDecimal headingId = new BigDecimal(Long.parseLong(allRequestParams.get("requestData").toString()));
					responseHashMap.put("responseData", serviceProvider.getLpstpAnnexMasterService().findByLamParentIdOrderByLamRowId(headingId));
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getLpstpAnnexMasterContentDetails")) {
				try {
					BigDecimal contentRowId = new BigDecimal(Long.parseLong(allRequestParams.get("requestData").toString()));
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", serviceProvider.getLpstpAnnexMasterService().findByLamRowId(contentRowId));
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("deleteAnnexureMaster")) {
				try {
					LpstpAnnexMaster lpstpAnnexMaster2 = new ObjectMapper().convertValue(allRequestParams.get("requestData"), LpstpAnnexMaster.class);
					LpstpAnnexMaster lpstpAnnexMaster = serviceProvider.getLpstpAnnexMasterService().findByLamRowId(lpstpAnnexMaster2.getLamRowId());
					serviceProvider.getLpstpAnnexMasterService().deleteLpstpAnnexMaster(lpstpAnnexMaster);
					responseHashMap.put("success", true);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getPageAccess")) {
				try {
					responseHashMap.put("pageAccess", serviceProvider.getLpmasPageMasterService().getPageAcessByPageId("406", serviceProvider, session));
					// responseHashMap.put("pageAccess","R");
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else {
				dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
			return responseHashMap;
		} catch (Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getCause().getMessage());
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}
		return responseHashMap;
	}
}
