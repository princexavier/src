package com.sai.lendperfect.setup.annexuremaster;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpAnnexMaster;
import com.sai.lendperfect.setuprepo.LpstpAnnexMasterRepo;

@Service("lpstpAnnexMasterService")
@Transactional
public class LpstpAnnexMasterServiceImpl implements LpstpAnnexMasterService {

	@Autowired
	private LpstpAnnexMasterRepo lpstpAnnexMasterRepo;

	public List<LpstpAnnexMaster> findAll() {
		return lpstpAnnexMasterRepo.findAll();
	}

	public LpstpAnnexMaster saveLpstpAnnexMaster(LpstpAnnexMaster lpstpAnnexMaster) {
		return lpstpAnnexMasterRepo.save(lpstpAnnexMaster);
	}

	public void deleteLpstpAnnexMaster(LpstpAnnexMaster lpstpAnnexMaster) {
		lpstpAnnexMasterRepo.delete(lpstpAnnexMaster);
	}

	public LpstpAnnexMaster findByLamRowId(BigDecimal lamRowId) {
		return lpstpAnnexMasterRepo.findOne(lamRowId);
	}

	public List<LpstpAnnexMaster> findByLamParentIdOrderByLamRowId(BigDecimal lamParentId) {
		return lpstpAnnexMasterRepo.findByLamParentIdOrderByLamRowId(lamParentId);
	}

	public List<LpstpAnnexMaster> findByLamAnnexTypeAndLamParentIdOrderByLamRowId(String lamAnnexType, BigDecimal lamParentId) {
		return lpstpAnnexMasterRepo.findByLamAnnexTypeAndLamParentIdOrderByLamRowId(lamAnnexType, lamParentId);
	}

	public List<LpstpAnnexMaster> findByLamAnnexType(String annxType) {
		return lpstpAnnexMasterRepo.findByLamAnnexType(annxType);
	}

	@Override
	public List<LpstpAnnexMaster> findByLamActiveAndLamParentIdIn(String lamActive, List<BigDecimal> lamParentIdList) {
		return lpstpAnnexMasterRepo.findByLamActiveAndLamParentIdIn(lamActive, lamParentIdList);
	}

	@Override
	public List<LpstpAnnexMaster> findByLamRowIdIn(List<BigDecimal> lamRowIdList) {
		return lpstpAnnexMasterRepo.findByLamRowIdIn(lamRowIdList);
	}

}
