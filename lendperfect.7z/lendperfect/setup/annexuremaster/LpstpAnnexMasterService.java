package com.sai.lendperfect.setup.annexuremaster;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpAnnexMaster;

public interface LpstpAnnexMasterService {
	List<LpstpAnnexMaster> findAll();

	LpstpAnnexMaster saveLpstpAnnexMaster(LpstpAnnexMaster lpstpAnnexMaster);

	void deleteLpstpAnnexMaster(LpstpAnnexMaster lpstpAnnexMaster);

	LpstpAnnexMaster findByLamRowId(BigDecimal lamRowId);

	List<LpstpAnnexMaster> findByLamParentIdOrderByLamRowId(BigDecimal lamParentId);

	List<LpstpAnnexMaster> findByLamAnnexTypeAndLamParentIdOrderByLamRowId(String lamAnnexType, BigDecimal lamParentId);

	List<LpstpAnnexMaster> findByLamAnnexType(String annxType);

	List<LpstpAnnexMaster> findByLamActiveAndLamParentIdIn(String lamActive, List<BigDecimal> lamParentIdList);

	List<LpstpAnnexMaster> findByLamRowIdIn(List<BigDecimal> lamRowIdList);
}
