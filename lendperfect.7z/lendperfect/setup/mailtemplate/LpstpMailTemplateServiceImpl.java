package com.sai.lendperfect.setup.mailtemplate;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.mastermodel.LpmasKeyParameter;
import com.sai.lendperfect.masterrepo.LpMasKeyParameterRepo;
import com.sai.lendperfect.setupmodel.LpstpMailTemplate;
import com.sai.lendperfect.setuprepo.LpStpMailTemplateRepo;




@Service("mailTemplateService")
@Transactional
public class LpstpMailTemplateServiceImpl implements LpstpMailTemplateService{

	
	@Autowired
	private LpMasKeyParameterRepo lpmasKeyParameterRepo;
	
	@Autowired
	private LpStpMailTemplateRepo lpStpMailTemplateRepo;
	

	
	public List<LpmasKeyParameter> findAllKeyParameter() {
		return lpmasKeyParameterRepo.findAll();
	}

	@Override
	public void deleteKeyParameter(LpmasKeyParameter lpmasKeyParameter1) {
		lpmasKeyParameterRepo.delete(lpmasKeyParameter1);
	}

	@Override
	public LpmasKeyParameter saveKeyParameter(LpmasKeyParameter lpmasKeyParameter) {
		return  lpmasKeyParameterRepo.save(lpmasKeyParameter);
	}

	@Override
	public LpstpMailTemplate saveMailTemplate(LpstpMailTemplate lpstpMailTemplate) {
		return lpStpMailTemplateRepo.saveAndFlush(lpstpMailTemplate);
		
	}

	
	@Override
	public List<LpstpMailTemplate> saveAllMailTemplate(List<LpstpMailTemplate> lpstpMailTemplateList) {
		return lpStpMailTemplateRepo.save(lpstpMailTemplateList);
		
	}
	
	@Override
	public List<LpstpMailTemplate> findAll() {
		return lpStpMailTemplateRepo.findAll();
	}

	@Override
	public void deleteMailTemplate(List<LpstpMailTemplate> lpstpMailTemplateList) {
		lpStpMailTemplateRepo.delete(lpstpMailTemplateList);
	}

	@Override
	public LpstpMailTemplate findByLmtTemplateTitle(String title) {
		return lpStpMailTemplateRepo.findByLmtTemplateTitle(title);
	}

	public LpstpMailTemplate findBylmtRowId(BigDecimal lmtRowId) {
		return lpStpMailTemplateRepo.findBylmtRowId(lmtRowId);
	}

	


}
