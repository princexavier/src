package com.sai.lendperfect.setup.mailtemplate;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.core.io.FileSystemResource;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpMailTemplate;
;

public class LpstpMailTemplateProvider {
	
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging) 
	{
		
		logging.setLoggerClass(LpstpMailTemplateProvider.class);		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		if(dpMethod.equals("getKeyWordList"))
		{
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("keywordList",serviceProvider.getMailTemplateService().findAllKeyParameter());
			dataHashMap.put("mailTemplateList",serviceProvider.getMailTemplateService().findAll());
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else if(dpMethod.equals("saveMailTemplate"))
		{			
			serviceProvider.getMailTemplateService().saveMailTemplate(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpMailTemplate>() { }));
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("mailTemplateList",serviceProvider.getMailTemplateService().findAll());
			/*
			File file = new File("C://Users//Abirami.N//Desktop//kotTest.xlsx");
			List<LpstpMailTemplate> list = (List<LpstpMailTemplate>)(List<?>) serviceProvider.getFileUploadManager().fileUpload(file);
			serviceProvider.getMailTemplateService().saveAllMailTemplate(list);*/
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}else if(dpMethod.equals("deleteMailTemplate"))
		{		
			List<LpstpMailTemplate> lpstpMailTemplateList=new ArrayList<>(); 		
			LpstpMailTemplate lpstpMailTemplate = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpMailTemplate>() { });
			lpstpMailTemplateList.add(lpstpMailTemplate);
			serviceProvider.getMailTemplateService().deleteMailTemplate(lpstpMailTemplateList);
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("mailTemplateList",serviceProvider.getMailTemplateService().findAll());
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else
		{
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
		
		
	}

}
