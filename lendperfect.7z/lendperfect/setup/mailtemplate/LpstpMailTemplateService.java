package com.sai.lendperfect.setup.mailtemplate;
import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.mastermodel.LpmasKeyParameter;
import com.sai.lendperfect.setupmodel.LpstpMailTemplate;



public interface LpstpMailTemplateService {
	
	List<LpmasKeyParameter> findAllKeyParameter();

	void deleteKeyParameter(LpmasKeyParameter lpmasKeyParameter1);

	LpmasKeyParameter saveKeyParameter(LpmasKeyParameter lpmasKeyParameter);

	LpstpMailTemplate saveMailTemplate(LpstpMailTemplate lpstpMailTemplate);

	List<LpstpMailTemplate> findAll();

	void deleteMailTemplate(List<LpstpMailTemplate> lpstpMailTemplateList);
	
	 List<LpstpMailTemplate> saveAllMailTemplate(List<LpstpMailTemplate> lpstpMailTemplateList);

	LpstpMailTemplate findByLmtTemplateTitle(String string);

	LpstpMailTemplate findBylmtRowId( BigDecimal lmtRowId);
	
}
