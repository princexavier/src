package com.sai.lendperfect.setup.processingfee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setuprepo.LpstpPrdProFeeRepo;
import com.sai.lendperfect.setup.processingfee.LpstpPrdProFeeService;
import com.sai.lendperfect.setupmodel.LpstpPrdProFee;




@Service("lpstpPrdProFeeService")
@Transactional
public class LpstpPrdProFeeServiceImpl implements LpstpPrdProFeeService{

	@Autowired
	LpstpPrdProFeeRepo lpstpPrdDocFeeRepo;

	@Override
	public List<LpstpPrdProFee> savePrdProFee(List<LpstpPrdProFee> lpstpPrdDocFee) {
		 return lpstpPrdDocFeeRepo.save(lpstpPrdDocFee);
	}

	@Override
	public List<LpstpPrdProFee> findAll() {
		return lpstpPrdDocFeeRepo.findAll();
	}

	@Override
	public void deletePrdProfee(List<LpstpPrdProFee> lpstpPrdDocFee1) {
		lpstpPrdDocFeeRepo.delete(lpstpPrdDocFee1);
	}

	@Override
	public List<LpstpPrdProFee> findByLpfProdIdOrderByLpfRowId(Long lpfProdId) {
		return lpstpPrdDocFeeRepo.findByLpfProdIdOrderByLpfRowId(lpfProdId);
	}

	@Override
	public 	List<LpstpPrdProFee> getIntRateByPrdId(Long prdId) {
		return lpstpPrdDocFeeRepo.findByLpfProdIdOrderByLpfRowId(prdId);
	}


	
}
