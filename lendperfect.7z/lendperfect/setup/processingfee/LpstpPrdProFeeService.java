package com.sai.lendperfect.setup.processingfee;
import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPrdProFee;;

public interface LpstpPrdProFeeService {

	List<LpstpPrdProFee> savePrdProFee(List<LpstpPrdProFee> lpstpPrdDocFee);

	List<LpstpPrdProFee> findAll();

	void deletePrdProfee(List<LpstpPrdProFee> lpstpPrdDocFee1);

	List<LpstpPrdProFee> findByLpfProdIdOrderByLpfRowId(Long lpfProdId);

	List<LpstpPrdProFee> getIntRateByPrdId(Long prdId);

	
}
