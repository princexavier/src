package com.sai.lendperfect.setup.processingfee;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.google.gson.Gson;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdProFee;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public class LpstpPrdProFeeDataProvider {
	
	@SuppressWarnings("rawtypes")
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		String userid = (String) session.getAttribute("userid");
		
	   if(dpMethod.equals("getPrdDocFeeDetails"))
		{
		   BigDecimal lpdProdId=new BigDecimal(allRequestParams.get("requestData").toString());
		   //LpstpProductDet lpstpProductDet= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpProductDet>() { });
		   LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(lpdProdId.longValue()));
		   if(lpstpProductDetfromDB!=null)
		   {
			   List<LpstpPrdProFee> lpstpPrdDocFee =serviceProvider.getLpstpPrdProFeeService().findByLpfProdIdOrderByLpfRowId(lpdProdId.longValue());
			   dataHashMap.put("lpstpPrdDocFee",lpstpPrdDocFee);
			   responseHashMap.put("success", true);
			   responseHashMap.put("responseData", dataHashMap);
		   }else
		   {
			   	dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		   }
		  
		}
	   
	    else if(dpMethod.equals("savePrdDocFee"))
	    {
	    	
	    	List prodfeeslist = (List) allRequestParams.get("requestData");
	    	
	    	for(int i=0;i<prodfeeslist.size();i++)
	    	{	
		    	List<LpstpPrdProFee> lpstpPrdDocFee= new ObjectMapper().convertValue(prodfeeslist.get(i), new TypeReference<List<LpstpPrdProFee>>() { });
		    	List<LpstpPrdProFee> lpstpPrdDocFeeList = serviceProvider.getLpstpPrdProFeeService().findByLpfProdIdOrderByLpfRowId(lpstpPrdDocFee.get(0).getlpfProdId());
		    	serviceProvider.getLpstpPrdProFeeService().deletePrdProfee(lpstpPrdDocFeeList);
	    		lpstpPrdDocFee.forEach(lpstpPrdDocFeelist1->{
    			lpstpPrdDocFeelist1.setlpfCreatedOn(Helper.getSystemDate());
    			lpstpPrdDocFeelist1.setlpfCreatedBy(userid);
    			lpstpPrdDocFeelist1.setlpfModifedBy(userid);
    			lpstpPrdDocFeelist1.setlpfComplete("N");
		    	lpstpPrdDocFeelist1.setlpfModifiedOn(Helper.getSystemDate());
	    	});
	    	
	    	List<LpstpPrdProFee> lpstpPrdDocFeeSaved = serviceProvider.getLpstpPrdProFeeService().savePrdProFee(lpstpPrdDocFee);
	    	Long l =(long) 0;
	    	Long prdId =(long) 0;
	    	for (LpstpPrdProFee lpstpPrdIntDoc :lpstpPrdDocFeeSaved)
	    	{
	    		prdId = new Long(lpstpPrdIntDoc.getlpfProdId().toString());
		    	 // prdId = BigDecimal.valueOf(l);
	    	}
	    	 
	    
	    	List<LpstpPrdProFee> lpstpPrdDocFeesave  = serviceProvider.getLpstpPrdProFeeService().getIntRateByPrdId(prdId);
	    	
			LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(prdId.longValue()));
	    	if(lpstpPrdDocFeesave !=null)
	    	{
	    		lpstpProductDetfromDB.setLpdComplete("N");
	    		lpstpProductDetfromDB=serviceProvider.getLpstpProductDetService().updateProductDetails(lpstpProductDetfromDB);
	    	}
	    	
	    	dataHashMap.put("lpstpProductDet",lpstpProductDetfromDB);
			dataHashMap.put("lpstpPrdDocFeesave",lpstpPrdDocFeeSaved);
	    	}
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	    
	    else if(dpMethod.equals("deletePrdDocfee"))
	    {
			List<LpstpPrdProFee> lpstpPrdDocFeesave= new ArrayList();
			lpstpPrdDocFeesave.add(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpPrdProFee>() { }));
		
			lpstpPrdDocFeesave.forEach(lpstpPrdDocFeedelete->{
				lpstpPrdDocFeedelete.setlpfCreatedOn(Helper.getSystemDate());
	    		lpstpPrdDocFeedelete.setlpfCreatedBy(userid);
	    		lpstpPrdDocFeedelete.setlpfModifedBy(userid);
	    		lpstpPrdDocFeedelete.setlpfComplete("N");
		    	lpstpPrdDocFeedelete.setlpfModifiedOn(Helper.getSystemDate());
	    	});
			
	    	serviceProvider.getLpstpPrdProFeeService().deletePrdProfee(lpstpPrdDocFeesave);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	   
	    
	   
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}

}
