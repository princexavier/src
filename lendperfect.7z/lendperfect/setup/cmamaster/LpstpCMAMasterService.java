package com.sai.lendperfect.setup.cmamaster;

import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpCMAMaster;

public interface LpstpCMAMasterService {

	public List<LpstpCMAMaster> findAll();
	public List<LpstpCMAMaster> fetchAllDataOrderByName();
	public LpstpCMAMaster saveData(LpstpCMAMaster modelObject);
}
