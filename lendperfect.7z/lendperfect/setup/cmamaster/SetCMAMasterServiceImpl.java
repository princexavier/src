package com.sai.lendperfect.setup.cmamaster;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.setupmodel.LpstpCMAMaster;
import com.sai.lendperfect.setuprepo.LpstpCMAMasterRepo;


@Service("setCMAMasterService")
@Transactional
public class SetCMAMasterServiceImpl implements LpstpCMAMasterService {
	@Autowired
	LpstpCMAMasterRepo setCMAMasterRepo;

	public List<LpstpCMAMaster> findAll() {
		return setCMAMasterRepo.findAll();
	}

	public List<LpstpCMAMaster> fetchAllDataOrderByName() {
		return  setCMAMasterRepo.findAll(new Sort(Sort.Direction.ASC, "cmaNo"));
	}

	public LpstpCMAMaster saveData(LpstpCMAMaster modelObject){
		return setCMAMasterRepo.saveAndFlush(modelObject);
	}
	

}
