package com.sai.lendperfect.setup.facilitymaster;

import java.math.BigDecimal;
import java.util.List;

/*import com.sai.lendperfect.model.SetStaticData;
*/import com.sai.lendperfect.setupmodel.LpstpFacility;

public interface LpstpFacilityService {
	
	List<LpstpFacility> findAll();
	LpstpFacility findById(long lsfFacId);
	LpstpFacility saveLpstpFacility(LpstpFacility lpstpFacility);
	void deleteLpstpFacility(LpstpFacility lpstpFacility);
	LpstpFacility findBylsfFacParentId(BigDecimal parentId);
	LpstpFacility findBylsfFacId(long facId);
	List<LpstpFacility> findBylsfFacParentIdAndLsfFacActive(BigDecimal lsfFacParentId,String lsfFacActive);
	List<LpstpFacility>  findByLsfFacActive(String LsfFacActive);
	LpstpFacility findByLsfFacDesc(String lsfFacDesc);
}
