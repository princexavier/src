package com.sai.lendperfect.setup.facilitymaster;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpFacility;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

public class LpstpFacilityDataProvider {
	
	@SuppressWarnings("null")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
 		Map <String,Object> dpHashMap=new HashMap<String,Object>();	
 		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
 		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
 		
 			
		if(dpMethod.equals("saveFacilityDetails"))
		{		
			try{
			LpstpFacility lpstpFacility =new LpstpFacility();
			lpstpFacility= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpFacility>() { });	
			
			if(lpstpFacility.getLsfFacId()==0)
			{
			lpstpFacility.setLsfCreatedOn(Helper.getSystemDate());
			lpstpFacility.setLsfCreatedBy(session.getAttribute("userid").toString());
			}
			lpstpFacility.setLsfModifiedBy(session.getAttribute("userid").toString());
			lpstpFacility.setLsfModifiedOn(Helper.getSystemDate());
		
			serviceProvider.getLpstpFacilityService().saveLpstpFacility(lpstpFacility);
			dataHashMap.put("FacilityDetails",lpstpFacility);		
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
			}
			catch (Exception e) {
				
				e.printStackTrace();
				logging.error("Provider : LpstpFacilityDataProvider /n saveFacilityDetails : {} /n Exception : ",dpMethod, e);
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
				responseHashMap.put("responseData", dataHashMap);
			}
		} 
		
		else if(dpMethod.equals("getMainFacility"))
		{	
			List<LpstpFacility>  lpstpFacilityList = new ArrayList<LpstpFacility>();
			 try
			 {
			dataHashMap.put("LoanType",serviceProvider.getCustomerDetailsService().findByllvHeader("LoanType"));
			
			List<LpstpFacility> lpstpFacility = serviceProvider.getLpstpFacilityService().findAll();
			
			for(int i=0;i<lpstpFacility.size();i++)
			{
				if(lpstpFacility.get(i).getLsfFacParentId() != 0)
				{
					LpstpFacility LpstpFacility = new LpstpFacility();
					LpstpFacility.setLsfFacDesc(lpstpFacility.get(i).getLsfFacDesc());
					LpstpFacility.setLsfFacId(lpstpFacility.get(i).getLsfFacId());
					lpstpFacilityList.add(LpstpFacility);
				}
				else
				{
					
				}
			}
			
			
			 dataHashMap.put("mainFacilityDetail",lpstpFacility);
			 dataHashMap.put("subfacility",lpstpFacilityList);
			 responseHashMap.put("success", true);
			 responseHashMap.put("responseData", dataHashMap);
			 }
			 catch (Exception e)
			 {
				e.printStackTrace();
				logging.error("Provider : LpstpFacilityDataProvider /n getMainFacility : {} /n Exception : ",dpMethod, e);
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
				responseHashMap.put("responseData", dataHashMap);
			}
			 
		}
		
		
		else if(dpMethod.equals("getFacilityDetails"))
		{
			try
			{
				long mainFacilityId=Long.parseLong(allRequestParams.get("requestData").toString());
				dataHashMap.put("FacilityDetails",serviceProvider.getLpstpFacilityService().findById(mainFacilityId));
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
			 catch (Exception e)
			 {
				e.printStackTrace();
				logging.error("Provider : LpstpFacilityDataProvider /n getFacilityDetails : {} /n Exception : ",dpMethod, e);
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
				responseHashMap.put("responseData", dataHashMap);
			}
			
		}
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
 		
		return responseHashMap;
	}

}
