package com.sai.lendperfect.setup.facilitymaster;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpFacility;
import com.sai.lendperfect.setuprepo.LpstpFacilityRepo;


@Service("LpstpFacilityService")
@Transactional
public class LpstpFacilityServiceImpl implements LpstpFacilityService{
	
	@Autowired
	private LpstpFacilityRepo lpstpFacilityRepo;

	@Override
	public List<LpstpFacility> findAll() {
		
		return lpstpFacilityRepo.findAll();
	}

	@Override
	public LpstpFacility findById(long lsfFacId) {
		
		return lpstpFacilityRepo.findOne(lsfFacId);
	}

	
	@Override
	public LpstpFacility saveLpstpFacility(LpstpFacility lpstpFacility) {
		return lpstpFacilityRepo.save(lpstpFacility);
	}

	@Override
	public void deleteLpstpFacility(LpstpFacility lpstpFacility) {
		lpstpFacilityRepo.delete(lpstpFacility);
	}

	@Override
	public LpstpFacility findBylsfFacParentId(BigDecimal parentId) {
		// TODO Auto-generated method stub
		return  lpstpFacilityRepo.findBylsfFacParentId(parentId);
	}

	@Override
	public LpstpFacility findBylsfFacId(long facId) {
		// TODO Auto-generated method stub
		return lpstpFacilityRepo.findBylsfFacId(facId);
	}

	public List<LpstpFacility> findBylsfFacParentIdAndLsfFacActive(BigDecimal lsfFacParentId, String lsfFacActive) {
		return lpstpFacilityRepo.findBylsfFacParentIdAndLsfFacActive(lsfFacParentId, lsfFacActive);
	}

	public List<LpstpFacility> findByLsfFacActive(String LsfFacActive) {
		return lpstpFacilityRepo.findByLsfFacActive(LsfFacActive);
	}

	@Override
	public LpstpFacility findByLsfFacDesc(String lsfFacDesc) {
		return lpstpFacilityRepo.findByLsfFacDesc(lsfFacDesc);
	}
		
	
}
