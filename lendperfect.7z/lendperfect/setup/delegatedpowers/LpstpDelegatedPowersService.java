package com.sai.lendperfect.setup.delegatedpowers;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpDelegatedPower;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.SetUserGroup;


public interface LpstpDelegatedPowersService  {
	List<LpstpDelegatedPower> findByLpstpProductDet(LpstpProductDet lpstpProductDet);
	LpstpDelegatedPower findByLpstpProductDetAndSetUserGroup(LpstpProductDet lpstpProductDet,SetUserGroup setUserGroup);
	LpstpDelegatedPower saveDelegatedPower(LpstpDelegatedPower lpstpDelegatedPowerList);

}
