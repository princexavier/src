package com.sai.lendperfect.setup.delegatedpowers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpDelegatedPower;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.LpstpTermsCondtn;
import com.sai.lendperfect.setupmodel.SetUserGroup;

public class LpstpDelegatedPowersDataProvider {

	@SuppressWarnings("unchecked")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		// TODO Auto-generated method stub
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		long lpdProdId=Long.parseLong(((Map<String,Object>) allRequestParams.get("requestData")).get("lpdProdId").toString());
		if(dpMethod.equals("getDelegatedPowersData"))
		{   
			   if(serviceProvider.getLpstpProductDetService().findByLpdProdNewId(lpdProdId)!=null)
			   {
				   try
				   {
				   LpstpProductDet lpstpProductDet=serviceProvider.getLpstpProductDetService().findByLpdProdNewId(lpdProdId);
				   List<SetUserGroup> setUserGroupList=serviceProvider.getUserGroupService().findAll();
				   List<Map<String,Object>> lpstpDelegatedPowersMapList=new ArrayList<Map<String,Object>>();
				   Iterator<SetUserGroup> setUserGroupListItr = setUserGroupList.iterator();
				   while(setUserGroupListItr.hasNext())
				   {
					   SetUserGroup setUserGroup = setUserGroupListItr.next();
					   LpstpDelegatedPower lpstpDelegatedPower = serviceProvider.getLpstpDelegatedPowersService().findByLpstpProductDetAndSetUserGroup(lpstpProductDet, setUserGroup);
					   Map<String,Object> lpstpDelegatedPowerMap;
					   if(lpstpDelegatedPower==null)
					   {
						   lpstpDelegatedPowerMap = new HashMap<String,Object>();
						   lpstpDelegatedPowerMap.put("ldpSno",0);
						   lpstpDelegatedPowerMap.put("ldpSanctionLimit",0);
					   }
					   else{
						   lpstpDelegatedPowerMap = new HashMap<String,Object>();
						   lpstpDelegatedPowerMap=new ObjectMapper().convertValue(lpstpDelegatedPower, Map.class);
					   }
					   lpstpDelegatedPowerMap.put("lpstpProductDet", lpstpProductDet.getLpdProdNewId());
					   lpstpDelegatedPowerMap.put("setUserGroup", setUserGroup.getSugGrpId());
					   lpstpDelegatedPowerMap.put("grpName", setUserGroup.getSugGrpName());
					   
					   lpstpDelegatedPowersMapList.add(lpstpDelegatedPowerMap);
				   }
				 
				   dataHashMap.put("lpstpDelegatedPowersMapList",lpstpDelegatedPowersMapList);
				   responseHashMap.put("success", true);
				   responseHashMap.put("responseData", dataHashMap);
				   }
				   catch(Exception e)
				   {
					   e.printStackTrace();
				   }
			   }
			   else
			   {
				   	dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
			   }
			   
		}else if(dpMethod.equals("saveDelegatedPowers")){
		//	List<LpstpDelegatedPower> delegatedPowerList = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<List<LpstpDelegatedPower>>() { });
			Map requestDataHashMap = new HashMap();
			requestDataHashMap = (Map<String,Object>)allRequestParams.get("requestData");
			
			List<LpstpDelegatedPower>  delegatedPowerList =  new ArrayList<LpstpDelegatedPower>() ;
			delegatedPowerList = (List<LpstpDelegatedPower>) requestDataHashMap.get("optionsFieldArray");
			List<LpstpDelegatedPower> list = new ArrayList();
			 ObjectMapper mapper = new ObjectMapper();
			 
			 LpstpDelegatedPower lpstpDelegatedPower1 = new LpstpDelegatedPower();
			 LpstpProductDet lpstpProductDet = new LpstpProductDet();
			 for(int i=0;i<delegatedPowerList.size();i++){
				 
				 mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				 Map<String,Object> data = (Map<String, Object>) delegatedPowerList.get(i);
				 lpstpDelegatedPower1 = mapper.convertValue(delegatedPowerList.get(i),LpstpDelegatedPower.class);
				 long sno = lpstpDelegatedPower1.getLdpSno();
				 if(sno==0)
				 {
					SetUserGroup setUserGroup = new SetUserGroup();
					setUserGroup.setSugGrpId(Long.parseLong(data.get("setUserGroup")+""));
					lpstpProductDet.setLpdProdNewId(Long.parseLong(data.get("lpstpProductDet")+""));
					lpstpDelegatedPower1.setLpstpUserGroup(setUserGroup);
					lpstpDelegatedPower1.setLpstpProductDet(lpstpProductDet);
					lpstpDelegatedPower1.setLdpCreatedBy(Helper.correctNull(session.getAttribute("userid")));
					lpstpDelegatedPower1.setLdpCreatedOn(Helper.getSystemDate());
					lpstpDelegatedPower1.setLdpModifiedBy(Helper.correctNull(session.getAttribute("userid")));
					lpstpDelegatedPower1.setLdpModifiedOn(Helper.getSystemDate());					 
					lpstpDelegatedPower1 = serviceProvider.getLpstpDelegatedPowersService().saveDelegatedPower(lpstpDelegatedPower1);
			 	}
				else{
					lpstpDelegatedPower1.setLdpSno(sno);
					lpstpProductDet.setLpdProdNewId(Long.parseLong(data.get("lpstpProductDet")+""));
					lpstpDelegatedPower1.setLpstpProductDet(lpstpProductDet);
					lpstpDelegatedPower1 = serviceProvider.getLpstpDelegatedPowersService().saveDelegatedPower(lpstpDelegatedPower1);
			 	}
			 }
		//	List<LpstpDelegatedPower> delegatedPowerSaveList = serviceProvider.getLpstpDelegatedPowersService().saveDelegatedPower(list);
			
			//LpstpProductDet lpstpProductDet=serviceProvider.getLpstpProductDetService().findByLpdProdNewId(lpdProdId);
			// LpstpDelegatedPower lpstpDelegatedPower = new LpstpDelegatedPower();
			 lpstpProductDet.setLpdProdNewId(lpdProdId);
			List<LpstpDelegatedPower> lpstpDelegatedPowersMapList =  serviceProvider.getLpstpDelegatedPowersService().findByLpstpProductDet(lpstpProductDet);
			dataHashMap.put("lpstpDelegatedPowersMapList",lpstpDelegatedPowersMapList);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
			
		}
		
		return responseHashMap;
	}

}
