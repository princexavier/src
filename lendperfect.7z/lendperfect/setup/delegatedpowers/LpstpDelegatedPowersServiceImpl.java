package com.sai.lendperfect.setup.delegatedpowers;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpDelegatedPower;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.SetUserGroup;
import com.sai.lendperfect.setuprepo.LpstpDelegatedPowersRepo;

@Service("LpstpDelegatedPowersService")
@Transactional
public class LpstpDelegatedPowersServiceImpl implements LpstpDelegatedPowersService{

	@Autowired
	LpstpDelegatedPowersRepo lpstpDelegatedPowersRepo;

	public List<LpstpDelegatedPower> findByLpstpProductDet(LpstpProductDet LpstpProductDet) {
		return lpstpDelegatedPowersRepo.findByLpstpProductDet(LpstpProductDet);
	}

	public LpstpDelegatedPower findByLpstpProductDetAndSetUserGroup(LpstpProductDet lpstpProductDet,SetUserGroup setUserGroup){
		return lpstpDelegatedPowersRepo.findByLpstpProductDetAndSetUserGroup( lpstpProductDet, setUserGroup);
	}

	public LpstpDelegatedPower saveDelegatedPower(LpstpDelegatedPower lpstpDelegatedPowerList) {
		return lpstpDelegatedPowersRepo.save(lpstpDelegatedPowerList);
	}
	

}
