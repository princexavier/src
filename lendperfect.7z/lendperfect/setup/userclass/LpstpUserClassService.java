package com.sai.lendperfect.setup.userclass;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpUserClass;

public interface LpstpUserClassService {

	List<LpstpUserClass> getRecordByDepartment(String lucDepartment);
	
	LpstpUserClass saveRecord(LpstpUserClass modelObject);
	void deleteRecord(LpstpUserClass modelObject);
	List<LpstpUserClass> findByLucDepartmentAndLucActive(String lucDepartment, String lucActive);
	List<LpstpUserClass> findByLucDepartmentAndLucActiveOrderByLucClassCode(String lucDepartment, String lucActive);
	LpstpUserClass findBylucClassCode(BigDecimal lucClassCode);
}
