package com.sai.lendperfect.setup.userclass;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.setupmodel.LpstpUserClass;
import com.sai.lendperfect.setuprepo.LpstpUserClassRepo;

@Service("lpstpUserClassService")
public class LpstpUserClassServiceImpl implements LpstpUserClassService {
@Autowired
private LpstpUserClassRepo repoObject;
	
	public List<LpstpUserClass> getRecordByDepartment(String lucDepartment) {
		return repoObject.findByLucDepartmentOrderByLucClassCode(lucDepartment);
	}

	public LpstpUserClass saveRecord(LpstpUserClass modelObject) {
		return repoObject.saveAndFlush(modelObject);
	}

	public void deleteRecord(LpstpUserClass modelObject) {
		
		repoObject.delete(modelObject);
	}

	public List<LpstpUserClass> findByLucDepartmentAndLucActive(String lucDepartment, String lucActive) {
		return repoObject.findByLucDepartmentAndLucActive(lucDepartment, lucActive);
	}

	@Override
	public List<LpstpUserClass> findByLucDepartmentAndLucActiveOrderByLucClassCode(String lucDepartment, String lucActive) {
		return repoObject.findByLucDepartmentAndLucActiveOrderByLucClassCode(lucDepartment, lucActive);
	}

	@Override
	public LpstpUserClass findBylucClassCode(BigDecimal lucClassCode) {
		return repoObject.findBylucClassCode(lucClassCode);
	}

}
