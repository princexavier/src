package com.sai.lendperfect.setup.orgmapping;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpOrgMapping;
import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setupmodel.SetOrganisation;

public interface LpstpOrgMappingService {
	LpstpOrgMapping saveLpstpOrgMapping(LpstpOrgMapping lpstpOrgMapping);
	List<LpstpOrgMapping> findByLomOrgParent(BigDecimal lomOrgParent);
	List<LpstpOrgMapping> findByLpstpOrganisation(LpstpOrganisation lpstpOrganisation);
	void deleteLpstpOrgMapping(List<LpstpOrgMapping> lpstpOrgMappingList);
	List<LpstpOrgMapping> findByLomBizVerticalAndLomDepartment(String lomBizVertical, String lomDepartment);
	LpstpOrgMapping findByLomBizVerticalAndLomDepartmentAndLpstpOrganisation(String bizVertical, String dept,
			LpstpOrganisation setOrganisation);
	
}
