package com.sai.lendperfect.setup.orgmapping;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpOrgMapping;
import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setuprepo.LpstpOrgMappingRepo;

@Service("lpstpOrgMappingService")
@Transactional
public class LpstpOrgMappingServiceImpl implements LpstpOrgMappingService {

	@Autowired
	private LpstpOrgMappingRepo lpstpOrgMappingRepo;

	public LpstpOrgMapping saveLpstpOrgMapping(LpstpOrgMapping lpstpOrgMapping) {
		return lpstpOrgMappingRepo.save(lpstpOrgMapping);
	}

	public List<LpstpOrgMapping> findByLomOrgParent(BigDecimal lomOrgParent) {
		return lpstpOrgMappingRepo.findByLomOrgParent(lomOrgParent);
	}

	public void deleteLpstpOrgMapping(List<LpstpOrgMapping> lpstpOrgMappingList) {
		lpstpOrgMappingRepo.delete(lpstpOrgMappingList);
	}

	public List<LpstpOrgMapping> findByLpstpOrganisation(LpstpOrganisation lpstpOrganisation) {
		return lpstpOrgMappingRepo.findByLpstpOrganisation(lpstpOrganisation);
	}

	public List<LpstpOrgMapping> findByLomBizVerticalAndLomDepartment(String lomBizVertical, String lomDepartment) {
		return lpstpOrgMappingRepo.findByLomBizVerticalAndLomDepartment(lomBizVertical, lomDepartment);
	}

	@Override
	public LpstpOrgMapping findByLomBizVerticalAndLomDepartmentAndLpstpOrganisation(String bizVertical, String dept, LpstpOrganisation setOrganisation) {

		return lpstpOrgMappingRepo.findByLomBizVerticalAndLomDepartmentAndLpstpOrganisation(bizVertical, dept, setOrganisation);
	}

}