package com.sai.lendperfect.setup.orgmapping;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustApplicantData;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomSecBankDeposit;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpAnnexMaster;
import com.sai.lendperfect.setupmodel.LpstpOrgMapping;
import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setupmodel.Organisation;

public class LpstpOrgMappingDataProvider {
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		Map <String,Object> lpstpOrgMappingHashMap=new HashMap<String,Object>();
		Map <String,Object> requestHashMap=new HashMap<String,Object>();
		Map <String,Object> dpHashMap=new HashMap<String,Object>();	
		List<LpstpOrgMapping> lpstpOrgMappingResponseList = new ArrayList<LpstpOrgMapping>();
		String strlevellet="",strcode="";
		Organisation organisation = new Organisation();
		responseHashMap.put("success", false);
		boolean flag = true;
		
		try {
			if (dpMethod.equals("saveOrgMapping")) {
				try {
					
					lpstpOrgMappingHashMap=(Map<String, Object>) allRequestParams.get("requestData");
					
					//Organization
					LpstpOrganisation lpstpOrganisation = new ObjectMapper().convertValue(lpstpOrgMappingHashMap.get("organisation"), new TypeReference<LpstpOrganisation>() {});
					if(lpstpOrganisation.getLoOrgId() == 0)
					{
						lpstpOrganisation.setLoOrgId(serviceProvider.getPrimaryIdGenerationService().getOrgId());
						lpstpOrganisation.setLoCreatedBy("SSK");
						lpstpOrganisation.setLoCreatedOn(Helper.getSystemDate());
						lpstpOrganisation.setLoOrgDepartment("C");
						flag = false;
					}
					else if(lpstpOrganisation.getLoOrgId() != 0)
					{
						lpstpOrganisation.setLoModifiedBy("SSK");
						lpstpOrganisation.setLoModifiedOn(Helper.getSystemDate());
						lpstpOrganisation.setLoOrgDepartment("C");
						flag = true;
					}
					
					LpstpOrganisation savedLpstpOrganisation=serviceProvider.getLpstpOrganisationService().saveLpstpOrganisation(lpstpOrganisation);
					
					//OrgMapping
					if(flag == true)
					{
						List<LpstpOrgMapping> lpstpOrgMappingList = serviceProvider.getLpstpOrgMappingService().findByLomOrgParent(new BigDecimal(savedLpstpOrganisation.getLoOrgId()));
						serviceProvider.getLpstpOrgMappingService().deleteLpstpOrgMapping(lpstpOrgMappingList); 
					}
					Organisation savedOrganisation = new Organisation();
					Organisation getOrganisation = new Organisation();
					LpstpOrgMapping lpstpOrgMapping;
					List<Map<String,Object>> unitListHashMap = (List<Map<String, Object>>) lpstpOrgMappingHashMap.get("unitList");
					Iterator unitListItr = unitListHashMap.iterator(); 
					while(unitListItr.hasNext()) 
					{
						lpstpOrgMapping = new LpstpOrgMapping();
						HashMap<String,Object> unitHashMap =  (HashMap<String, Object>) unitListItr.next();
						long unit = Long.parseLong(unitHashMap.get("unit").toString());
						LpstpOrganisation lpstpOrganisationForOrgMap = serviceProvider.getLpstpOrganisationService().findByLoOrgId(unit);
						lpstpOrgMapping.setLomBizVertical(lpstpOrganisation.getLoOrgBizVertical());
						lpstpOrgMapping.setLomDepartment("C");
						lpstpOrgMapping.setLpstpOrganisation(lpstpOrganisationForOrgMap);
						lpstpOrgMapping.setLomOrgParent(new BigDecimal(lpstpOrganisation.getLoOrgId()));
						lpstpOrgMapping.setLomCreatedBy("Sathish");
						lpstpOrgMapping.setLomCreatedOn(Helper.getSystemDate());
						lpstpOrgMapping.setLomModifiedBy("Sathish");
						lpstpOrgMapping.setLomModifiedOn(Helper.getSystemDate());
						serviceProvider.getLpstpOrgMappingService().saveLpstpOrgMapping(lpstpOrgMapping);
						lpstpOrgMappingResponseList.add(lpstpOrgMapping);
						
						/*Inserting Orgcode after Location Grouping*/
						
						getOrganisation=serviceProvider.getOrganisationService().findByorgId(lpstpOrganisation.getLoOrgId());
						strcode=getOrganisation.getOrgCode();
					
							if(lpstpOrganisation.getLoOrgLevel().equalsIgnoreCase("1")){
								strlevellet="B";
							}else if(lpstpOrganisation.getLoOrgLevel().equalsIgnoreCase("2")){
								strlevellet="A";
							}else if(lpstpOrganisation.getLoOrgLevel().equalsIgnoreCase("3")){
								strlevellet="D";
							}else if(lpstpOrganisation.getLoOrgLevel().equalsIgnoreCase("4")){
								strlevellet="R";
							}else if(lpstpOrganisation.getLoOrgLevel().equalsIgnoreCase("5")){
								strlevellet="C";
							}
							String[] strcheck=serviceProvider.getApplicationService().getOrgCode(strlevellet,strcode);
							organisation.setOrgId(unit);
							organisation.setOrgCode(strcheck[0]);	
							organisation.setOrgLevel(strcheck[1]);
							organisation.setOrgName(Helper.correctNull(lpstpOrganisationForOrgMap.getLoName()));
							organisation.setOrgScode(Helper.correctNull(lpstpOrganisationForOrgMap.getLoSolId()));
							organisation.setOrgAdd1(Helper.correctNull(lpstpOrganisationForOrgMap.getLoAddress1()));
							organisation.setOrgAdd2(Helper.correctNull(lpstpOrganisationForOrgMap.getLoAddress2()));
							organisation.setOrgCity(Helper.correctNull(lpstpOrganisationForOrgMap.getLoCity()));
							organisation.setOrgState(Helper.correctNull(lpstpOrganisationForOrgMap.getLoState()));
							organisation.setOrgZip(Helper.correctNull(String.valueOf(lpstpOrganisationForOrgMap.getLoPostalPin())));
							organisation.setOrgPhone(Helper.correctNull(lpstpOrganisationForOrgMap.getLoContactNo()));
							organisation.setOrgUrl(Helper.correctNull(lpstpOrganisationForOrgMap.getLoEmailId()));
							organisation.setOrgHead(Helper.correctNull(lpstpOrganisationForOrgMap.getLoOrgHead()));
							organisation.setOrgScode(Helper.correctNull(lpstpOrganisationForOrgMap.getLoSolId()));
							savedOrganisation=serviceProvider.getOrganisationService().saveOrganisation(organisation);
					}
					
					
					responseHashMap.put("success", true);
					responseHashMap.put("setOrganisation", lpstpOrganisation);
					responseHashMap.put("lpstpOrgMappingResponseList", lpstpOrgMappingResponseList);
					responseHashMap.put("lapsorganisation",savedOrganisation);
				
				    
				
					
					
					

				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} 
			
			else if(dpMethod.equals("getUnitListByUnitName"))
			{
				try {
					String strcodecheck="";
					List<LpstpOrganisation> setOrganisationList = new ArrayList<LpstpOrganisation>();
					Organisation getOrganisation = new Organisation();
					requestHashMap = (Map<String, Object>) allRequestParams.get("requestData");
					String loOrgBizVertical = requestHashMap.get("vertical").toString();
					String loOrgDepartment = (String) requestHashMap.get("dept");
					String loOrgLevel = (String) requestHashMap.get("orgLevel");
					long soOrgId = Long.parseLong((String) requestHashMap.get("unitName"));
					
					getOrganisation=serviceProvider.getOrganisationService().findByorgId(soOrgId);
					strcodecheck=getOrganisation.getOrgCode();
					
					if(!strcodecheck.equalsIgnoreCase("12345"))
					{
						LpstpOrganisation setOrganisation= serviceProvider.getLpstpOrganisationService().findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevelAndLoOrgId(loOrgBizVertical, loOrgDepartment, loOrgLevel, soOrgId);
						List<LpstpOrgMapping> lpstpOrgMappingList= serviceProvider.getLpstpOrgMappingService().findByLomOrgParent(new BigDecimal(setOrganisation.getLoOrgId()));
						Iterator<LpstpOrgMapping> lpstpOrgMappingListItr = lpstpOrgMappingList.iterator();
						while(lpstpOrgMappingListItr.hasNext())
						{
							LpstpOrgMapping lpstpOrgMappingItr = lpstpOrgMappingListItr.next();
							setOrganisationList.add(lpstpOrgMappingItr.getLpstpOrganisation());
						}
						dpHashMap.put("unitListByUnitName",setOrganisationList);
						dpHashMap.put("unitorgcheck","Y");
						responseHashMap.put("success", true);
						responseHashMap.put("responseData", dpHashMap);
				    }else
				    {
				    	dpHashMap.put("unitorgcheck","N");
						responseHashMap.put("success", true);
				    }
				}
				catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			
			else {
				dataHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
			return responseHashMap;
		}
		catch (Exception e) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod,e.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		}
		return responseHashMap;
	}
}
