package com.sai.lendperfect.setup.finformula;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpCMAMaster;
import com.sai.lendperfect.setupmodel.LpstpFinFormula;

public class CMAFormulaDataProvider {
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{	
		logging.setLoggerClass(this.getClass());	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		responseHashMap.put("success", true);
		LpstpFinFormula lpstpFinFormula=null;
		try{
		if(dpMethod.equals("getGlobalVariableDataOrderByName"))
		{			
			try {
				responseHashMap.put("globalVariableDataOrderByName", serviceProvider.getLpstpGlobalVariableService().findAll());
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}

		}
		
		else if(dpMethod.equals("getformulaDataOrderByRowId"))
		{		
			try {
			
				
			responseHashMap.put("formulaDataOrderByRowId", serviceProvider.getLpstpFinFormulaService().fetchAllDataOrderByRowId());
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			}
			
		}
		else if(dpMethod.equals("getFormulaForOrderByName"))
		{		
			try {
				
			responseHashMap.put("formulaDataOrderByName", serviceProvider.getLpstpFinFormulaService().fetchAllDataOrderByRowId());
			
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			}}
			else if(dpMethod.equals("getFinMasterAllDataOrderByName"))
			{		
				try {
					// order by RowId 
				responseHashMap.put("finMasterAllDataOrderByName", serviceProvider.getSetFinMasterService().fetchAllDataRowTypeAsEntryOrderByName());
				
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
						}
				}
		}
			else if(dpMethod.equals("getCMADataListOrderByName"))
			{		
				try {
					
					responseHashMap.put("cmaMasterAllDataOrderByName", serviceProvider.getSetCMAMasterService().fetchAllDataOrderByName());
				
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
						}
				}
		}
			else if(dpMethod.equals("saveData"))
			{		
				try {
					lpstpFinFormula=new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpFinFormula>() {});

					responseHashMap.put("saveCurrentData",serviceProvider.getLpstpFinFormulaService().saveData(lpstpFinFormula));
				
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
						}
				}
		}
			else if(dpMethod.equals("updateData"))
			{		
				try {
					lpstpFinFormula=new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpFinFormula>() {});
					 int i =serviceProvider.getLpstpFinFormulaService().updateData(lpstpFinFormula);
					 if(i>0){
							responseHashMap.put("saveCurrentData",serviceProvider.getLpstpFinFormulaService().getDataByRowId(lpstpFinFormula.getLffFormId()));

					 }else{
						 
					 }
				
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
						}
				}
		}
			else if(dpMethod.equals("getFormulaDataByCMATypeAndFormulaFor")){		
			try {
				HashMap hshMap=(HashMap)allRequestParams.get("requestData");
				long cmaType=Long.valueOf(hshMap.get("cmaType").toString());
				String fromulaFor=hshMap.get("formulaFor").toString();
				responseHashMap.put("formulaDataByCMATypeandFormulaFor",serviceProvider.getLpstpFinFormulaService().fetchformulaDataByCmaTypeandformulaFor(cmaType,fromulaFor));
		
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			}
			}
			else if(dpMethod.equals("saveFinTypeData"))
			{		
				try {
					HashMap hshMap=(HashMap)allRequestParams.get("requestData");
					String cmaName=hshMap.get("cmaName").toString();
					BigDecimal indCode=new BigDecimal(hshMap.get("indCode").toString());
					LpstpCMAMaster modelObject= new LpstpCMAMaster();
					modelObject.setCmaFormatDesc(cmaName);
					modelObject.setIndCode(indCode);
					modelObject=	serviceProvider.getSetCMAMasterService().saveData(modelObject);
					responseHashMap.put("cmaMasterAllDataOrderByName", serviceProvider.getSetCMAMasterService().fetchAllDataOrderByName());
					
				
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
						}
				}
		}else if(dpMethod.equals("getPageAccess"))
		 {
			try {
			 responseHashMap.put("pageAccess",serviceProvider.getLpmasPageMasterService().getPageAcessByPageId("403",serviceProvider,session) ); 
			// responseHashMap.put("pageAccess","R");
			}
		catch (Exception ex) {
		if (!dataHashMap.containsKey("errorData")) {
			logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
			dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		}	 }else {
			dataHashMap.put("errorData",new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		
		
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		return responseHashMap;
		}
	}


