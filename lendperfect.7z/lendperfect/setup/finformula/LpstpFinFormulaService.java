package com.sai.lendperfect.setup.finformula;

import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpFinFormula;


public interface LpstpFinFormulaService {
 List<LpstpFinFormula> fetchAllDataOrderByRowId();
 List<LpstpFinFormula> getDataByRowId(long rowId);

 List<LpstpFinFormula> fetchAllDataOrderByFormulaName();
 List<LpstpFinFormula> saveData(LpstpFinFormula modelObject);
 Integer updateData(LpstpFinFormula modelObject);
 void deleteData(LpstpFinFormula modelObject);
 String getFormulaValueByRowId(long rowId);
 List<LpstpFinFormula> fetchformulaDataByCmaTypeandformulaFor(long lffCmaNo,String lffFormFor);
}
