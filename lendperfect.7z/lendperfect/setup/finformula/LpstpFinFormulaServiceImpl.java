package com.sai.lendperfect.setup.finformula;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpFinFormula;
import com.sai.lendperfect.setuprepo.LpstpFinFormulaRepo;


@Service("lpstpFinFormulaService")
@Transactional
public class LpstpFinFormulaServiceImpl implements LpstpFinFormulaService {
@Autowired
private LpstpFinFormulaRepo repoObj;

public List<LpstpFinFormula> fetchAllDataOrderByRowId() {
	return repoObj.findAll(new Sort(Sort.Direction.ASC, "lffFormId"));
}

public List<LpstpFinFormula> fetchAllDataOrderByFormulaName() {
	return repoObj.findAll(new Sort(Sort.Direction.ASC, "lffFormName"));
}

public List<LpstpFinFormula> saveData(LpstpFinFormula modelObject) {
	return Arrays.asList(repoObj.saveAndFlush(modelObject));
}

public List<LpstpFinFormula> getDataByRowId(long rowId) {
	return  Arrays.asList(repoObj.findOne(rowId));
}

public Integer updateData(LpstpFinFormula modelObject) {
	return repoObj.updateRowofFinFormula(modelObject.getLffCmaNo(), modelObject.getLffFormDesc(), modelObject.getLffFormFor(),
			modelObject.getLffFormName(), modelObject.getLffFormValue(), modelObject.getLffModifiedBy(), modelObject.getLffModifiedOn(), modelObject.getLffFormId());
}

public void deleteData(LpstpFinFormula modelObject) {
repoObj.delete(modelObject);
}

public String getFormulaValueByRowId(long rowId) {
	return repoObj.getFormulaValueByRowId(rowId);
}

public List<LpstpFinFormula> fetchformulaDataByCmaTypeandformulaFor(long lffCmaNo, String lffFormFor) {
	return repoObj.findByLffCmaNoAndLffFormForOrderByLffFormIdAsc(BigDecimal.valueOf(lffCmaNo), lffFormFor);
}
	
}
