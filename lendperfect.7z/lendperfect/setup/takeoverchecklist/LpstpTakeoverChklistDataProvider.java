package com.sai.lendperfect.setup.takeoverchecklist;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasPageMaster;
import com.sai.lendperfect.setupmodel.LpstpTakeoverChklist;

public class LpstpTakeoverChklistDataProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
	
				try{
		 if(dpMethod.equals("getBusinessVertical"))
			{
				dataHashMap.put("BizVertical",serviceProvider.getLpmasBizVerticalService().findAll());
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}

		 else if(dpMethod.equals("getTakeoverMaster")){
			 LpstpTakeoverChklist lpstpTakeoverChklist=new LpstpTakeoverChklist();
			 lpstpTakeoverChklist.setLtcBizVertical(String.valueOf(allRequestParams.get("requestData")));
			 List<LpstpTakeoverChklist>lpstpTakeoverChklistList=serviceProvider.getLpstpTakeoverChklistService().findByltcBizVertical(lpstpTakeoverChklist.getLtcBizVertical());
				dataHashMap.put("TakeoverMaster",lpstpTakeoverChklistList);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
		 }
		 else if(dpMethod.equals("saveTakeoverMaster"))
			{			
			 LpstpTakeoverChklist lpstpTakeoverChklist=	new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpTakeoverChklist>() { });				
			if(lpstpTakeoverChklist.getLtcRowId()==null){
			 lpstpTakeoverChklist.setLtcCreatedBy(session.getAttribute("userid").toString());
			 lpstpTakeoverChklist.setLtcCreatedOn(new Date(System.currentTimeMillis()));
			}
			 lpstpTakeoverChklist.setLtcModifiedBy(session.getAttribute("userid").toString());
			 lpstpTakeoverChklist.setLtcModifiedOn(new Date(System.currentTimeMillis()));
			 lpstpTakeoverChklist= serviceProvider.getLpstpTakeoverChklistService().saveTakeoverMaster(lpstpTakeoverChklist);
			 dataHashMap.put("takeover", lpstpTakeoverChklist);
			 responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
			}
		 else if(dpMethod.equals("getTakeoverMasterData"))
			{			
			 LpstpTakeoverChklist lpstpTakeoverChklist=new LpstpTakeoverChklist();
			 lpstpTakeoverChklist.setLtcRowId((new BigDecimal(String.valueOf(allRequestParams.get("requestData")))));
			 List<LpstpTakeoverChklist>lpstpTakeoverChklistList=new ArrayList();
			 lpstpTakeoverChklist =serviceProvider.getLpstpTakeoverChklistService().findByltcRowId(lpstpTakeoverChklist.getLtcRowId());
			 lpstpTakeoverChklistList.add(lpstpTakeoverChklist);
			 dataHashMap.put("TakeoverMaster",lpstpTakeoverChklistList);
			 responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
			}
		 else	 if(dpMethod.equals("deleteTakeoverMaster"))
			{
			 LpstpTakeoverChklist lpstpTakeoverChklist=new LpstpTakeoverChklist();
			BigDecimal id=new BigDecimal(String.valueOf(allRequestParams.get("requestData")));
			 lpstpTakeoverChklist=serviceProvider.getLpstpTakeoverChklistService().findByltcRowId(id);
			 serviceProvider.getLpstpTakeoverChklistService().deleteLpstpTakeoverChklist(lpstpTakeoverChklist);
				responseHashMap.put("success", true);
			}
		 
		}
		
		 catch (Exception ex) {
			 ex.printStackTrace();
				dataHashMap.put("errorData", ex.getLocalizedMessage());
					responseHashMap.put("success", false);		
					responseHashMap.put("responseData", dataHashMap);
			}
return responseHashMap;
	}

}
