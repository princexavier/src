package com.sai.lendperfect.setup.takeoverchecklist;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpTakeoverChklist;

public interface LpstpTakeoverChklistService {

	LpstpTakeoverChklist saveTakeoverMaster(LpstpTakeoverChklist lpstpTakeoverChklist);

	LpstpTakeoverChklist findByltcRowId(BigDecimal ltcRowId);

	void deleteLpstpTakeoverChklist(LpstpTakeoverChklist lpstpTakeoverChklist);

  List<LpstpTakeoverChklist> findByltcBizVertical(String ltcBizVertical);

List<LpstpTakeoverChklist> findAll();

}
