package com.sai.lendperfect.setup.takeoverchecklist;
import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpTakeoverChklist;
import com.sai.lendperfect.setuprepo.LpstpTakeoverChklistRepo;

@Service("lpstpTakeoverChklistService")
@Transactional
public class LpstpTakeoverChklistServiceImpl implements LpstpTakeoverChklistService {
	@Autowired
	LpstpTakeoverChklistRepo lpstpTakeoverChklistRepo;


	public LpstpTakeoverChklist saveTakeoverMaster(LpstpTakeoverChklist lpstpTakeoverChklist) {
		return lpstpTakeoverChklistRepo.save(lpstpTakeoverChklist);
	}


	public LpstpTakeoverChklist findByltcRowId(BigDecimal ltcRowId) {
		
		return lpstpTakeoverChklistRepo.findByltcRowId(ltcRowId);
	}


	public void deleteLpstpTakeoverChklist(LpstpTakeoverChklist lpstpTakeoverChklist) {
		lpstpTakeoverChklistRepo.delete(lpstpTakeoverChklist);
	}
	
	public List<LpstpTakeoverChklist> findByltcBizVertical(String ltcBizVertical) {
	
		return lpstpTakeoverChklistRepo.findByltcBizVertical(ltcBizVertical);
	}


	public List<LpstpTakeoverChklist> findAll() {
		
		return lpstpTakeoverChklistRepo.findAll();
	}



}
