package com.sai.lendperfect.setup.scorecardmaster;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpScorecardMaster;
import com.sai.lendperfect.setuprepo.LpstpScorecardMasterRepo;

@Service("lpstpScorecardMasterService")
@Transactional
public class LpstpScorecardMasterServiceImpl implements LpstpScorecardMasterService {

	@Autowired
	private LpstpScorecardMasterRepo lpstpScorecardMasterRepo;

	public List<LpstpScorecardMaster> findAll() {
		return lpstpScorecardMasterRepo.findAll();
	}

	public List<LpstpScorecardMaster> findById(long scmRowId) {
		return Arrays.asList(lpstpScorecardMasterRepo.findOne(scmRowId));
	}

	public List<Object> getDistinctnonDeleteandActiveHeaderList(String scpmAvailable) {
		// return null;
		return lpstpScorecardMasterRepo.getDistinctHeader(scpmAvailable);
	}

	public LpstpScorecardMaster findByid(long scmRowId) {
		return lpstpScorecardMasterRepo.findOne(scmRowId);

	}

	public LpstpScorecardMaster saveData(LpstpScorecardMaster lpstpScorecardMaster) {
		return lpstpScorecardMasterRepo.saveAndFlush(lpstpScorecardMaster);
	}

	public void deleteData(LpstpScorecardMaster lpstpScorecardMaster) {
		lpstpScorecardMasterRepo.delete(lpstpScorecardMaster);
	}

	public Integer updateDataHeaderDescByQuesHeaderId(LpstpScorecardMaster lpstpScorecardMaster) {
		// return null;
		return lpstpScorecardMasterRepo.updateHeaderDescByQuesHeaderId(lpstpScorecardMaster.getScmHeaderDesc(), BigDecimal.valueOf(lpstpScorecardMaster.getScmRowId()));
	}

	public List<Object> getDistinctHeaderByScFor(String scmScFor) {// , String
																	// scpmAvailable)
																	// {
		return lpstpScorecardMasterRepo.getDistinctHeaderByScFor(scmScFor);// ;,
																			// scpmAvailable);
	}

	// public List<LpstpScorecardMaster> findByScmScForAndScmAvailable(String
	// scmScFor, String scmAvailable) {
	// return
	// lpstpScorecardMasterRepo.findByScmScForAndScmAvailableOrderByScmRowId(scmScFor,
	// scmAvailable);
	// }

	@Override
	public List<Object> getDistinctHeaderByScForAndBizVerticalAndBizRule(String scmScFor, String scmBizVertical, long scmLrbSeqno) {
		return lpstpScorecardMasterRepo.getDistinctHeaderByScForAndBizVerticalAndBusinessrule(scmScFor, scmBizVertical, scmLrbSeqno);
	}

	@Override
	public List<LpstpScorecardMaster> findDistinctByScmQuesHeaderIdAndScmLapsDefined(BigDecimal scmQuesHeaderId, String scmLapsDefined) {
		return lpstpScorecardMasterRepo.findDistinctByScmQuesHeaderIdAndScmLapsDefined(scmQuesHeaderId, scmLapsDefined);
	}

	@Override
	public List<LpstpScorecardMaster> findByScmQuesHeaderIdAndScmAvailable(BigDecimal scmQuesHeaderId, String scmAvailable) {
		// TODO Auto-generated method stub
		return lpstpScorecardMasterRepo.findByScmQuesHeaderIdAndScmAvailable(scmQuesHeaderId, scmAvailable);
	}

	@Override
	public List<LpstpScorecardMaster> findByScmScForAndScmAvailableAndScmLrbSeqnoAndScmLapsDefinedOrderByScmQuesHeaderId(String scmScFor, String scmAvailable, long scmLrbSeqno, String scmLapsDefined) {
		return lpstpScorecardMasterRepo.findByScmScForAndScmAvailableAndScmLrbSeqnoAndScmLapsDefinedOrderByScmQuesHeaderId(scmScFor, scmAvailable, scmLrbSeqno, scmLapsDefined);
	}
}
