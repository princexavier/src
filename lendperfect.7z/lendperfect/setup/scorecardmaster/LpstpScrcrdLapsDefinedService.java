package com.sai.lendperfect.setup.scorecardmaster;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpScrcrdLapsDefined;

public interface LpstpScrcrdLapsDefinedService {
	List<LpstpScrcrdLapsDefined> findAll();

	LpstpScrcrdLapsDefined findById(BigDecimal id);

	List[] getSystemDefinedParameter(Long proposalNo, Long facilityNo);

	Object getDscrValue(Long proposalNo);
}
