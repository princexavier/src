package com.sai.lendperfect.setup.scorecardmaster;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpScrcrdLapsDefined;
import com.sai.lendperfect.setuprepo.LpstpScrcrdLapsDefinedRepo;

@Service("lpstpScrcrdLapsDefinedService")
@Transactional
public class LpstpScrcrdLapsDefinedServiceImpl implements LpstpScrcrdLapsDefinedService {

	@Autowired
	private LpstpScrcrdLapsDefinedRepo lpstpScrcrdLapsDefinedRepo;

	@Override
	public List<LpstpScrcrdLapsDefined> findAll() {
		return lpstpScrcrdLapsDefinedRepo.findAll();
	}

	@Override
	public LpstpScrcrdLapsDefined findById(BigDecimal id) {
		return lpstpScrcrdLapsDefinedRepo.findOne(id);
	}

	@Override
	public List[] getSystemDefinedParameter(Long proposalNo, Long facilityNo) {
		return lpstpScrcrdLapsDefinedRepo.getSystemDefinedParameter(proposalNo, facilityNo);
	}

	@Override
	public Object getDscrValue(Long proposalNo) {
		return lpstpScrcrdLapsDefinedRepo.getDscrValue(proposalNo);
	}

}
