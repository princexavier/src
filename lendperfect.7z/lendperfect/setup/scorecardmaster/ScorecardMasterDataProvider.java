package com.sai.lendperfect.setup.scorecardmaster;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.mastermodel.LpmasListofvalues1;
import com.sai.lendperfect.setupmodel.LpstpScorecardMaster;
import com.sai.lendperfect.setupmodel.LpstpScorecardOptionMaster;
import com.sai.lendperfect.setupmodel.LpstpScrcrdLapsDefined;

public class ScorecardMasterDataProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData, ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(this.getClass());
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		LpstpScorecardMaster lpstpScorecardMaster = null;
		LpstpScorecardOptionMaster lpstpScorecardOptionMaster = null;
		responseHashMap.put("success", true);
		logging.info("method:{}", dpMethod);

		try {
			if (dpMethod.equals("getDistinctHeaderDetail")) {
				try {

					responseHashMap.put("distinctHeaderDetail", serviceProvider.getLpstpScorecardMasterService().getDistinctnonDeleteandActiveHeaderList("Y"));

				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}

			} else if (dpMethod.equals("getAllBankDefinedQuestionList")) {
				try {
					long rowId = Long.parseLong((String) allRequestParams.get("requestData"));
					// responseHashMap.put("allQuestionList",serviceProvider.getSetScorecardMasterService().getDistinctActiveQuestionList(rowId,"Y"));
					List<LpstpScorecardMaster> list = serviceProvider.getLpstpScorecardMasterService().findDistinctByScmQuesHeaderIdAndScmLapsDefined(new BigDecimal(rowId), "N");
					responseHashMap.put("allQuestionList", list);
				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getAllLapsDefinedQuestionList")) {
				try {
					long rowId = Long.parseLong((String) allRequestParams.get("requestData"));
					// responseHashMap.put("allQuestionList",serviceProvider.getSetScorecardMasterService().getDistinctActiveQuestionList(rowId,"Y"));
					List<LpstpScorecardMaster> list = serviceProvider.getLpstpScorecardMasterService().findDistinctByScmQuesHeaderIdAndScmLapsDefined(new BigDecimal(rowId), "Y");
					responseHashMap.put("allQuestionList", list);
				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getAllOptionListByQuestionId")) {
				try {
					long rowId = Long.parseLong((String) allRequestParams.get("requestData").toString());
					lpstpScorecardMaster = serviceProvider.getLpstpScorecardMasterService().findByid(rowId);
					lpstpScorecardMaster.getScmRowId();
					// responseHashMap.put("allOptionListByquestionRowId",serviceProvider.getSetScorecardOptionMasterService().getDataByQuestionId(setScorecardMaster));
					responseHashMap.put("allOptionListByquestionRowId", serviceProvider.getLpstpScorecardOptionMasterService().findByLpstpScorecardMasterAndScpmdelete(lpstpScorecardMaster, "N"));

				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						ex.printStackTrace();
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}

			else if (dpMethod.equals("deleteScoreCard")) {
				try {
					responseHashMap = (Map<String, Object>) allRequestParams.get("requestData");
					Long rowid = Long.parseLong(responseHashMap.get("rowId").toString());
					List<LpstpScorecardOptionMaster> lpstpScorecardOptionMasterlist = new ArrayList();
					LpstpScorecardMaster LpstpScorecardMasterObj = new LpstpScorecardMaster();
					LpstpScorecardOptionMaster lpstpScorecardOptionMasterObj = serviceProvider.getLpstpScorecardOptionMasterService().findByRowId(rowid);
					lpstpScorecardOptionMasterObj.setScpmdelete("Y");
					lpstpScorecardOptionMasterObj = serviceProvider.getLpstpScorecardOptionMasterService().savaData(lpstpScorecardOptionMasterObj);
					LpstpScorecardMasterObj = lpstpScorecardOptionMasterObj.getLpstpScorecardMaster();
					lpstpScorecardOptionMasterlist = serviceProvider.getLpstpScorecardOptionMasterService().findByLpstpScorecardMasterAndScpmdelete(lpstpScorecardMaster, "N");
					responseHashMap.put("success", true);
					responseHashMap.put("lpstpScorecardOptionMasterlist", lpstpScorecardOptionMasterlist);
				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}

				}
			}

			else if (dpMethod.equals("saveMasterData")) {
				try {
					lpstpScorecardMaster = new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpScorecardMaster>() {
					});
					if (lpstpScorecardMaster.getScmRowId() == 0) {
						lpstpScorecardMaster.setScmCreatedBy(session.getAttribute("userid").toString());
						lpstpScorecardMaster.setScmCreatedOn(new Date());
						lpstpScorecardMaster.setScmModifiedOn(lpstpScorecardMaster.getScmCreatedOn());
						lpstpScorecardMaster.setScmModifiedBy((session.getAttribute("userid").toString()));
					} else {
						lpstpScorecardMaster.setScmModifiedOn(new Date());
						lpstpScorecardMaster.setScmModifiedBy((session.getAttribute("userid").toString()));
					}

					lpstpScorecardMaster = serviceProvider.getLpstpScorecardMasterService().saveData(lpstpScorecardMaster);
					responseHashMap.put("saveDataasList", Arrays.asList(lpstpScorecardMaster));

					if (lpstpScorecardMaster.getScmQuesHeaderId() != null && lpstpScorecardMaster.getScmQuesHeaderId().intValueExact() == 0) {
						serviceProvider.getLpstpScorecardMasterService().updateDataHeaderDescByQuesHeaderId(lpstpScorecardMaster);
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("saveOptionMasterData")) {

				try {
					@SuppressWarnings("unchecked")
					Map<String, Object> requestHashMap = (Map<String, Object>) allRequestParams.get("requestData");
					@SuppressWarnings("unchecked")
					List<Map<String, Object>> fieldArrayHashMapList = (List<Map<String, Object>>) requestHashMap.get("optionsFieldArray");
					Iterator<Map<String, Object>> fieldArrayHashMapListItr = fieldArrayHashMapList.iterator();
					long rowId = Long.valueOf((String) requestHashMap.get("scmRowId").toString());
					List<LpstpScorecardOptionMaster> listOfoptions = new ArrayList<LpstpScorecardOptionMaster>();
					String Optiontype = requestHashMap.get("optionType").toString();
					lpstpScorecardMaster = new ObjectMapper().convertValue(requestHashMap.get("cardModel"), LpstpScorecardMaster.class);

					if (rowId == 0) {
						lpstpScorecardMaster.setScmCreatedBy(session.getAttribute("userid").toString());
						lpstpScorecardMaster.setScmCreatedOn(new Date());
						lpstpScorecardMaster.setScmModifiedOn(lpstpScorecardMaster.getScmCreatedOn());
						lpstpScorecardMaster.setScmModifiedBy((session.getAttribute("userid").toString()));
						lpstpScorecardMaster = serviceProvider.getLpstpScorecardMasterService().saveData(lpstpScorecardMaster);
					} else {
						lpstpScorecardMaster = serviceProvider.getLpstpScorecardMasterService().findByid(rowId);
						lpstpScorecardMaster.setScmOptionType(Optiontype);
						lpstpScorecardMaster = serviceProvider.getLpstpScorecardMasterService().saveData(lpstpScorecardMaster);
					}
					if (lpstpScorecardMaster != null) {
						Map<String, Object> hshMap = null;
						String temp = null;

						while (fieldArrayHashMapListItr.hasNext()) {
							hshMap = fieldArrayHashMapListItr.next();
							lpstpScorecardOptionMaster = new LpstpScorecardOptionMaster();
							lpstpScorecardOptionMaster.setScpmRowId(Long.valueOf((String) hshMap.get("rowId").toString()));
							lpstpScorecardOptionMaster.setScpmOptionDesc(Optiontype);
							lpstpScorecardOptionMaster.setScpmdelete("N");
							temp = (String) hshMap.get("weightage").toString();
							if (!temp.equalsIgnoreCase("")) {
								lpstpScorecardOptionMaster.setScpmOptionWgt(BigDecimal.valueOf(Long.valueOf(temp)));
							} else {
								lpstpScorecardOptionMaster.setScpmOptionWgt(null);
							}
							// setScorecardOptionMaster.setScpmOptionWgt(BigDecimal.valueOf(Long.valueOf((String)hshMap.get("weightage").toString())));
							if (Optiontype.equals("R")) {
								lpstpScorecardOptionMaster.setScpmOptionFrom(new BigDecimal(hshMap.get("valFrom").toString()));
								temp = hshMap.get("valTo").toString();
								if (!temp.equalsIgnoreCase("")) {
									lpstpScorecardOptionMaster.setScpmOptionTo(new BigDecimal(temp));
								} else {
									lpstpScorecardOptionMaster.setScpmOptionTo(null);
								}
							} else if (Optiontype.equals("V")) {

								temp = (String) hshMap.get("optionvalue").toString();
								if (!temp.equalsIgnoreCase(""))
									lpstpScorecardOptionMaster.setScpmOptionValue(temp);

							}
							lpstpScorecardOptionMaster.setScpmOptionAvailable((String) hshMap.get("active"));
							// lpstpScorecardOptionMaster.setScpmOptionAvailable(null);
							// lpstpScorecardOptionMaster.setScpmOptionIsdelete((String)hshMap.get("delete"));
							if (lpstpScorecardOptionMaster.getScpmRowId() == 0) {
								lpstpScorecardOptionMaster.setScpmCreatedBy(session.getAttribute("userid").toString());
								lpstpScorecardOptionMaster.setScpmCreatedOn(new Date());
								lpstpScorecardOptionMaster.setScpmModifiedBy(session.getAttribute("userid").toString());
								lpstpScorecardOptionMaster.setScpmModifiedOn(lpstpScorecardOptionMaster.getScpmCreatedOn());
							} else {
								LpstpScorecardOptionMaster lpstpScorecardOptionMaster2 = serviceProvider.getLpstpScorecardOptionMasterService().findByRowId(lpstpScorecardOptionMaster.getScpmRowId());
								lpstpScorecardOptionMaster.setScpmCreatedBy(lpstpScorecardOptionMaster2.getScpmCreatedBy());
								lpstpScorecardOptionMaster.setScpmCreatedOn(lpstpScorecardOptionMaster2.getScpmCreatedOn());
								lpstpScorecardOptionMaster.setScpmModifiedBy(session.getAttribute("userid").toString());
								lpstpScorecardOptionMaster.setScpmModifiedOn(new Date());
							}
							lpstpScorecardOptionMaster.setLpstpScorecardMaster(lpstpScorecardMaster);
							listOfoptions.add(lpstpScorecardOptionMaster);
							responseHashMap.put("savedlpstpScoreCardOption", serviceProvider.getLpstpScorecardOptionMasterService().savaData(lpstpScorecardOptionMaster));
						}
						lpstpScorecardMaster.setLpstpScorecardOptionMasters(listOfoptions);

						responseHashMap.put("saveDataasList", Arrays.asList(serviceProvider.getLpstpScorecardMasterService().saveData(lpstpScorecardMaster)));

					}

				} catch (Exception ex) {
					ex.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getMessage());
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getBizVerticalList")) {
				try {
					responseHashMap.put("arryOfBizVerticalList", serviceProvider.getLpmasBizVerticalService().findAll());
				} catch (Exception e) {
					e.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
						dataHashMap.put("errorData", new CustomErr(e.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getBizRuleList")) {
				try {
					responseHashMap.put("arryOfBizRule", serviceProvider.getLpstpRiskBusinessruleService().findAll());
				} catch (Exception e) {
					e.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
						dataHashMap.put("errorData", new CustomErr(e.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}

			else if (dpMethod.equals("getLapsDefinedParameters")) {
				try {
					responseHashMap.put("lapsDefinedQuestions", serviceProvider.getLpstpScrcrdLapsDefinedService().findAll());
					responseHashMap.put("success", true);
				} catch (Exception e) {
					e.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
						dataHashMap.put("errorData", new CustomErr(e.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}

			else if (dpMethod.equals("getLapsOptions")) {
				try {
					LpstpScrcrdLapsDefined lpstpScrcrdLapsDefined = serviceProvider.getLpstpScrcrdLapsDefinedService().findById(new BigDecimal(allRequestParams.get("requestData").toString()));
					LpmasListofvalues1 lpmasListofvalue = serviceProvider.getLpmasListofvalues1Service().findByLlvRowId(lpstpScrcrdLapsDefined.getLsldLlvRowId());
					List<LpmasListofvalue> lpmasListofvalueslist = serviceProvider.getLpmasListofvalueService().findByLlvHeader(lpmasListofvalue.getLlvHeader());
					ArrayList<String> optionDescList = new ArrayList<>();
					for (LpmasListofvalue llv : lpmasListofvalueslist) {
						optionDescList.add(llv.getLlvOptionDesc());
					}
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", optionDescList);
				} catch (Exception e) {
					e.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
						dataHashMap.put("errorData", new CustomErr(e.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}

			else if (dpMethod.equals("getDistinctHeaderRecordBySCFor")) {
				try {
					String scmScFor = allRequestParams.get("requestData").toString();

					// responseHashMap.put("arryOfBizVerticalList",
					// serviceProvider.getLpmasBizVerticalService().findAll());
					responseHashMap.put("distinctHeaderDetail", serviceProvider.getLpstpScorecardMasterService().getDistinctHeaderByScFor(scmScFor));// ,"Y"));

				} catch (Exception e) {
					e.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
						dataHashMap.put("errorData", new CustomErr(e.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("getDistinctHeaderRecordByScForandBizVeritcalandBizRule")) {
				try {
					@SuppressWarnings("unchecked")
					Map<String, Object> hshMap = (Map<String, Object>) allRequestParams.get("requestData");
					String scmScFor = hshMap.get("scmScFor").toString();
					String scmBizvertical = hshMap.get("scmBizvertical").toString();
					long scmLrbSeqno = Long.parseLong(hshMap.get("scmLrbSeqno").toString());
					// responseHashMap.put("arryOfBizVerticalList",
					// serviceProvider.getLpmasBizVerticalService().findAll());
					responseHashMap.put("distinctHeaderDetail", serviceProvider.getLpstpScorecardMasterService().getDistinctHeaderByScForAndBizVerticalAndBizRule(scmScFor, scmBizvertical, scmLrbSeqno));// ,"Y"));

				} catch (Exception e) {
					e.printStackTrace();
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
						dataHashMap.put("errorData", new CustomErr(e.getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}

			else {
				dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}

		} catch (Exception e) {
			e.printStackTrace();
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
				dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
		}
		return responseHashMap;
	}

}
