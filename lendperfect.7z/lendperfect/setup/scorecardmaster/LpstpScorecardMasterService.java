package com.sai.lendperfect.setup.scorecardmaster;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpScorecardMaster;

public interface LpstpScorecardMasterService {

	List<LpstpScorecardMaster> findAll();

	List<LpstpScorecardMaster> findById(long scmRowId);

	List<Object> getDistinctnonDeleteandActiveHeaderList(String scpmAvailable);

	List<LpstpScorecardMaster> findByScmQuesHeaderIdAndScmAvailable(BigDecimal scmQuesHeaderId, String scmAvailable);

	LpstpScorecardMaster findByid(long scmRowId);

	LpstpScorecardMaster saveData(LpstpScorecardMaster lpstpScorecardMaster);

	Integer updateDataHeaderDescByQuesHeaderId(LpstpScorecardMaster lpstpScorecardMaster);

	void deleteData(LpstpScorecardMaster lpstpScorecardMaster);

	List<Object> getDistinctHeaderByScFor(String scmScFor);// ,String
															// scpmAvailable) ;

	List<Object> getDistinctHeaderByScForAndBizVerticalAndBizRule(String scmScFor, String scmBizVertical, long scmLrbSeqno);// ,String
																															// scpmAvailable)
																															// ;

	List<LpstpScorecardMaster> findByScmScForAndScmAvailableAndScmLrbSeqnoAndScmLapsDefinedOrderByScmQuesHeaderId(String scmScFor, String scmAvailable, long scmLrbSeqno, String scmLapsDefined);

	List<LpstpScorecardMaster> findDistinctByScmQuesHeaderIdAndScmLapsDefined(BigDecimal scmQuesHeaderId, String scmLapsDefined);

}
