package com.sai.lendperfect.setup.scorecardmaster;

import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpScorecardMaster;
import com.sai.lendperfect.setupmodel.LpstpScorecardOptionMaster;

public interface LpstpScorecardOptionMasterService {
	List<LpstpScorecardOptionMaster> findAll();

	LpstpScorecardOptionMaster findByRowId(Long rowId);

	List<LpstpScorecardOptionMaster> getDataByQuestionId(LpstpScorecardMaster lpstpScorecardMaster);

	// List<LpstpScorecardOptionMaster> getNonDeleteData(String
	// ScpmOptionIsdelete);
	// List<LpstpScorecardOptionMaster> getNonDeleteDataByQuestionId(String
	// ScpmOptionIsdelete,String scpmOptionAvailable,LpstpScorecardMaster
	// setScorecardMaster);
	// List<LpstpScorecardOptionMaster> getNonDeleteDataByQuestionId(String
	// scpmdelete, LpstpScorecardMaster lpstpScorecardMaster);

	LpstpScorecardOptionMaster savaData(LpstpScorecardOptionMaster lpstpScorecardOptionMaster);

	void deleteData(LpstpScorecardOptionMaster lpstpScorecardOptionMaster);

	// List<LpstpScorecardOptionMaster>
	// getNonDeleteAndAvailableDatabyScorceCardID(String scpmdelete, String
	// scpmOptionAvailable, LpstpScorecardMaster lpstpScorecardMaster);

	// By Me
	List<LpstpScorecardOptionMaster> findByLpstpScorecardMasterAndScpmdelete(LpstpScorecardMaster lpstpScorecardMaster, String scpmDelete);

	List<LpstpScorecardOptionMaster> findByLpstpScorecardMasterAndScpmdeleteScpmOptionAvailable(LpstpScorecardMaster lpstpScorecardMaster, String scpmDelete, String scpmOptionAvailable);

	LpstpScorecardOptionMaster findByLpstpScorecardMasterAndScpmOptionValueAndScpmOptionAvailable(LpstpScorecardMaster lpstpScorecardMaster, String scpmOptionValue, String scpmOptionAvailable);

}
