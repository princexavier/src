
package com.sai.lendperfect.setup.scorecardmaster;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpScorecardMaster;
import com.sai.lendperfect.setupmodel.LpstpScorecardOptionMaster;
import com.sai.lendperfect.setuprepo.LpstpScorecardOptionMasterRepo;

@Service("lpstpScorecardOptionMasterService")
@Transactional
public class LpstpScorecardOptionMasterServiceImpl implements LpstpScorecardOptionMasterService {
	@Autowired
	private LpstpScorecardOptionMasterRepo lpstpScorecardOptionMasterRepo;

	public List<LpstpScorecardOptionMaster> findAll() {
		return lpstpScorecardOptionMasterRepo.findAll();
	}

	public List<LpstpScorecardOptionMaster> getDataByQuestionId(LpstpScorecardMaster lpstpScorecardMaster) {
		// return null;
		return lpstpScorecardOptionMasterRepo.findByLpstpScorecardMaster(lpstpScorecardMaster);
	}

	public LpstpScorecardOptionMaster savaData(LpstpScorecardOptionMaster lpstpScorecardOptionMaster) {
		return lpstpScorecardOptionMasterRepo.save(lpstpScorecardOptionMaster);
	}

	public void deleteData(LpstpScorecardOptionMaster lpstpScorecardOptionMaster) {
		lpstpScorecardOptionMasterRepo.delete(lpstpScorecardOptionMaster);
	}

	public LpstpScorecardOptionMaster findByRowId(Long rowId) {
		return lpstpScorecardOptionMasterRepo.findOne(rowId);
	}

	@Override
	public List<LpstpScorecardOptionMaster> findByLpstpScorecardMasterAndScpmdelete(LpstpScorecardMaster lpstpScorecardMaster, String scpmDelete) {
		return lpstpScorecardOptionMasterRepo.findByLpstpScorecardMasterAndScpmdelete(lpstpScorecardMaster, scpmDelete);
	}

	@Override
	public List<LpstpScorecardOptionMaster> findByLpstpScorecardMasterAndScpmdeleteScpmOptionAvailable(LpstpScorecardMaster lpstpScorecardMaster, String scpmDelete, String scpmOptionAvailable) {
		return lpstpScorecardOptionMasterRepo.findByLpstpScorecardMasterAndScpmdeleteAndScpmOptionAvailable(lpstpScorecardMaster, scpmDelete, scpmOptionAvailable);
	}

	@Override
	public LpstpScorecardOptionMaster findByLpstpScorecardMasterAndScpmOptionValueAndScpmOptionAvailable(LpstpScorecardMaster lpstpScorecardMaster, String scpmOptionValue, String scpmOptionAvailable) {
		// TODO Auto-generated method stub
		return lpstpScorecardOptionMasterRepo.findByLpstpScorecardMasterAndScpmOptionValueAndScpmOptionAvailable(lpstpScorecardMaster, scpmOptionValue, scpmOptionAvailable);
	}

}
