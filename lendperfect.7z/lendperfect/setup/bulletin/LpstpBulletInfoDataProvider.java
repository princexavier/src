package com.sai.lendperfect.setup.bulletin;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import javax.servlet.http.HttpSession;
import org.json.JSONArray;
import org.json.JSONObject;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpBulletInfo;

public class LpstpBulletInfoDataProvider {
	
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		String userid = (String) session.getAttribute("userid");
	   if(dpMethod.equals("getBulletinfo"))
		{
		   List<LpstpBulletInfo> lpstpBulletInfo =serviceProvider.getLpstpBulletInfoService().findAll();
		   dataHashMap.put("lpstpBulletinlist",lpstpBulletInfo);
		   responseHashMap.put("success", true);
		   responseHashMap.put("responseData", dataHashMap);
		}
	    else if(dpMethod.equals("saveBulletin"))
	    {
	    	List<LpstpBulletInfo> lpstpBulletInfoList= new ObjectMapper().convertValue(allRequestParams.get("requestData"),new TypeReference<List<LpstpBulletInfo>>() { });
	    	
	    	lpstpBulletInfoList.forEach(lpstpBulletInfo1->{
	    		lpstpBulletInfo1.setLbiCreatedOn(Helper.getSystemDate());
		    	lpstpBulletInfo1.setLbiCreatedBy(userid);
		    	lpstpBulletInfo1.setLbiModifedBy(userid);
		    	lpstpBulletInfo1.setLbiModifiedOn(Helper.getSystemDate());
	    	});
	    	
	    	List<LpstpBulletInfo> lpstpBulletInfoAftSaved = serviceProvider.getLpstpBulletInfoService().saveBulletin(lpstpBulletInfoList);

			dataHashMap.put("lpstpBulletinlist",lpstpBulletInfoAftSaved);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else if(dpMethod.equals("deleteBulletin"))
	    {
			List<LpstpBulletInfo> lpstpBulletInfoList= new ArrayList();
			lpstpBulletInfoList.add(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpBulletInfo>() { }));
		
			lpstpBulletInfoList.forEach(lpstpBulletInfo1->{
	    		lpstpBulletInfo1.setLbiCreatedOn(Helper.getSystemDate());
		    	lpstpBulletInfo1.setLbiCreatedBy(userid);
		    	lpstpBulletInfo1.setLbiModifedBy(userid);
		    	lpstpBulletInfo1.setLbiModifiedOn(Helper.getSystemDate());
	    	});
			
	    	serviceProvider.getLpstpBulletInfoService().deleteBulletin(lpstpBulletInfoList);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}

}
