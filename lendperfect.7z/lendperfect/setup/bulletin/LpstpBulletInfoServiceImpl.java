package com.sai.lendperfect.setup.bulletin;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setuprepo.LpstpBulletInfoRepo;
import com.sai.lendperfect.setup.bulletin.LpstpBulletInfoService;
import com.sai.lendperfect.setupmodel.LpstpBulletInfo;

@Service("lpstpBulletInfoService")
@Transactional
public class LpstpBulletInfoServiceImpl implements LpstpBulletInfoService{

	@Autowired
	LpstpBulletInfoRepo lpstpBulletInfoRepo;

	
	@Override
	public List<LpstpBulletInfo> saveBulletin(List<LpstpBulletInfo> lpstpBulletInfolist) {
		 return lpstpBulletInfoRepo.save(lpstpBulletInfolist);
	}

	@Override
	public List<LpstpBulletInfo> findAll() {
		return lpstpBulletInfoRepo.findAll();
	}

	@Override
	public void deleteBulletin(List<LpstpBulletInfo> lpstpBulletInfolist1) {
		lpstpBulletInfoRepo.delete(lpstpBulletInfolist1);
	}

	@Override
	public List<LpstpBulletInfo> findByLbiShowUptoAfter(Date lbishowuptodate) {
		return lpstpBulletInfoRepo.findByLbiShowUptoAfter(lbishowuptodate);
	}


	
}
