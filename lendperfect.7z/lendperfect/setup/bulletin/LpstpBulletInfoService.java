package com.sai.lendperfect.setup.bulletin;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpBulletInfo;

public interface LpstpBulletInfoService {

	List<LpstpBulletInfo> saveBulletin(List<LpstpBulletInfo> lpstpBulletInfolist);

	List<LpstpBulletInfo> findAll();
	
	List<LpstpBulletInfo> findByLbiShowUptoAfter(Date lbishowuptodate);

	void deleteBulletin(List<LpstpBulletInfo> lpstpBulletInfo);
	
}
