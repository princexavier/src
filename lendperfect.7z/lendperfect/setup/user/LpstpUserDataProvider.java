package com.sai.lendperfect.setup.user;

import java.math.BigDecimal;
import java.security.MessageDigest;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.EmailManager;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.SequenceNoServiceImpl;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomCustInfo;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.mastermodel.LpmasListofvalue;
import com.sai.lendperfect.setupmodel.LpstpMailTemplate;
import com.sai.lendperfect.setupmodel.LpstpUser;
import com.sai.lendperfect.setupmodel.LpstpUserAccess;
import com.sai.lendperfect.setupmodel.LpstpUserClass;
import com.sai.lendperfect.setupmodel.LpstpUserLocation;
import com.sai.lendperfect.setupmodel.SetOrganisation;
import com.sai.lendperfect.setupmodel.SetUserGroup;

import org.apache.catalina.webresources.FileResource;
import org.springframework.core.io.FileSystemResource;
import com.sai.lendperfect.commodel.MailTemplate;
import sun.misc.BASE64Encoder;
import java.security.MessageDigest;


public class LpstpUserDataProvider {
	@SuppressWarnings("unchecked")
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpUserDataProvider.class);	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		SequenceNoServiceImpl sequenceNoServiceImpl = new SequenceNoServiceImpl();
 		String tableName= "LPSTP_USER_ACCESS";
		String seqId = "LUA_SEQ_NO";
		String userId = "LUA_USER_ID";
		//SetUser setUser=null;
		responseHashMap.put("success",true);
		try{
			if(dpMethod.equals("getUserDataList")){	
			try {
				responseHashMap.put("userDataListAll", serviceProvider.getLpstpUserService().findAllOrderByname());
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}else if(dpMethod.equals("saveUserData")){	
			try {
				
				HashMap hshMap=(HashMap)allRequestParams.get("requestData");
				HashMap<String,Object> userHashMap=new HashMap<String,Object>();
				List<LpstpUserAccess> responseUserAccessList=new ArrayList();
				List<LpstpUserAccess> LpstpUserAccessList = new ObjectMapper().convertValue(hshMap.get("userAccessArray"), new TypeReference<List<LpstpUserAccess>>() {});
				HashMap hshMapMail=new HashMap();
				LpstpUser	setUser=new ObjectMapper().convertValue(hshMap.get("model"), LpstpUser.class);
			setUser.setSuUserPassword((String)hshMap.get("pwd"));
			if(Helper.correctNull(setUser.getSuUserPassword())!=null&&(!Helper.correctNull(setUser.getSuUserPassword()).equalsIgnoreCase(""))){
			setUser.setSuUserPassword(Helper.decrypt("7061737323313233",setUser.getSuUserPassword()));
			setUser.setSuUserPassword(Helper.encrypt("7061737323414141",setUser.getSuUserPassword()));
			setUser.setSuAccLocked("N");
			setUser.setSuFirstLogin("Y");
			setUser.setSuCreatedBy(setUser.getSuRowId());
			setUser.setSuCreatedOn(Helper.getSystemDate());
			setUser.setSuModifiedBy(setUser.getSuRowId());
			setUser.setSuModifiedOn(Helper.getSystemDate());
			setUser.setSuLoginAttempt(new BigDecimal(0));
			hshMapMail.put("@PASSWORD", setUser.getRandStr());
			userHashMap=serviceProvider.getLpstpUserService().saveAllSetUserData(setUser,LpstpUserAccessList);
			if(!userHashMap.isEmpty())
			{
				setUser=(LpstpUser)userHashMap.get("setUser");
				hshMapMail.put("@USERNAME", setUser.getSuFirstName()+" "+setUser.getSuLastName());
				hshMapMail.put("@USERID", setUser.getSuRowId());
				
					String to = setUser.getSuEmailId();
					String bcc = "";
					String cc = "";
					String subject = "Hi, this is Your First time Password";
					LpstpMailTemplate LpstpMailTemplate=serviceProvider.getMailTemplateService().findBylmtRowId(new BigDecimal(27435));
					if(LpstpMailTemplate!=null)
					{
					String message=LpstpMailTemplate.getLmtTemplate();
					MailTemplate mailtemplate = new MailTemplate(to,cc,bcc,subject, message,true);
					responseHashMap.put("templateAvailmsg", true);	
					try
					{
						serviceProvider.getEmailManager().sendEmail(mailtemplate, hshMapMail);
					}catch (Exception e) {
						e.printStackTrace();
						dataHashMap.put("errorData",new CustomErr(e.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
					}
					else
						responseHashMap.put("templateAvailmsg", false);	
			}
			}else{

			if((setUser.getSuRowId()==null)){
				setUser.setSuUserPassword(Helper.encrypt("7061737323414141",setUser.getSuRowId()+setUser.getSuFirstName()));
				setUser.setSuAccLocked("N");
				setUser.setSuFirstLogin("Y");
				setUser.setSuLoginAttempt(new BigDecimal(0));
				userHashMap=serviceProvider.getLpstpUserService().saveAllSetUserData(setUser,LpstpUserAccessList);
			}else{
				
				LpstpUser setUser2= serviceProvider.getLpstpUserService().findById(setUser.getSuRowId());
				setUser.setSuUserPassword(setUser2.getSuUserPassword());
				setUser.setSuModifiedBy(setUser.getSuRowId());
				setUser.setSuModifiedOn(Helper.getSystemDate());	
				userHashMap=serviceProvider.getLpstpUserService().saveAllSetUserData(setUser,LpstpUserAccessList);
			}	
				}
			if(!userHashMap.isEmpty())
			{
				responseHashMap.put("success", true);
				if(setUser.getSuResignedOn()!=null)
					responseHashMap.put("ResignedOn",(new SimpleDateFormat("dd/MM/yyyy").format(setUser.getSuResignedOn())));
				else
					responseHashMap.put("ResignedOn","");	
				responseHashMap.put("usercode",setUser.getSuRowId());
				responseUserAccessList=(List<LpstpUserAccess>) userHashMap.get("lpstpUserAccessList");
				responseHashMap.put("LpstpUserAccessList",responseUserAccessList);
				responseHashMap.put("getCurrentSavedUserByid",java.util.Arrays.asList(setUser));
			}
			else
			{
				responseHashMap.put("success", false);
			}
			
			}catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
		else if(dpMethod.equals("passwordreset"))
		{
			HashMap hshMap=(HashMap)allRequestParams.get("requestData");
			HashMap hshMapMail=new HashMap();
			LpstpUser setUser=new ObjectMapper().convertValue(hshMap.get("model"), LpstpUser.class);
			String resetpassword = Helper.correctNull((String)setUser.getSuRowId());
			String mypwd1 = "",encryptpwd="";
			mypwd1 = resetpassword;
			encryptpwd = "";
			MessageDigest md=null;
			if(!mypwd1.equals(""))
			{
			    md= MessageDigest.getInstance("SHA");
				md.update(mypwd1.getBytes("UTF-8"));
				byte[] encpwd=md.digest();
			    encryptpwd=(new BASE64Encoder()).encode(encpwd);
			}
			setUser.setSuUserPassword(encryptpwd);	
			if(Helper.correctNull(setUser.getSuUserPassword())!=null&&(!Helper.correctNull(setUser.getSuUserPassword()).equalsIgnoreCase(""))){
			setUser.setSuRowId(setUser.getSuRowId());
			if(setUser!=null)
			{
				hshMapMail.put("@USERNAME", setUser.getSuFirstName()+" "+setUser.getSuLastName());
				hshMapMail.put("@USERID", setUser.getSuRowId());
				hshMapMail.put("@PASSWORD", setUser.getSuUserPassword());
				setUser=serviceProvider.getLpstpUserService().saveSetUserData(setUser);
				responseHashMap.put("success", true);
				responseHashMap.put("ResetCheck", true);    
					}
					else
					{
					responseHashMap.put("success", true);
					responseHashMap.put("ResetCheckmsg", false);
					}
			}
		}			
		else if(dpMethod.equals("unlockUser")){	
			try {
				
				HashMap hshMap=(HashMap)allRequestParams.get("requestData");
				HashMap hshMapMail=new HashMap();
				LpstpUser	setUser=new ObjectMapper().convertValue(hshMap.get("model"), LpstpUser.class);
			setUser.setSuUserPassword((String)hshMap.get("pwd"));
			if(Helper.correctNull(setUser.getSuUserPassword())!=null&&(!Helper.correctNull(setUser.getSuUserPassword()).equalsIgnoreCase(""))){
			setUser.setSuUserPassword(Helper.decrypt("7061737323313233",setUser.getSuUserPassword()));
			setUser.setSuUserPassword(Helper.encrypt("7061737323414141",setUser.getSuUserPassword()));
			setUser.setSuAccLocked("N");
			setUser.setSuLoginAttempt(new BigDecimal(0));
			hshMapMail.put("@PASSWORD", setUser.getRandStr());
			if(setUser!=null)
			{
				hshMapMail.put("@USERNAME", setUser.getSuFirstName()+" "+setUser.getSuLastName());
				hshMapMail.put("@USERID", setUser.getSuRowId());
				
					String to = setUser.getSuEmailId();
					String bcc = "";
					String cc = "";
					String subject = "Unlock User";
					LpstpMailTemplate LpstpMailTemplate=serviceProvider.getMailTemplateService().findBylmtRowId(new BigDecimal(27434));
					if(LpstpMailTemplate!=null)
					{
					setUser=serviceProvider.getLpstpUserService().saveSetUserData(setUser);
					String message=LpstpMailTemplate.getLmtTemplate();
					MailTemplate mailtemplate = new MailTemplate(to,cc,bcc,subject, message,true);
					responseHashMap.put("templateAvailmsg", true);
					try
					{
						serviceProvider.getEmailManager().sendEmail(mailtemplate,hshMapMail);
						if(setUser.getSuResignedOn()!=null)
							responseHashMap.put("resignedOn",(new SimpleDateFormat("dd/MM/yyyy").format(setUser.getSuResignedOn())));
						else
							responseHashMap.put("resignedOn","");
						responseHashMap.put("success", true);
					}catch (Exception e) {
						e.printStackTrace();
						responseHashMap.put("success", false);
					}
					}
					else
					{
					responseHashMap.put("success", true);
					responseHashMap.put("templateAvailmsg", false);
					}
			}
		
			}
			}
			catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		
		
		else if(dpMethod.equals("getValueOfHeaderFromListOfValueMaster")){
			try {
			String[] header=allRequestParams.get("requestData").toString().split(":");
			if(header.length==2){
//			responseHashMap.put("listOfValueOfHeader",serviceProvider.getListOfValuesService().getOptionList(header[0], header[1]));
			}else{
				responseHashMap.put("listOfValueOfHeader", new ArrayList<LpmasListofvalue>()	);
			}
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		}		                                             
	
		else if(dpMethod.equals("getLocationList")){
			try {
			
				responseHashMap.put("locationList",serviceProvider.getLpstpOrganisationService().findAllOrderByName());
				 responseHashMap.put("designation",serviceProvider.getLpmasListofvalueService().findByLlvHeader("userdesignation"));
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		
		else if(dpMethod.equals("getUserGrpAccess"))
		{	
			try
			{
				 List<Map<String,Object>> verticalList=new ArrayList<Map<String,Object>>();
				 List<Map<String,Object>> reportList=new ArrayList<Map<String,Object>>();
				List<LpmasBizVertical> LpmasBizVerticalList=serviceProvider.getLpmasBizVerticalService().findByLbvActive("Y");
				List<LpstpUser> LpstpUserreportList=serviceProvider.getLpstpUserService().findBysuSupervisorUsr("Y");
				Iterator<LpmasBizVertical> LpmasBizVerticalListitr=LpmasBizVerticalList.iterator();
				Iterator<LpstpUser> LpstpUserreportListitr=LpstpUserreportList.iterator();
				Map<String,Object>  verticalListMap=new HashMap<String,Object>();
				Map<String,Object>  reportMap=new HashMap<String,Object>();
				LpmasBizVertical LpmasBizVerticalObj=new LpmasBizVertical();
				LpstpUser LpstpUserobj=new LpstpUser();
			
				while(LpmasBizVerticalListitr.hasNext())
				{
					verticalListMap=new HashMap<String,Object>();
					LpmasBizVerticalObj=LpmasBizVerticalListitr.next();
					verticalListMap.put("lbvRowId", LpmasBizVerticalObj.getLbvRowId());
					verticalListMap.put("lbvBizVertical", LpmasBizVerticalObj.getLbvBizVertical());
					verticalList.add(verticalListMap);
				}
			
				while(LpstpUserreportListitr.hasNext())
				{
					reportMap=new HashMap<String,Object>();
					LpstpUserobj=LpstpUserreportListitr.next();
					reportMap.put("userId", LpstpUserobj.getSuRowId());
					reportMap.put("userName",LpstpUserobj.getSuFirstName());
					reportList.add(reportMap);
				}
				dataHashMap.put("verticalList", verticalList);
				dataHashMap.put("reportList", reportList);
			responseHashMap.put("responseData", dataHashMap);
			responseHashMap.put("success", true);
				
			}
			catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}

		else if(dpMethod.equals("getUserAccessDetails"))
		{	
			try
			{	
				System.out.println("testing");
				LpstpUser LpstpUserObj=new LpstpUser();
				LpstpUserObj=serviceProvider.getLpstpUserService().findBysuRowId(allRequestParams.get("requestData").toString());
				if(LpstpUserObj.getSuResignedOn()!=null)
					responseHashMap.put("ResignedOn",(new SimpleDateFormat("dd/MM/yyyy").format(LpstpUserObj.getSuResignedOn())));
				else
					responseHashMap.put("ResignedOn","");
				List<LpstpUserAccess> LpstpUserAccessList = serviceProvider.getLpstpUserAccessService().findByluaUserId(allRequestParams.get("requestData").toString());
				dataHashMap.put("LpstpUserAccessList", LpstpUserAccessList);
				dataHashMap.put("LpstpUserObj", LpstpUserObj);
				responseHashMap.put("responseData", dataHashMap);
				responseHashMap.put("success", true);
			}
			catch (Exception ex) {
				dataHashMap.put("errorData", ex.getLocalizedMessage());
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
			 
		}
	}	
			else if(dpMethod.equals("getUserLocationdetails"))
			{	
				try
				{
					HashMap hshMap=(HashMap)allRequestParams.get("requestData");
					String userid=hshMap.get("userid").toString();
					String vertical=hshMap.get("lulBizVertical").toString();
					List<String> locationList=new ArrayList();
					List<LpstpUserLocation> LpstpUserLocationList = serviceProvider.getLpstpUserLocationService().findByLulBizVerticalAndLulUserId(vertical, userid);
					Iterator<LpstpUserLocation> LpstpUserLocationListitr=LpstpUserLocationList.iterator();
					while(LpstpUserLocationListitr.hasNext())
					{
						locationList.add(LpstpUserLocationListitr.next().getLulOrgId().toString());
					}
					dataHashMap.put("usrlocationList", locationList);
					responseHashMap.put("responseData", dataHashMap);
					responseHashMap.put("success", true);
				}
				catch (Exception ex) {
					dataHashMap.put("errorData", ex.getLocalizedMessage());
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
				 
			}
		}	
			else if(dpMethod.equals("selectOrgLevelDetails")){
				try {
					HashMap hshMap=(HashMap)allRequestParams.get("requestData");
					String UserDept=hshMap.get("UserDept").toString();
					String vertical=hshMap.get("Vertical").toString();
					String verticalgrp=hshMap.get("Vertical").toString();
					List<Object> setOrganisationlist=serviceProvider.getsetOrganisationService().findDistinctLevel(vertical, UserDept);
					List<SetUserGroup> SetUserGrouplist=serviceProvider.getUserGroupService().findBySugGrpVerticalAndLugGrpDeptAndSugGrpActive(verticalgrp, UserDept, "Y");
					dataHashMap.put("setOrganisationlist", setOrganisationlist);
					dataHashMap.put("SetUserGrouplist", SetUserGrouplist);
					responseHashMap.put("responseData",dataHashMap);
					responseHashMap.put("success", true);
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			else if(dpMethod.equals("selectUsrClassDetails")){
				try {
					String UserDept=allRequestParams.get("requestData").toString();
					List<LpstpUserClass>  LpstpUserClasslist=serviceProvider.getLpstpUserClassService().findByLucDepartmentAndLucActive(UserDept,"Y");
					dataHashMap.put("LpstpUserClasslist", LpstpUserClasslist);
					responseHashMap.put("responseData",dataHashMap);
					responseHashMap.put("success", true);
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			
			else if(dpMethod.equals("selectOrgLocation")){
				try {
					HashMap hshMap=(HashMap)allRequestParams.get("requestData");
					String UserDept=hshMap.get("UserDept").toString();
					String vertical= hshMap.get("Vertical").toString();
					List<String> levelValues=(List) hshMap.get("level");
					String level=hshMap.get("orglevel").toString();
					List<SetOrganisation> locationList=new ArrayList();
					List<SetOrganisation> fianllocationList=new ArrayList();
						locationList=serviceProvider.getsetOrganisationService().findByLoOrgLevel(level);
						fianllocationList.addAll(locationList);
					for(int i=0;i<levelValues.size();i++)
					{
					locationList=serviceProvider.getsetOrganisationService().findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(vertical, UserDept,levelValues.get(i));
					fianllocationList.addAll(locationList);
					}
					dataHashMap.put("locationList", fianllocationList);
					responseHashMap.put("responseData",dataHashMap);
 					responseHashMap.put("success", true);
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			else if(dpMethod.equals("deleteUserAccessDetails"))
			{	
				try
				{
					LpstpUserAccess LpstpUserAccessObj=null;
					List<LpstpUserLocation> LpstpUserLocationList=new ArrayList();
					final LpstpUserAccess LpstpUserAccessObjdelete=new ObjectMapper().convertValue(allRequestParams.get("requestData"), LpstpUserAccess.class);
					serviceProvider.getLpstpUserAccessService().deleteUserAccessDetails(LpstpUserAccessObjdelete);
					String vertical = LpstpUserAccessObjdelete.getLuaBizVertical();
					LpstpUserLocationList=serviceProvider.getLpstpUserLocationService().findByLulBizVerticalAndLulUserId(vertical,LpstpUserAccessObjdelete.getLuaUserId());
					if(!LpstpUserLocationList.isEmpty())
					{
					Iterator<LpstpUserLocation> LpstpUserLocationlistitr=LpstpUserLocationList.iterator();
					while(LpstpUserLocationlistitr.hasNext())
					{
						serviceProvider.getLpstpUserLocationService().deleteUserLocation(LpstpUserLocationlistitr.next());
					}
					}
					responseHashMap.put("success", true);
				}
				catch (Exception ex) {
					dataHashMap.put("errorData", ex.getLocalizedMessage());
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
				
			}
		}	
			
		
		else{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
	return responseHashMap;
	
}
}


