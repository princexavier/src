package com.sai.lendperfect.setup.user;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpUserLocation;


public interface LpstpUserLocationService {
	
	List<LpstpUserLocation> findByLulBizVerticalAndLulUserId(String lulBizVertical,String lulUserId);
	List<LpstpUserLocation> saveUserLocation(List<LpstpUserLocation> LpstpUserLocation);
	void deleteUserLocation(LpstpUserLocation LpstpUserLocation);
	LpstpUserLocation  saveUserLoc(LpstpUserLocation LpstpUserLocation);
	List<LpstpUserLocation> findByLulUserId(String lulUserId);

}
