package com.sai.lendperfect.setup.user;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpUserLocation;
import com.sai.lendperfect.setuprepo.LpstpUserLocationRepo;;

@Service("LpstpUserLocationService")
@Transactional

public class LpstpUserLocationServiceImpl  implements LpstpUserLocationService{
	
	@Autowired
	 LpstpUserLocationRepo LpstpUserLocationRepo;

	

	public List<LpstpUserLocation> saveUserLocation(List<LpstpUserLocation> LpstpUserLocation) {
		return LpstpUserLocationRepo.save(LpstpUserLocation);
	}

	public void deleteUserLocation(LpstpUserLocation LpstpUserLocation) {
		LpstpUserLocationRepo.delete(LpstpUserLocation);
	}

	public List<LpstpUserLocation> findByLulBizVerticalAndLulUserId(String lulBizVertical, String lulUserId) {
		return LpstpUserLocationRepo.findByLulBizVerticalAndLulUserId(lulBizVertical, lulUserId);
	}

	public LpstpUserLocation saveUserLoc(LpstpUserLocation LpstpUserLocation) {
		return LpstpUserLocationRepo.save(LpstpUserLocation);
	}

	public List<LpstpUserLocation> findByLulUserId(String lulUserId) {
		return LpstpUserLocationRepo.findByLulUserId(lulUserId);
	}

}
