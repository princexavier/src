package com.sai.lendperfect.setup.user;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpUserAccess;

public interface LpstpUserAccessService {
	
	List<LpstpUserAccess> saveLpstpUserAccessDetails(List<LpstpUserAccess> LpstpUserAccesslist);
	List<LpstpUserAccess> findByluaUserId(String luaUserId);
	LpstpUserAccess findByluaUserIdAndLuaBizVertical(String luaUserId, BigDecimal luaBizVertical);
	void deleteUserAccessDetails(LpstpUserAccess LpstpUserAccessObj);
	LpstpUserAccess findByluaUserId1(String luaUserId);
}
