package com.sai.lendperfect.setup.user;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.setupmodel.LpstpUser;
import com.sai.lendperfect.setupmodel.LpstpUserAccess;
import com.sai.lendperfect.setupmodel.LpstpUserLocation;
import com.sai.lendperfect.setuprepo.LpstpUserAccessRepo;
import com.sai.lendperfect.setuprepo.LpstpUserRepo;
import com.sai.lendperfect.setuprepo.LpstpUserLocationRepo;
@Service("lpstpUserService")
@Transactional
public class LpstpUserServiceImpl implements LpstpUserService{

	

	@Autowired
	LpstpUserRepo setUserRepo;
	@Autowired
	LpstpUserAccessRepo lpstpUserAccessRepo;
	@Autowired
    LpstpUserLocationRepo lpstpUserLocationRepo;
	@Autowired
	ServiceProvider serviceProvider;
	
	public List<LpstpUser> findAllOrderByname() {
		return setUserRepo.findAll(new Sort(Sort.Direction.ASC,"suFirstName"));
	}
	public List<LpstpUser> findAll() {
		return setUserRepo.findAll(new Sort(Sort.Direction.ASC,"suRowId"));
	}

	public LpstpUser saveSetUserData(LpstpUser setUser) {
		return setUserRepo.save(setUser);
	}

	public LpstpUser updateSetUserData(LpstpUser setUser) {
		return saveSetUserData(setUser);
	}

	public void deleteSetUserData(LpstpUser setUser) {
		setUserRepo.delete(setUser);
	}

	public List<LpstpUser> getUserDeatilByActiveStatus(String suAvailable) {
		return setUserRepo.findBysuAvailable(suAvailable);
	}
	/*public boolean checkuserIdEditable(String suRowId) {
		boolean flag=true;
		Long l=	setUserRepo.countBysuRowIdGreaterThan(suRowId);
		if (l == 0) {
			flag = false;
		}
		return flag;
	}*/
	
	public boolean checkUserExistance(String suRowId) {
		boolean flag=true;
		 List<LpstpUser> list1= Arrays.asList(setUserRepo.findBysuRowId(suRowId));
		if (list1.size() == 0|| list1.isEmpty()) {
			flag = false;
		}
		return flag;
	}

	public List<LpstpUser> findByIdasList(String suRowId) {
		return Arrays.asList(setUserRepo.findBysuRowId(suRowId));
	}

	public LpstpUser findById(String suRowId) {
		return setUserRepo.findBysuRowId(suRowId);
	}


	public Integer updateSetUserDatawithpassword(LpstpUser setUser) {
		return 	setUserRepo.updateWithoutPassword( setUser.getSuempid() ,  setUser.getSuFirstName() , setUser.getSuLastName() ,
				setUser.getSuUserAdId() , setUser.getSuDesignation() , setUser.getLuaUserDept() , setUser.getSuLocation() , 
				setUser.getSuAvailable() , setUser.getSuResignedOn(),setUser.getSuEmailId(),setUser.getSuEmailNotify(),setUser.getSuMobNo(),setUser.getSuMobNotify(),setUser.getSuSupervisorUsr(),setUser.getSuEmpType(),setUser.getSuRowId());
	
	}

	public List<LpstpUser> findBysuAvailable(String suAvailable) {
		return setUserRepo.findBysuAvailable(suAvailable);
	}
	public List<LpstpUser> findBysuSupervisorUsr(String suSupervisorUsr) {
		return setUserRepo.findBysuSupervisorUsr(suSupervisorUsr);
	}

	
	public List<LpstpUser> findAllOrderBySuRowId() {
		return setUserRepo.findAllOrderBySuRowId();
	}
	
	public List<LpstpUser> findUserDetail(String searchval) {
		
		return setUserRepo.findBysuAvailable(searchval);
	}
	public List<LpstpUser> findBySuFirstNameIgnoreCaseContaining(String searchval) {
		
		return setUserRepo.findBySuFirstNameIgnoreCaseContaining(searchval);
	}
	public LpstpUser findBysuRowId(String suRowId) {
		return setUserRepo.findBysuRowId(suRowId);
	}
	public LpstpUser findBySuSupervisorUsrAndsuRowIdIgnoreCase(String suSupervisorUsr, String suRowId) {
		return setUserRepo.findBySuSupervisorUsrAndSuRowIdIgnoreCase(suSupervisorUsr, suRowId);
	}
	public List<LpstpUser> findBySuSupervisorUsrAndSuFirstNameIgnoreCaseContaining(String suSupervisorUsr,
			String searchval) {
		return setUserRepo.findBySuSupervisorUsrAndSuFirstNameIgnoreCaseContaining(suSupervisorUsr, searchval);
	}
	@Override
	public HashMap saveAllSetUserData(LpstpUser setUser,List<LpstpUserAccess> lpstpUserAccessList) {
		HashMap<String,Object> userHashMap=new HashMap<String,Object>();
		setUser= setUserRepo.save(setUser);
		if(setUser!=null)
		{
			if(setUser.getSuRowId()!=null)
			{
				lpstpUserAccessList = saveLpstpUserAccessList(setUser,lpstpUserAccessList);		
				userHashMap.put("lpstpUserAccessList", lpstpUserAccessList);
				userHashMap.put("setUser", setUser);
			}
		}
		
		return  userHashMap;
	}
	@Override
	public HashMap updateAllSetUserData(LpstpUser setUser, List<LpstpUserAccess> lpstpUserAccessList){
		HashMap<String,Object> userHashMap=new HashMap<String,Object>();
		try
		{
		setUserRepo.updateWithoutPassword( setUser.getSuempid() ,  setUser.getSuFirstName() , setUser.getSuLastName() ,
				setUser.getSuUserAdId() , setUser.getSuDesignation() , setUser.getLuaUserDept() , setUser.getSuLocation() , 
				setUser.getSuAvailable() , setUser.getSuResignedOn(),setUser.getSuEmailId(),setUser.getSuEmailNotify(),setUser.getSuMobNo(),setUser.getSuMobNotify(),setUser.getSuSupervisorUsr(),setUser.getSuEmpType(),setUser.getSuRowId());;
	
				lpstpUserAccessList = saveLpstpUserAccessList(setUser,lpstpUserAccessList);		
				userHashMap.put("lpstpUserAccessList", lpstpUserAccessList);
				userHashMap.put("setUser", setUser);
			
		}
		catch (Exception ex) {
		
			}
		
		return  userHashMap;
	}
	@Override
	public List<LpstpUserAccess> saveLpstpUserAccessList(LpstpUser setUser,List<LpstpUserAccess> lpstpUserAccessList) {
		
		Iterator<LpstpUserAccess> LpstpUserAccessListitr=lpstpUserAccessList.iterator();
		String tableName= "LPSTP_USER_ACCESS";
		String seqId = "LUA_SEQ_NO";
		String userId = "LUA_USER_ID";
		BigDecimal seq = serviceProvider.getSequenceNoService().findMaxString(tableName, seqId, userId,setUser.getSuRowId());
		List<LpstpUserLocation> LpstpUserLocationlist=new ArrayList();
		LpstpUserLocation LpstpUserLocationObj=new LpstpUserLocation();
		List<BigDecimal>  lulOrgId=new ArrayList();
		while(LpstpUserAccessListitr.hasNext())
		{
			LpstpUserAccess LpstpUserAccessObj=LpstpUserAccessListitr.next();
			if(LpstpUserAccessObj.getLuaSeqNo()==null)
			{
				seq=seq.add(new BigDecimal(1));
				LpstpUserAccessObj.setLuaUserId(setUser.getSuRowId());
				LpstpUserAccessObj.setLuaCreatedBy(setUser.getSuRowId());
				LpstpUserAccessObj.setLuaCreatedOn(Helper.getSystemDate());
				LpstpUserAccessObj.setLuaModifiedBy(setUser.getSuRowId());	
				LpstpUserAccessObj.setLuaModifiedOn(Helper.getSystemDate());
				LpstpUserAccessObj.setLuaSeqNo(seq);
				lulOrgId=LpstpUserAccessObj.getLulOrgId();
				Iterator<BigDecimal> lulOrgIddeleteitr=lulOrgId.iterator();
				Iterator<BigDecimal> lulOrgIditr=lulOrgId.iterator();
				while(lulOrgIddeleteitr.hasNext())
				{
					BigDecimal orgId=lulOrgIddeleteitr.next();
					LpstpUserLocationlist=serviceProvider.getLpstpUserLocationService().findByLulBizVerticalAndLulUserId(LpstpUserAccessObj.getLuaBizVertical(), LpstpUserAccessObj.getLuaUserId());
					if(!LpstpUserLocationlist.isEmpty())
					{
					Iterator<LpstpUserLocation> LpstpUserLocationlistitr=LpstpUserLocationlist.iterator();
					while(LpstpUserLocationlistitr.hasNext())
					{
						lpstpUserLocationRepo.delete(LpstpUserLocationlistitr.next());
					}
					}
					}
				while(lulOrgIditr.hasNext())
				{
					BigDecimal orgId=lulOrgIditr.next();
					LpstpUserLocationObj=new LpstpUserLocation();
					LpstpUserLocationObj.setLulBizVertical(LpstpUserAccessObj.getLuaBizVertical());
					LpstpUserLocationObj.setLulCreatedBy(setUser.getSuRowId());
					LpstpUserLocationObj.setLulCreatedOn(Helper.getSystemDate());
					LpstpUserLocationObj.setLulModifiedBy(setUser.getSuRowId());
					LpstpUserLocationObj.setLulModifiedOn(Helper.getSystemDate());
					LpstpUserLocationObj.setLulOrgId(new BigDecimal(orgId.toString()));
					LpstpUserLocationObj.setLulUserId(LpstpUserAccessObj.getLuaUserId());
					LpstpUserLocationObj=lpstpUserLocationRepo.save(LpstpUserLocationObj);
				}
				
			}
			else
			{
				LpstpUserAccessObj.setLuaModifiedBy(setUser.getSuRowId());	
				LpstpUserAccessObj.setLuaModifiedOn(Helper.getSystemDate());
				LpstpUserAccessObj.setLuaSeqNo(seq);
				lulOrgId=LpstpUserAccessObj.getLulOrgId();
				Iterator<BigDecimal> lulOrgIddeleteitr=lulOrgId.iterator();
				Iterator<BigDecimal> lulOrgIditr=lulOrgId.iterator();
				while(lulOrgIddeleteitr.hasNext())
				{
					BigDecimal orgId=lulOrgIddeleteitr.next();
					LpstpUserLocationlist=serviceProvider.getLpstpUserLocationService().findByLulBizVerticalAndLulUserId(LpstpUserAccessObj.getLuaBizVertical(), LpstpUserAccessObj.getLuaUserId());
					if(!LpstpUserLocationlist.isEmpty())
					{
					Iterator<LpstpUserLocation> LpstpUserLocationlistitr=LpstpUserLocationlist.iterator();
					while(LpstpUserLocationlistitr.hasNext())
					{
						lpstpUserLocationRepo.delete(LpstpUserLocationlistitr.next());
					}
					}
				}
			
				while(lulOrgIditr.hasNext())
				{
					BigDecimal orgId=lulOrgIditr.next();
					LpstpUserLocationObj=new LpstpUserLocation();
					LpstpUserLocationObj.setLulBizVertical(LpstpUserAccessObj.getLuaBizVertical());
					LpstpUserLocationObj.setLulCreatedBy(LpstpUserAccessObj.getLuaUserId());
					LpstpUserLocationObj.setLulCreatedOn(Helper.getSystemDate());
					LpstpUserLocationObj.setLulModifiedBy(LpstpUserAccessObj.getLuaUserId());
					LpstpUserLocationObj.setLulModifiedOn(Helper.getSystemDate());
					LpstpUserLocationObj.setLulOrgId(new BigDecimal(orgId.toString()));
					LpstpUserLocationObj.setLulUserId(LpstpUserAccessObj.getLuaUserId());
					LpstpUserLocationObj=lpstpUserLocationRepo.save(LpstpUserLocationObj);
				}
			}
		
		}

		lpstpUserAccessList=lpstpUserAccessRepo.save(lpstpUserAccessList);
		return lpstpUserAccessList;
		
	}
	@Override
	public LpstpUser findBySuempid(String suempid) {
		return setUserRepo.findBySuempid(suempid);
	}
	@Override
	public List<LpstpUser> findBysuLocation(BigDecimal groupId) {
		// TODO Auto-generated method stub
		return setUserRepo.findBysuLocation(groupId);
	}
	


	
	
	
	
}
