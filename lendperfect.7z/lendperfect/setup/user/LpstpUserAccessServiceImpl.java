package com.sai.lendperfect.setup.user;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpUserAccess;
import com.sai.lendperfect.setuprepo.LpstpUserAccessRepo;

@Service("LpstpUserAccessService")
@Transactional
public class LpstpUserAccessServiceImpl implements  LpstpUserAccessService{

	@Autowired
	private LpstpUserAccessRepo  LpstpUserAccessRepo;
	
	public List<LpstpUserAccess> saveLpstpUserAccessDetails(List<LpstpUserAccess> LpstpUserAccesslist) {
		return LpstpUserAccessRepo.save(LpstpUserAccesslist);
	}

	public List<LpstpUserAccess> findByluaUserId(String luaUserId) {
		return LpstpUserAccessRepo.findByLuaUserIdOrderByLuaSeqNo(luaUserId);
	}

	public void deleteUserAccessDetails(LpstpUserAccess LpstpUserAccessObj) {
		LpstpUserAccessRepo.delete(LpstpUserAccessObj);
	}

	public LpstpUserAccess findByluaUserIdAndLuaBizVertical(String luaUserId, BigDecimal luaBizVertical) {
		return LpstpUserAccessRepo.findByluaUserIdAndLuaBizVertical(luaUserId, luaBizVertical);
	}

	@Override
	public LpstpUserAccess findByluaUserId1(String luaUserId) {
		return LpstpUserAccessRepo.findByluaUserId(luaUserId);
	}

}
