package com.sai.lendperfect.setup.user;

import java.util.HashMap;
/*import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
*/import java.util.Map;

import javax.servlet.http.HttpSession;

/*import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
*/import com.sai.lendperfect.logging.Logging;
/*import com.sai.lendperfect.model.SetStaticData;
*/
/*import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;*/
import com.sai.lendperfect.application.util.ServiceProvider;

public class UserDataProvider {
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(UserDataProvider.class);	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
//		try{
//			if(dpMethod.equals("getUserDataList")){	
//			try {
//				responseHashMap.put("userDataListAll", serviceProvider.getSetUserService().findAll());
//			}catch (Exception ex) {
//				if (!dataHashMap.containsKey("errorData")) {
//					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
//					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
//					responseHashMap.put("success", false);
//					responseHashMap.put("responseData", dataHashMap);
//				}
//			}
//		}else if(dpMethod.equals("saveUserData")){	
//			try {
//			SetUser setUser = serviceProvider.getSetUserService().saveSetUserData(new ObjectMapper()
//					.convertValue(allRequestParams.get("requestData"), new TypeReference<SetUser>() {}));
//			responseHashMap.put("getCurrentSavedUserByid",serviceProvider.getSetUserService().findById(setUser.getSuRowId()));
//			}catch (Exception ex) {
//					if (!dataHashMap.containsKey("errorData")) {
//						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
//						dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
//						responseHashMap.put("success", false);
//						responseHashMap.put("responseData", dataHashMap);
//					}
//				}
//			}else if(dpMethod.equals("getSetStaticDataListBySsdValueId")){
//			try {
//			long SsdValueId=Long.parseLong(allRequestParams.get("requestData").toString());
//			@SuppressWarnings("unchecked")
//			List<SetStaticData> setStaticDataList=(ArrayList<SetStaticData>)masterData;			
//			List<SetStaticData> setStaticDataListBySsdValueId=new ArrayList<SetStaticData>();
//			Iterator<SetStaticData> itr=setStaticDataList.iterator();
//			while(itr.hasNext())
//			{
//				SetStaticData setStaticData=itr.next();
//				if(setStaticData.getSsdValueId().longValue()==SsdValueId)
//					setStaticDataListBySsdValueId.add(setStaticData);				
//			}
//			responseHashMap.put("setStaticDataListBySsdValueId",setStaticDataListBySsdValueId);	
//		}catch (Exception ex) {
//			if (!dataHashMap.containsKey("errorData")) {
//				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
//				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
//				responseHashMap.put("success", false);
//				responseHashMap.put("responseData", dataHashMap);
//				}
//			}
//		}else if(dpMethod.equals("getuserIdEditable")){
//			try {
//			long ssdRowId=Long.parseLong(allRequestParams.get("requestData").toString());
//			responseHashMap.put("isuserIdEditable",serviceProvider.getSetUserService().checkuserIdEditable(ssdRowId));	
//			}catch (Exception ex) {
//				if (!dataHashMap.containsKey("errorData")) {
//					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
//					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
//					responseHashMap.put("success", false);
//					responseHashMap.put("responseData", dataHashMap);
//				}
//			}
//		}else if(dpMethod.equals("getGroupData"))
//		{			
//			try {
//				responseHashMap.put("usergroupDataList", serviceProvider.getUserGroupService().findAll());
//			} catch (Exception ex) {
//				if (!dataHashMap.containsKey("errorData")) {
//					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
//					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
//					responseHashMap.put("success", false);
//					responseHashMap.put("responseData", dataHashMap);
//					}
//				}
//		}else{
//			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
//			responseHashMap.put("success", false);
//			responseHashMap.put("responseData", dataHashMap);
//		}
//		}catch (Exception ex) {
//			if (!dataHashMap.containsKey("errorData")) {
//				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
//				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
//				responseHashMap.put("success", false);
//				responseHashMap.put("responseData", dataHashMap);
//				}
//			}
	return responseHashMap;
	}
}

