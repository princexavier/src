package com.sai.lendperfect.setup.user;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpUser;
import com.sai.lendperfect.setupmodel.LpstpUserAccess;
import com.sai.lendperfect.setupmodel.LpstpUserLocation;


public interface LpstpUserService {
	
	List<LpstpUser> findAll();
	List<LpstpUser>findAllOrderByname();
	List<LpstpUser> findByIdasList(String suRowId);
	
	LpstpUser findById(String suRowId);
	LpstpUser saveSetUserData(LpstpUser setUser);
	LpstpUser updateSetUserData(LpstpUser setUser);
	void deleteSetUserData(LpstpUser setUser);

	/*boolean checkuserIdEditable(String suRowId);
	*/
	boolean checkUserExistance(String suRowId ) ;
	Integer updateSetUserDatawithpassword(LpstpUser setUser);
	List<LpstpUser> findBysuAvailable(String suAvailable);
	public List<LpstpUser> findBysuSupervisorUsr(String suSupervisorUsr); 

	List<LpstpUser> findAllOrderBySuRowId();
	List<LpstpUser> findUserDetail(String searchval);
	List<LpstpUser> findBySuFirstNameIgnoreCaseContaining(String searchval);
	LpstpUser findBysuRowId(String suRowId );
	LpstpUser findBySuempid(String suempid );
	public LpstpUser findBySuSupervisorUsrAndsuRowIdIgnoreCase(String suSupervisorUsr,String suRowId);
	List<LpstpUser> findBySuSupervisorUsrAndSuFirstNameIgnoreCaseContaining(String suSupervisorUsr,String searchval);
	
	HashMap saveAllSetUserData(LpstpUser setUser, List<LpstpUserAccess> lpstpUserAccessList);
	HashMap updateAllSetUserData(LpstpUser setUser, List<LpstpUserAccess> lpstpUserAccessList);
	
	public List<LpstpUserAccess> saveLpstpUserAccessList(LpstpUser setUser,List<LpstpUserAccess> lpstpUserAccessList);
	List<LpstpUser> findBysuLocation(BigDecimal groupId);
	
}
