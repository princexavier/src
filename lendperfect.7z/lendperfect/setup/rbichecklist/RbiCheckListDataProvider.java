/*package com.sai.lendperfect.setup.rbichecklist;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.SetRbiCheckList;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.corpmodel.LpcorpBcacAnnex;

public class RbiCheckListDataProvider {
	public  Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(this.getClass());	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		responseHashMap.put("success", true);
		try{
		if(dpMethod.equals("saveRbiCheckList")){	
			try {
					SetRbiCheckList setRbiCheckList = serviceProvider.getSetRbiCheckListService().saveSetRbiCheckList(new ObjectMapper()
					.convertValue(allRequestParams.get("requestData"), new TypeReference<SetRbiCheckList>() {}));
			        responseHashMap.put("getRbiCheckListdata",serviceProvider.getSetRbiCheckListService().findById(setRbiCheckList.getSrcBizVertical()));
					responseHashMap.put("getRbiCheckListdata",Arrays.asList(setRbiCheckList));
					
			}catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			
			else if(dpMethod.equals("getDataBusinessVertical"))
			{		
				try {
				Long srcBizVertical= Long.valueOf((String)allRequestParams.get("requestData"));
				responseHashMap.put("allBusinessVerticalDetail",serviceProvider.getSetRbiCheckListService().getListByBVandIsDeleteOrNull(srcBizVertical,"N"));
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			    }
			}

			else if(dpMethod.equals("getDataCheckListHeader"))
			{		
				try {	
                //String srcListHeader= (allRequestParams.get("requestData").toString());
				responseHashMap.put("allCheckListHeaderDetail",serviceProvider.getSetRbiCheckListService().getListByIsDeleteOrNull("N"));
			}catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
					}
			    }
			}		
		else	if(dpMethod.equals("getPropNo"))
	 		{
	 			try{
	 				if(!(session.getAttribute("LP_COM_PROP_NO")).toString().equals("new"))
					{
	 				LpcomProposal lpcomProposal=serviceProvider.getLpcomProposalService().findByLpPropNo(Long.parseLong(session.getAttribute("LP_COM_PROP_NO").toString()));
	 				List<LpcorpBcacAnnex> lpcorpBcacAnnexList=serviceProvider.getLpcorpBcacAnnexService().findByLpcomProposal(lpcomProposal);
	 				responseHashMap.put("success", true);
	 				responseHashMap.put("responseData",lpcorpBcacAnnexList);
					}
	 				} 
	 				 catch (Exception e) {
	 						e.printStackTrace();
	 						logging.error("Provider : LpcorpBcacAnnexDataProvider /n getPropNo : {} /n Exception : ",dpMethod, e);
	 						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
	 						responseHashMap.put("responseData", dataHashMap);
	 				}
	 			
	 		}
		else{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		}catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
				}
			}
	return responseHashMap;
	}

}
*/