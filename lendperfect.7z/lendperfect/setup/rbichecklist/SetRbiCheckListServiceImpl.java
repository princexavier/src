/*

package com.sai.lendperfect.setup.rbichecklist;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.SetRbiCheckList;
import com.sai.lendperfect.setuprepo.SetRbiCheckListRepo;

@Service("setRbiCheckListService")
@Transactional
public class SetRbiCheckListServiceImpl implements SetRbiCheckListService{

	@Autowired
	SetRbiCheckListRepo setRbiCheckListRepo;
	
	public List<SetRbiCheckList> findAll() {
		return setRbiCheckListRepo.findAll() ;
	}
	
	public SetRbiCheckList saveSetRbiCheckList(SetRbiCheckList setRbiCheckList) {
		return setRbiCheckListRepo.save(setRbiCheckList);
	}
	
	
	public void deleteSetRbiCheckList(SetRbiCheckList setRbiCheckList) {
	setRbiCheckListRepo.delete(setRbiCheckList);	
	}


	@Override
	public List<SetRbiCheckList> findByIDasList(long srcRowid) {
		return setRbiCheckListRepo.findAll();
	}

	@Override
	public SetRbiCheckList findById(long srcRowid) {
		return setRbiCheckListRepo.findOne(srcRowid);
	}

	public List<SetRbiCheckList> getListByBVandIsDeleteOrNull(long srcBizVertical,String srcIsDelete) {
	//	return null;
		
		return setRbiCheckListRepo.getListByBVandIsDeleteOrNull(srcBizVertical,srcIsDelete);
	}
	
	public List<SetRbiCheckList> getListByIsDeleteOrNull(String srcIsDelete) {
//		return null;
		
		return setRbiCheckListRepo.getListByIsDeleteOrNull(srcIsDelete);
	}

}

*/