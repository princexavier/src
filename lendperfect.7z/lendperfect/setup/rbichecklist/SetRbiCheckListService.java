/*package com.sai.lendperfect.setup.rbichecklist;

import java.util.List;

import com.sai.lendperfect.setupmodel.SetRbiCheckList;

public interface SetRbiCheckListService {
	
	List<SetRbiCheckList> findAll();
	List<SetRbiCheckList> findByIDasList(long srcRowid);
	
	SetRbiCheckList findById(long srcRowid);
	SetRbiCheckList saveSetRbiCheckList(SetRbiCheckList setRbiCheckList);

	void deleteSetRbiCheckList(SetRbiCheckList setRbiCheckList);
	
	List<SetRbiCheckList> getListByBVandIsDeleteOrNull(long srcBizVertical,String srcIsDelete);
	List<SetRbiCheckList> getListByIsDeleteOrNull(String  srcIsDelete);
	
}
*/