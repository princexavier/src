package com.sai.lendperfect.setup.businessrulemaster;
/*package com.sai.lendperfect.service.master;
import java.util.List;

import com.sai.lendperfect.model.SetProductBusinessRule;

public interface ProductBusinessRuleService {
	
	List<SetProductBusinessRule> findAll();
	SetProductBusinessRule saveProductBusinessRule(SetProductBusinessRule setPrdBusiRuleVersion);
}
*/