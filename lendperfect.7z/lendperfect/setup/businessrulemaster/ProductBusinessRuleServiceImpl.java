package com.sai.lendperfect.setup.businessrulemaster;
/*package com.sai.lendperfect.service.master;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.model.SetProductBusinessRule;
import com.sai.lendperfect.repo.master.SetProductBusinessRuleRepo;



@Service("productBusinessRuleService")
@Transactional
public class ProductBusinessRuleServiceImpl implements ProductBusinessRuleService{

	
	@Autowired
	private SetProductBusinessRuleRepo productBusinessRuleRepo;
	
	public List<SetProductBusinessRule> findAll() {
		return productBusinessRuleRepo.findAll();
	}

	@Override
	public SetProductBusinessRule saveProductBusinessRule(SetProductBusinessRule setProductBusinessRule) {
		return productBusinessRuleRepo.saveAndFlush(setProductBusinessRule);
	}


	
	

}
*/