package com.sai.lendperfect.setup.businessrulemaster;
/*package com.sai.lendperfect.service.master;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.model.SetPrdBusiRuleVersion;
import com.sai.lendperfect.repo.master.SetPrdBusiRuleVersionRepo;



@Service("productBusRuleVersionService")
@Transactional
public class ProductBusRuleVersionServiceImpl implements ProductBusRuleVersionService{

	
	@Autowired
	private SetPrdBusiRuleVersionRepo prdBusiRuleVersionRepo;
	
	public List<SetPrdBusiRuleVersion> findAll() {
		return prdBusiRuleVersionRepo.findAll();
	}

	@Override
	public SetPrdBusiRuleVersion saveProductBusinessversion(SetPrdBusiRuleVersion setPrdBusiRuleVersion) {
		return prdBusiRuleVersionRepo.saveAndFlush(setPrdBusiRuleVersion);
	}


	
	

}
*/