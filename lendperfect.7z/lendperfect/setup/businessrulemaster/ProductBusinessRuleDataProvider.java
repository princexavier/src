package com.sai.lendperfect.setup.businessrulemaster;
/*package com.sai.lendperfect.util.dataprovider;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;



import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.model.SetBusinessRulesMaster;
import com.sai.lendperfect.model.SetPrdBusiRuleVersion;
import com.sai.lendperfect.model.SetProductBusinessRule;
import com.sai.lendperfect.model.SetStaticData;

public class ProductBusinessRuleDataProvider {
	
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(ProductBusinessRuleDataProvider.class);		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
	try{
		if(dpMethod.equals("getBusinessRuleList"))
		{
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("businessDataList",serviceProvider.getBusinessRuleMasterService().findAll());
			dataHashMap.put("prdVersionDataList",serviceProvider.getProductBusRuleVersionService().findAll());
			dataHashMap.put("prdRuleDataList",serviceProvider.getProductBusinessRuleService().findAll());
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else if(dpMethod.equals("saveProductBusinessRule"))
		{			
		SetPrdBusiRuleVersion setPrdBusiRuleVersion = serviceProvider.getProductBusRuleVersionService().saveProductBusinessversion(new ObjectMapper().convertValue(allRequestParams.get("requestPrdVersionData"), new TypeReference<SetPrdBusiRuleVersion>() { }));
		if(setPrdBusiRuleVersion!=null && setPrdBusiRuleVersion.getPbrvSeqId()!=0)
		{
			SetProductBusinessRule setPrdBusinessRule =  new ObjectMapper().convertValue(allRequestParams.get("requestPrdRuleData"), new TypeReference<SetProductBusinessRule>() { });
			setPrdBusinessRule.setPbrVersionId( new BigDecimal(setPrdBusiRuleVersion.getPbrvSeqId()));
			serviceProvider.getProductBusinessRuleService().saveProductBusinessRule(setPrdBusinessRule);
		}
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		dataHashMap.put("businessDataList",serviceProvider.getBusinessRuleMasterService().findAll());
		dataHashMap.put("prdVersionDataList",serviceProvider.getProductBusRuleVersionService().findAll());
		dataHashMap.put("prdRuleDataList",serviceProvider.getProductBusinessRuleService().findAll());		
		responseHashMap.put("success", true);
		responseHashMap.put("responseData", dataHashMap);
		}else if(dpMethod.equals("deleteProductBusinessRule"))
		{
			serviceProvider.getProductBusRuleVersionService().saveProductBusinessversion(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<SetPrdBusiRuleVersion>() { }));
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("businessDataList",serviceProvider.getBusinessRuleMasterService().findAll());
			dataHashMap.put("prdVersionDataList",serviceProvider.getProductBusRuleVersionService().findAll());
			dataHashMap.put("prdRuleDataList",serviceProvider.getProductBusinessRuleService().findAll());		
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else
		{
			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return responseHashMap;
		
	}

}
*/