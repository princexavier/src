package com.sai.lendperfect.setup.businessrulemaster;
//package com.sai.lendperfect.util.dataprovider;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import javax.servlet.http.HttpSession;
//
//
//
//import com.fasterxml.jackson.core.type.TypeReference;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.sai.lendperfect.application.util.CustomErr;
//import com.sai.lendperfect.application.util.ErrConstants;
//import com.sai.lendperfect.application.util.ServiceProvider;
//import com.sai.lendperfect.logging.Logging;
//import com.sai.lendperfect.model.SetBusinessRulesMaster;
//
//
//public class BusinessRuleMasterDataProvider {
//	
//	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
//	{
//		
//		logging.setLoggerClass(BusinessRuleMasterDataProvider.class);		
//		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
//		if(dpMethod.equals("getBusinessRuleList"))
//		{
//			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
//			dataHashMap.put("businessDataList",serviceProvider.getBusinessRuleMasterService().findAll());
//			dataHashMap.put("prdVersionDataList",serviceProvider.getProductBusRuleVersionService().findAll());
//			dataHashMap.put("prdRuleDataList",serviceProvider.getProductBusinessRuleService().findAll());
//			responseHashMap.put("success", true);
//			responseHashMap.put("responseData", dataHashMap);
//		}
//		else if(dpMethod.equals("saveBusinessRule"))
//		{			
//		serviceProvider.getBusinessRuleMasterService().saveBusinessRule(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<SetBusinessRulesMaster>() { }));
//		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
//		dataHashMap.put("businessDataList",serviceProvider.getBusinessRuleMasterService().findAll());
//		dataHashMap.put("prdVersionDataList",serviceProvider.getProductBusRuleVersionService().findAll());
//		dataHashMap.put("prdRuleDataList",serviceProvider.getProductBusinessRuleService().findAll());		
//		responseHashMap.put("success", true);
//		responseHashMap.put("responseData", dataHashMap);
//		}
//		else
//		{
//			Map <String,Object> dataHashMap=new HashMap<String,Object>();	
//			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
//			responseHashMap.put("success", false);
//			responseHashMap.put("responseData", dataHashMap);
//		}
//		return responseHashMap;
//		
//		
//	}
//
//}
