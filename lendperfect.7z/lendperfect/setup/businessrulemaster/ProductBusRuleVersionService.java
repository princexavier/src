package com.sai.lendperfect.setup.businessrulemaster;
/*package com.sai.lendperfect.service.master;
import java.util.List;

import com.sai.lendperfect.model.SetPrdBusiRuleVersion;

public interface ProductBusRuleVersionService {
	
	List<SetPrdBusiRuleVersion> findAll();
	SetPrdBusiRuleVersion saveProductBusinessversion(SetPrdBusiRuleVersion setPrdBusiRuleVersion);
}
*/