package com.sai.lendperfect.setup.productdetails;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;
import javax.servlet.http.HttpSession;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.setupmodel.LpstpFacility;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setupmodel.LpstpRiskBusinessrule;


public class LpstpProductDataProvider {
	
	@SuppressWarnings("unchecked")
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
					
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		String userid = (String) session.getAttribute("userid");
		responseHashMap.put("success",false);
	    if(dpMethod.equals("getBusinessRules"))
		    {
		    	try
		    	{
		    		 List<LpstpRiskBusinessrule> lpstpRiskBusinessruleList=serviceProvider.getLpstpRiskBusinessruleService().findAll();
		    		 responseHashMap.put("success", true);
					 responseHashMap.put("BusinessRules",lpstpRiskBusinessruleList);
		    	}  	
		    	 catch (Exception e) {
						e.printStackTrace();
						logging.error("Provider : LpstpProductDataProvider /n getProduct : {} /n Exception : ",dpMethod, e);
						dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
						responseHashMap.put("responseData", dataHashMap);
				}
				    	
		    }
		else if(dpMethod.equals("getproductData"))
		{
		   List<LpstpFacility> lpstpFacilityList =serviceProvider.getLpstpFacilityService().findAll();
		   
		   lpstpFacilityList.sort((LpstpFacility m1, LpstpFacility m2)->String.valueOf(m1.getLsfFacId()).compareTo(String.valueOf(m2.getLsfFacId())));
			
			List<LpstpFacility> parentList = lpstpFacilityList.stream().
					filter(m3->m3.getLsfFacParentId().equals(new Long(0))).collect(Collectors.toList());
			
			
			List<LpstpFacility> childList = lpstpFacilityList.stream().
					filter(m3->!m3.getLsfFacParentId().equals(new Long(0))).collect(Collectors.toList());
			
	    	List<LpmasBizVertical> lpmasBizVerticalList=serviceProvider.getLpmasBizVerticalService().findAll();
	    	dataHashMap.put("sanctionletterbybank",serviceProvider.getLpstpDocumentService().findAllByLdDocTypeAndLdDocActive("B", "Y"));
	    	dataHashMap.put("sanctionletterbycustomer",serviceProvider.getLpstpDocumentService().findAllByLdDocTypeAndLdDocActive("B", "Y"));
	    	dataHashMap.put("LoanType",serviceProvider.getCustomerDetailsService().findByllvHeader("LoanType"));
			dataHashMap.put("lpmasBizVerticalList",lpmasBizVerticalList);
			dataHashMap.put("mainFacilityDetail",parentList);
			dataHashMap.put("childFacilityDetail",childList);
			dataHashMap.put("success", true);
		   responseHashMap.put("responseData", dataHashMap);
		}
	   
	    else if(dpMethod.equals("saveProduct"))
		{
	    	
	    	BigDecimal vertical=new BigDecimal(allRequestParams.get("vertical").toString());
	    	LpmasBizVertical lpmasBizVertical=serviceProvider.getLpmasBizVerticalService().findByLbvRowId(vertical.longValue());
	    	BigDecimal oldId = serviceProvider.getSequenceNoService().findMaxForTable("LPSTP_PRODUCT_DET","LPD_PROD_NEW_ID");
	    	LpstpProductDet lpstpProductDet= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpProductDet>() { });
	    	if(lpstpProductDet.getLpdProdNewId()==0)
	    		lpstpProductDet.setLpdProdId(oldId);
	    	lpstpProductDet.setLpdCreatedOn(Helper.getSystemDate());
	    	lpstpProductDet.setLpdRecentPrd(lpstpProductDet.getLpdPrdDesc());
	    	lpstpProductDet.setLpdCreatedBy(userid);
	    	lpstpProductDet.setLpdModifiedBy(userid);
	    	lpstpProductDet.setLpdComplete("N");
	    	lpstpProductDet.setLpdModifiedOn(Helper.getSystemDate());
	    	lpstpProductDet.setLpmasBizVertical(lpmasBizVertical);
	    	lpstpProductDet = serviceProvider.getLpstpProductDetService().saveProductDetails(lpstpProductDet);
			dataHashMap.put("lpstpProductDet",lpstpProductDet);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
	    	
		}
	    else if(dpMethod.equals("getProduct"))
	    {
	    	try
	    	{
	    		BigDecimal lpdProdId=new BigDecimal(allRequestParams.get("requestData").toString());
	    		
	    	 if(Integer.valueOf(lpdProdId.intValue())!=0)
	    	 {
			 LpstpProductDet lpstpProductDet=(LpstpProductDet) serviceProvider.getLpstpProductDetService().findByLpdProdNewId(lpdProdId.longValue());			
			 LpmasBizVertical lpmasBizVertical=serviceProvider.getLpmasBizVerticalService().findByLbvRowId(lpstpProductDet.getLpmasBizVertical().getLbvRowId());
			 dataHashMap.put("lpmasBizVertical",lpmasBizVertical);
			 dataHashMap.put("lpstpProductDet",lpstpProductDet);
			 if(lpstpProductDet.getLpdEffectiveFrom()==null)
				 dataHashMap.put("effDate","");
			 else
			 dataHashMap.put("effDate",(new SimpleDateFormat("dd/MM/yyyy").format(lpstpProductDet.getLpdEffectiveFrom())));
			 responseHashMap.put("success", true);
			 responseHashMap.put("responseData",dataHashMap);
	    	 }
	    	}	    	
	    	 catch (Exception e) {
					e.printStackTrace();
					logging.error("Provider : LpstpProductDataProvider /n getProduct : {} /n Exception : ",dpMethod, e);
					dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
					responseHashMap.put("responseData", dataHashMap);
			}
			    	
	    }
	    else if(dpMethod.equals("copyProduct"))
	    {
	    	try
	    	{
	    		//String userid = (String) session.getAttribute("userid");
	    		LpstpProductDet lpstpProductDet= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpProductDet>() { });
	    		BigDecimal lpdProdId=new BigDecimal(lpstpProductDet.getLpdProdNewId());
	    		lpstpProductDet=serviceProvider.getLpstpProductDetService().copyProduct(lpdProdId,userid,lpstpProductDet.getLpdActive());
	    		 responseHashMap.put("success", true);
				 responseHashMap.put("responseData",dataHashMap);
	    	}  	
	    	 catch (Exception e) {
					e.printStackTrace();
					logging.error("Provider : LpstpProductDataProvider /n getProduct : {} /n Exception : ",dpMethod, e);
					dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
					responseHashMap.put("responseData", dataHashMap);
			}
			    	
	    }
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
		
		
	}

}

