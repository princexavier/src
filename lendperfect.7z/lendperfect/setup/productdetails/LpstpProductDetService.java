package com.sai.lendperfect.setup.productdetails;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Query;

import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.setupmodel.LpstpProductDet;



public interface LpstpProductDetService {

	LpstpProductDet saveProductDetails(LpstpProductDet lpstpProductDet);

	List<LpstpProductDet> findAll(long l);

	void deleteProductDetails(List<LpstpProductDet> lpstpProductDetList1);

	LpstpProductDet findByLpdProdNewId(Long lpdProdNewId);
	
	List<LpstpProductDet> findByLpdProdNewId(List<Long> lpdProdNewId);

	LpstpProductDet updateProductDetails(LpstpProductDet lpstpProductDet);
	
	List<LpstpProductDet> findByLpdPrdMainCatAndLpdPrdSubCatAndLpdActiveAndLpdComplete(String lpdPrdMainCat,String lpdPrdSubCat,String lpdActive,String lpdComplete);

	//List<Object[]> findAllProductSearch(long lpdBizVertical,String lpdActive,String lpdPrdType,String lpdPrdNature,String lpdComplete,BigDecimal lpdAmtFrom,BigDecimal lpdAmtTo,String lpdRecentPrd);
	
	Query query(String condition);

	LpstpProductDet copyProduct(BigDecimal lpdProdId, String userid,String cpyRenew);

	LpstpProductDet findByLpdPrdSubCat(String lpdPrdSubCat);
	
	List<LpstpProductDet> findByLpdPrdMainCatAndLpdActiveAndLpdComplete(String lpdPrdMainCat,String lpdActive,String lpdComplete);
	
	List<LpstpProductDet> findByLpdActiveAndLpdComplete(String lpdActive,String lpdComplete);
	
	List<LpstpProductDet> findAllByLpdActiveAndLpdComplete(String lpdActive,String lpdComplete);
	
	//getProducts based on type for chart report 
	List<LpstpProductDet> findBylpdPrdType(String lpdPrdType);

}
