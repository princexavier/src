package com.sai.lendperfect.setup.productdetails;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setuprepo.LpstpProductDetRepo;


@Service("lpstpProductDetService")
@Transactional
public class LpstpProductDetServiceImpl implements LpstpProductDetService{

	@Autowired
	LpstpProductDetRepo lpstpProductDetRepo;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public LpstpProductDet saveProductDetails(LpstpProductDet lpstpProductDet) {
		return lpstpProductDetRepo.save(lpstpProductDet);
	}

	
	public List<LpstpProductDet> findAll() {
		return lpstpProductDetRepo.findAll();
	}

	@Override
	public void deleteProductDetails(List<LpstpProductDet> lpstpProductDetList1) {
		lpstpProductDetRepo.delete(lpstpProductDetList1);
	}

	@Override
	public LpstpProductDet findByLpdProdNewId(Long lpdProdNewId) {
		return lpstpProductDetRepo.findByLpdProdNewId(lpdProdNewId);
	}

	@Override
	public LpstpProductDet updateProductDetails(LpstpProductDet lpstpProductDet) {
		return lpstpProductDetRepo.save(lpstpProductDet);
	}

	public List<LpstpProductDet> findByLpdPrdMainCatAndLpdPrdSubCatAndLpdActiveAndLpdComplete(String lpdPrdMainCat,
			String lpdPrdSubCat, String lpdActive, String lpdComplete) {
		return lpstpProductDetRepo.findByLpdPrdMainCatAndLpdPrdSubCatAndLpdActiveAndLpdComplete( lpdPrdMainCat, lpdPrdSubCat, lpdActive, lpdComplete);
	}

	public List<LpstpProductDet> findByLpdProdNewId(List<Long> lpdProdNewId) {
		return lpstpProductDetRepo.findByLpdProdNewIdIn(lpdProdNewId);
		
	}

	public Query query(String condition) {
		
		Query productDetList=entityManager.createNativeQuery("select * from LPSTP_PRODUCT_DET where "+condition+"order by LPD_PROD_ID");
		return productDetList;
	}

	@Override
	public LpstpProductDet copyProduct(BigDecimal lpdProdId, String userid,String cpyRenew) {
		StoredProcedureQuery query = entityManager.createStoredProcedureQuery("copy1"); 

        //Declare the parameters in the same order
		query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(3, String.class, ParameterMode.IN);
        query.registerStoredProcedureParameter(4, String.class, ParameterMode.IN);
        
        //Pass the parameter values
        query.setParameter(1, lpdProdId+"");
        query.setParameter(2, userid+"");
        query.setParameter(3, userid+"");
        query.setParameter(4, cpyRenew+"");
        //Execute query
        query.execute();
		return null;

	}

	@Override
	public List<LpstpProductDet> findAll(long l) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public LpstpProductDet findByLpdPrdSubCat(String lpdPrdSubCat) {
		return lpstpProductDetRepo.findByLpdPrdSubCat(lpdPrdSubCat);
	}


	@Override
	public List<LpstpProductDet> findByLpdPrdMainCatAndLpdActiveAndLpdComplete(String lpdPrdMainCat, String lpdActive,
			String lpdComplete) {
		
		return lpstpProductDetRepo.findByLpdPrdMainCatAndLpdActiveAndLpdComplete(lpdPrdMainCat, lpdActive, lpdComplete);
	}


	@Override
	public List<LpstpProductDet> findByLpdActiveAndLpdComplete(String lpdActive, String lpdComplete) {
		// TODO Auto-generated method stub
		return lpstpProductDetRepo.findByLpdActiveAndLpdComplete(lpdActive, lpdComplete);
	}


	@Override
	public List<LpstpProductDet> findAllByLpdActiveAndLpdComplete(String lpdActive, String lpdComplete) {
		// TODO Auto-generated method stub
		return lpstpProductDetRepo.findAllByLpdActiveAndLpdComplete(lpdActive, lpdComplete);

	}


	@Override
	public List<LpstpProductDet> findBylpdPrdType(String lpdPrdType) {
		// TODO Auto-generated method stub
		return lpstpProductDetRepo.findBylpdPrdType(lpdPrdType);
	}



	
	
}
