package com.sai.lendperfect.setup.interestrate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setuprepo.LpstpPrdIntRateRepo;
import com.sai.lendperfect.setup.interestrate.LpstpPrdIntRateService;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;



@Service("lpstpPrdIntRateService")
@Transactional
public class LpstpPrdIntRateServiceImpl implements LpstpPrdIntRateService{

	@Autowired
	LpstpPrdIntRateRepo lpstpPrdIntRateRepo;

	
	@Override
	public List<LpstpPrdIntRate> savePrdIntRate(List<LpstpPrdIntRate> lpstpPrdIntRatelist) {
		 return lpstpPrdIntRateRepo.save(lpstpPrdIntRatelist);
	}

	@Override
	public List<LpstpPrdIntRate> findAll() {
		return lpstpPrdIntRateRepo.findAll();
	}

	@Override
	public void deletePrdIntRate(List<LpstpPrdIntRate> lpstpProductDetList1) {
		lpstpPrdIntRateRepo.delete(lpstpProductDetList1);
	}

	@Override
	public List<LpstpPrdIntRate> findByLirProdIdOrderByLirRowId(Long lirProdId) {
		return lpstpPrdIntRateRepo.findByLirProdIdOrderByLirRowId(lirProdId);
	}

	@Override
	public 	List<LpstpPrdIntRate> getIntRateByPrdId(Long prdId) {
		return lpstpPrdIntRateRepo.findByLirProdIdOrderByLirRowId(prdId);
	}

	@Override
	public LpstpPrdIntRate findByLirProdId(Long lirProdId) {
		return lpstpPrdIntRateRepo.findByLirProdId(lirProdId);
	}


	
}
