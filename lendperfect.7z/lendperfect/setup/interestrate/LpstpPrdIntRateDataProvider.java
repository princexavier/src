package com.sai.lendperfect.setup.interestrate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.google.gson.Gson;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public class LpstpPrdIntRateDataProvider {
	
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		String userid = (String) session.getAttribute("userid");
	   if(dpMethod.equals("getprdIntRateData"))
		{
		  // LpstpProductDet lpstpProductDet= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpProductDet>() { });
		   BigDecimal lpdProdId=new BigDecimal(allRequestParams.get("requestData").toString());
		   LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(lpdProdId.longValue()));
		   if(lpstpProductDetfromDB!=null)
		   {
			   List<LpstpPrdIntRate> lpstpPrdIntRate =serviceProvider.getLpstpPrdInterestRateService().findByLirProdIdOrderByLirRowId((lpdProdId.longValue()));
			   dataHashMap.put("lpstpPrdIntRateList",lpstpPrdIntRate);
			   responseHashMap.put("success", true);
			   responseHashMap.put("responseData", dataHashMap);
		   }else
		   {
			   	dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		   }
		  
		}
	    else if(dpMethod.equals("savePrdIntRate"))
	    {
	    	List InterestRatelist = (List) allRequestParams.get("requestData");
	    	for(int i=0;i<InterestRatelist.size();i++)
	    	{
		    	
		    	List<LpstpPrdIntRate> lpstpPrdIntRateList = new ObjectMapper().convertValue(InterestRatelist.get(i), new TypeReference<List<LpstpPrdIntRate>>() { });
		    	List<LpstpPrdIntRate> lpstpPrdIntRateListDel  = serviceProvider.getLpstpPrdInterestRateService().findByLirProdIdOrderByLirRowId(lpstpPrdIntRateList.get(0).getLirProdId());
		    	serviceProvider.getLpstpPrdInterestRateService().deletePrdIntRate(lpstpPrdIntRateListDel);
		    	
		    	lpstpPrdIntRateList.forEach(lpstpPrdIntRate->{
		    		lpstpPrdIntRate.setLirCreatedOn(Helper.getSystemDate());
			    	lpstpPrdIntRate.setLirCreatedBy(userid);
			    	lpstpPrdIntRate.setLirModifedBy(userid);
			    	lpstpPrdIntRate.setLirComplete("N");
			    	lpstpPrdIntRate.setLirModifiedOn(Helper.getSystemDate());
		    	});
		    	
		    	List<LpstpPrdIntRate> lpstpPrdIntRateAftSaved = serviceProvider.getLpstpPrdInterestRateService().savePrdIntRate(lpstpPrdIntRateList);
		    	Long l =(long) 0;
		    	long prdId = 0;
		    	for (LpstpPrdIntRate lpstpPrdIntRate :lpstpPrdIntRateAftSaved)
		    	{
		    		prdId = new Long(lpstpPrdIntRate.getLirProdId());
		    	}
		    	 
		    
		    	List<LpstpPrdIntRate> lpstpPrdIntRatelist  = serviceProvider.getLpstpPrdInterestRateService().getIntRateByPrdId(prdId);
		    	
				LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prdId);
		    	if(lpstpPrdIntRatelist !=null)
		    	{
		    		lpstpProductDetfromDB.setLpdComplete("N");
		    		lpstpProductDetfromDB=serviceProvider.getLpstpProductDetService().updateProductDetails(lpstpProductDetfromDB);
		    	}
		    	
		    	dataHashMap.put("lpstpProductDet",lpstpProductDetfromDB);
				dataHashMap.put("lpstpPrdIntRateList",lpstpPrdIntRateAftSaved);
	    	}
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		} else if(dpMethod.equals("deletePrdIntRate"))
	    {
			List<LpstpPrdIntRate> lpstpPrdIntRateList= new ArrayList();
			lpstpPrdIntRateList.add(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpPrdIntRate>() { }));
		
			lpstpPrdIntRateList.forEach(lpstpPrdIntRate->{
	    		lpstpPrdIntRate.setLirCreatedOn(Helper.getSystemDate());
		    	lpstpPrdIntRate.setLirCreatedBy(userid);
		    	lpstpPrdIntRate.setLirModifedBy(userid);
		    	lpstpPrdIntRate.setLirComplete("N");
		    	lpstpPrdIntRate.setLirModifiedOn(Helper.getSystemDate());
	    	});
			
	    	serviceProvider.getLpstpPrdInterestRateService().deletePrdIntRate(lpstpPrdIntRateList);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}

}
