package com.sai.lendperfect.setup.interestrate;
import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPrdIntRate;

public interface LpstpPrdIntRateService {

	List<LpstpPrdIntRate> savePrdIntRate(List<LpstpPrdIntRate> lpstpPrdIntRatelist);

	List<LpstpPrdIntRate> findAll();

	void deletePrdIntRate(List<LpstpPrdIntRate> lpstpProductDetList1);

	List<LpstpPrdIntRate> getIntRateByPrdId(Long prdId);

	List<LpstpPrdIntRate> findByLirProdIdOrderByLirRowId(Long lirProdId);

	LpstpPrdIntRate findByLirProdId(Long lirProdId);
}
