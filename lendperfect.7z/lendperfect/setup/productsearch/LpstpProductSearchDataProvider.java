package com.sai.lendperfect.setup.productsearch;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasBizVertical;
import com.sai.lendperfect.setupmodel.LpstpProductDet;


public class LpstpProductSearchDataProvider {
		
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		List<Object[]> lpstpProductDetList=new ArrayList<Object[]>();
		
		 if(dpMethod.equals("getBizVertical"))
		{
			 try
			 {
		    	List<LpmasBizVertical> lpmasBizVerticalList=serviceProvider.getLpmasBizVerticalService().findAll();
		    	dataHashMap.put("LoanType",serviceProvider.getCustomerDetailsService().findByllvHeader("LoanType"));
				dataHashMap.put("lpmasBizVerticalList",lpmasBizVerticalList);
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			 }
			 catch (Exception e) {
					e.printStackTrace();
					logging.error("Provider : LpstpProductSearchDataProvider /n getBizVertical : {} /n Exception : ",dpMethod, e);
					dataHashMap.put("errorData", new CustomErr(ErrConstants.invalidDataErrCode,ErrConstants.invalidDataErrMessage));
					responseHashMap.put("responseData", dataHashMap);
			}
		
		    	
		}
 		else if(dpMethod.equals("productSearch"))
		{
	    	long vertical;
			Map <String,Object> productMap=new HashMap<String,Object>();
	    	Map<String, Object> productHashMap = new HashMap<String, Object>();
	    	productHashMap=(Map<String, Object>) allRequestParams.get("requestData");
	    	if(productHashMap.get("lpdBizVertical").toString().equals("s"))
	    		vertical=0;
	    	else
	    		vertical=Long.parseLong(productHashMap.get("lpdBizVertical").toString());
	    	String lpdRecentPrd=Helper.correctNull(productHashMap.get("lpdRecentPrd").toString());
	    	String lpdActive=Helper.correctNull(productHashMap.get("lpdActive").toString());
	    	String lpdPrdType=Helper.correctNull(productHashMap.get("lpdPrdType").toString());
	    	String lpdPrdNature=Helper.correctNull(productHashMap.get("lpdPrdNature").toString());
	    	String lpdComplete=Helper.correctNull(productHashMap.get("lpdComplete").toString());
	    	String lpdAmtFrom=Helper.correctNull(productHashMap.get("lpdAmtFrom").toString());
	    	String lpdAmtTo=Helper.correctNull(productHashMap.get("lpdAmtTo").toString());
	    	
	 		String condition="";
			if(vertical!=0)
			{
				condition="LPD_BIZ_VERTICAL = "+vertical;
				if(!lpdActive.equals(""))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"'";		
				if((!lpdPrdType.equals("")) && (!lpdPrdType.equals("s")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_PRD_TYPE='"+lpdPrdType+"'";	
				if((!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_PRD_NATURE='"+lpdPrdNature+"'";		
				if(!lpdComplete.equals(""))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_COMPLETE='"+lpdComplete+"'";	
				if(((!lpdAmtFrom.equals(""))&&(!lpdAmtFrom.equals(0))) && ((!lpdAmtTo.equals("")) && (!lpdAmtTo.equals(0))))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_AMT_FROM="+lpdAmtFrom+"and LPD_AMT_TO="+lpdAmtTo;	
				if(!lpdRecentPrd.equals(""))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_RECENT_PRD='"+lpdRecentPrd+"'";
				//2
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&&(!lpdPrdType.equals("s")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"'and LPD_PRD_TYPE='"+lpdPrdType+"'";		
				
				if((!lpdActive.equals(""))&&(!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"' and LPD_PRD_NATURE='"+lpdPrdNature+"'";	
				
				if((!lpdActive.equals(""))&& (!lpdComplete.equals("")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+
					"'and LPD_COMPLETE='"+lpdComplete+"'";	
					
				if((!lpdActive.equals(""))&& ((!lpdAmtFrom.equals(""))&&(!lpdAmtFrom.equals(0))) && ((!lpdAmtTo.equals("")) && (!lpdAmtTo.equals(0))))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+
					"'and LPD_AMT_FROM="+lpdAmtFrom+"and LPD_AMT_TO="+lpdAmtTo;	
					
				if((!lpdActive.equals(""))&& (!lpdRecentPrd.equals("")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+
					"'and LPD_RECENT_PRD='"+lpdRecentPrd+"'";
			///3
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&&(!lpdPrdType.equals("s")) && (!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s")) )
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_PRD_NATURE='"+lpdPrdNature+"'";		

				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&& (!lpdComplete.equals("")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_COMPLETE='"+lpdComplete+"'";	
					
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&& ((!lpdAmtFrom.equals(""))&&(!lpdAmtFrom.equals(0))) && ((!lpdAmtTo.equals("")) && (!lpdAmtTo.equals(0))))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_AMT_FROM="+lpdAmtFrom+"and LPD_AMT_TO="+lpdAmtTo;	
				
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&& (!lpdRecentPrd.equals("")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_RECENT_PRD='"+lpdRecentPrd+"'";
			
			/////4
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&&(!lpdPrdType.equals("s")) && (!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s"))&& (!lpdComplete.equals("")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_PRD_NATURE='"+lpdPrdNature+"' and LPD_COMPLETE='"+lpdComplete+"'";			
				
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&&(!lpdPrdType.equals("s")) && (!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s"))&& (!lpdAmtFrom.equals(""))&& (!lpdAmtFrom.equals(0)) && ((!lpdAmtTo.equals("")) && (!lpdAmtTo.equals(0))))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_PRD_NATURE='"+lpdPrdNature+"' and LPD_AMT_FROM="+lpdAmtFrom+"and LPD_AMT_TO="+lpdAmtTo;	
				
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&&(!lpdPrdType.equals("s")) && (!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s"))&&  (!lpdRecentPrd.equals("")))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_PRD_NATURE='"+lpdPrdNature+"' and LPD_RECENT_PRD='"+lpdRecentPrd+"'";	
			
			///5
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&&(!lpdPrdType.equals("s")) && (!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s"))&& (!lpdComplete.equals("")) && (!lpdAmtFrom.equals(""))&&(!lpdAmtFrom.equals(0)) && ((!lpdAmtTo.equals("")) && (!lpdAmtTo.equals(0))))
				condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_PRD_NATURE='"+lpdPrdNature+"' and LPD_COMPLETE='"+lpdComplete+"'and LPD_AMT_FROM="+lpdAmtFrom+"and LPD_AMT_TO="+lpdAmtTo;	
			
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&&(!lpdPrdType.equals("s")) && (!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s"))&& (!lpdComplete.equals("")) &&(!lpdRecentPrd.equals("")))
				condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_PRD_NATURE='"+lpdPrdNature+"' and LPD_COMPLETE='"+lpdComplete+"'and LPD_RECENT_PRD='"+lpdRecentPrd+"'";	
			
			//6
				if((!lpdActive.equals(""))&&(!lpdPrdType.equals(""))&&(!lpdPrdType.equals("s")) && (!lpdPrdNature.equals("")) && (!lpdPrdNature.equals("s"))&& (!lpdComplete.equals("")) && (!lpdAmtFrom.equals(""))&&(!lpdAmtFrom.equals(0)) && ((!lpdAmtTo.equals("")) && (!lpdAmtTo.equals(0)) && (!lpdRecentPrd.equals(""))))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"and LPD_PRD_TYPE='"+lpdPrdType+"' and LPD_PRD_NATURE='"+lpdPrdNature+"' and LPD_COMPLETE='"+lpdComplete+"'and LPD_AMT_FROM="+lpdAmtFrom+"and LPD_AMT_TO="+lpdAmtTo+" LPD_RECENT_PRD='"+lpdRecentPrd+"'";		
			
			}	
			
				Query query=serviceProvider.getLpstpProductDetService().query(condition);
				lpstpProductDetList=query.getResultList();
			 	
				List<Object> productListNew=new ArrayList<Object>();
				for(Object[] object : lpstpProductDetList)
			     {
					productMap=new HashMap<String,Object>();
					productMap.put("lpdProdNewId",object[1]);
					productMap.put("lpdActive", object[6]);
					productMap.put("lpdAmtFrom", object[7]);
					productMap.put("lpdAmtTo", object[8]);
					productMap.put("lpdCbsCode", object[9]);
					productMap.put("lpdComplete", object[10]);
					productMap.put("lpdCreatedBy", object[4]);
					productMap.put("lpdCreatedOn", object[5]);
					productMap.put("lpdEffectiveFrom", object[11]);
					productMap.put("lpdModifiedBy", object[2]);
					productMap.put("lpdModifiedOn", object[3]);
					productMap.put("lpdPrdDesc",object[12]);
					productMap.put("lpdPrdMainCat", object[13]);
					productMap.put("lpdPrdNature", object[14]);
					productMap.put("lpdPrdSubCat", object[15]);
					productMap.put("lpdPrdType", object[16]);
					productMap.put("lpdProdId",object[0]);
					productMap.put("lpdRecentPrd", object[17]);
					productMap.put("lpdTenorFrom", object[18]);
					productMap.put("lpdTenorTo", object[19]);
					productMap.put("vertical",object[20]);
					
					productListNew.add(productMap);
				}
				
			  dataHashMap.put("productListNew",productListNew);
			  responseHashMap.put("success", true);
			  responseHashMap.put("responseData", dataHashMap);
		}
		 
		else if(dpMethod.equals("productPopupSearch"))
		{
	    	long vertical;
			Map <String,Object> productMap=new HashMap<String,Object>();
	    	Map<String, Object> productHashMap = new HashMap<String, Object>();
	    	productHashMap=(Map<String, Object>) allRequestParams.get("requestData");
	    	if(productHashMap.get("lpdBizVertical").toString().equals("s"))
	    		vertical=0;
	    	else
	    	vertical=Long.parseLong(productHashMap.get("lpdBizVertical").toString());
	    	String lpdRecentPrd=Helper.correctNull(productHashMap.get("lpdRecentPrd").toString());
	    	String lpdActive=Helper.correctNull(productHashMap.get("lpdActive").toString());
	    	String lpdPrdType=Helper.correctNull(productHashMap.get("lpdPrdType").toString());
	    	String lpdPrdNature=Helper.correctNull(productHashMap.get("lpdPrdNature").toString());
	    	String lpdComplete=Helper.correctNull(productHashMap.get("lpdComplete").toString());
	    	String lpdAmtFrom=Helper.correctNull(productHashMap.get("lpdAmtFrom").toString());
	    	String lpdAmtTo = Helper.correctNull(productHashMap.get("lpdAmtTo").toString());
	    	String name = Helper.correctNull(productHashMap.get("name").toString());
	    	String searchcode = Helper.correctNull(productHashMap.get("searchval").toString());
	 		String condition="";
			if(vertical!=0)
			{
				condition="LPD_BIZ_VERTICAL = "+vertical;
				if(name.equalsIgnoreCase("N"))
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"'"+" and LPD_PROD_NEW_ID like '"+searchcode+"%'";	
				else 
					condition="LPD_BIZ_VERTICAL = "+vertical+" and LPD_ACTIVE='"+lpdActive+"'"+" and LPD_PRD_DESC like '"+searchcode+"%'";	
				
			}	
			
				Query query=serviceProvider.getLpstpProductDetService().query(condition);
				lpstpProductDetList=query.getResultList();
			 	
				List<Object> productListNew=new ArrayList<Object>();
				for(Object[] object : lpstpProductDetList)
			     {
					productMap=new HashMap<String,Object>();
					productMap.put("lpdProdNewId",object[1]);
					productMap.put("lpdActive", object[6]);
					productMap.put("lpdAmtFrom", object[7]);
					productMap.put("lpdAmtTo", object[8]);
					productMap.put("lpdCbsCode", object[9]);
					productMap.put("lpdComplete", object[10]);
					productMap.put("lpdCreatedBy", object[4]);
					productMap.put("lpdCreatedOn", object[5]);
					productMap.put("lpdEffectiveFrom", object[11]);
					productMap.put("lpdModifiedBy", object[2]);
					productMap.put("lpdModifiedOn", object[3]);
					productMap.put("lpdPrdDesc",object[12]);
					productMap.put("lpdPrdMainCat", object[13]);
					productMap.put("lpdPrdNature", object[14]);
					productMap.put("lpdPrdSubCat", object[15]);
					productMap.put("lpdPrdType", object[16]);
					productMap.put("lpdProdId",object[0]);
					productMap.put("lpdRecentPrd", object[17]);
					productMap.put("lpdTenorFrom", object[18]);
					productMap.put("lpdTenorTo", object[19]);
					productMap.put("vertical",object[20]);
					
					productListNew.add(productMap);
				}
				
			  dataHashMap.put("productListNew",productListNew);
			  responseHashMap.put("success", true);
			  responseHashMap.put("responseData", dataHashMap);
		}
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
		
		
	}

}
