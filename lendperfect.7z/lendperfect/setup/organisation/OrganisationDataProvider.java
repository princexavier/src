package com.sai.lendperfect.setup.organisation;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.SetOrganisation;

public class OrganisationDataProvider {
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(OrganisationDataProvider.class);		
		Map <String,Object> dpHashMap=new HashMap<String,Object>();	
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> requestHashMap=new HashMap<String,Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		responseHashMap.put("success", false);
		
		if(dpMethod.equals("saveSetOrganisation"))
		{		
			try {
			SetOrganisation setOrganisation=new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<SetOrganisation>() { });	
			
			if(setOrganisation.getSoOrgId() == 0)
			{
				setOrganisation.setSoOrgId(serviceProvider.getPrimaryIdGenerationService().getOrgId());
				setOrganisation.setLoOrgLevel("1");
				setOrganisation.setSoCreatedBy(session.getAttribute("userid").toString());
//				setOrganisation.setSoCreatedBy("guhan");
				setOrganisation.setSoCreatedOn(Helper.getSystemDate());
			}
			setOrganisation.setSoModifiedBy(session.getAttribute("userid").toString());
//			setOrganisation.setSoModifiedBy("guhan");
			setOrganisation.setSoModifiedOn(Helper.getSystemDate());
			
			responseHashMap.put("responseData", serviceProvider.getsetOrganisationService().saveSetOrganisation(setOrganisation));
			
			responseHashMap.put("success", true);
			session.setAttribute("orgId",setOrganisation.getSoOrgId());
			session.setAttribute("orgScode",setOrganisation.getSoSolId());
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		} 
		

		else if(dpMethod.equals("getLevelOneDetails"))
		{
			try {
			List<SetOrganisation> setOrganisation=serviceProvider.getsetOrganisationService().findAll();
			responseHashMap.put("success", true);
	        responseHashMap.put("setOrganisation", setOrganisation);
		} catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
		}
		}
		
		else if(dpMethod.equals("getLevel"))
		{
			try {
			long soOrgId=Long.parseLong(allRequestParams.get("requestData").toString());
			dpHashMap.put("organisationData",serviceProvider.getsetOrganisationService().findBysoOrgId(soOrgId));
			responseHashMap.put("success", true);
	        responseHashMap.put("responseData", dpHashMap);
		} catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
		}
		}
		
		else if(dpMethod.equals("getBranches"))
		{
			try {
				String loOrgLevel = allRequestParams.get("requestData").toString();
				dpHashMap.put("unitList",serviceProvider.getsetOrganisationService().findByLoOrgLevel(loOrgLevel));
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dpHashMap);
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		
		else if(dpMethod.equals("getUnitList"))
		{
			try {
			requestHashMap = (Map<String, Object>) allRequestParams.get("requestData");
			String loOrgBizVertical = requestHashMap.get("vertical").toString();
			String loOrgDepartment = (String) requestHashMap.get("dept");
			String loOrgLevel = (String) requestHashMap.get("orgLevel");
			
			dpHashMap.put("unitNameList",serviceProvider.getsetOrganisationService().findByLoOrgBizVerticalAndLoOrgDepartmentAndLoOrgLevel(loOrgBizVertical, loOrgDepartment, loOrgLevel));
			responseHashMap.put("success", true);
	        responseHashMap.put("responseData", dpHashMap);
			} catch (Exception ex) {
				if (!dataHashMap.containsKey("errorData")) {
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),dpMethod, ex.getCause().getMessage());
					dataHashMap.put("errorData",new CustomErr(ErrConstants.invalidDataErrCode, ErrConstants.invalidDataErrMessage));
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
				}
			}
		}
		
		else{
			dpHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
		responseHashMap.put("success", false);
        responseHashMap.put("responseData", dpHashMap);
		}
		return responseHashMap;
	}

}
