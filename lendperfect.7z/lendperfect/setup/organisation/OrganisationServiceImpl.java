package com.sai.lendperfect.setup.organisation;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.Organisation;

import com.sai.lendperfect.setuprepo.OrganisationRepo;

@Service("OrganisationService")
@Transactional
public class OrganisationServiceImpl  implements OrganisationService{
	
	@Autowired
	private OrganisationRepo organisationRepo;

	public List<Organisation> findAll() {
		return organisationRepo.findAll();
	}

	public Organisation saveOrganisation(Organisation organisation) {
		return organisationRepo.save(organisation);
	}

	public void deleteOrganisation(Organisation organisation) {
		organisationRepo.delete(organisation);
	}

	@Override
	public Organisation findByorgId(long orgId) {
		// TODO Auto-generated method stub
		return organisationRepo.findByorgId(orgId);
	}

	@Override
	public Organisation findByorgCode(String orgCode) {
		// TODO Auto-generated method stub
		return organisationRepo.findByorgCode(orgCode);
	}

}
