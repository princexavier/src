package com.sai.lendperfect.setup.organisation;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.repository.query.Param;

import com.sai.lendperfect.setupmodel.LpstpOrganisation;
import com.sai.lendperfect.setupmodel.Organisation;

public interface OrganisationService {
	List<Organisation> findAll();
	Organisation saveOrganisation(Organisation organisation);
	void deleteOrganisation(Organisation organisation);
	Organisation findByorgId(long orgId);
	Organisation findByorgCode(String orgCode);
}

