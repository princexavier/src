package com.sai.lendperfect.setup.comboconfiguration;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.model.LpcustApplicantEduCourseDetail;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdComboConfig;
import com.sai.lendperfect.setupmodel.LpstpProductDet;


public class LpstpComboMasterDataProvider {
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();
		List<LpstpPrdComboConfig> lpstpPrdComboConfigList = new ArrayList<LpstpPrdComboConfig>();
		LpstpPrdComboConfig lpstpPrdComboConfig = new LpstpPrdComboConfig();
		LpstpProductDet lpstpProductDet = new LpstpProductDet();
		LpstpProductDet lpstpProductDet1 = new LpstpProductDet();
		String userid = (String) session.getAttribute("userid");
		Timestamp sysDate = (Timestamp) Helper.getSystemDate();
		ObjectMapper mapper = new ObjectMapper();
		if(dpMethod.equals("saveComboConfig"))
		{
			Map<String,Object> requestMap = (Map<String,Object>)allRequestParams.get("requestData");
			lpstpPrdComboConfig.setLpccComboName(requestMap.get("lpdPrdDesc").toString());
			lpstpProductDet.setLpdProdNewId(Long.parseLong(requestMap.get("comboProductId72").toString()));
			lpstpProductDet1.setLpdProdNewId(Long.parseLong(requestMap.get("comboProductId2").toString()));
			lpstpPrdComboConfig.setLpstpProductDet1(lpstpProductDet);
			lpstpPrdComboConfig.setLpstpProductDet2(lpstpProductDet1);
			lpstpPrdComboConfig.setLpccCreatedBy(Helper.correctNull(userid));
			lpstpPrdComboConfig.setLpccCreatedOn(sysDate); 
			lpstpPrdComboConfig.setLpccModifiedBy(Helper.correctNull(userid));
			lpstpPrdComboConfig.setLpccModifiedOn(sysDate);
			Long lpccId1 =  ((Integer) requestMap.get("lpccId")).longValue();
			if(lpccId1 != 0){
				lpstpPrdComboConfig.setLpccId(lpccId1);
			}else{
				lpstpPrdComboConfig.setLpccId(0);
			}
			lpstpPrdComboConfig = serviceProvider.getLpstpComboMasterService().saveCourseDetail(lpstpPrdComboConfig);
			dataHashMap.put("lpstpPrdComboConfigList",lpstpPrdComboConfigList);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		else if(dpMethod.equals("getComboMasterList"))
		{
			Map<String,Object> requestMap = (Map<String,Object>)allRequestParams.get("requestData");
			lpstpPrdComboConfigList = serviceProvider.getLpstpComboMasterService().findAll();
			dataHashMap.put("lpstpPrdComboConfigList",lpstpPrdComboConfigList);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}
}
