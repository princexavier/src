package com.sai.lendperfect.setup.comboconfiguration;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sai.lendperfect.setupmodel.LpstpPrdComboConfig;
import com.sai.lendperfect.setuprepo.LpstpComboMasterRepo;

@Service("LpstpComboMasterService")
@Transactional
public class LpstpComboMasterServiceImpl implements LpstpComboMasterService{

	@Autowired
	LpstpComboMasterRepo lpstpComboMasterRepo;
	
	@Override
	public List<LpstpPrdComboConfig> findAll() {
		return lpstpComboMasterRepo.findAll();
	}

	@Override
	public LpstpPrdComboConfig saveCourseDetail(LpstpPrdComboConfig lpstpPrdComboConfig) {
		return lpstpComboMasterRepo.save(lpstpPrdComboConfig);
	}

}
