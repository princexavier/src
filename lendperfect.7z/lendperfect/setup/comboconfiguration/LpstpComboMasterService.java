package com.sai.lendperfect.setup.comboconfiguration;

import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPrdComboConfig;

public interface LpstpComboMasterService {

	List<LpstpPrdComboConfig> findAll();

	LpstpPrdComboConfig saveCourseDetail(LpstpPrdComboConfig lpstpPrdComboConfig);

}
