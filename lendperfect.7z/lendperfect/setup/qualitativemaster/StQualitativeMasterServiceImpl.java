package com.sai.lendperfect.setup.qualitativemaster;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.StQualitativeMaster;
import com.sai.lendperfect.setuprepo.StQualitativeMasterRepo;

@Service("stQualitativeMasterService")
@Transactional
public class StQualitativeMasterServiceImpl implements StQualitativeMasterService{
	@Autowired
	StQualitativeMasterRepo stQualitativeMasterRepo;


	public StQualitativeMaster saveQualitativeMaster(StQualitativeMaster stQualitativeMaster) {
		
		return stQualitativeMasterRepo.save(stQualitativeMaster) ;
	}


	public List<StQualitativeMaster> findAll() {
		
		return stQualitativeMasterRepo.findAll();
	}



	public StQualitativeMaster findBysqmRowId(long id) {
	
		return stQualitativeMasterRepo.findBysqmRowId(id);
	}


	public List<StQualitativeMaster> findBysqmActive(String flag) {
	
		return stQualitativeMasterRepo.findBysqmActive(flag);
	}


	


	public List<StQualitativeMaster> findBySqmBizVerticalAndSqmCommentForAndSqmActive(String sqmBizVertical,
			String sqmCommentFor, String sqmActive) {
		return stQualitativeMasterRepo.findBySqmBizVerticalAndSqmCommentForAndSqmActive(sqmBizVertical, sqmCommentFor, sqmActive);
	}


	public List<StQualitativeMaster> findBySqmBizVerticalAndSqmCommentFor(String sqmBizVertical,
			String sqmCommentFor) {
		return stQualitativeMasterRepo.findBySqmBizVerticalAndSqmCommentFor(sqmBizVertical, sqmCommentFor);
	}

	
}
