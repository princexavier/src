package com.sai.lendperfect.setup.qualitativemaster;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.StQualitativeMaster;

public interface StQualitativeMasterService {

	StQualitativeMaster saveQualitativeMaster(StQualitativeMaster stQualitativeMaster);

    List<StQualitativeMaster> findAll();

	StQualitativeMaster findBysqmRowId(long id);

	List <StQualitativeMaster> findBysqmActive(String flag);

	List <StQualitativeMaster> findBySqmBizVerticalAndSqmCommentFor(String sqmBizVertical, String sqmCommentFor);
	
	List<StQualitativeMaster> findBySqmBizVerticalAndSqmCommentForAndSqmActive(String sqmBizVertical, String sqmCommentFor,String sqmActive);

	

}
