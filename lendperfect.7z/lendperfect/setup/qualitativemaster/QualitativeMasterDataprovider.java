package com.sai.lendperfect.setup.qualitativemaster;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.mastermodel.LpmasPageMaster;
import com.sai.lendperfect.setupmodel.StQualitativeMaster;

public class QualitativeMasterDataprovider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData,
			ServiceProvider serviceProvider, Logging logging) {
		
		logging.setLoggerClass(QualitativeMasterDataprovider.class);		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		try{
		 if(dpMethod.equals("saveQualitative"))
		{			
		StQualitativeMaster stQualitativeMaster=new StQualitativeMaster();
		stQualitativeMaster=new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<StQualitativeMaster>() { });
		stQualitativeMaster.setSqmModifiedBy(session.getAttribute("userid").toString());
		stQualitativeMaster.setSqmModifiedOn(Helper.getSystemDate());
		if(stQualitativeMaster.getSqmRowId()==0){
		stQualitativeMaster.setSqmCreatedOn(Helper.getSystemDate());
		stQualitativeMaster.setSqmCreatedBy(session.getAttribute("userid").toString());
		}
		serviceProvider.getStQualitativeMasterService().saveQualitativeMaster(stQualitativeMaster);
		String flag="Y";
		dataHashMap.put("qualitativeData",serviceProvider.getStQualitativeMasterService().findBySqmBizVerticalAndSqmCommentForAndSqmActive(stQualitativeMaster.getSqmBizVertical(),stQualitativeMaster.getSqmCommentFor(),flag));				
		responseHashMap.put("success", true);
		responseHashMap.put("responseData", dataHashMap);
		}
		 else	 if(dpMethod.equals("getQualitative"))
			{
			 StQualitativeMaster stQualitativeMaster=new StQualitativeMaster();
			 stQualitativeMaster=new ObjectMapper().convertValue(allRequestParams.get("requestData"), StQualitativeMaster.class);
			 String flag="Y";
				dataHashMap.put("qualitativeData",serviceProvider.getStQualitativeMasterService().findBySqmBizVerticalAndSqmCommentForAndSqmActive(stQualitativeMaster.getSqmBizVertical(),stQualitativeMaster.getSqmCommentFor(),flag));
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
		 else	 if(dpMethod.equals("getMasterdata"))
			{
				dataHashMap.put("bizvertical",serviceProvider.getLpmasBizVerticalService().findAll());
				LpmasPageMaster lpmasPageMaster=serviceProvider.getLpmasPageMasterService().findByLpmPageId(Long.parseLong("414"));
				String pageAccess=Helper.pageAccessRights(lpmasPageMaster.getLpmPageType(),new BigDecimal((lpmasPageMaster.getLpmPageId())), new BigDecimal(0),serviceProvider,session);
				responseHashMap.put("pageAccess",pageAccess); 
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
		 else	 if(dpMethod.equals("getQualitativeData"))
			{
			 StQualitativeMaster stQualitativeMaster=new StQualitativeMaster();
			 stQualitativeMaster.setSqmRowId(Long.parseLong(String.valueOf(allRequestParams.get("requestData"))));
				dataHashMap.put("qualitativeData",serviceProvider.getStQualitativeMasterService().findBysqmRowId(stQualitativeMaster.getSqmRowId()));
				responseHashMap.put("success", true);
				responseHashMap.put("responseData", dataHashMap);
			}
		 else	 if(dpMethod.equals("deleteQualitativeData"))
			{
			 StQualitativeMaster stQualitativeMaster=new StQualitativeMaster();
			 stQualitativeMaster.setSqmRowId(Long.parseLong(String.valueOf(allRequestParams.get("requestData"))));
				stQualitativeMaster=serviceProvider.getStQualitativeMasterService().findBysqmRowId(stQualitativeMaster.getSqmRowId());
				stQualitativeMaster.setSqmActive("N");
				serviceProvider.getStQualitativeMasterService().saveQualitativeMaster(stQualitativeMaster);
				String flag="Y";
				dataHashMap.put("qualitativeData",serviceProvider.getStQualitativeMasterService().findBySqmBizVerticalAndSqmCommentForAndSqmActive(stQualitativeMaster.getSqmBizVertical(),stQualitativeMaster.getSqmCommentFor(),flag));
				responseHashMap.put("responseData", dataHashMap);
				responseHashMap.put("success", true);
				
			}
		 
		 
		else
		{
			
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		}
			catch (Exception ex) {
				dataHashMap.put("errorData", ex.getLocalizedMessage());
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", dataHashMap);
			
		}
		return responseHashMap;
	}

}
