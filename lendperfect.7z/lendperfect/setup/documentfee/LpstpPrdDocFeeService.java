package com.sai.lendperfect.setup.documentfee;
import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPrdDocFee;;

public interface LpstpPrdDocFeeService {

	List<LpstpPrdDocFee> savePrdDocFee(List<LpstpPrdDocFee> lpstpPrdDocFee);

	List<LpstpPrdDocFee> findAll();

	void deletePrdDocfee(List<LpstpPrdDocFee> lpstpPrdDocFee1);

	List<LpstpPrdDocFee> findByLdfProdIdOrderByLdfRowId(Long ldfProdId);

	List<LpstpPrdDocFee> getIntRateByPrdId(Long prdId);

	
}
