package com.sai.lendperfect.setup.documentfee;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.google.gson.Gson;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdDocFee;
import com.sai.lendperfect.setupmodel.LpstpPrdMargin;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public class LpstpPrdDocFeeDataProvider {
	
	@SuppressWarnings("rawtypes")
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		String userid = (String) session.getAttribute("userid");
		
	   if(dpMethod.equals("getPrdDocFeeDetails"))
		{
		   BigDecimal lpdProdId=new BigDecimal(allRequestParams.get("requestData").toString());
		   //LpstpProductDet lpstpProductDet= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpProductDet>() { });
		   LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(lpdProdId.longValue()));
		   
		   if(lpstpProductDetfromDB!=null)
		   {
			   List<LpstpPrdDocFee> lpstpPrdDocFee =serviceProvider.getLpstpPrdDocFeeService().findByLdfProdIdOrderByLdfRowId((lpdProdId.longValue()));
			   dataHashMap.put("lpstpPrdDocFee",lpstpPrdDocFee);
			   responseHashMap.put("success", true);
			   responseHashMap.put("responseData", dataHashMap);
		   }else
		   {
			   	dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		   }
		  
		}
	   
	    else if(dpMethod.equals("savePrdDocFee"))
	    {
	    	
	    	
	    	List DocumnetFesslist = (List) allRequestParams.get("requestData");
	    	for(int i=0;i<DocumnetFesslist.size();i++)
	    	{
		    	    List<LpstpPrdDocFee> lpstpPrdDocFee= new ObjectMapper().convertValue(DocumnetFesslist.get(i), new TypeReference<List<LpstpPrdDocFee>>() { });
		    	    List<LpstpPrdDocFee> lpstpPrdDocFeedel= serviceProvider.getLpstpPrdDocFeeService().findByLdfProdIdOrderByLdfRowId(lpstpPrdDocFee.get(0).getldfProdId());   
	    		    serviceProvider.getLpstpPrdDocFeeService().deletePrdDocfee(lpstpPrdDocFeedel);
	    		    
		    		lpstpPrdDocFee.forEach(lpstpPrdDocFeelist1->{
	    			lpstpPrdDocFeelist1.setldfCreatedOn(Helper.getSystemDate());
	    			lpstpPrdDocFeelist1.setldfCreatedBy(userid);
	    			lpstpPrdDocFeelist1.setldfModifedBy(userid);
	    			lpstpPrdDocFeelist1.setldfComplete("N");
			    	lpstpPrdDocFeelist1.setldfModifiedOn(Helper.getSystemDate());
		    	});
		    	
		    	List<LpstpPrdDocFee> lpstpPrdDocFeeSaved = serviceProvider.getLpstpPrdDocFeeService().savePrdDocFee(lpstpPrdDocFee);
		    	Long l =(long) 0;
		    	Long prdId = (long) 0;
		    	for (LpstpPrdDocFee lpstpPrdIntDoc :lpstpPrdDocFeeSaved)
		    	{
		    		prdId = new Long(lpstpPrdIntDoc.getldfProdId());
			    	  //prdId = BigDecimal.valueOf(l);
		    	}
		    	 
		    
		    	List<LpstpPrdDocFee> lpstpPrdDocFeesave  = serviceProvider.getLpstpPrdDocFeeService().getIntRateByPrdId(prdId);
		    	
				LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prdId);
		    	if(lpstpPrdDocFeesave !=null)
		    	{
		    		lpstpProductDetfromDB.setLpdComplete("N");
		    		lpstpProductDetfromDB=serviceProvider.getLpstpProductDetService().updateProductDetails(lpstpProductDetfromDB);
		    	}
		    	
		    	dataHashMap.put("lpstpProductDet",lpstpProductDetfromDB);
				dataHashMap.put("lpstpPrdDocFeesave",lpstpPrdDocFeeSaved);
	    	}
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	    
	    else if(dpMethod.equals("deletePrdDocfee"))
	    {
			List<LpstpPrdDocFee> lpstpPrdDocFeesave= new ArrayList();
			lpstpPrdDocFeesave.add(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpPrdDocFee>() { }));
		
			lpstpPrdDocFeesave.forEach(lpstpPrdDocFeedelete->{
				lpstpPrdDocFeedelete.setldfCreatedOn(Helper.getSystemDate());
	    		lpstpPrdDocFeedelete.setldfCreatedBy(userid);
	    		lpstpPrdDocFeedelete.setldfModifedBy(userid);
	    		lpstpPrdDocFeedelete.setldfComplete("N");
		    	lpstpPrdDocFeedelete.setldfModifiedOn(Helper.getSystemDate());
	    	});
			
	    	serviceProvider.getLpstpPrdDocFeeService().deletePrdDocfee(lpstpPrdDocFeesave);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	   
	   
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}

}
