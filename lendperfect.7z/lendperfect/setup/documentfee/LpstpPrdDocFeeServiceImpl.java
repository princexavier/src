package com.sai.lendperfect.setup.documentfee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setuprepo.LpstpPrdDocFeeRepo;
import com.sai.lendperfect.setup.documentfee.LpstpPrdDocFeeService;
import com.sai.lendperfect.setupmodel.LpstpPrdDocFee;




@Service("lpstpPrdDocFeeService")
@Transactional
public class LpstpPrdDocFeeServiceImpl implements LpstpPrdDocFeeService{

	@Autowired
	LpstpPrdDocFeeRepo lpstpPrdDocFeeRepo;

	@Override
	public List<LpstpPrdDocFee> savePrdDocFee(List<LpstpPrdDocFee> lpstpPrdDocFee) {
		 return lpstpPrdDocFeeRepo.save(lpstpPrdDocFee);
	}

	@Override
	public List<LpstpPrdDocFee> findAll() {
		return lpstpPrdDocFeeRepo.findAll();
	}

	@Override
	public void deletePrdDocfee(List<LpstpPrdDocFee> lpstpPrdDocFee1) {
		lpstpPrdDocFeeRepo.delete(lpstpPrdDocFee1);
	}

	@Override
	public List<LpstpPrdDocFee> findByLdfProdIdOrderByLdfRowId(Long ldfProdId) {
		return lpstpPrdDocFeeRepo.findByLdfProdIdOrderByLdfRowId(ldfProdId);
	}

	@Override
	public 	List<LpstpPrdDocFee> getIntRateByPrdId(Long  prdId) {
		return lpstpPrdDocFeeRepo.findByLdfProdIdOrderByLdfRowId(prdId);
	}


	
}
