package com.sai.lendperfect.setup.assessmentengine;

import org.springframework.stereotype.Repository;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpAssessment;
import com.sai.lendperfect.setuprepo.LpstpAssessmentRepo;

@Service("LpstpAssessmentService")
@Transactional
public class LpstpAssessmentServiceImpl  implements LpstpAssessmentService {

	@Autowired
	LpstpAssessmentRepo lpstpAssessmentRepo;
	
	@Override
	public List<LpstpAssessment> saveLpstpAssessmentlist(List<LpstpAssessment> saveLpstpAssessmentlist) {
		// TODO Auto-generated method stub
		return lpstpAssessmentRepo.save(saveLpstpAssessmentlist);
	}

	@Override
	public void deleteAllByLaAssmntId(BigDecimal laAssmntId) {
		// TODO Auto-generated method stub
		lpstpAssessmentRepo.deleteAllByLaAssmntId(laAssmntId);
		
	}

	@Override
	public List<LpstpAssessment> findAllByLaAssmntId(BigDecimal laAssmntId) {
		// TODO Auto-generated method stub
		return lpstpAssessmentRepo.findAllByLaAssmntIdOrderByLaRowId(laAssmntId);
	}

	@Override
	public void deleteAllByLaRowId(BigDecimal laRowId) {
		// TODO Auto-generated method stub
		lpstpAssessmentRepo.deleteAllByLaRowId(laRowId);
		
	}

	@Override
	public List<Object[]> findAllDistinct() {
		// TODO Auto-generated method stub
		return lpstpAssessmentRepo.findAllDistinct();
	}

}
