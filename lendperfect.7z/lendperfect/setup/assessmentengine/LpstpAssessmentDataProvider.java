package com.sai.lendperfect.setup.assessmentengine;
import static org.junit.Assert.assertNotNull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.DecimalMax;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.setupmodel.LpstpAssessment;
import com.sai.lendperfect.setupmodel.LpstpFinMaster;

public class LpstpAssessmentDataProvider {
	
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		logging.setLoggerClass(LpstpAssessment.class);	
		Map <String,Object> requestHashMap=	(Map<String, Object>) allRequestParams.get("requestData");
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map <String,Object> modelMap=new HashMap<String,Object>();	
		
		 List<LpstpAssessment> lpstpAssessment	=	new ArrayList<LpstpAssessment>();
		 LpstpAssessment LpstpAssessmentobj	=	new LpstpAssessment();
		 Map <String,Object> AssessmentMap=new HashMap<String,Object>();	
		 ArrayList<Map<String, Object>> AssessmentMapnew = new ArrayList<Map <String, Object>>();
		 List<LpstpFinMaster> lpstpFinMaster	=	new ArrayList<LpstpFinMaster>();
		 LpstpFinMaster lpstpFinMasterobj	=	new LpstpFinMaster();
		 try
			{
			 if(dpMethod.equals("getAssessmentconfigList"))
				{
				try {
					   
					    String finPage="AS";
					    lpstpFinMaster=serviceProvider.getSetFinMasterService().findAllByFinPageOrderByfinSno(finPage);

					    for (int i=0;i<lpstpFinMaster.size();i++)
						{
							
					    	lpstpFinMasterobj=lpstpFinMaster.get(i);
					    	AssessmentMap=new HashMap();
					    	AssessmentMap.put("laLineitemId", lpstpFinMasterobj.getFinRowid());
					    	AssessmentMap.put("findec", lpstpFinMasterobj.getFinRowdesc());
					    	AssessmentMapnew.add(AssessmentMap);
							
							}
					    dataHashMap.put("finassessmentlist",AssessmentMapnew);
					    responseHashMap.put("success", true);
						responseHashMap.put("responseData", dataHashMap);	
							}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
				}
			 else if(dpMethod.equals("saveAssessment")){	
					try {
								BigDecimal laAssmntId=new BigDecimal((String)requestHashMap.get("laAssmntId").toString());
								String laAssmntName=(String)requestHashMap.get("laAssmntName");
								serviceProvider.getLpstpAssessmentService().deleteAllByLaAssmntId(laAssmntId);
								String tablename="LPSTP_ASSESSMENT";
								String seqid="LA_ASSMNT_ID";
								laAssmntId=serviceProvider.getSequenceNoService().findoverallMax(tablename, seqid);
								List<Map<String,Object>> AssessmentList=(List<Map<String, Object>>) requestHashMap.get("optionalarry");
								Iterator<Map<String,Object>> AssessmentListtItr=AssessmentList.iterator();
								while(AssessmentListtItr.hasNext())
								{
									Map<String,Object> modelassessment=AssessmentListtItr.next();
									AssessmentMap=new HashMap();
									AssessmentMap.put("laAssmntId",laAssmntId);
									AssessmentMap.put("laAssmntName",laAssmntName);
									AssessmentMap.put("laLineitemId",modelassessment.get("laLineitemId"));
									AssessmentMap.put("laCreatedBy","mrd");
									AssessmentMap.put("laModifiedBy", "mrd");
									AssessmentMap.put("laCreatedOn", new Date());
									AssessmentMap.put("laModifiedOn", new Date());
									AssessmentMapnew.add(AssessmentMap);
									
								}
								
								List<LpstpAssessment> LpstpAssessmentList=new ObjectMapper()
										.convertValue(AssessmentMapnew,new TypeReference<List<LpstpAssessment>>() {});
								serviceProvider.getLpstpAssessmentService().saveLpstpAssessmentlist(LpstpAssessmentList);
								responseHashMap.put("success", true);
								responseHashMap.put("responseData", dataHashMap);	
					
					}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
			 else if(dpMethod.equals("getCheckList")){	
					try{
						 List<LpstpAssessment> lpstpAssessmentlist	=	new ArrayList<LpstpAssessment>();
						 Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
						 BigDecimal laAssmntId=new BigDecimal((String)requestHashMapnew.get("laAssmntId").toString());
						 lpstpAssessmentlist=serviceProvider.getLpstpAssessmentService().findAllByLaAssmntId(laAssmntId);
						 LpstpAssessment lpstpAssessmentobj	=	new LpstpAssessment();
						 Map <String,Object> assessmentlistMap=new HashMap<String,Object>();	
						 ArrayList<Map<String, Object>> assessmentlistMapnew = new ArrayList<Map <String, Object>>();
						 for (int i=0;i<lpstpAssessmentlist.size();i++)
							{
								
							 lpstpAssessmentobj=lpstpAssessmentlist.get(i);
							 assessmentlistMap=new HashMap();
							 assessmentlistMap.put("laAssmntId", lpstpAssessmentobj.getLaAssmntId());
							 assessmentlistMap.put("laLineitemId", lpstpAssessmentobj.getLaLineitemId());

								
							 assessmentlistMapnew.add(assessmentlistMap);
								}
						 
						 dataHashMap.put("checklist",assessmentlistMapnew);
						responseHashMap.put("success", true);
						responseHashMap.put("responseData", dataHashMap);					
					
					}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
					}
			 else if(dpMethod.equals("getAssessmentList"))
				{
				try {
					   
					     List<Object[]> lpstpFinMasterlist=serviceProvider.getLpstpAssessmentService().findAllDistinct();
					     
					     for(Object[] object : lpstpFinMasterlist)
					     {
							
					    
					    	AssessmentMap=new HashMap<String,Object>();
					    	AssessmentMap.put("laAssmntId",object[1]);
					    	AssessmentMap.put("laAssmntName", object[0]);
					    	AssessmentMapnew.add(AssessmentMap);
					    	
							
							}
					    dataHashMap.put("listAssessment",AssessmentMapnew);
					    responseHashMap.put("success", true);
						responseHashMap.put("responseData", dataHashMap);	
							}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
				}
			 else if(dpMethod.equals("getAssessmentmaster"))
				{
				 try {
					 List<LpstpAssessment> lpstpAssessmentlist	=	new ArrayList<LpstpAssessment>();
					 Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					 BigDecimal laAssmntId=new BigDecimal((String)requestHashMapnew.get("laAssmntId").toString());
					 lpstpAssessmentlist=serviceProvider.getLpstpAssessmentService().findAllByLaAssmntId(laAssmntId);
					 LpstpAssessment lpstpAssessmentobj	=	new LpstpAssessment();
					 Map <String,Object> assessmentlistMap=new HashMap<String,Object>();	
					 ArrayList<Map<String, Object>> assessmentlistMapnew = new ArrayList<Map <String, Object>>();
					 for (int i=0;i<lpstpAssessmentlist.size();i++)
						{
							
						 lpstpAssessmentobj=lpstpAssessmentlist.get(i);
						 Long laLineitemId=new Long(lpstpAssessmentobj.getLaLineitemId().toString());
						 BigDecimal laRowId=new BigDecimal(lpstpAssessmentobj.getLaRowId().toString());
						 lpstpFinMasterobj=serviceProvider.getSetFinMasterService().findById(laLineitemId);
						 assessmentlistMap=new HashMap();
						 assessmentlistMap.put("laLineitemId", lpstpFinMasterobj.getFinRowid());
						 assessmentlistMap.put("lwfWfType", lpstpFinMasterobj.getFinRowtype());
						 assessmentlistMap.put("laRowId",laRowId);
						 assessmentlistMap.put("ladesc",lpstpFinMasterobj.getFinRowdesc());
						 AssessmentMapnew.add(assessmentlistMap);
						 
						 
						}
					 
					 dataHashMap.put("Listfinmaster",AssessmentMapnew);
					 responseHashMap.put("success", true);
					 responseHashMap.put("responseData", dataHashMap);	
					 
				}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
				}
			 else if(dpMethod.equals("deleteAssessment"))
				{
				try {
					Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					BigDecimal laRowId=new BigDecimal((String)requestHashMapnew.get("delete_Rowid").toString());
					serviceProvider.getLpstpAssessmentService().deleteAllByLaRowId(laRowId);
					 responseHashMap.put("success", true);
					 responseHashMap.put("responseData", dataHashMap);	
					 
				}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
				}
			 else if(dpMethod.equals("deleteAllAssessment"))
				{
				try {
					Map <String,Object> requestHashMapnew=(Map<String, Object>) allRequestParams.get("requestData");
					BigDecimal laAssmntId=new BigDecimal((String)requestHashMap.get("laAssmntId").toString());
					serviceProvider.getLpstpAssessmentService().deleteAllByLaAssmntId(laAssmntId);
					 responseHashMap.put("success", true);
					 responseHashMap.put("responseData", dataHashMap);	
					 
				}catch (Exception ex) {
							if (!dataHashMap.containsKey("errorData")) {
								logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
								dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
								responseHashMap.put("success", false);
								responseHashMap.put("responseData", dataHashMap);
							}
						}
				}
				
			}
	
	
	catch (Exception ex) {
		if (!dataHashMap.containsKey("errorData")) {
			logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(),	dpMethod, ex.getCause().getMessage());
			dataHashMap.put("errorData",new CustomErr(ex.getCause().getMessage()));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
			}
		}
	return responseHashMap;
	}

}
