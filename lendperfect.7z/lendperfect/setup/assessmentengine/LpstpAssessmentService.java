package com.sai.lendperfect.setup.assessmentengine;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpAssessment;

public interface LpstpAssessmentService {
	
	List<LpstpAssessment> saveLpstpAssessmentlist(List<LpstpAssessment> saveLpstpAssessmentlist);
	void deleteAllByLaAssmntId(BigDecimal laAssmntId);
	List<LpstpAssessment> findAllByLaAssmntId(BigDecimal laAssmntId);
	void deleteAllByLaRowId(BigDecimal laRowId);
	List<Object[]> findAllDistinct();

}
