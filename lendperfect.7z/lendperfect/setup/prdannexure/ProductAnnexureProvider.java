package com.sai.lendperfect.setup.prdannexure;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdAnnexure;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public class ProductAnnexureProvider {

	@SuppressWarnings("unchecked")
	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData, ServiceProvider serviceProvider, Logging logging) {

		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		Map<String, Object> dataHashMap = new HashMap<String, Object>();

		try {
			if (dpMethod.equals("getCheckListsByProd")) {
				try {
					LpstpProductDet lpstpProductDet = serviceProvider.getLpstpProductDetService().findByLpdProdNewId(new Long(allRequestParams.get("requestData").toString()));
					List<LpstpPrdAnnexure> lpstpAnnexureList = serviceProvider.getLpstpPrdAnnexureService().findByLpstpProductDet(lpstpProductDet);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", lpstpAnnexureList);
				} catch (Exception e) {
					e.printStackTrace();
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", e.getMessage());
				}
			} else if (dpMethod.equals("deleteCheckListById")) {
				try {
					Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");
					LpstpPrdAnnexure lpstpPrdAnnexure = serviceProvider.getLpstpPrdAnnexureService().findById(new Long(requestMap.get("checkListId").toString()));
					LpstpProductDet lpstpProductDet = serviceProvider.getLpstpProductDetService().findByLpdProdNewId(new Long(requestMap.get("productId").toString()));
					serviceProvider.getLpstpPrdAnnexureService().deleteAnnexure(lpstpPrdAnnexure);
					// serviceProvider.getLpcorpCirAnnexService().deleteByLpstpProductDetAndLcaLamRowId(lpstpProductDet,
					// lpstpPrdAnnexure.getLpaLamRowId());
					// serviceProvider.getLpcorpCirAnnexService().deleteByLpstpProductDetAndLcaParentId(lpstpProductDet,
					// lpstpPrdAnnexure.getLpaLamRowId());
					responseHashMap.put("success", true);
				} catch (Exception e) {
					e.printStackTrace();
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", e.getMessage());
				}
			} else if (dpMethod.equals("getMasterCheckLists")) {
				try {
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", serviceProvider.getLpstpAnnexMasterService().findByLamAnnexTypeAndLamParentIdOrderByLamRowId("CIR", new BigDecimal("0")));
				} catch (Exception e) {
					e.printStackTrace();
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", e.getMessage());
				}
			} else if (dpMethod.equals("saveProductCheckList")) {
				try {
					Map<String, Object> requestMap = (Map<String, Object>) allRequestParams.get("requestData");
					Long prdId = new Long(requestMap.get("productId").toString());
					LpstpProductDet lpstpProductDet = serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prdId);

					List<Map<String, Object>> checkListCollection = (List<Map<String, Object>>) requestMap.get("checkLists");
					ArrayList<LpstpPrdAnnexure> checkLists = new ArrayList<>();
					for (Map<String, Object> checkListMap : checkListCollection) {
						LpstpPrdAnnexure lpstpPrdAnnexure = new ObjectMapper().convertValue(checkListMap, LpstpPrdAnnexure.class);
						if (lpstpPrdAnnexure.getLpaRowId() == 0) {
							lpstpPrdAnnexure.setLpaCreatedBy(session.getAttribute("userid").toString());
							lpstpPrdAnnexure.setLpaCreatedOn(new Date());
							lpstpPrdAnnexure.setLpaModifiedBy(session.getAttribute("userid").toString());
							lpstpPrdAnnexure.setLpaModifiedOn(lpstpPrdAnnexure.getLpaCreatedOn());
						} else {
							lpstpPrdAnnexure.setLpaModifiedBy(session.getAttribute("userid").toString());
							lpstpPrdAnnexure.setLpaModifiedOn(new Date());
						}
						lpstpPrdAnnexure.setLpstpProductDet(lpstpProductDet);
						checkLists.add(lpstpPrdAnnexure);
					}
					List<LpstpPrdAnnexure> lpstpAnnexureList = serviceProvider.getLpstpPrdAnnexureService().saveAnnexure(checkLists);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", lpstpAnnexureList);
				} catch (Exception e) {
					e.printStackTrace();
					logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, e.getMessage());
					responseHashMap.put("success", false);
					responseHashMap.put("responseData", e.getMessage());
				}
			} else {
				dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode, ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			dataHashMap.put("errorData", ex.getLocalizedMessage());
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);

		}
		return responseHashMap;
	}
}
