package com.sai.lendperfect.setup.prdannexure;

import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPrdAnnexure;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public interface LpstpPrdAnnexureService {
	List<LpstpPrdAnnexure> findByLpstpProductDet(LpstpProductDet lpstpProductDet);

	List<LpstpPrdAnnexure> saveAnnexure(List<LpstpPrdAnnexure> lpstpPrdAnnexureList);

	void deleteAnnexure(LpstpPrdAnnexure lpstpPrdAnnexure);

	LpstpPrdAnnexure findById(Long id);
}
