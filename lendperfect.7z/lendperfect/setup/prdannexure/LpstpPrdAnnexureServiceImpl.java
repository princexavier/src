package com.sai.lendperfect.setup.prdannexure;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setupmodel.LpstpPrdAnnexure;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setuprepo.LpstpPrdAnnexureRepo;

@Service("lpstpPrdAnnexureService")
@Transactional
public class LpstpPrdAnnexureServiceImpl implements LpstpPrdAnnexureService {

	@Autowired
	LpstpPrdAnnexureRepo lpstpPrdAnnexureRepo;

	@Override
	public List<LpstpPrdAnnexure> findByLpstpProductDet(LpstpProductDet lpstpProductDet) {
		return lpstpPrdAnnexureRepo.findByLpstpProductDet(lpstpProductDet);
	}

	@Override
	public void deleteAnnexure(LpstpPrdAnnexure lpstpPrdAnnexure) {
		lpstpPrdAnnexureRepo.delete(lpstpPrdAnnexure);
	}

	@Override
	public List<LpstpPrdAnnexure> saveAnnexure(List<LpstpPrdAnnexure> lpstpPrdAnnexureList) {
		return lpstpPrdAnnexureRepo.save(lpstpPrdAnnexureList);
	}

	@Override
	public LpstpPrdAnnexure findById(Long id) {
		return lpstpPrdAnnexureRepo.findOne(id);
	}

}
