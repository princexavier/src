package com.sai.lendperfect.setup.PrdTermsCond;

import java.math.BigDecimal;
import java.util.List;
import com.sai.lendperfect.setupmodel.LpstpPrdTermsCond;

public interface LpstpPrdTermsCondService {
	
	List<LpstpPrdTermsCond> findAll();
	LpstpPrdTermsCond findById(BigDecimal lptcTermsId);
	List<LpstpPrdTermsCond> saveLpstpPrdTermsCondList(List<LpstpPrdTermsCond> lpstpPrdTermsCondList);
	List<LpstpPrdTermsCond> findAllByLptcProdId(BigDecimal lptcProdId);
	void deleteAllByLptcProdId(BigDecimal lptcProdId);
	void deleteAllByLptcProdIdAndLptcTermsId(BigDecimal lptcProdId,BigDecimal lptcTermsId);
	List<LpstpPrdTermsCond> findAllByLptcProdIdAndLptcTermsId(BigDecimal lptcProdId,BigDecimal lptcTermsId);
	List<LpstpPrdTermsCond> findAllByLptcProdIdAndLptcTermsFor(BigDecimal lptcProdId,String lptcTermsFor);
	LpstpPrdTermsCond saveData(LpstpPrdTermsCond lpstpPrdTermsCond);
}
