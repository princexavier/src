package com.sai.lendperfect.setup.PrdTermsCond;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdTermsCond;

public class LpstpPrdTermsCondDataProvider {

	public Map<String, ?> getData(String dpMethod, HttpSession session, Map<?, ?> allRequestParams, Object masterData, ServiceProvider serviceProvider, Logging logging) {
		logging.setLoggerClass(LpstpPrdTermsCondDataProvider.class);
		Map<String, Object> requestHashMap = (Map<String, Object>) allRequestParams.get("requestData");
		Map<String, Object> dataHashMap = new HashMap<String, Object>();
		Map<String, Object> responseHashMap = new HashMap<String, Object>();
		BigDecimal lptcProdId = new BigDecimal((String) requestHashMap.get("prdid").toString());
		String lptcTermsFor = (String) requestHashMap.get("lptcTermsFor");
		try {
			if (dpMethod.equals("getprdterms")) {
				try {
					dataHashMap.put("prdtermslist", responseHashMap.put("prdtermslist", serviceProvider.getLpstpPrdTermsCondService().findAllByLptcProdIdAndLptcTermsFor(lptcProdId, lptcTermsFor)));
					responseHashMap.put("lptcProdId", lptcProdId);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			} else if (dpMethod.equals("saveprdtermssearch")) {
				try {
					Map<String, Object> modelMap = new HashMap<String, Object>();
					List<Map<String, Object>> lpstpPrdTermsCondList = (List<Map<String, Object>>) requestHashMap.get("SearchAlllist");
					Iterator<Map<String, Object>> lpstpPrdTermsCondListItr = lpstpPrdTermsCondList.iterator();
					ArrayList<Map<String, Object>> lpstpPrdTermsCondListnew = new ArrayList<Map<String, Object>>();
					while (lpstpPrdTermsCondListItr.hasNext()) {
						Map<String, Object> terms = lpstpPrdTermsCondListItr.next();
						modelMap = new HashMap();
						modelMap.put("lptcTermsId", terms.get("CommonVal"));
						modelMap.put("lptcType", terms.get("Commontype"));
						modelMap.put("lptcTermsDesc", terms.get("CommonDesc"));
						modelMap.put("lptcDisbType", terms.get("CommonDisptype"));
						modelMap.put("lptcIntExt", terms.get("Commoninternal"));
						modelMap.put("lptcMandatory", terms.get("Commonmandatory"));
						modelMap.put("lptcCompleted", "S");
						modelMap.put("lptcCreatedBy", "mrd");
						modelMap.put("lptcModifiedBy", "mrd");
						modelMap.put("lptcCreatedOn", new Date());
						modelMap.put("lptcModifiedOn", new Date());
						modelMap.put("lptcProdId", lptcProdId);
						modelMap.put("lptcTermsFor", lptcTermsFor);

						lpstpPrdTermsCondListnew.add(modelMap);

					}

					List<LpstpPrdTermsCond> lpstpPrdTermsCond = new ObjectMapper().convertValue(lpstpPrdTermsCondListnew, new TypeReference<List<LpstpPrdTermsCond>>() {
					});
					serviceProvider.getLpstpPrdTermsCondService().saveLpstpPrdTermsCondList(lpstpPrdTermsCond);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);

				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}

			else if (dpMethod.equals("saveprdterms")) {
				try {

					List<LpstpPrdTermsCond> lpstpPrdTermsCondList = new ObjectMapper().convertValue(requestHashMap.get("optionsFieldArray"), new TypeReference<List<LpstpPrdTermsCond>>() {
					});

					Iterator<LpstpPrdTermsCond> lpstpPrdTermsCondListItr = lpstpPrdTermsCondList.iterator();
					while (lpstpPrdTermsCondListItr.hasNext()) {
						LpstpPrdTermsCond lpstpPrdTermsCond = lpstpPrdTermsCondListItr.next();
						lpstpPrdTermsCond.setLptcCreatedBy(session.getAttribute("userid").toString());
						lpstpPrdTermsCond.setLptcModifiedBy(session.getAttribute("userid").toString());
						lpstpPrdTermsCond.setLptcCreatedOn(new Date());
						lpstpPrdTermsCond.setLptcModifiedOn(new Date());
						lpstpPrdTermsCond.setLptcProdId(lptcProdId);

					}
					serviceProvider.getLpstpPrdTermsCondService().saveLpstpPrdTermsCondList(lpstpPrdTermsCondList);
					responseHashMap.put("success", true);
					responseHashMap.put("responseData", dataHashMap);

				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			// delete all
			else if (dpMethod.equals("deleteAllprdterms")) {
				try {
					serviceProvider.getLpstpPrdTermsCondService().deleteAllByLptcProdId(lptcProdId);
					responseHashMap.put("responseData", dataHashMap);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
			// delete single reference
			else if (dpMethod.equals("deleteprdterms")) {
				try {
					Map<String, Object> requestHashMapnew = (Map<String, Object>) allRequestParams.get("requestData");
					BigDecimal lptcTermsId = BigDecimal.valueOf(Long.valueOf((String) requestHashMapnew.get("TermId").toString()));
					serviceProvider.getLpstpPrdTermsCondService().deleteAllByLptcProdIdAndLptcTermsId(lptcProdId, lptcTermsId);
					;
					responseHashMap.put("responseData", dataHashMap);
				} catch (Exception ex) {
					if (!dataHashMap.containsKey("errorData")) {
						logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
						dataHashMap.put("errorData", new CustomErr(ex.getCause().getMessage()));
						responseHashMap.put("success", false);
						responseHashMap.put("responseData", dataHashMap);
					}
				}
			}
		} catch (Exception ex) {
			if (!dataHashMap.containsKey("errorData")) {
				logging.error("Provider : {} , Method : {} , ErrorMessage : {}", this.getClass().getName(), dpMethod, ex.getCause().getMessage());
				dataHashMap.put("errorData", new CustomErr(ex.getCause().getMessage()));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
			}
		}
		return responseHashMap;
	}

}
