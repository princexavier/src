package com.sai.lendperfect.setup.PrdTermsCond;

import java.math.BigDecimal;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sai.lendperfect.setupmodel.LpstpPrdTermsCond;
import com.sai.lendperfect.setuprepo.LpstpPrdTermsCondRepo;

@Service("LpstpPrdTermsCondService")
@Transactional

public class LpstpPrdTermsCondServiceImpl  implements LpstpPrdTermsCondService{
	
	@Autowired
	LpstpPrdTermsCondRepo lpstpPrdTermsCondRepo;

	public List<LpstpPrdTermsCond> findAll() {
		// TODO Auto-generated method stub
		return lpstpPrdTermsCondRepo.findAll();
	}

	@Override
	public LpstpPrdTermsCond findById(BigDecimal lptcTermsId) {
		// TODO Auto-generated method stub
		return lpstpPrdTermsCondRepo.findOne(lptcTermsId);
	}

	@Override
	public List<LpstpPrdTermsCond> saveLpstpPrdTermsCondList(List<LpstpPrdTermsCond> lpstpPrdTermsCondList) {
		// TODO Auto-generated method stub
		return lpstpPrdTermsCondRepo.save(lpstpPrdTermsCondList);
	}

	@Override
	public List<LpstpPrdTermsCond> findAllByLptcProdId(BigDecimal lptcProdId) {
		// TODO Auto-generated method stub
		return lpstpPrdTermsCondRepo.findAllByLptcProdId(lptcProdId);
	}
	
	@Override
	public List<LpstpPrdTermsCond> findAllByLptcProdIdAndLptcTermsId(BigDecimal lptcProdId, BigDecimal lptcTermsId) {
		// TODO Auto-generated method stub
		return lpstpPrdTermsCondRepo.findAllByLptcProdIdAndLptcTermsId(lptcProdId, lptcTermsId);
	}

	@Override
	public void deleteAllByLptcProdId(BigDecimal lptcProdId) {
		// TODO Auto-generated method stub
		lpstpPrdTermsCondRepo.deleteAllByLptcProdId(lptcProdId);
	}

	@Override
	public void deleteAllByLptcProdIdAndLptcTermsId(BigDecimal lptcProdId, BigDecimal lptcTermsId) {
		// TODO Auto-generated method stub
		lpstpPrdTermsCondRepo.deleteAllByLptcProdIdAndLptcTermsId(lptcProdId, lptcTermsId);
		
	}

	@Override
	public List<LpstpPrdTermsCond> findAllByLptcProdIdAndLptcTermsFor(BigDecimal lptcProdId, String lptcTermsFor) {
		// TODO Auto-generated method stub
		return lpstpPrdTermsCondRepo.findAllByLptcProdIdAndLptcTermsFor(lptcProdId, lptcTermsFor);
	}

	@Override
	public LpstpPrdTermsCond saveData(LpstpPrdTermsCond lpstpPrdTermsCond) {
		// TODO Auto-generated method stub
		return lpstpPrdTermsCondRepo.saveAndFlush(lpstpPrdTermsCond);
	}

}
