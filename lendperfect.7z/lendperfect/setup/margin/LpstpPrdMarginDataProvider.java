package com.sai.lendperfect.setup.margin;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.google.gson.Gson;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;

import com.sai.lendperfect.logging.Logging;

import com.sai.lendperfect.setupmodel.*;

public class LpstpPrdMarginDataProvider {
	
	@SuppressWarnings("rawtypes")
	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		String userid = (String) session.getAttribute("userid");
		
	   if(dpMethod.equals("getPrdMarginDetails"))
		{
		   BigDecimal lpdProdId=new BigDecimal(allRequestParams.get("requestData").toString());
		   //LpstpProductDet lpstpProductDet= new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpProductDet>() { });
		   LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(lpdProdId.longValue()));
		   if(lpstpProductDetfromDB!=null)
		   {
			   List<LpstpPrdMargin> lpstpPrdMargin =serviceProvider.getLpstpPrdMarginService().findByLmgProdIdOrderByLmgRowId((lpdProdId.longValue()));
			   dataHashMap.put("lpstpPrdMargin",lpstpPrdMargin);
			   responseHashMap.put("success", true);
			   responseHashMap.put("responseData", dataHashMap);
		   }else
		   {
			   	dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		   }
		  
		}
	   
	    else if(dpMethod.equals("savePrdMargin"))
	    {
	    	List prodfeeslist = (List) allRequestParams.get("requestData");
	    	
	    	for(int i=0;i<prodfeeslist.size();i++)
	    	{
	    		List<LpstpPrdMargin> lpstpPrdMargin= new ObjectMapper().convertValue(prodfeeslist.get(i), new TypeReference<List<LpstpPrdMargin>>() { });
	    		List<LpstpPrdMargin> LpstpPrdMargindel= serviceProvider.getLpstpPrdMarginService().findByLmgProdIdOrderByLmgRowId(lpstpPrdMargin.get(0).getlmgProdId());
    		    
    		    serviceProvider.getLpstpPrdMarginService().deletePrdMargin(LpstpPrdMargindel);
	    		
	    	
	    	lpstpPrdMargin.forEach(lpstpPrdMarginList1->{
	    		lpstpPrdMarginList1.setlmgCreatedOn(Helper.getSystemDate());
    			lpstpPrdMarginList1.setlmgCreatedBy(userid);
    			lpstpPrdMarginList1.setlmgModifedBy(userid);
    			lpstpPrdMarginList1.setlmgComplete("N");
    			lpstpPrdMarginList1.setlmgModifiedOn(Helper.getSystemDate());
	    	});
	    	
	    	List<LpstpPrdMargin> lpstpPrdMarginSaved = serviceProvider.getLpstpPrdMarginService().savePrdMargin(lpstpPrdMargin);
	    	Long l =(long) 0;
	    	Long prdId =(long)0;
	    	for (LpstpPrdMargin lpstpPrdIntDoc :lpstpPrdMarginSaved)
	    	{
	    		prdId = new Long(lpstpPrdIntDoc.getlmgProdId());
		    	  
	    	}
	    	 
	    
	    	List<LpstpPrdMargin> lpstpPrdMarginsave  = serviceProvider.getLpstpPrdMarginService().getIntRateByPrdId(prdId);
	    	
			LpstpProductDet lpstpProductDetfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(prdId);
	    	if(lpstpPrdMarginsave !=null)
	    	{
	    		lpstpProductDetfromDB.setLpdComplete("N");
	    		lpstpProductDetfromDB=serviceProvider.getLpstpProductDetService().updateProductDetails(lpstpProductDetfromDB);
	    	}
	    	
	    	dataHashMap.put("lpstpProductDet",lpstpProductDetfromDB);
			dataHashMap.put("lpstpPrdMarginsave",lpstpPrdMarginSaved);
	    	}
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	    
	    else if(dpMethod.equals("deletePrdMargin"))
	    {
			List<LpstpPrdMargin> lpstpPrdMarginsave= new ArrayList();
			lpstpPrdMarginsave.add(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpPrdMargin>() { }));
		
			lpstpPrdMarginsave.forEach(lpstpPrdMargindelete->{
				lpstpPrdMargindelete.setlmgCreatedOn(Helper.getSystemDate());
				lpstpPrdMargindelete.setlmgCreatedBy(userid);
				lpstpPrdMargindelete.setlmgModifedBy(userid);
				lpstpPrdMargindelete.setlmgComplete("N");
				lpstpPrdMargindelete.setlmgModifiedOn(Helper.getSystemDate());
	    	});
			
	    	serviceProvider.getLpstpPrdMarginService().deletePrdMargin(lpstpPrdMarginsave);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	   
	   
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}

}
