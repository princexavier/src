package com.sai.lendperfect.setup.margin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sai.lendperfect.setuprepo.LpstpPrdMarginRepo;
import com.sai.lendperfect.setup.margin.LpstpPrdMarginService;
import com.sai.lendperfect.setupmodel.LpstpPrdMargin;




@Service("lpstpPrdMarginService")
@Transactional
public class LpstpPrdMarginServiceImpl implements LpstpPrdMarginService{

	@Autowired
	LpstpPrdMarginRepo lpstpPrdMarginRepo;

	@Override
	public List<LpstpPrdMargin> savePrdMargin(List<LpstpPrdMargin> lpstpPrdMargin) {
		 return lpstpPrdMarginRepo.save(lpstpPrdMargin);
	}

	@Override
	public List<LpstpPrdMargin> findAll() {
		return lpstpPrdMarginRepo.findAll();
	}

	@Override
	public void deletePrdMargin(List<LpstpPrdMargin> lpstpPrdMargin1) {
		lpstpPrdMarginRepo.delete(lpstpPrdMargin1);
	}

	@Override
	public List<LpstpPrdMargin> findByLmgProdIdOrderByLmgRowId(Long lmgProdId) {
		return lpstpPrdMarginRepo.findByLmgProdIdOrderByLmgRowId(lmgProdId);
	}

	@Override
	public 	List<LpstpPrdMargin> getIntRateByPrdId(Long prdId) {
		return lpstpPrdMarginRepo.findByLmgProdIdOrderByLmgRowId(prdId);
	}


	
}
