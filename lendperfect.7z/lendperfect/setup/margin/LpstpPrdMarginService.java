package com.sai.lendperfect.setup.margin;
import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.setupmodel.LpstpPrdMargin;;

public interface LpstpPrdMarginService {

	List<LpstpPrdMargin> savePrdMargin(List<LpstpPrdMargin> lpstpPrdMargin);

	List<LpstpPrdMargin> findAll();

	void deletePrdMargin(List<LpstpPrdMargin> lpstpPrdMargin1);


	List<LpstpPrdMargin> getIntRateByPrdId(Long prdId);

	List<LpstpPrdMargin> findByLmgProdIdOrderByLmgRowId(Long lmgProdId);

	
}
