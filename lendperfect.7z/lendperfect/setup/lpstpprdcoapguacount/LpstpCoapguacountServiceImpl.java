package com.sai.lendperfect.setup.lpstpprdcoapguacount;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdCoappguacount;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setuprepo.LpstpPrdCoappguacountRepo;

@Service("LpstpPrdCoapguarcountService")
@Transactional
public class LpstpCoapguacountServiceImpl implements LpstpPrdCoapguarcountService {

	@Autowired
	LpstpPrdCoappguacountRepo lpstpPrdCoappguacountRepo;

	@Override
	public List<LpstpPrdCoappguacount> savePrdDocFee(List<LpstpPrdCoappguacount> lpstpPrdCoapguar) {
		 return lpstpPrdCoappguacountRepo.save(lpstpPrdCoapguar);
	}

	@Override
	public List<LpstpPrdCoappguacount> findAll() {
		return lpstpPrdCoappguacountRepo.findAll();
	}

	@Override
	public void deletePrdDocfee(List<LpstpPrdCoappguacount> lpstpPrdCoapguar) {
		lpstpPrdCoappguacountRepo.delete(lpstpPrdCoapguar);
	}

	@Override
	public List<LpstpPrdCoappguacount> findByLrcProdIdOrderByLrcRowId(Long prdId) {
		return lpstpPrdCoappguacountRepo.findByLrcProdIdOrderByLrcRowId(prdId);
	}

	@Override
	public 	List<LpstpPrdCoappguacount> getIntRateByPrdId(Long prdId) {
		return lpstpPrdCoappguacountRepo.findByLrcProdIdOrderByLrcRowId(prdId);
	}

	@Override
	public LpstpPrdCoappguacount findByRow(BigDecimal lrcProdId, BigDecimal amount) {
		return lpstpPrdCoappguacountRepo.findByRow(lrcProdId, amount);
	}

	
}


	

