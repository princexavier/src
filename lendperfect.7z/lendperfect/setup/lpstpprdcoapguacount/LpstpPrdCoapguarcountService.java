package com.sai.lendperfect.setup.lpstpprdcoapguacount;

import java.math.BigDecimal;
import java.util.List;

import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.commodel.LpcomTakeoverChklist;
import com.sai.lendperfect.setupmodel.LpstpPrdCoappguacount;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

public interface LpstpPrdCoapguarcountService {
	List<LpstpPrdCoappguacount> savePrdDocFee(List<LpstpPrdCoappguacount> lpstpPrdCoapguar);

	List<LpstpPrdCoappguacount> findAll();

	void deletePrdDocfee(List<LpstpPrdCoappguacount> lpstpPrdCoapguar);
	
//List<LpstpPrdCoappguacount> findByLpstpProductDet(LpstpProductDet lpstpProductDet);
	
//	List<LpstpPrdCoappguacount> findByLpstpProductDetOrderByLrcRowId(LpstpProductDet lpstpProductDet);
	

	List<LpstpPrdCoappguacount> findByLrcProdIdOrderByLrcRowId(Long prdId);

	List<LpstpPrdCoappguacount> getIntRateByPrdId(Long prdId);
	LpstpPrdCoappguacount findByRow(BigDecimal lrcProdId, BigDecimal amount);

}
