package com.sai.lendperfect.setup.lpstpprdcoapguacount;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sai.lendperfect.application.util.CustomErr;
import com.sai.lendperfect.application.util.ErrConstants;
import com.sai.lendperfect.application.util.Helper;
import com.sai.lendperfect.application.util.ServiceProvider;
import com.sai.lendperfect.logging.Logging;
import com.sai.lendperfect.setupmodel.LpstpPrdCoappguacount;
import com.sai.lendperfect.setupmodel.LpstpPrdDocFee;
import com.sai.lendperfect.setupmodel.LpstpProductDet;
import com.sai.lendperfect.setuprepo.LpstpPrdCoappguacountRepo;



public class LpstpPrdCoapguarcountProvider
{

	public Map<String,?> getData(String dpMethod,HttpSession session,Map<?, ?> allRequestParams,Object masterData,ServiceProvider serviceProvider,Logging logging)
	{
		
		Map <String,Object> responseHashMap=new HashMap<String,Object>();	
		Map <String,Object> dataHashMap=new HashMap<String,Object>();	
		
	   if(dpMethod.equals("getPrdCoapGuar"))
		{
		   BigDecimal lpdProdId=new BigDecimal(allRequestParams.get("requestData").toString());
		   LpstpProductDet lpstpProductCoapfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(lpdProdId.longValue()));
		   if(lpstpProductCoapfromDB!=null)
		   {
//			   LpstpProductDet lpstpPrdCoappguacount = (LpstpProductDet) serviceProvider.getLpstpPrdCoapguarcountService().findByLpstpProductDet(lpstpProductCoapfromDB);
			   List<LpstpPrdCoappguacount> lpstpPrdCoapguar =serviceProvider.getLpstpPrdCoapguarcountService().findByLrcProdIdOrderByLrcRowId(lpdProdId.longValue());
			   dataHashMap.put("lpstpPrdCoapguar",lpstpPrdCoapguar);
			   responseHashMap.put("success", true);
			   responseHashMap.put("responseData", dataHashMap);
		   }else
		   {
			   	dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
				responseHashMap.put("success", false);
				responseHashMap.put("responseData", dataHashMap);
		   }
		  
		}
	   
	    else if(dpMethod.equals("savePrdCoapGuar"))
	    {
	    	
	    	List CoappGuaranterlist = (List) allRequestParams.get("requestData");
	    	for(int i=0;i<CoappGuaranterlist.size();i++)
	    	{
		    	List<LpstpPrdCoappguacount> lpstpPrdCoapguar= new ObjectMapper().convertValue(CoappGuaranterlist.get(i), new TypeReference<List<LpstpPrdCoappguacount>>() { });
		    	List<LpstpPrdCoappguacount> lpstpPrdDocFeedel= serviceProvider.getLpstpPrdCoapguarcountService().findByLrcProdIdOrderByLrcRowId(lpstpPrdCoapguar.get(0).getLrcProdId());   
	    		serviceProvider.getLpstpPrdCoapguarcountService().deletePrdDocfee(lpstpPrdDocFeedel);
		    	
		    	lpstpPrdCoapguar.forEach(documentfeelist->{
		    		documentfeelist.setLrcCreatedOn(Helper.getSystemDate());
		    		documentfeelist.setLrcCreatedBy(session.getAttribute("userid").toString());
		    		documentfeelist.setLrcModifiedBy(session.getAttribute("userid").toString());
		    		documentfeelist.setLrcModifiedOn(Helper.getSystemDate());
		    	});
		    	
		    	List<LpstpPrdCoappguacount> lpstpPrdCoapGuarSaved = serviceProvider.getLpstpPrdCoapguarcountService().savePrdDocFee(lpstpPrdCoapguar);
		    	Long l =(long) 0;
		    	BigDecimal prdId = null;
		    	for (LpstpPrdCoappguacount lpstpPrdCoap :lpstpPrdCoapGuarSaved)
		    	{
		    		  l = new Long(lpstpPrdCoap.getLrcProdId().toString());
			    	  prdId = BigDecimal.valueOf(l);
		    	}
		    	 
		    
		    	List<LpstpPrdCoappguacount> lpstpPrdDocFeesave  = serviceProvider.getLpstpPrdCoapguarcountService().getIntRateByPrdId(prdId.longValue());
		    	
				LpstpProductDet lpstpProdCoapfromDB =serviceProvider.getLpstpProductDetService().findByLpdProdNewId(Helper.convertLong(prdId.longValue()));
		    	if(lpstpPrdDocFeesave !=null)
		    	{
		    		lpstpProdCoapfromDB=serviceProvider.getLpstpProductDetService().updateProductDetails(lpstpProdCoapfromDB);
		    	}
		    	
		    	dataHashMap.put("lpstpProductDet",lpstpProdCoapfromDB);
				dataHashMap.put("lpstpPrdDocFeesave",lpstpPrdCoapGuarSaved);
	    	}
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	    
	    else if(dpMethod.equals("deletePrdCoap"))
	    {
			List<LpstpPrdCoappguacount> lpstpPrdCoap= new ArrayList();
			lpstpPrdCoap.add(new ObjectMapper().convertValue(allRequestParams.get("requestData"), new TypeReference<LpstpPrdCoappguacount>() { }));
		
			lpstpPrdCoap.forEach(lpstpPrdDocFeedelete->{
				lpstpPrdDocFeedelete.setLrcCreatedOn(Helper.getSystemDate());
	    		lpstpPrdDocFeedelete.setLrcCreatedBy(session.getAttribute("userid").toString());
	    		lpstpPrdDocFeedelete.setLrcModifiedBy(session.getAttribute("userid").toString());
//	    		lpstpPrdDocFeedelete.setldfComplete("N");
		    	lpstpPrdDocFeedelete.setLrcModifiedOn(Helper.getSystemDate());
	    	});
			
	    	serviceProvider.getLpstpPrdCoapguarcountService().deletePrdDocfee(lpstpPrdCoap);
			responseHashMap.put("success", true);
			responseHashMap.put("responseData", dataHashMap);
		}
	   
	   
		else
		{
			dataHashMap.put("errorData", new CustomErr(ErrConstants.methodNotFoundErrCode,ErrConstants.methodNotFoundErrMessage));
			responseHashMap.put("success", false);
			responseHashMap.put("responseData", dataHashMap);
		}
		return responseHashMap;
	}

}






