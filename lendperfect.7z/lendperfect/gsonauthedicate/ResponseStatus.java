package com.sai.lendperfect.gsonauthedicate;

public class ResponseStatus {
private status status;


private int errorCode;
public int getErrorCode() {
	return errorCode;
}
public void setErrorCode(int errorCode) {
	this.errorCode = errorCode;
}

private String message;
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public status getStatus() {
	return status;
}
public void setStatus(status status) {
	this.status = status;
}

}
