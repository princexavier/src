package com.sai.lendperfect.gsonauthedicate;

public class status {
	private boolean mutable;

	public boolean isMutable() {
		return mutable;
	}
	public void setMutable(boolean mutable) {
		this.mutable = mutable;
	}
	public String getEnumValue() {
		return enumValue;
	}
	public void setEnumValue(String enumValue) {
		this.enumValue = enumValue;
	}
	private String enumValue;
	
}
