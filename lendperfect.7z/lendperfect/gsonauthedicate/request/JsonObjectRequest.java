package com.sai.lendperfect.gsonauthedicate.request;

public class JsonObjectRequest {
private sessioncontext sessioncontext;


public sessioncontext getSessioncontext() {
	return sessioncontext;
}
public void setSessioncontext(sessioncontext sessioncontext) {
	this.sessioncontext = sessioncontext;
}
public UserProfileDTO getUserProfileDTO() {
	return UserProfileDTO;
}
public void setUserProfileDTO(UserProfileDTO userProfileDTO) {
	UserProfileDTO = userProfileDTO;
}
public String getApplicationID() {
	return applicationID;
}
public void setApplicationID(String applicationID) {
	this.applicationID = applicationID;
}
public String getService() {
	return service;
}
public void setService(String service) {
	this.service = service;
}
public String getResponseStatus() {
	return ResponseStatus;
}
public void setResponseStatus(String responseStatus) {
	ResponseStatus = responseStatus;
}
private UserProfileDTO UserProfileDTO; 
private String applicationID;
private String service;
private String ResponseStatus;
}
