package com.sai.lendperfect.gsonauthedicate.request;

public class sessioncontext {
private String userId;
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getUserPwd() {
	return userPwd;
}
public void setUserPwd(String userPwd) {
	this.userPwd = userPwd;
}
private String userPwd;
}
