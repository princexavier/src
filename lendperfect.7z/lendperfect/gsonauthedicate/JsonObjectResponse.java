package com.sai.lendperfect.gsonauthedicate;

public class JsonObjectResponse {
private UserProfileDTO UserProfileDTO;
private ResponseStatus ResponseStatus;
private sessioncontext sessioncontext;

public UserProfileDTO getUserProfileDTO() {
	return UserProfileDTO;
}
public void setUserProfileDTO(UserProfileDTO userProfileDTO) {
	UserProfileDTO = userProfileDTO;
}
public ResponseStatus getResponseStatus() {
	return ResponseStatus;
}
public void setResponseStatus(ResponseStatus responseStatus) {
	ResponseStatus = responseStatus;
}
public sessioncontext getSessioncontext() {
	return sessioncontext;
}
public void setSessioncontext(sessioncontext sessioncontext) {
	this.sessioncontext = sessioncontext;
}




}
