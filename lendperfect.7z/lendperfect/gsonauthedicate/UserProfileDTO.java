package com.sai.lendperfect.gsonauthedicate;

public class UserProfileDTO {
private String userId;
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPrimaryPwd() {
	return primaryPwd;
}
public void setPrimaryPwd(String primaryPwd) {
	this.primaryPwd = primaryPwd;
}

public String getEmployeeID() {
	return employeeID;
}
public void setEmployeeID(String employeeID) {
	this.employeeID = employeeID;
}
public String getTxtEmailID() {
	return txtEmailID;
}
public void setTxtEmailID(String txtEmailID) {
	this.txtEmailID = txtEmailID;
}

private String userName;
private String primaryPwd;
private int branchCode;
public int getBranchCode() {
	return branchCode;
}
public void setBranchCode(int branchCode) {
	this.branchCode = branchCode;
}
private String employeeID;
private String txtEmailID;
private int desigCode;
public int getDesigCode() {
	return desigCode;
}
public void setDesigCode(int desigCode) {
	this.desigCode = desigCode;
}
public int getPrivilages() {
	return privilages;
}
public void setPrivilages(int privilages) {
	this.privilages = privilages;
}

private int privilages;
}
