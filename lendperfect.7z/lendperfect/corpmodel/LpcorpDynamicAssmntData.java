package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_DYNAMIC_ASSMNT_DATA database table.
 * 
 */
@Entity
@Table(name="LPCORP_DYNAMIC_ASSMNT_DATA")
@NamedQuery(name="LpcorpDynamicAssmntData.findAll", query="SELECT l FROM LpcorpDynamicAssmntData l")
public class LpcorpDynamicAssmntData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LDAD_CREATED_BY")
	private String ldadCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LDAD_CREATED_ON")
	private Date ldadCreatedOn;

	@Column(name="LDAD_DATA_1")
	private BigDecimal ldadData1;

	@Column(name="LDAD_DATA_2")
	private BigDecimal ldadData2;

	@Column(name="LDAD_DATA_3")
	private BigDecimal ldadData3;

	@Column(name="LDAD_DATA_4")
	private BigDecimal ldadData4;

	@Column(name="LDAD_DATA_5")
	private BigDecimal ldadData5;

	@Column(name="LDAD_LINE_DESC")
	private String ldadLineDesc;

	@Column(name="LDAD_MODIFIED_BY")
	private String ldadModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LDAD_MODIFIED_ON")
	private Date ldadModifiedOn;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LDAD_ROW_ID")
	private BigDecimal ldadRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LDAD_PROP_NO")
	private LpcomProposal lpcomProposal;

	//bi-directional many-to-one association to LpcorpDynmAssessmnt
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LDAD_ASSMNT_ID")
	private LpcorpDynmAssessmnt lpcorpDynmAssessmnt;

	public LpcorpDynamicAssmntData() {
	}

	public String getLdadCreatedBy() {
		return this.ldadCreatedBy;
	}

	public void setLdadCreatedBy(String ldadCreatedBy) {
		this.ldadCreatedBy = ldadCreatedBy;
	}

	public Date getLdadCreatedOn() {
		return this.ldadCreatedOn;
	}

	public void setLdadCreatedOn(Date ldadCreatedOn) {
		this.ldadCreatedOn = ldadCreatedOn;
	}

	public BigDecimal getLdadData1() {
		return this.ldadData1;
	}

	public void setLdadData1(BigDecimal ldadData1) {
		this.ldadData1 = ldadData1;
	}

	public BigDecimal getLdadData2() {
		return this.ldadData2;
	}

	public void setLdadData2(BigDecimal ldadData2) {
		this.ldadData2 = ldadData2;
	}

	public BigDecimal getLdadData3() {
		return this.ldadData3;
	}

	public void setLdadData3(BigDecimal ldadData3) {
		this.ldadData3 = ldadData3;
	}

	public BigDecimal getLdadData4() {
		return this.ldadData4;
	}

	public void setLdadData4(BigDecimal ldadData4) {
		this.ldadData4 = ldadData4;
	}

	public BigDecimal getLdadData5() {
		return this.ldadData5;
	}

	public void setLdadData5(BigDecimal ldadData5) {
		this.ldadData5 = ldadData5;
	}

	public String getLdadLineDesc() {
		return this.ldadLineDesc;
	}

	public void setLdadLineDesc(String ldadLineDesc) {
		this.ldadLineDesc = ldadLineDesc;
	}

	public String getLdadModifiedBy() {
		return this.ldadModifiedBy;
	}

	public void setLdadModifiedBy(String ldadModifiedBy) {
		this.ldadModifiedBy = ldadModifiedBy;
	}

	public Date getLdadModifiedOn() {
		return this.ldadModifiedOn;
	}

	public void setLdadModifiedOn(Date ldadModifiedOn) {
		this.ldadModifiedOn = ldadModifiedOn;
	}

	public BigDecimal getLdadRowId() {
		return this.ldadRowId;
	}

	public void setLdadRowId(BigDecimal ldadRowId) {
		this.ldadRowId = ldadRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public LpcorpDynmAssessmnt getLpcorpDynmAssessmnt() {
		return this.lpcorpDynmAssessmnt;
	}

	public void setLpcorpDynmAssessmnt(LpcorpDynmAssessmnt lpcorpDynmAssessmnt) {
		this.lpcorpDynmAssessmnt = lpcorpDynmAssessmnt;
	}

}