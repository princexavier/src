package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_VISIT_DET database table.
 * 
 */
@Entity
@Table(name="LPCORP_VISIT_DET")
@NamedQuery(name="LpcorpVisitDet.findAll", query="SELECT l FROM LpcorpVisitDet l")
public class LpcorpVisitDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LVD_COMMENTS")
	private String lvdComments;

	@Column(name="LVD_CREATED_BY")
	private String lvdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LVD_CREATED_ON")
	private Date lvdCreatedOn;

	@Column(name="LVD_FILLER_1")
	private String lvdFiller1;

	@Column(name="LVD_FILLER_2")
	private String lvdFiller2;

	@Column(name="LVD_MODIFED_BY")
	private String lvdModifedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LVD_MODIFIED_ON")
	private Date lvdModifiedOn;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LVD_ROW_ID")
	private BigDecimal lvdRowId;

	@Column(name="LVD_SEQ_NO")
	private BigDecimal lvdSeqNo;

	@Column(name="LVD_VISIT_BY")
	private String lvdVisitBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LVD_VISIT_DATE")
	private Date lvdVisitDate;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LVD_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpVisitDet() {
	}

	public String getLvdComments() {
		return this.lvdComments;
	}

	public void setLvdComments(String lvdComments) {
		this.lvdComments = lvdComments;
	}

	public String getLvdCreatedBy() {
		return this.lvdCreatedBy;
	}

	public void setLvdCreatedBy(String lvdCreatedBy) {
		this.lvdCreatedBy = lvdCreatedBy;
	}

	public Date getLvdCreatedOn() {
		return this.lvdCreatedOn;
	}

	public void setLvdCreatedOn(Date lvdCreatedOn) {
		this.lvdCreatedOn = lvdCreatedOn;
	}

	public String getLvdFiller1() {
		return this.lvdFiller1;
	}

	public void setLvdFiller1(String lvdFiller1) {
		this.lvdFiller1 = lvdFiller1;
	}

	public String getLvdFiller2() {
		return this.lvdFiller2;
	}

	public void setLvdFiller2(String lvdFiller2) {
		this.lvdFiller2 = lvdFiller2;
	}

	public String getLvdModifedBy() {
		return this.lvdModifedBy;
	}

	public void setLvdModifedBy(String lvdModifedBy) {
		this.lvdModifedBy = lvdModifedBy;
	}

	public Date getLvdModifiedOn() {
		return this.lvdModifiedOn;
	}

	public void setLvdModifiedOn(Date lvdModifiedOn) {
		this.lvdModifiedOn = lvdModifiedOn;
	}

	public BigDecimal getLvdRowId() {
		return this.lvdRowId;
	}

	public void setLvdRowId(BigDecimal lvdRowId) {
		this.lvdRowId = lvdRowId;
	}

	public BigDecimal getLvdSeqNo() {
		return this.lvdSeqNo;
	}

	public void setLvdSeqNo(BigDecimal lvdSeqNo) {
		this.lvdSeqNo = lvdSeqNo;
	}

	public String getLvdVisitBy() {
		return this.lvdVisitBy;
	}

	public void setLvdVisitBy(String lvdVisitBy) {
		this.lvdVisitBy = lvdVisitBy;
	}

	public Date getLvdVisitDate() {
		return this.lvdVisitDate;
	}

	public void setLvdVisitDate(Date lvdVisitDate) {
		this.lvdVisitDate = lvdVisitDate;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}