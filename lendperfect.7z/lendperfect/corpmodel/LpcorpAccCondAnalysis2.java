package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_ACC_COND_ANALYSIS_2 database table.
 * 
 */
@Entity
@Table(name="LPCORP_ACC_COND_ANALYSIS_2")
@NamedQuery(name="LpcorpAccCondAnalysis2.findAll", query="SELECT l FROM LpcorpAccCondAnalysis2 l")
public class LpcorpAccCondAnalysis2 implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LACA_BANK_NAME")
	private String lacaBankName;

	@Column(name="LACA_BORR_ID")
	private String lacaBorrId;

	@Column(name="LACA_CHQ_RTN_IW")
	private BigDecimal lacaChqRtnIw;

	@Column(name="LACA_CHQ_RTN_OW")
	private BigDecimal lacaChqRtnOw;

	@Column(name="LACA_CREATED_BY")
	private String lacaCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LACA_CREATED_ON")
	private Date lacaCreatedOn;

	@Column(name="LACA_CREDITS_SUM")
	private BigDecimal lacaCreditsSum;

	@Column(name="LACA_DEBITS_SUM")
	private BigDecimal lacaDebitsSum;

	@Column(name="LACA_LOAN_NATURE")
	private String lacaLoanNature;

	@Column(name="LACA_MODIFIED_BY")
	private String lacaModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LACA_MODIFIED_ON")
	private Date lacaModifiedOn;

	@Column(name="LACA_REVIEW_PRD")
	private String lacaReviewPrd;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LACA_ROW_ID")
	private BigDecimal lacaRowId;

	@Column(name="LACA_ORDER_NO")
	private BigDecimal lacaOrderNo;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LACA_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpAccCondAnalysis2() {
	}

	public LpcorpAccCondAnalysis2(String lacaBankName, String lacaBorrId, BigDecimal lacaChqRtnIw,
			BigDecimal lacaChqRtnOw, String lacaCreatedBy, Date lacaCreatedOn, BigDecimal lacaCreditsSum,
			BigDecimal lacaDebitsSum, String lacaLoanNature, String lacaModifiedBy, Date lacaModifiedOn,
			String lacaReviewPrd, BigDecimal lacaRowId, BigDecimal lacaSeqNo, LpcomProposal lpcomProposal) {
		super();
		this.lacaBankName = lacaBankName;
		this.lacaBorrId = lacaBorrId;
		this.lacaChqRtnIw = lacaChqRtnIw;
		this.lacaChqRtnOw = lacaChqRtnOw;
		this.lacaCreatedBy = lacaCreatedBy;
		this.lacaCreatedOn = lacaCreatedOn;
		this.lacaCreditsSum = lacaCreditsSum;
		this.lacaDebitsSum = lacaDebitsSum;
		this.lacaLoanNature = lacaLoanNature;
		this.lacaModifiedBy = lacaModifiedBy;
		this.lacaModifiedOn = lacaModifiedOn;
		this.lacaReviewPrd = lacaReviewPrd;
		this.lacaRowId = lacaRowId;
		this.lacaOrderNo = lacaSeqNo;
		this.lpcomProposal = lpcomProposal;
	}

	public String getLacaBankName() {
		return this.lacaBankName;
	}

	public void setLacaBankName(String lacaBankName) {
		this.lacaBankName = lacaBankName;
	}

	public String getLacaBorrId() {
		return this.lacaBorrId;
	}

	public void setLacaBorrId(String lacaBorrId) {
		this.lacaBorrId = lacaBorrId;
	}

	public BigDecimal getLacaChqRtnIw() {
		return this.lacaChqRtnIw;
	}

	public void setLacaChqRtnIw(BigDecimal lacaChqRtnIw) {
		this.lacaChqRtnIw = lacaChqRtnIw;
	}

	public BigDecimal getLacaChqRtnOw() {
		return this.lacaChqRtnOw;
	}

	public void setLacaChqRtnOw(BigDecimal lacaChqRtnOw) {
		this.lacaChqRtnOw = lacaChqRtnOw;
	}

	public String getLacaCreatedBy() {
		return this.lacaCreatedBy;
	}

	public void setLacaCreatedBy(String lacaCreatedBy) {
		this.lacaCreatedBy = lacaCreatedBy;
	}

	public Date getLacaCreatedOn() {
		return this.lacaCreatedOn;
	}

	public void setLacaCreatedOn(Date lacaCreatedOn) {
		this.lacaCreatedOn = lacaCreatedOn;
	}

	public BigDecimal getLacaCreditsSum() {
		return this.lacaCreditsSum;
	}

	public void setLacaCreditsSum(BigDecimal lacaCreditsSum) {
		this.lacaCreditsSum = lacaCreditsSum;
	}

	public BigDecimal getLacaDebitsSum() {
		return this.lacaDebitsSum;
	}

	public void setLacaDebitsSum(BigDecimal lacaDebitsSum) {
		this.lacaDebitsSum = lacaDebitsSum;
	}

	public String getLacaLoanNature() {
		return this.lacaLoanNature;
	}

	public void setLacaLoanNature(String lacaLoanNature) {
		this.lacaLoanNature = lacaLoanNature;
	}

	public String getLacaModifiedBy() {
		return this.lacaModifiedBy;
	}

	public void setLacaModifiedBy(String lacaModifiedBy) {
		this.lacaModifiedBy = lacaModifiedBy;
	}

	public Date getLacaModifiedOn() {
		return this.lacaModifiedOn;
	}

	public void setLacaModifiedOn(Date lacaModifiedOn) {
		this.lacaModifiedOn = lacaModifiedOn;
	}

	public String getLacaReviewPrd() {
		return this.lacaReviewPrd;
	}

	public void setLacaReviewPrd(String lacaReviewPrd) {
		this.lacaReviewPrd = lacaReviewPrd;
	}

	public BigDecimal getLacaRowId() {
		return this.lacaRowId;
	}

	public void setLacaRowId(BigDecimal lacaRowId) {
		this.lacaRowId = lacaRowId;
	}

	public BigDecimal getLacaOrderNo() {
		return this.lacaOrderNo;
	}

	public void setLacaOrderNo(BigDecimal lacaOrderNo) {
		this.lacaOrderNo = lacaOrderNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}