package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_DEBTORS_SALES database table.
 * 
 */
@Entity
@Table(name="LPCORP_DEBTORS_SALES")
@NamedQuery(name="LpcorpDebtorsSale.findAll", query="SELECT l FROM LpcorpDebtorsSale l")
public class LpcorpDebtorsSale implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LP_CREATED_BY")
	private String lpCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LP_CREATED_ON")
	private Date lpCreatedOn;

	@Column(name="LP_MODIFIED_BY")
	private String lpModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LP_MODIFIED_ON")
	private Date lpModifiedOn;

	@Column(name="LPDS_0TO30_DAYS")
	private BigDecimal lpds0to30Days;

	@Column(name="LPDS_180ABOVE_DAYS")
	private BigDecimal lpds180aboveDays;

	@Column(name="LPDS_30TO90_DAYS")
	private BigDecimal lpds30to90Days;

	@Column(name="LPDS_90TO120_DAYS")
	private BigDecimal lpds90to120Days;

	@Column(name="LPDS_90TO180_DAYS")
	private BigDecimal lpds90to180Days;

	@Column(name="LPDS_PARTY_NAME")
	private String lpdsPartyName;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPDS_ROW_ID")
	private BigDecimal lpdsRowId;

	@Column(name="LPDS_ORDER_NO")
	private BigDecimal lpdsOrderNo;

	@Column(name="LPDS_TOTAL")
	private BigDecimal lpdsTotal;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LPDS_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpDebtorsSale() {
	}

	public LpcorpDebtorsSale(String lpCreatedBy, Date lpCreatedOn, String lpModifiedBy, Date lpModifiedOn,
			BigDecimal lpds0to30Days, BigDecimal lpds180aboveDays, BigDecimal lpds30to90Days,
			BigDecimal lpds90to120Days, BigDecimal lpds90to180Days, String lpdsPartyName, BigDecimal lpdsRowId,
			BigDecimal lpdsOrderNo, BigDecimal lpdsTotal, LpcomProposal lpcomProposal) {
		super();
		this.lpCreatedBy = lpCreatedBy;
		this.lpCreatedOn = lpCreatedOn;
		this.lpModifiedBy = lpModifiedBy;
		this.lpModifiedOn = lpModifiedOn;
		this.lpds0to30Days = lpds0to30Days;
		this.lpds180aboveDays = lpds180aboveDays;
		this.lpds30to90Days = lpds30to90Days;
		this.lpds90to120Days = lpds90to120Days;
		this.lpds90to180Days = lpds90to180Days;
		this.lpdsPartyName = lpdsPartyName;
		this.lpdsRowId = lpdsRowId;
		this.lpdsOrderNo = lpdsOrderNo;
		this.lpdsTotal = lpdsTotal;
		this.lpcomProposal = lpcomProposal;
	}

	public String getLpCreatedBy() {
		return this.lpCreatedBy;
	}

	public void setLpCreatedBy(String lpCreatedBy) {
		this.lpCreatedBy = lpCreatedBy;
	}

	public Date getLpCreatedOn() {
		return this.lpCreatedOn;
	}

	public void setLpCreatedOn(Date lpCreatedOn) {
		this.lpCreatedOn = lpCreatedOn;
	}

	public String getLpModifiedBy() {
		return this.lpModifiedBy;
	}

	public void setLpModifiedBy(String lpModifiedBy) {
		this.lpModifiedBy = lpModifiedBy;
	}

	public Date getLpModifiedOn() {
		return this.lpModifiedOn;
	}

	public void setLpModifiedOn(Date lpModifiedOn) {
		this.lpModifiedOn = lpModifiedOn;
	}

	public BigDecimal getLpds0to30Days() {
		return this.lpds0to30Days;
	}

	public void setLpds0to30Days(BigDecimal lpds0to30Days) {
		this.lpds0to30Days = lpds0to30Days;
	}

	public BigDecimal getLpds180aboveDays() {
		return this.lpds180aboveDays;
	}

	public void setLpds180aboveDays(BigDecimal lpds180aboveDays) {
		this.lpds180aboveDays = lpds180aboveDays;
	}

	public BigDecimal getLpds30to90Days() {
		return this.lpds30to90Days;
	}

	public void setLpds30to90Days(BigDecimal lpds30to90Days) {
		this.lpds30to90Days = lpds30to90Days;
	}

	public BigDecimal getLpds90to120Days() {
		return this.lpds90to120Days;
	}

	public void setLpds90to120Days(BigDecimal lpds90to120Days) {
		this.lpds90to120Days = lpds90to120Days;
	}

	public BigDecimal getLpds90to180Days() {
		return this.lpds90to180Days;
	}

	public void setLpds90to180Days(BigDecimal lpds90to180Days) {
		this.lpds90to180Days = lpds90to180Days;
	}

	public String getLpdsPartyName() {
		return this.lpdsPartyName;
	}

	public void setLpdsPartyName(String lpdsPartyName) {
		this.lpdsPartyName = lpdsPartyName;
	}

	public BigDecimal getLpdsRowId() {
		return this.lpdsRowId;
	}

	public void setLpdsRowId(BigDecimal lpdsRowId) {
		this.lpdsRowId = lpdsRowId;
	}

	public BigDecimal getLpdsOrderNo() {
		return this.lpdsOrderNo;
	}

	public void setLpdsOrderNo(BigDecimal lpdsOrderNo) {
		this.lpdsOrderNo = lpdsOrderNo;
	}

	public BigDecimal getLpdsTotal() {
		return this.lpdsTotal;
	}

	public void setLpdsTotal(BigDecimal lpdsTotal) {
		this.lpdsTotal = lpdsTotal;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}