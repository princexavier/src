package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_TA_SALES database table.
 * 
 */
@Entity
@Table(name="LPCORP_TA_SALES")
@NamedQuery(name="LpcorpTaSale.findAll", query="SELECT l FROM LpcorpTaSale l")
public class LpcorpTaSale implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LTS_CREATED_BY")
	private String ltsCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LTS_CREATED_ON")
	private Date ltsCreatedOn;

	@Column(name="LTS_CUST_ID")
	private BigDecimal ltsCustId;

	@Column(name="LTS_MODIFIED_BY")
	private String ltsModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LTS_MODIFIED_ON")
	private Date ltsModifiedOn;

	@Column(name="LTS_MONTH_1")
	private String ltsMonth1;

	@Column(name="LTS_MONTH_10")
	private String ltsMonth10;

	@Column(name="LTS_MONTH_11")
	private String ltsMonth11;

	@Column(name="LTS_MONTH_12")
	private String ltsMonth12;

	@Column(name="LTS_MONTH_2")
	private String ltsMonth2;

	@Column(name="LTS_MONTH_3")
	private String ltsMonth3;

	@Column(name="LTS_MONTH_4")
	private String ltsMonth4;

	@Column(name="LTS_MONTH_5")
	private String ltsMonth5;

	@Column(name="LTS_MONTH_6")
	private String ltsMonth6;

	@Column(name="LTS_MONTH_7")
	private String ltsMonth7;

	@Column(name="LTS_MONTH_8")
	private String ltsMonth8;

	@Column(name="LTS_MONTH_9")
	private String ltsMonth9;

	@Column(name="LTS_PROP_NO")
	private BigDecimal ltsPropNo;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LTS_ROW_ID")
	private BigDecimal ltsRowId;

	@Column(name="LTS_TOT_SALES")
	private BigDecimal ltsTotSales;

	public LpcorpTaSale() {
	}

	public String getLtsCreatedBy() {
		return this.ltsCreatedBy;
	}

	public void setLtsCreatedBy(String ltsCreatedBy) {
		this.ltsCreatedBy = ltsCreatedBy;
	}

	public Date getLtsCreatedOn() {
		return this.ltsCreatedOn;
	}

	public void setLtsCreatedOn(Date ltsCreatedOn) {
		this.ltsCreatedOn = ltsCreatedOn;
	}

	public BigDecimal getLtsCustId() {
		return this.ltsCustId;
	}

	public void setLtsCustId(BigDecimal ltsCustId) {
		this.ltsCustId = ltsCustId;
	}

	public String getLtsModifiedBy() {
		return this.ltsModifiedBy;
	}

	public void setLtsModifiedBy(String ltsModifiedBy) {
		this.ltsModifiedBy = ltsModifiedBy;
	}

	public Date getLtsModifiedOn() {
		return this.ltsModifiedOn;
	}

	public void setLtsModifiedOn(Date ltsModifiedOn) {
		this.ltsModifiedOn = ltsModifiedOn;
	}

	public String getLtsMonth1() {
		return this.ltsMonth1;
	}

	public void setLtsMonth1(String ltsMonth1) {
		this.ltsMonth1 = ltsMonth1;
	}

	public String getLtsMonth10() {
		return this.ltsMonth10;
	}

	public void setLtsMonth10(String ltsMonth10) {
		this.ltsMonth10 = ltsMonth10;
	}

	public String getLtsMonth11() {
		return this.ltsMonth11;
	}

	public void setLtsMonth11(String ltsMonth11) {
		this.ltsMonth11 = ltsMonth11;
	}

	public String getLtsMonth12() {
		return this.ltsMonth12;
	}

	public void setLtsMonth12(String ltsMonth12) {
		this.ltsMonth12 = ltsMonth12;
	}

	public String getLtsMonth2() {
		return this.ltsMonth2;
	}

	public void setLtsMonth2(String ltsMonth2) {
		this.ltsMonth2 = ltsMonth2;
	}

	public String getLtsMonth3() {
		return this.ltsMonth3;
	}

	public void setLtsMonth3(String ltsMonth3) {
		this.ltsMonth3 = ltsMonth3;
	}

	public String getLtsMonth4() {
		return this.ltsMonth4;
	}

	public void setLtsMonth4(String ltsMonth4) {
		this.ltsMonth4 = ltsMonth4;
	}

	public String getLtsMonth5() {
		return this.ltsMonth5;
	}

	public void setLtsMonth5(String ltsMonth5) {
		this.ltsMonth5 = ltsMonth5;
	}

	public String getLtsMonth6() {
		return this.ltsMonth6;
	}

	public void setLtsMonth6(String ltsMonth6) {
		this.ltsMonth6 = ltsMonth6;
	}

	public String getLtsMonth7() {
		return this.ltsMonth7;
	}

	public void setLtsMonth7(String ltsMonth7) {
		this.ltsMonth7 = ltsMonth7;
	}

	public String getLtsMonth8() {
		return this.ltsMonth8;
	}

	public void setLtsMonth8(String ltsMonth8) {
		this.ltsMonth8 = ltsMonth8;
	}

	public String getLtsMonth9() {
		return this.ltsMonth9;
	}

	public void setLtsMonth9(String ltsMonth9) {
		this.ltsMonth9 = ltsMonth9;
	}

	public BigDecimal getLtsPropNo() {
		return this.ltsPropNo;
	}

	public void setLtsPropNo(BigDecimal ltsPropNo) {
		this.ltsPropNo = ltsPropNo;
	}

	public BigDecimal getLtsRowId() {
		return this.ltsRowId;
	}

	public void setLtsRowId(BigDecimal ltsRowId) {
		this.ltsRowId = ltsRowId;
	}

	public BigDecimal getLtsTotSales() {
		return this.ltsTotSales;
	}

	public void setLtsTotSales(BigDecimal ltsTotSales) {
		this.ltsTotSales = ltsTotSales;
	}

}