package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_COMP_CP_ANNEX database table.
 * 
 */
@Entity
@Table(name="LPCORP_COMP_CP_ANNEX")
@NamedQuery(name="LpcorpCompCpAnnex.findAll", query="SELECT l FROM LpcorpCompCpAnnex l")
public class LpcorpCompCpAnnex implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LCCA_CREATED_BY")
	private String lccaCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCCA_CREATED_ON")
	private Date lccaCreatedOn;

	@Column(name="LCCA_DESC")
	private String lccaDesc;

	@Column(name="LCCA_MODIFIED_BY")
	private String lccaModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCCA_MODIFIED_ON")
	private Date lccaModifiedOn;

	@Column(name="LCCA_ORDER_NO")
	private BigDecimal lccaOrderNo;

	@Column(name="LCCA_PARENT_ID")
	private BigDecimal lccaParentId;

	@Column(name="LCCA_PROVIDED")
	private String lccaProvided;

	@Column(name="LCCA_REMARKS")
	private String lccaRemarks;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LCCA_ROW_ID")
	private BigDecimal lccaRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LCCA_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpCompCpAnnex() {
	}

	public String getLccaCreatedBy() {
		return this.lccaCreatedBy;
	}

	public void setLccaCreatedBy(String lccaCreatedBy) {
		this.lccaCreatedBy = lccaCreatedBy;
	}

	public Date getLccaCreatedOn() {
		return this.lccaCreatedOn;
	}

	public void setLccaCreatedOn(Date lccaCreatedOn) {
		this.lccaCreatedOn = lccaCreatedOn;
	}

	public String getLccaDesc() {
		return this.lccaDesc;
	}

	public void setLccaDesc(String lccaDesc) {
		this.lccaDesc = lccaDesc;
	}

	public String getLccaModifiedBy() {
		return this.lccaModifiedBy;
	}

	public void setLccaModifiedBy(String lccaModifiedBy) {
		this.lccaModifiedBy = lccaModifiedBy;
	}

	public Date getLccaModifiedOn() {
		return this.lccaModifiedOn;
	}

	public void setLccaModifiedOn(Date lccaModifiedOn) {
		this.lccaModifiedOn = lccaModifiedOn;
	}

	public BigDecimal getLccaOrderNo() {
		return this.lccaOrderNo;
	}

	public void setLccaOrderNo(BigDecimal lccaOrderNo) {
		this.lccaOrderNo = lccaOrderNo;
	}

	public BigDecimal getLccaParentId() {
		return this.lccaParentId;
	}

	public void setLccaParentId(BigDecimal lccaParentId) {
		this.lccaParentId = lccaParentId;
	}

	public String getLccaProvided() {
		return this.lccaProvided;
	}

	public void setLccaProvided(String lccaProvided) {
		this.lccaProvided = lccaProvided;
	}

	public String getLccaRemarks() {
		return this.lccaRemarks;
	}

	public void setLccaRemarks(String lccaRemarks) {
		this.lccaRemarks = lccaRemarks;
	}

	public BigDecimal getLccaRowId() {
		return this.lccaRowId;
	}

	public void setLccaRowId(BigDecimal lccaRowId) {
		this.lccaRowId = lccaRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}