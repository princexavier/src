package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_BCAC_ANNEX database table.
 * 
 */
@Entity
@Table(name="LPCORP_BCAC_ANNEX")
@NamedQuery(name="LpcorpBcacAnnex.findAll", query="SELECT l FROM LpcorpBcacAnnex l")
public class LpcorpBcacAnnex implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LBA_ADHERENCE")
	private String lbaAdherence;

	@Column(name="LBA_CREATED_BY")
	private String lbaCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBA_CREATED_ON")
	private Date lbaCreatedOn;

	@Column(name="LBA_DESC")
	private String lbaDesc;

	@Column(name="LBA_MODIFIED_BY")
	private String lbaModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBA_MODIFIED_ON")
	private Date lbaModifiedOn;

	@Column(name="LBA_NORMS")
	private String lbaNorms;

	@Column(name="LBA_ORDER_NO")
	private BigDecimal lbaOrderNo;

	@Column(name="LBA_PARENT_ID")
	private BigDecimal lbaParentId;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LBA_ROW_ID")
	private BigDecimal lbaRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LBA_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpBcacAnnex() {
	}

	public String getLbaAdherence() {
		return this.lbaAdherence;
	}

	public void setLbaAdherence(String lbaAdherence) {
		this.lbaAdherence = lbaAdherence;
	}

	public String getLbaCreatedBy() {
		return this.lbaCreatedBy;
	}

	public void setLbaCreatedBy(String lbaCreatedBy) {
		this.lbaCreatedBy = lbaCreatedBy;
	}

	public Date getLbaCreatedOn() {
		return this.lbaCreatedOn;
	}

	public void setLbaCreatedOn(Date lbaCreatedOn) {
		this.lbaCreatedOn = lbaCreatedOn;
	}

	public String getLbaDesc() {
		return this.lbaDesc;
	}

	public void setLbaDesc(String lbaDesc) {
		this.lbaDesc = lbaDesc;
	}

	public String getLbaModifiedBy() {
		return this.lbaModifiedBy;
	}

	public void setLbaModifiedBy(String lbaModifiedBy) {
		this.lbaModifiedBy = lbaModifiedBy;
	}

	public Date getLbaModifiedOn() {
		return this.lbaModifiedOn;
	}

	public void setLbaModifiedOn(Date lbaModifiedOn) {
		this.lbaModifiedOn = lbaModifiedOn;
	}

	public String getLbaNorms() {
		return this.lbaNorms;
	}

	public void setLbaNorms(String lbaNorms) {
		this.lbaNorms = lbaNorms;
	}

	public BigDecimal getLbaOrderNo() {
		return this.lbaOrderNo;
	}

	public void setLbaOrderNo(BigDecimal lbaOrderNo) {
		this.lbaOrderNo = lbaOrderNo;
	}

	public BigDecimal getLbaParentId() {
		return this.lbaParentId;
	}

	public void setLbaParentId(BigDecimal lbaParentId) {
		this.lbaParentId = lbaParentId;
	}

	public BigDecimal getLbaRowId() {
		return this.lbaRowId;
	}

	public void setLbaRowId(BigDecimal lbaRowId) {
		this.lbaRowId = lbaRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}