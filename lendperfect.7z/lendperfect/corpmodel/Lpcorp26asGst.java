package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_26AS_GST database table.
 * 
 */
@Entity
@Table(name="LPCORP_26AS_GST")
@NamedQuery(name="Lpcorp26asGst.findAll", query="SELECT l FROM Lpcorp26asGst l")
public class Lpcorp26asGst implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LSG_CREATED_BY")
	private String lsgCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSG_CREATED_ON")
	private Date lsgCreatedOn;

	@Column(name="LSG_MODIFIED_BY")
	private String lsgModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LSG_MODIFIED_ON")
	private Date lsgModifiedOn;

	@Column(name="LSG_PERIOD")
	private String lsgPeriod;

	@Column(name="LSG_REASON")
	private String lsgReason;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LSG_ROW_ID")
	private BigDecimal lsgRowId;

	@Column(name="LSG_ORDER_NO")
	private BigDecimal lsgOrderNo;

	@Column(name="LSG_TOPLINE_DIFF")
	private BigDecimal lsgToplineDiff;

	@Column(name="LSG_TOPLINE_FIN")
	private BigDecimal lsgToplineFin;

	@Column(name="LSG_TOPLINE_GST")
	private BigDecimal lsgToplineGst;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LSG_PROP_NO")
	private LpcomProposal lpcomProposal;

	public Lpcorp26asGst() {
	}

	public Lpcorp26asGst(String lsgCreatedBy, Date lsgCreatedOn, String lsgModifiedBy, Date lsgModifiedOn,
			String lsgPeriod, String lsgReason, BigDecimal lsgRowId, BigDecimal lsgOrderNo, BigDecimal lsgToplineDiff,
			BigDecimal lsgToplineFin, BigDecimal lsgToplineGst, LpcomProposal lpcomProposal) {
		super();
		this.lsgCreatedBy = lsgCreatedBy;
		this.lsgCreatedOn = lsgCreatedOn;
		this.lsgModifiedBy = lsgModifiedBy;
		this.lsgModifiedOn = lsgModifiedOn;
		this.lsgPeriod = lsgPeriod;
		this.lsgReason = lsgReason;
		this.lsgRowId = lsgRowId;
		this.lsgOrderNo = lsgOrderNo;
		this.lsgToplineDiff = lsgToplineDiff;
		this.lsgToplineFin = lsgToplineFin;
		this.lsgToplineGst = lsgToplineGst;
		this.lpcomProposal = lpcomProposal;
	}

	public String getLsgCreatedBy() {
		return this.lsgCreatedBy;
	}

	public void setLsgCreatedBy(String lsgCreatedBy) {
		this.lsgCreatedBy = lsgCreatedBy;
	}

	public Date getLsgCreatedOn() {
		return this.lsgCreatedOn;
	}

	public void setLsgCreatedOn(Date lsgCreatedOn) {
		this.lsgCreatedOn = lsgCreatedOn;
	}

	public String getLsgModifiedBy() {
		return this.lsgModifiedBy;
	}

	public void setLsgModifiedBy(String lsgModifiedBy) {
		this.lsgModifiedBy = lsgModifiedBy;
	}

	public Date getLsgModifiedOn() {
		return this.lsgModifiedOn;
	}

	public void setLsgModifiedOn(Date lsgModifiedOn) {
		this.lsgModifiedOn = lsgModifiedOn;
	}

	public String getLsgPeriod() {
		return this.lsgPeriod;
	}

	public void setLsgPeriod(String lsgPeriod) {
		this.lsgPeriod = lsgPeriod;
	}

	public String getLsgReason() {
		return this.lsgReason;
	}

	public void setLsgReason(String lsgReason) {
		this.lsgReason = lsgReason;
	}

	public BigDecimal getLsgRowId() {
		return this.lsgRowId;
	}

	public void setLsgRowId(BigDecimal lsgRowId) {
		this.lsgRowId = lsgRowId;
	}

	public BigDecimal getLsgOrderNo() {
		return this.lsgOrderNo;
	}

	public void setLsgOrderNo(BigDecimal lsgOrderNo) {
		this.lsgOrderNo = lsgOrderNo;
	}

	public BigDecimal getLsgToplineDiff() {
		return this.lsgToplineDiff;
	}

	public void setLsgToplineDiff(BigDecimal lsgToplineDiff) {
		this.lsgToplineDiff = lsgToplineDiff;
	}

	public BigDecimal getLsgToplineFin() {
		return this.lsgToplineFin;
	}

	public void setLsgToplineFin(BigDecimal lsgToplineFin) {
		this.lsgToplineFin = lsgToplineFin;
	}

	public BigDecimal getLsgToplineGst() {
		return this.lsgToplineGst;
	}

	public void setLsgToplineGst(BigDecimal lsgToplineGst) {
		this.lsgToplineGst = lsgToplineGst;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}