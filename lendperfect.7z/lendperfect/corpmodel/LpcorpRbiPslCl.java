package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_RBI_PSL_CLS database table.
 * 
 */
@Entity
@Table(name="LPCORP_RBI_PSL_CLS")
@NamedQuery(name="LpcorpRbiPslCl.findAll", query="SELECT l FROM LpcorpRbiPslCl l")
public class LpcorpRbiPslCl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LRP_BSR_CODE")
	private String lrpBsrCode;

	@Column(name="LRP_CATEGORY")
	private String lrpCategory;

	@Column(name="LRP_CLAUSE")
	private String lrpClause;

	@Column(name="LRP_CREATED_BY")
	private String lrpCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LRP_CREATED_ON")
	private Date lrpCreatedOn;

	@Column(name="LRP_DESC")
	private String lrpDesc;

	@Column(name="LRP_FAC_AMT")
	private BigDecimal lrpFacAmt;

	@Column(name="LRP_FAC_NO")
	private BigDecimal lrpFacNo;

	@Column(name="LRP_FAC_TYPE")
	private String lrpFacType;

	@Column(name="LRP_MODIFIED_BY")
	private String lrpModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LRP_MODIFIED_ON")
	private Date lrpModifiedOn;

	@Column(name="LRP_REMARKS")
	private String lrpRemarks;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LRP_ROW_ID")
	private BigDecimal lrpRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LRP_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpRbiPslCl() {
	}

	public String getLrpBsrCode() {
		return this.lrpBsrCode;
	}

	public void setLrpBsrCode(String lrpBsrCode) {
		this.lrpBsrCode = lrpBsrCode;
	}

	public String getLrpCategory() {
		return this.lrpCategory;
	}

	public void setLrpCategory(String lrpCategory) {
		this.lrpCategory = lrpCategory;
	}

	public String getLrpClause() {
		return this.lrpClause;
	}

	public void setLrpClause(String lrpClause) {
		this.lrpClause = lrpClause;
	}

	public String getLrpCreatedBy() {
		return this.lrpCreatedBy;
	}

	public void setLrpCreatedBy(String lrpCreatedBy) {
		this.lrpCreatedBy = lrpCreatedBy;
	}

	public Date getLrpCreatedOn() {
		return this.lrpCreatedOn;
	}

	public void setLrpCreatedOn(Date lrpCreatedOn) {
		this.lrpCreatedOn = lrpCreatedOn;
	}

	public String getLrpDesc() {
		return this.lrpDesc;
	}

	public void setLrpDesc(String lrpDesc) {
		this.lrpDesc = lrpDesc;
	}

	public BigDecimal getLrpFacAmt() {
		return this.lrpFacAmt;
	}

	public void setLrpFacAmt(BigDecimal lrpFacAmt) {
		this.lrpFacAmt = lrpFacAmt;
	}

	public BigDecimal getLrpFacNo() {
		return this.lrpFacNo;
	}

	public void setLrpFacNo(BigDecimal lrpFacNo) {
		this.lrpFacNo = lrpFacNo;
	}

	public String getLrpFacType() {
		return this.lrpFacType;
	}

	public void setLrpFacType(String lrpFacType) {
		this.lrpFacType = lrpFacType;
	}

	public String getLrpModifiedBy() {
		return this.lrpModifiedBy;
	}

	public void setLrpModifiedBy(String lrpModifiedBy) {
		this.lrpModifiedBy = lrpModifiedBy;
	}

	public Date getLrpModifiedOn() {
		return this.lrpModifiedOn;
	}

	public void setLrpModifiedOn(Date lrpModifiedOn) {
		this.lrpModifiedOn = lrpModifiedOn;
	}

	public String getLrpRemarks() {
		return this.lrpRemarks;
	}

	public void setLrpRemarks(String lrpRemarks) {
		this.lrpRemarks = lrpRemarks;
	}

	public BigDecimal getLrpRowId() {
		return this.lrpRowId;
	}

	public void setLrpRowId(BigDecimal lrpRowId) {
		this.lrpRowId = lrpRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}