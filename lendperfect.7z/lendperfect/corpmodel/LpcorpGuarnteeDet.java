package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_GUARNTEE_DET database table.
 * 
 */
@Entity
@Table(name="LPCORP_GUARNTEE_DET")
@NamedQuery(name="LpcorpGuarnteeDet.findAll", query="SELECT l FROM LpcorpGuarnteeDet l")
public class LpcorpGuarnteeDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	@Column(name="LGD_AS_ON_DATE")
	private Date lgdAsOnDate;

	@Column(name="LGD_CONSTITUTION")
	private String lgdConstitution;

	@Column(name="LGD_CREATED_BY")
	private String lgdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LGD_CREATED_ON")
	private Date lgdCreatedOn;

	@Column(name="LGD_GUAR_AMT")
	private BigDecimal lgdGuarAmt;

	@Column(name="LGD_GUAR_NETWORTH")
	private BigDecimal lgdGuarNetworth;

	@Column(name="LGD_GUAR_PARTY_ID")
	private String lgdGuarPartyId;

	@Column(name="LGD_GUAR_TYPE")
	private String lgdGuarType;

	@Column(name="LGD_MODIFIED_BY")
	private String lgdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LGD_MODIFIED_ON")
	private Date lgdModifiedOn;

	@Column(name="LGD_REMARKS")
	private String lgdRemarks;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LGD_ROW_ID")
	private BigDecimal lgdRowId;

	@Column(name="LGD_SEQ_NO")
	private BigDecimal lgdSeqNo;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LGD_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpGuarnteeDet() {
	}

	public Date getLgdAsOnDate() {
		return this.lgdAsOnDate;
	}

	public void setLgdAsOnDate(Date lgdAsOnDate) {
		this.lgdAsOnDate = lgdAsOnDate;
	}

	public String getLgdConstitution() {
		return this.lgdConstitution;
	}

	public void setLgdConstitution(String lgdConstitution) {
		this.lgdConstitution = lgdConstitution;
	}

	public String getLgdCreatedBy() {
		return this.lgdCreatedBy;
	}

	public void setLgdCreatedBy(String lgdCreatedBy) {
		this.lgdCreatedBy = lgdCreatedBy;
	}

	public Date getLgdCreatedOn() {
		return this.lgdCreatedOn;
	}

	public void setLgdCreatedOn(Date lgdCreatedOn) {
		this.lgdCreatedOn = lgdCreatedOn;
	}

	public BigDecimal getLgdGuarAmt() {
		return this.lgdGuarAmt;
	}

	public void setLgdGuarAmt(BigDecimal lgdGuarAmt) {
		this.lgdGuarAmt = lgdGuarAmt;
	}

	public BigDecimal getLgdGuarNetworth() {
		return this.lgdGuarNetworth;
	}

	public void setLgdGuarNetworth(BigDecimal lgdGuarNetworth) {
		this.lgdGuarNetworth = lgdGuarNetworth;
	}

	public String getLgdGuarPartyId() {
		return this.lgdGuarPartyId;
	}

	public void setLgdGuarPartyId(String lgdGuarPartyId) {
		this.lgdGuarPartyId = lgdGuarPartyId;
	}

	public String getLgdGuarType() {
		return this.lgdGuarType;
	}

	public void setLgdGuarType(String lgdGuarType) {
		this.lgdGuarType = lgdGuarType;
	}

	public String getLgdModifiedBy() {
		return this.lgdModifiedBy;
	}

	public void setLgdModifiedBy(String lgdModifiedBy) {
		this.lgdModifiedBy = lgdModifiedBy;
	}

	public Date getLgdModifiedOn() {
		return this.lgdModifiedOn;
	}

	public void setLgdModifiedOn(Date lgdModifiedOn) {
		this.lgdModifiedOn = lgdModifiedOn;
	}

	public String getLgdRemarks() {
		return this.lgdRemarks;
	}

	public void setLgdRemarks(String lgdRemarks) {
		this.lgdRemarks = lgdRemarks;
	}

	public BigDecimal getLgdRowId() {
		return this.lgdRowId;
	}

	public void setLgdRowId(BigDecimal lgdRowId) {
		this.lgdRowId = lgdRowId;
	}

	public BigDecimal getLgdSeqNo() {
		return this.lgdSeqNo;
	}

	public void setLgdSeqNo(BigDecimal lgdSeqNo) {
		this.lgdSeqNo = lgdSeqNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}