package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_EXISTING_EXPOSURE database table.
 * 
 */
@Entity
@Table(name="LPCORP_EXISTING_EXPOSURE")
@NamedQuery(name="LpcorpExistingExposure.findAll", query="SELECT l FROM LpcorpExistingExposure l")
public class LpcorpExistingExposure implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LEE_BANK_NAME")
	private String leeBankName;

	@Column(name="LEE_CREATED_BY")
	private String leeCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LEE_CREATED_ON")
	private Date leeCreatedOn;

	@Column(name="LEE_EMI_PAID")
	private BigDecimal leeEmiPaid;

	@Column(name="LEE_FAC_NATURE")
	private String leeFacNature;

	@Column(name="LEE_FAC_TYPE")
	private String leeFacType;

	@Column(name="LEE_FACILITY_DESC")
	private String leeFacilityDesc;

	@Column(name="LEE_MARGIN")
	private BigDecimal leeMargin;

	@Column(name="LEE_MODIFIED_BY")
	private String leeModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LEE_MODIFIED_ON")
	private Date leeModifiedOn;

	@Column(name="LEE_OS_AMT")
	private BigDecimal leeOsAmt;

	@Temporal(TemporalType.DATE)
	@Column(name="LEE_OS_DATE")
	private Date leeOsDate;

	@Column(name="LEE_OUR_BANK")
	private String leeOurBank;

	@Column(name="LEE_OVERDUE")
	private BigDecimal leeOverdue;

	@Column(name="LEE_PARTY_ID")
	private BigDecimal leePartyId;

	@Column(name="LEE_REMARKS")
	private String leeRemarks;

	@Column(name="LEE_REPAY_TYPE")
	private String leeRepayType;

	@Column(name="LEE_REPAY_Y1")
	private BigDecimal leeRepayY1;

	@Column(name="LEE_REPAY_Y2")
	private BigDecimal leeRepayY2;

	@Column(name="LEE_REPAY_Y3")
	private BigDecimal leeRepayY3;

	@Column(name="LEE_REPAY_Y4")
	private BigDecimal leeRepayY4;

	@Column(name="LEE_ROI")
	private BigDecimal leeRoi;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LEE_ROW_ID")
	private BigDecimal leeRowId;

	@Column(name="LEE_SANC_AMT")
	private BigDecimal leeSancAmt;

	@Temporal(TemporalType.DATE)
	@Column(name="LEE_SANC_DATE")
	private Date leeSancDate;

	@Column(name="LEE_SEQ_NO")
	private BigDecimal leeSeqNo;

	@Column(name="LEE_TENOR")
	private BigDecimal leeTenor;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LEE_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpExistingExposure() {
	}

	public String getLeeBankName() {
		return this.leeBankName;
	}

	public void setLeeBankName(String leeBankName) {
		this.leeBankName = leeBankName;
	}

	public String getLeeCreatedBy() {
		return this.leeCreatedBy;
	}

	public void setLeeCreatedBy(String leeCreatedBy) {
		this.leeCreatedBy = leeCreatedBy;
	}

	public Date getLeeCreatedOn() {
		return this.leeCreatedOn;
	}

	public void setLeeCreatedOn(Date leeCreatedOn) {
		this.leeCreatedOn = leeCreatedOn;
	}

	public BigDecimal getLeeEmiPaid() {
		return this.leeEmiPaid;
	}

	public void setLeeEmiPaid(BigDecimal leeEmiPaid) {
		this.leeEmiPaid = leeEmiPaid;
	}

	public String getLeeFacNature() {
		return this.leeFacNature;
	}

	public void setLeeFacNature(String leeFacNature) {
		this.leeFacNature = leeFacNature;
	}

	public String getLeeFacType() {
		return this.leeFacType;
	}

	public void setLeeFacType(String leeFacType) {
		this.leeFacType = leeFacType;
	}

	public String getLeeFacilityDesc() {
		return this.leeFacilityDesc;
	}

	public void setLeeFacilityDesc(String leeFacilityDesc) {
		this.leeFacilityDesc = leeFacilityDesc;
	}

	public BigDecimal getLeeMargin() {
		return this.leeMargin;
	}

	public void setLeeMargin(BigDecimal leeMargin) {
		this.leeMargin = leeMargin;
	}

	public String getLeeModifiedBy() {
		return this.leeModifiedBy;
	}

	public void setLeeModifiedBy(String leeModifiedBy) {
		this.leeModifiedBy = leeModifiedBy;
	}

	public Date getLeeModifiedOn() {
		return this.leeModifiedOn;
	}

	public void setLeeModifiedOn(Date leeModifiedOn) {
		this.leeModifiedOn = leeModifiedOn;
	}

	public BigDecimal getLeeOsAmt() {
		return this.leeOsAmt;
	}

	public void setLeeOsAmt(BigDecimal leeOsAmt) {
		this.leeOsAmt = leeOsAmt;
	}

	public Date getLeeOsDate() {
		return this.leeOsDate;
	}

	public void setLeeOsDate(Date leeOsDate) {
		this.leeOsDate = leeOsDate;
	}

	public String getLeeOurBank() {
		return this.leeOurBank;
	}

	public void setLeeOurBank(String leeOurBank) {
		this.leeOurBank = leeOurBank;
	}

	public BigDecimal getLeeOverdue() {
		return this.leeOverdue;
	}

	public void setLeeOverdue(BigDecimal leeOverdue) {
		this.leeOverdue = leeOverdue;
	}

	public BigDecimal getLeePartyId() {
		return this.leePartyId;
	}

	public void setLeePartyId(BigDecimal leePartyId) {
		this.leePartyId = leePartyId;
	}

	public String getLeeRemarks() {
		return this.leeRemarks;
	}

	public void setLeeRemarks(String leeRemarks) {
		this.leeRemarks = leeRemarks;
	}

	public String getLeeRepayType() {
		return this.leeRepayType;
	}

	public void setLeeRepayType(String leeRepayType) {
		this.leeRepayType = leeRepayType;
	}

	public BigDecimal getLeeRepayY1() {
		return this.leeRepayY1;
	}

	public void setLeeRepayY1(BigDecimal leeRepayY1) {
		this.leeRepayY1 = leeRepayY1;
	}

	public BigDecimal getLeeRepayY2() {
		return this.leeRepayY2;
	}

	public void setLeeRepayY2(BigDecimal leeRepayY2) {
		this.leeRepayY2 = leeRepayY2;
	}

	public BigDecimal getLeeRepayY3() {
		return this.leeRepayY3;
	}

	public void setLeeRepayY3(BigDecimal leeRepayY3) {
		this.leeRepayY3 = leeRepayY3;
	}

	public BigDecimal getLeeRepayY4() {
		return this.leeRepayY4;
	}

	public void setLeeRepayY4(BigDecimal leeRepayY4) {
		this.leeRepayY4 = leeRepayY4;
	}

	public BigDecimal getLeeRoi() {
		return this.leeRoi;
	}

	public void setLeeRoi(BigDecimal leeRoi) {
		this.leeRoi = leeRoi;
	}

	public BigDecimal getLeeRowId() {
		return this.leeRowId;
	}

	public void setLeeRowId(BigDecimal leeRowId) {
		this.leeRowId = leeRowId;
	}

	public BigDecimal getLeeSancAmt() {
		return this.leeSancAmt;
	}

	public void setLeeSancAmt(BigDecimal leeSancAmt) {
		this.leeSancAmt = leeSancAmt;
	}

	public Date getLeeSancDate() {
		return this.leeSancDate;
	}

	public void setLeeSancDate(Date leeSancDate) {
		this.leeSancDate = leeSancDate;
	}

	public BigDecimal getLeeSeqNo() {
		return this.leeSeqNo;
	}

	public void setLeeSeqNo(BigDecimal leeSeqNo) {
		this.leeSeqNo = leeSeqNo;
	}

	public BigDecimal getLeeTenor() {
		return this.leeTenor;
	}

	public void setLeeTenor(BigDecimal leeTenor) {
		this.leeTenor = leeTenor;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}