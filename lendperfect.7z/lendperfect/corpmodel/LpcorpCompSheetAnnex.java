package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_COMP_SHEET_ANNEX database table.
 * 
 */
@Entity
@Table(name="LPCORP_COMP_SHEET_ANNEX")
@NamedQuery(name="LpcorpCompSheetAnnex.findAll", query="SELECT l FROM LpcorpCompSheetAnnex l")
public class LpcorpCompSheetAnnex implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LCSA_ADHERENCE")
	private String lcsaAdherence;

	@Column(name="LCSA_CREATED_BY")
	private String lcsaCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCSA_CREATED_ON")
	private Date lcsaCreatedOn;

	@Column(name="LCSA_DESC")
	private String lcsaDesc;

	@Column(name="LCSA_EXPOSURE")
	private String lcsaExposure;

	@Column(name="LCSA_MODIFIED_BY")
	private String lcsaModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCSA_MODIFIED_ON")
	private Date lcsaModifiedOn;

	@Column(name="LCSA_NORMS")
	private String lcsaNorms;

	@Column(name="LCSA_ORDER_NO")
	private BigDecimal lcsaOrderNo;

	@Column(name="LCSA_PARENT_ID")
	private BigDecimal lcsaParentId;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LCSA_ROW_ID")
	private BigDecimal lcsaRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LCSA_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpCompSheetAnnex() {
	}

	public String getLcsaAdherence() {
		return this.lcsaAdherence;
	}

	public void setLcsaAdherence(String lcsaAdherence) {
		this.lcsaAdherence = lcsaAdherence;
	}

	public String getLcsaCreatedBy() {
		return this.lcsaCreatedBy;
	}

	public void setLcsaCreatedBy(String lcsaCreatedBy) {
		this.lcsaCreatedBy = lcsaCreatedBy;
	}

	public Date getLcsaCreatedOn() {
		return this.lcsaCreatedOn;
	}

	public void setLcsaCreatedOn(Date lcsaCreatedOn) {
		this.lcsaCreatedOn = lcsaCreatedOn;
	}

	public String getLcsaDesc() {
		return this.lcsaDesc;
	}

	public void setLcsaDesc(String lcsaDesc) {
		this.lcsaDesc = lcsaDesc;
	}

	public String getLcsaExposure() {
		return this.lcsaExposure;
	}

	public void setLcsaExposure(String lcsaExposure) {
		this.lcsaExposure = lcsaExposure;
	}

	public String getLcsaModifiedBy() {
		return this.lcsaModifiedBy;
	}

	public void setLcsaModifiedBy(String lcsaModifiedBy) {
		this.lcsaModifiedBy = lcsaModifiedBy;
	}

	public Date getLcsaModifiedOn() {
		return this.lcsaModifiedOn;
	}

	public void setLcsaModifiedOn(Date lcsaModifiedOn) {
		this.lcsaModifiedOn = lcsaModifiedOn;
	}

	public String getLcsaNorms() {
		return this.lcsaNorms;
	}

	public void setLcsaNorms(String lcsaNorms) {
		this.lcsaNorms = lcsaNorms;
	}

	public BigDecimal getLcsaOrderNo() {
		return this.lcsaOrderNo;
	}

	public void setLcsaOrderNo(BigDecimal lcsaOrderNo) {
		this.lcsaOrderNo = lcsaOrderNo;
	}

	public BigDecimal getLcsaParentId() {
		return this.lcsaParentId;
	}

	public void setLcsaParentId(BigDecimal lcsaParentId) {
		this.lcsaParentId = lcsaParentId;
	}

	public BigDecimal getLcsaRowId() {
		return this.lcsaRowId;
	}

	public void setLcsaRowId(BigDecimal lcsaRowId) {
		this.lcsaRowId = lcsaRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}