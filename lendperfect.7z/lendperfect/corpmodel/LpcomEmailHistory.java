package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_EMAIL_HISTORY database table.
 * 
 */
@Entity
@Table(name="LPCOM_EMAIL_HISTORY")
@NamedQuery(name="LpcomEmailHistory.findAll", query="SELECT l FROM LpcomEmailHistory l")
public class LpcomEmailHistory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LEH_ROW_ID")
	private long lehRowId;

	@Column(name="LEH_CREATED_BY")
	private String lehCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LEH_CREATED_ON")
	private Date lehCreatedOn;

	@Column(name="LEH_MODIFIED_BY")
	private String lehModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LEH_MODIFIED_ON")
	private Date lehModifiedOn;

	@Column(name="LEH_PROP_NO")
	private BigDecimal lehPropNo;

	@Column(name="LEH_STATUS")
	private String lehStatus;

	@Column(name="LEH_TOKEN")
	private String lehToken;

	@Column(name="LEH_USER_ID")
	private String lehUserId;

	public LpcomEmailHistory() {
	}

	public long getLehRowId() {
		return this.lehRowId;
	}

	public void setLehRowId(long lehRowId) {
		this.lehRowId = lehRowId;
	}

	public String getLehCreatedBy() {
		return this.lehCreatedBy;
	}

	public void setLehCreatedBy(String lehCreatedBy) {
		this.lehCreatedBy = lehCreatedBy;
	}

	public Date getLehCreatedOn() {
		return this.lehCreatedOn;
	}

	public void setLehCreatedOn(Date lehCreatedOn) {
		this.lehCreatedOn = lehCreatedOn;
	}

	public String getLehModifiedBy() {
		return this.lehModifiedBy;
	}

	public void setLehModifiedBy(String lehModifiedBy) {
		this.lehModifiedBy = lehModifiedBy;
	}

	public Date getLehModifiedOn() {
		return this.lehModifiedOn;
	}

	public void setLehModifiedOn(Date lehModifiedOn) {
		this.lehModifiedOn = lehModifiedOn;
	}

	public BigDecimal getLehPropNo() {
		return this.lehPropNo;
	}

	public void setLehPropNo(BigDecimal lehPropNo) {
		this.lehPropNo = lehPropNo;
	}

	public String getLehStatus() {
		return this.lehStatus;
	}

	public void setLehStatus(String lehStatus) {
		this.lehStatus = lehStatus;
	}

	public String getLehToken() {
		return this.lehToken;
	}

	public void setLehToken(String lehToken) {
		this.lehToken = lehToken;
	}

	public String getLehUserId() {
		return this.lehUserId;
	}

	public void setLehUserId(String lehUserId) {
		this.lehUserId = lehUserId;
	}

}