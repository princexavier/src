package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the LPCORP_DYNM_ASSESSMNT database table.
 * 
 */
@Entity
@Table(name="LPCORP_DYNM_ASSESSMNT")
@NamedQuery(name="LpcorpDynmAssessmnt.findAll", query="SELECT l FROM LpcorpDynmAssessmnt l")
public class LpcorpDynmAssessmnt implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LDA_ROW_ID")
	private long ldaRowId;

	@Column(name="LDA_ASSMNT_NAME")
	private String ldaAssmntName;

	@Column(name="LDA_CREATED_BY")
	private String ldaCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LDA_CREATED_ON")
	private Date ldaCreatedOn;

	@Column(name="LDA_FAC_NO")
	private BigDecimal ldaFacNo;

	@Column(name="LDA_MODIFIED_BY")
	private String ldaModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LDA_MODIFIED_ON")
	private Date ldaModifiedOn;

	//bi-directional many-to-one association to LpcorpDynamicAssmntData
	@JsonIgnore
	@OneToMany(mappedBy="lpcorpDynmAssessmnt")
	private List<LpcorpDynamicAssmntData> lpcorpDynamicAssmntData;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LDA_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpDynmAssessmnt() {
	}

	public long getLdaRowId() {
		return this.ldaRowId;
	}

	public void setLdaRowId(long ldaRowId) {
		this.ldaRowId = ldaRowId;
	}

	public String getLdaAssmntName() {
		return this.ldaAssmntName;
	}

	public void setLdaAssmntName(String ldaAssmntName) {
		this.ldaAssmntName = ldaAssmntName;
	}

	public String getLdaCreatedBy() {
		return this.ldaCreatedBy;
	}

	public void setLdaCreatedBy(String ldaCreatedBy) {
		this.ldaCreatedBy = ldaCreatedBy;
	}

	public Date getLdaCreatedOn() {
		return this.ldaCreatedOn;
	}

	public void setLdaCreatedOn(Date ldaCreatedOn) {
		this.ldaCreatedOn = ldaCreatedOn;
	}

	public BigDecimal getLdaFacNo() {
		return this.ldaFacNo;
	}

	public void setLdaFacNo(BigDecimal ldaFacNo) {
		this.ldaFacNo = ldaFacNo;
	}

	public String getLdaModifiedBy() {
		return this.ldaModifiedBy;
	}

	public void setLdaModifiedBy(String ldaModifiedBy) {
		this.ldaModifiedBy = ldaModifiedBy;
	}

	public Date getLdaModifiedOn() {
		return this.ldaModifiedOn;
	}

	public void setLdaModifiedOn(Date ldaModifiedOn) {
		this.ldaModifiedOn = ldaModifiedOn;
	}

	public List<LpcorpDynamicAssmntData> getLpcorpDynamicAssmntData() {
		return this.lpcorpDynamicAssmntData;
	}

	public void setLpcorpDynamicAssmntData(List<LpcorpDynamicAssmntData> lpcorpDynamicAssmntData) {
		this.lpcorpDynamicAssmntData = lpcorpDynamicAssmntData;
	}

	public LpcorpDynamicAssmntData addLpcorpDynamicAssmntData(LpcorpDynamicAssmntData lpcorpDynamicAssmntData) {
		getLpcorpDynamicAssmntData().add(lpcorpDynamicAssmntData);
		lpcorpDynamicAssmntData.setLpcorpDynmAssessmnt(this);

		return lpcorpDynamicAssmntData;
	}

	public LpcorpDynamicAssmntData removeLpcorpDynamicAssmntData(LpcorpDynamicAssmntData lpcorpDynamicAssmntData) {
		getLpcorpDynamicAssmntData().remove(lpcorpDynamicAssmntData);
		lpcorpDynamicAssmntData.setLpcorpDynmAssessmnt(null);

		return lpcorpDynamicAssmntData;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}