package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_MODEL_SALES database table.
 * 
 */
@Entity
@Table(name="LPCORP_MODEL_SALES")
@NamedQuery(name="LpcorpModelSale.findAll", query="SELECT l FROM LpcorpModelSale l")
public class LpcorpModelSale implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LPMS_AMOUNT")
	private BigDecimal lpmsAmount;

	@Column(name="LPMS_AMOUNT_TOT")
	private BigDecimal lpmsAmountTot;

	@Column(name="LPMS_CREATED_BY")
	private String lpmsCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPMS_CREATED_ON")
	private Date lpmsCreatedOn;

	@Column(name="LPMS_MODEL_NAME")
	private String lpmsModelName;

	@Column(name="LPMS_MODIFIED_BY")
	private String lpmsModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPMS_MODIFIED_ON")
	private Date lpmsModifiedOn;

	@Column(name="LPMS_MONTH")
	private BigDecimal lpmsMonth;

	@Column(name="LPMS_QUANTITY")
	private BigDecimal lpmsQuantity;

	@Column(name="LPMS_QUANTITY_TOT")
	private BigDecimal lpmsQuantityTot;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPMS_ROW_ID")
	private BigDecimal lpmsRowId;

	@Column(name="LPMS_ORDER_NO")
	private BigDecimal lpmsOrderNo;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LPMS_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpModelSale() {
	}

	public LpcorpModelSale(BigDecimal lpmsAmount, BigDecimal lpmsAmountTot, String lpmsCreatedBy, Date lpmsCreatedOn,
			String lpmsModelName, String lpmsModifiedBy, Date lpmsModifiedOn, BigDecimal lpmsMonth,
			BigDecimal lpmsQuantity, BigDecimal lpmsQuantityTot, BigDecimal lpmsRowId, BigDecimal lpmsOrderNo,
			LpcomProposal lpcomProposal) {
		super();
		this.lpmsAmount = lpmsAmount;
		this.lpmsAmountTot = lpmsAmountTot;
		this.lpmsCreatedBy = lpmsCreatedBy;
		this.lpmsCreatedOn = lpmsCreatedOn;
		this.lpmsModelName = lpmsModelName;
		this.lpmsModifiedBy = lpmsModifiedBy;
		this.lpmsModifiedOn = lpmsModifiedOn;
		this.lpmsMonth = lpmsMonth;
		this.lpmsQuantity = lpmsQuantity;
		this.lpmsQuantityTot = lpmsQuantityTot;
		this.lpmsRowId = lpmsRowId;
		this.lpmsOrderNo = lpmsOrderNo;
		this.lpcomProposal = lpcomProposal;
	}

	public BigDecimal getLpmsAmount() {
		return this.lpmsAmount;
	}

	public void setLpmsAmount(BigDecimal lpmsAmount) {
		this.lpmsAmount = lpmsAmount;
	}

	public BigDecimal getLpmsAmountTot() {
		return this.lpmsAmountTot;
	}

	public void setLpmsAmountTot(BigDecimal lpmsAmountTot) {
		this.lpmsAmountTot = lpmsAmountTot;
	}

	public String getLpmsCreatedBy() {
		return this.lpmsCreatedBy;
	}

	public void setLpmsCreatedBy(String lpmsCreatedBy) {
		this.lpmsCreatedBy = lpmsCreatedBy;
	}

	public Date getLpmsCreatedOn() {
		return this.lpmsCreatedOn;
	}

	public void setLpmsCreatedOn(Date lpmsCreatedOn) {
		this.lpmsCreatedOn = lpmsCreatedOn;
	}

	public String getLpmsModelName() {
		return this.lpmsModelName;
	}

	public void setLpmsModelName(String lpmsModelName) {
		this.lpmsModelName = lpmsModelName;
	}

	public String getLpmsModifiedBy() {
		return this.lpmsModifiedBy;
	}

	public void setLpmsModifiedBy(String lpmsModifiedBy) {
		this.lpmsModifiedBy = lpmsModifiedBy;
	}

	public Date getLpmsModifiedOn() {
		return this.lpmsModifiedOn;
	}

	public void setLpmsModifiedOn(Date lpmsModifiedOn) {
		this.lpmsModifiedOn = lpmsModifiedOn;
	}

	public BigDecimal getLpmsMonth() {
		return this.lpmsMonth;
	}

	public void setLpmsMonth(BigDecimal lpmsMonth) {
		this.lpmsMonth = lpmsMonth;
	}

	public BigDecimal getLpmsQuantity() {
		return this.lpmsQuantity;
	}

	public void setLpmsQuantity(BigDecimal lpmsQuantity) {
		this.lpmsQuantity = lpmsQuantity;
	}

	public BigDecimal getLpmsQuantityTot() {
		return this.lpmsQuantityTot;
	}

	public void setLpmsQuantityTot(BigDecimal lpmsQuantityTot) {
		this.lpmsQuantityTot = lpmsQuantityTot;
	}

	public BigDecimal getLpmsRowId() {
		return this.lpmsRowId;
	}

	public void setLpmsRowId(BigDecimal lpmsRowId) {
		this.lpmsRowId = lpmsRowId;
	}

	public BigDecimal getLpmsOrderNo() {
		return this.lpmsOrderNo;
	}

	public void setLpmsOrderNo(BigDecimal lpmsOrderNo) {
		this.lpmsOrderNo = lpmsOrderNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}