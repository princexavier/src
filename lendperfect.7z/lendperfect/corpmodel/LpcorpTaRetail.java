package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_TA_RETAIL database table.
 * 
 */
@Entity
@Table(name="LPCORP_TA_RETAIL")
@NamedQuery(name="LpcorpTaRetail.findAll", query="SELECT l FROM LpcorpTaRetail l")
public class LpcorpTaRetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LTR_AVG_RETAIL")
	private BigDecimal ltrAvgRetail;

	@Column(name="LTR_AVG_TICKET_SIZE")
	private BigDecimal ltrAvgTicketSize;

	@Column(name="LTR_CREATED_BY")
	private String ltrCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LTR_CREATED_ON")
	private Date ltrCreatedOn;

	@Column(name="LTR_CUST_ID")
	private BigDecimal ltrCustId;

	@Column(name="LTR_KMB_PENETRATION")
	private BigDecimal ltrKmbPenetration;

	@Column(name="LTR_MODIFIED_BY")
	private String ltrModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LTR_MODIFIED_ON")
	private Date ltrModifiedOn;

	@Column(name="LTR_MONTH_1")
	private String ltrMonth1;

	@Column(name="LTR_MONTH_10")
	private String ltrMonth10;

	@Column(name="LTR_MONTH_11")
	private String ltrMonth11;

	@Column(name="LTR_MONTH_12")
	private String ltrMonth12;

	@Column(name="LTR_MONTH_2")
	private String ltrMonth2;

	@Column(name="LTR_MONTH_3")
	private String ltrMonth3;

	@Column(name="LTR_MONTH_4")
	private String ltrMonth4;

	@Column(name="LTR_MONTH_5")
	private String ltrMonth5;

	@Column(name="LTR_MONTH_6")
	private String ltrMonth6;

	@Column(name="LTR_MONTH_7")
	private String ltrMonth7;

	@Column(name="LTR_MONTH_8")
	private String ltrMonth8;

	@Column(name="LTR_MONTH_9")
	private String ltrMonth9;

	@Column(name="LTR_PROP_NO")
	private BigDecimal ltrPropNo;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LTR_ROW_ID")
	private BigDecimal ltrRowId;

	@Column(name="LTR_TOT_RETAIL")
	private BigDecimal ltrTotRetail;

	public LpcorpTaRetail() {
	}

	public BigDecimal getLtrAvgRetail() {
		return this.ltrAvgRetail;
	}

	public void setLtrAvgRetail(BigDecimal ltrAvgRetail) {
		this.ltrAvgRetail = ltrAvgRetail;
	}

	public BigDecimal getLtrAvgTicketSize() {
		return this.ltrAvgTicketSize;
	}

	public void setLtrAvgTicketSize(BigDecimal ltrAvgTicketSize) {
		this.ltrAvgTicketSize = ltrAvgTicketSize;
	}

	public String getLtrCreatedBy() {
		return this.ltrCreatedBy;
	}

	public void setLtrCreatedBy(String ltrCreatedBy) {
		this.ltrCreatedBy = ltrCreatedBy;
	}

	public Date getLtrCreatedOn() {
		return this.ltrCreatedOn;
	}

	public void setLtrCreatedOn(Date ltrCreatedOn) {
		this.ltrCreatedOn = ltrCreatedOn;
	}

	public BigDecimal getLtrCustId() {
		return this.ltrCustId;
	}

	public void setLtrCustId(BigDecimal ltrCustId) {
		this.ltrCustId = ltrCustId;
	}

	public BigDecimal getLtrKmbPenetration() {
		return this.ltrKmbPenetration;
	}

	public void setLtrKmbPenetration(BigDecimal ltrKmbPenetration) {
		this.ltrKmbPenetration = ltrKmbPenetration;
	}

	public String getLtrModifiedBy() {
		return this.ltrModifiedBy;
	}

	public void setLtrModifiedBy(String ltrModifiedBy) {
		this.ltrModifiedBy = ltrModifiedBy;
	}

	public Date getLtrModifiedOn() {
		return this.ltrModifiedOn;
	}

	public void setLtrModifiedOn(Date ltrModifiedOn) {
		this.ltrModifiedOn = ltrModifiedOn;
	}

	public String getLtrMonth1() {
		return this.ltrMonth1;
	}

	public void setLtrMonth1(String ltrMonth1) {
		this.ltrMonth1 = ltrMonth1;
	}

	public String getLtrMonth10() {
		return this.ltrMonth10;
	}

	public void setLtrMonth10(String ltrMonth10) {
		this.ltrMonth10 = ltrMonth10;
	}

	public String getLtrMonth11() {
		return this.ltrMonth11;
	}

	public void setLtrMonth11(String ltrMonth11) {
		this.ltrMonth11 = ltrMonth11;
	}

	public String getLtrMonth12() {
		return this.ltrMonth12;
	}

	public void setLtrMonth12(String ltrMonth12) {
		this.ltrMonth12 = ltrMonth12;
	}

	public String getLtrMonth2() {
		return this.ltrMonth2;
	}

	public void setLtrMonth2(String ltrMonth2) {
		this.ltrMonth2 = ltrMonth2;
	}

	public String getLtrMonth3() {
		return this.ltrMonth3;
	}

	public void setLtrMonth3(String ltrMonth3) {
		this.ltrMonth3 = ltrMonth3;
	}

	public String getLtrMonth4() {
		return this.ltrMonth4;
	}

	public void setLtrMonth4(String ltrMonth4) {
		this.ltrMonth4 = ltrMonth4;
	}

	public String getLtrMonth5() {
		return this.ltrMonth5;
	}

	public void setLtrMonth5(String ltrMonth5) {
		this.ltrMonth5 = ltrMonth5;
	}

	public String getLtrMonth6() {
		return this.ltrMonth6;
	}

	public void setLtrMonth6(String ltrMonth6) {
		this.ltrMonth6 = ltrMonth6;
	}

	public String getLtrMonth7() {
		return this.ltrMonth7;
	}

	public void setLtrMonth7(String ltrMonth7) {
		this.ltrMonth7 = ltrMonth7;
	}

	public String getLtrMonth8() {
		return this.ltrMonth8;
	}

	public void setLtrMonth8(String ltrMonth8) {
		this.ltrMonth8 = ltrMonth8;
	}

	public String getLtrMonth9() {
		return this.ltrMonth9;
	}

	public void setLtrMonth9(String ltrMonth9) {
		this.ltrMonth9 = ltrMonth9;
	}

	public BigDecimal getLtrPropNo() {
		return this.ltrPropNo;
	}

	public void setLtrPropNo(BigDecimal ltrPropNo) {
		this.ltrPropNo = ltrPropNo;
	}

	public BigDecimal getLtrRowId() {
		return this.ltrRowId;
	}

	public void setLtrRowId(BigDecimal ltrRowId) {
		this.ltrRowId = ltrRowId;
	}

	public BigDecimal getLtrTotRetail() {
		return this.ltrTotRetail;
	}

	public void setLtrTotRetail(BigDecimal ltrTotRetail) {
		this.ltrTotRetail = ltrTotRetail;
	}

}