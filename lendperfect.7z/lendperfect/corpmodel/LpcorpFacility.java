package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_FACILITIES database table.
 * 
 */
@Entity
@Table(name="LPCORP_FACILITIES")
@NamedQuery(name="LpcorpFacility.findAll", query="SELECT l FROM LpcorpFacility l")
public class LpcorpFacility implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LF_APPROVED_BY")
	private String lfApprovedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LF_APPROVED_ON")
	private Date lfApprovedOn;

	@Column(name="LF_CREATED_BY")
	private String lfCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LF_CREATED_ON")
	private Date lfCreatedOn;

	@Column(name="LF_CREDIT_RECMD")
	private BigDecimal lfCreditRecmd;

	@Column(name="LF_EXIST_LIMIT")
	private BigDecimal lfExistLimit;

	@Column(name="LF_FAC_CMBD_RATING")
	private String lfFacCmbdRating;

	@Column(name="LF_FAC_LEVEL")
	private BigDecimal lfFacLevel;

	@Column(name="LF_FAC_NATURE")
	private String lfFacNature;

	@Column(name="LF_FAC_NO")
	private BigDecimal lfFacNo;

	@Column(name="LF_FAC_PARENT")
	private BigDecimal lfFacParent;

	@Column(name="LF_FAC_RATING")
	private String lfFacRating;

	@Column(name="LF_FAC_SECURE")
	private String lfFacSecure;

	@Column(name="LF_FAC_STATUS")
	private String lfFacStatus;

	@Column(name="LF_FAC_TYPE")
	private String lfFacType;

	@Column(name="LF_LOAN_TYPE")
	private String lfLoanType;

	@Column(name="LF_MAIN_CAT")
	private BigDecimal lfMainCat;

	@Column(name="LF_MARGIN")
	private BigDecimal lfMargin;

	@Column(name="LF_MODIFIED_BY")
	private String lfModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LF_MODIFIED_ON")
	private Date lfModifiedOn;

	@Column(name="LF_OS_LIMIT")
	private BigDecimal lfOsLimit;

	@Column(name="LF_OTHER_TERMS")
	private String lfOtherTerms;

	@Column(name="LF_PROD_ID")
	private BigDecimal lfProdId;

	

	@Column(name="LF_PROPOSED_LIMIT")
	private BigDecimal lfProposedLimit;

	@Column(name="LF_RE_EXPOSURE")
	private String lfReExposure;

	@Column(name="LF_RENEWED")
	private String lfRenewed;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LF_ROW_ID")
	private BigDecimal lfRowId;

	
	@Column(name="LF_SALES_RECMD")
	private BigDecimal lfSalesRecmd;

	@Column(name="LF_SANC_LIMIT")
	private BigDecimal lfSancLimit;

	@Column(name="LF_SUB_CAT")
	private BigDecimal lfSubCat;

	@Column(name="LF_TAKEOVR_OS_LIMIT")
	private BigDecimal lfTakeovrOsLimit;

	@Column(name="LF_TAKEOVR_SANC_LIMIT")
	private BigDecimal lfTakeovrSancLimit;

	@Column(name="LF_TENOR")
	private BigDecimal lfTenor;
	
	@Column(name="LF_FAC_RECMD")
	private String lfRecmd;
	
	//bi-directional many-to-one association to LpcomProposal
		@ManyToOne
		@JsonIgnore
		@JoinColumn(name="LF_PROP_NO")
		private LpcomProposal lpcomProposal;


	public LpcorpFacility() {
	}

	public String getLfApprovedBy() {
		return this.lfApprovedBy;
	}

	public void setLfApprovedBy(String lfApprovedBy) {
		this.lfApprovedBy = lfApprovedBy;
	}

	public Date getLfApprovedOn() {
		return this.lfApprovedOn;
	}

	public void setLfApprovedOn(Date lfApprovedOn) {
		this.lfApprovedOn = lfApprovedOn;
	}

	public String getLfCreatedBy() {
		return this.lfCreatedBy;
	}

	public void setLfCreatedBy(String lfCreatedBy) {
		this.lfCreatedBy = lfCreatedBy;
	}

	public Date getLfCreatedOn() {
		return this.lfCreatedOn;
	}

	public void setLfCreatedOn(Date lfCreatedOn) {
		this.lfCreatedOn = lfCreatedOn;
	}

	public BigDecimal getLfCreditRecmd() {
		return this.lfCreditRecmd;
	}

	public void setLfCreditRecmd(BigDecimal lfCreditRecmd) {
		this.lfCreditRecmd = lfCreditRecmd;
	}

	public BigDecimal getLfExistLimit() {
		return this.lfExistLimit;
	}

	public void setLfExistLimit(BigDecimal lfExistLimit) {
		this.lfExistLimit = lfExistLimit;
	}

	public String getLfFacCmbdRating() {
		return this.lfFacCmbdRating;
	}

	public void setLfFacCmbdRating(String lfFacCmbdRating) {
		this.lfFacCmbdRating = lfFacCmbdRating;
	}

	public BigDecimal getLfFacLevel() {
		return this.lfFacLevel;
	}

	public void setLfFacLevel(BigDecimal lfFacLevel) {
		this.lfFacLevel = lfFacLevel;
	}

	public String getLfFacNature() {
		return this.lfFacNature;
	}

	public void setLfFacNature(String lfFacNature) {
		this.lfFacNature = lfFacNature;
	}

	public BigDecimal getLfFacNo() {
		return this.lfFacNo;
	}

	public void setLfFacNo(BigDecimal lfFacNo) {
		this.lfFacNo = lfFacNo;
	}

	public BigDecimal getLfFacParent() {
		return this.lfFacParent;
	}

	public void setLfFacParent(BigDecimal lfFacParent) {
		this.lfFacParent = lfFacParent;
	}

	public String getLfFacRating() {
		return this.lfFacRating;
	}

	public void setLfFacRating(String lfFacRating) {
		this.lfFacRating = lfFacRating;
	}

	public String getLfFacSecure() {
		return this.lfFacSecure;
	}

	public void setLfFacSecure(String lfFacSecure) {
		this.lfFacSecure = lfFacSecure;
	}

	public String getLfFacStatus() {
		return this.lfFacStatus;
	}

	public void setLfFacStatus(String lfFacStatus) {
		this.lfFacStatus = lfFacStatus;
	}

	public String getLfFacType() {
		return this.lfFacType;
	}

	public void setLfFacType(String lfFacType) {
		this.lfFacType = lfFacType;
	}

	public String getLfLoanType() {
		return this.lfLoanType;
	}

	public void setLfLoanType(String lfLoanType) {
		this.lfLoanType = lfLoanType;
	}

	public BigDecimal getLfMainCat() {
		return this.lfMainCat;
	}

	public void setLfMainCat(BigDecimal lfMainCat) {
		this.lfMainCat = lfMainCat;
	}

	public BigDecimal getLfMargin() {
		return this.lfMargin;
	}

	public void setLfMargin(BigDecimal lfMargin) {
		this.lfMargin = lfMargin;
	}

	public String getLfModifiedBy() {
		return this.lfModifiedBy;
	}

	public void setLfModifiedBy(String lfModifiedBy) {
		this.lfModifiedBy = lfModifiedBy;
	}

	public Date getLfModifiedOn() {
		return this.lfModifiedOn;
	}

	public void setLfModifiedOn(Date lfModifiedOn) {
		this.lfModifiedOn = lfModifiedOn;
	}

	public BigDecimal getLfOsLimit() {
		return this.lfOsLimit;
	}

	public void setLfOsLimit(BigDecimal lfOsLimit) {
		this.lfOsLimit = lfOsLimit;
	}

	public String getLfOtherTerms() {
		return this.lfOtherTerms;
	}

	public void setLfOtherTerms(String lfOtherTerms) {
		this.lfOtherTerms = lfOtherTerms;
	}

	public BigDecimal getLfProdId() {
		return this.lfProdId;
	}

	public void setLfProdId(BigDecimal lfProdId) {
		this.lfProdId = lfProdId;
	}

	
	public BigDecimal getLfProposedLimit() {
		return this.lfProposedLimit;
	}

	public void setLfProposedLimit(BigDecimal lfProposedLimit) {
		this.lfProposedLimit = lfProposedLimit;
	}

	public String getLfReExposure() {
		return this.lfReExposure;
	}

	public void setLfReExposure(String lfReExposure) {
		this.lfReExposure = lfReExposure;
	}

	public String getLfRenewed() {
		return this.lfRenewed;
	}

	public void setLfRenewed(String lfRenewed) {
		this.lfRenewed = lfRenewed;
	}

	public BigDecimal getLfRowId() {
		return this.lfRowId;
	}

	public void setLfRowId(BigDecimal lfRowId) {
		this.lfRowId = lfRowId;
	}

	public BigDecimal getLfSalesRecmd() {
		return this.lfSalesRecmd;
	}

	public void setLfSalesRecmd(BigDecimal lfSalesRecmd) {
		this.lfSalesRecmd = lfSalesRecmd;
	}

	public BigDecimal getLfSancLimit() {
		return this.lfSancLimit;
	}

	public void setLfSancLimit(BigDecimal lfSancLimit) {
		this.lfSancLimit = lfSancLimit;
	}

	public BigDecimal getLfSubCat() {
		return this.lfSubCat;
	}

	public void setLfSubCat(BigDecimal lfSubCat) {
		this.lfSubCat = lfSubCat;
	}

	public BigDecimal getLfTakeovrOsLimit() {
		return this.lfTakeovrOsLimit;
	}

	public void setLfTakeovrOsLimit(BigDecimal lfTakeovrOsLimit) {
		this.lfTakeovrOsLimit = lfTakeovrOsLimit;
	}

	public BigDecimal getLfTakeovrSancLimit() {
		return this.lfTakeovrSancLimit;
	}

	public void setLfTakeovrSancLimit(BigDecimal lfTakeovrSancLimit) {
		this.lfTakeovrSancLimit = lfTakeovrSancLimit;
	}

	public BigDecimal getLfTenor() {
		return this.lfTenor;
	}

	public void setLfTenor(BigDecimal lfTenor) {
		this.lfTenor = lfTenor;
	}

	public String getLfRecmd() {
		return lfRecmd;
	}

	public void setLfRecmd(String lfRecmd) {
		this.lfRecmd = lfRecmd;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}
	@Override
	public String toString() {
		return "LpcorpFacility [lfApprovedBy=" + lfApprovedBy + ", lfApprovedOn=" + lfApprovedOn + ", lfCreatedBy="
				+ lfCreatedBy + ", lfCreatedOn=" + lfCreatedOn + ", lfCreditRecmd=" + lfCreditRecmd + ", lfExistLimit="
				+ lfExistLimit + ", lfFacCmbdRating=" + lfFacCmbdRating + ", lfFacLevel=" + lfFacLevel
				+ ", lfFacNature=" + lfFacNature + ", lfFacNo=" + lfFacNo + ", lfFacParent=" + lfFacParent
				+ ", lfFacRating=" + lfFacRating + ", lfFacSecure=" + lfFacSecure + ", lfFacStatus=" + lfFacStatus
				+ ", lfFacType=" + lfFacType + ", lfLoanType=" + lfLoanType + ", lfMainCat=" + lfMainCat + ", lfMargin="
				+ lfMargin + ", lfModifiedBy=" + lfModifiedBy + ", lfModifiedOn=" + lfModifiedOn + ", lfOsLimit="
				+ lfOsLimit + ", lfOtherTerms=" + lfOtherTerms + ", lfProdId=" + lfProdId 
				+ ", lfProposedLimit=" + lfProposedLimit + ", lfReExposure=" + lfReExposure + ", lfRenewed=" + lfRenewed
				+ ", lfRowId=" + lfRowId + ", lfSalesRecmd=" + lfSalesRecmd + ", lfSancLimit=" + lfSancLimit
				+ ", lfSubCat=" + lfSubCat + ", lfTakeovrOsLimit=" + lfTakeovrOsLimit + ", lfTakeovrSancLimit="
				+ lfTakeovrSancLimit + ", lfTenor=" + lfTenor +" , lfRecmd=" + lfRecmd +"]";
	}
	
	public LpcorpFacility(String lfApprovedBy, Date lfApprovedOn, String lfCreatedBy, Date lfCreatedOn,
			BigDecimal lfCreditRecmd, BigDecimal lfExistLimit, String lfFacCmbdRating, BigDecimal lfFacLevel,
			String lfFacNature, BigDecimal lfFacNo, BigDecimal lfFacParent, String lfFacRating, String lfFacSecure,
			String lfFacStatus, String lfFacType, String lfLoanType, BigDecimal lfMainCat, BigDecimal lfMargin,
			String lfModifiedBy, Date lfModifiedOn, BigDecimal lfOsLimit, String lfOtherTerms, BigDecimal lfProdId,
			BigDecimal lfPropNo, BigDecimal lfProposedLimit, String lfReExposure, String lfRenewed,
			BigDecimal lfSalesRecmd, BigDecimal lfSancLimit, BigDecimal lfSubCat, BigDecimal lfTakeovrOsLimit,
			BigDecimal lfTakeovrSancLimit, BigDecimal lfTenor,String lfRecmd ) {
		super();
		this.lfApprovedBy = lfApprovedBy;
		this.lfApprovedOn = lfApprovedOn;
		this.lfCreatedBy = lfCreatedBy;
		this.lfCreatedOn = lfCreatedOn;
		this.lfCreditRecmd = lfCreditRecmd;
		this.lfExistLimit = lfExistLimit;
		this.lfFacCmbdRating = lfFacCmbdRating;
		this.lfFacLevel = lfFacLevel;
		this.lfFacNature = lfFacNature;
		this.lfFacNo = lfFacNo;
		this.lfFacParent = lfFacParent;
		this.lfFacRating = lfFacRating;
		this.lfFacSecure = lfFacSecure;
		this.lfFacStatus = lfFacStatus;
		this.lfFacType = lfFacType;
		this.lfLoanType = lfLoanType;
		this.lfMainCat = lfMainCat;
		this.lfMargin = lfMargin;
		this.lfModifiedBy = lfModifiedBy;
		this.lfModifiedOn = lfModifiedOn;
		this.lfOsLimit = lfOsLimit;
		this.lfOtherTerms = lfOtherTerms;
		this.lfProdId = lfProdId;
		this.lfProposedLimit = lfProposedLimit;
		this.lfReExposure = lfReExposure;
		this.lfRenewed = lfRenewed;
		this.lfSalesRecmd = lfSalesRecmd;
		this.lfSancLimit = lfSancLimit;
		this.lfSubCat = lfSubCat;
		this.lfTakeovrOsLimit = lfTakeovrOsLimit;
		this.lfTakeovrSancLimit = lfTakeovrSancLimit;
		this.lfTenor = lfTenor;
		this.lfRecmd=lfRecmd;
	}

	public LpcorpFacility(String lfApprovedBy, Date lfApprovedOn, String lfCreatedBy, Date lfCreatedOn,
			BigDecimal lfCreditRecmd, BigDecimal lfExistLimit, String lfFacCmbdRating, BigDecimal lfFacLevel,
			String lfFacNature, BigDecimal lfFacNo, BigDecimal lfFacParent, String lfFacRating, String lfFacSecure,
			String lfFacStatus, String lfFacType, String lfLoanType, BigDecimal lfMainCat, BigDecimal lfMargin,
			BigDecimal lfOsLimit, String lfOtherTerms, BigDecimal lfProdId, 
			BigDecimal lfProposedLimit, String lfReExposure, String lfRenewed, BigDecimal lfSalesRecmd,
			BigDecimal lfSancLimit, BigDecimal lfSubCat, BigDecimal lfTakeovrOsLimit, BigDecimal lfTakeovrSancLimit,
			BigDecimal lfTenor,String lfRecmd) {
		super();
		this.lfApprovedBy = lfApprovedBy;
		this.lfApprovedOn = lfApprovedOn;
		this.lfCreatedBy = lfCreatedBy;
		this.lfCreatedOn = lfCreatedOn;
		this.lfCreditRecmd = lfCreditRecmd;
		this.lfExistLimit = lfExistLimit;
		this.lfFacCmbdRating = lfFacCmbdRating;
		this.lfFacLevel = lfFacLevel;
		this.lfFacNature = lfFacNature;
		this.lfFacNo = lfFacNo;
		this.lfFacParent = lfFacParent;
		this.lfFacRating = lfFacRating;
		this.lfFacSecure = lfFacSecure;
		this.lfFacStatus = lfFacStatus;
		this.lfFacType = lfFacType;
		this.lfLoanType = lfLoanType;
		this.lfMainCat = lfMainCat;
		this.lfMargin = lfMargin;
		this.lfOsLimit = lfOsLimit;
		this.lfOtherTerms = lfOtherTerms;
		this.lfProdId = lfProdId;
		this.lfProposedLimit = lfProposedLimit;
		this.lfReExposure = lfReExposure;
		this.lfRenewed = lfRenewed;
		this.lfSalesRecmd = lfSalesRecmd;
		this.lfSancLimit = lfSancLimit;
		this.lfSubCat = lfSubCat;
		this.lfTakeovrOsLimit = lfTakeovrOsLimit;
		this.lfTakeovrSancLimit = lfTakeovrSancLimit;
		this.lfTenor = lfTenor;
		this.lfRecmd=lfRecmd;
	}

}