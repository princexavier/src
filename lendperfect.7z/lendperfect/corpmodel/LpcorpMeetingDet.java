package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_MEETING_DET database table.
 * 
 */
@Entity
@Table(name="LPCORP_MEETING_DET")
@NamedQuery(name="LpcorpMeetingDet.findAll", query="SELECT l FROM LpcorpMeetingDet l")
public class LpcorpMeetingDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LMD_CREATED_BY")
	private String lmdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LMD_CREATED_ON")
	private Date lmdCreatedOn;

	@Column(name="LMD_FILLER_1")
	private String lmdFiller1;

	@Column(name="LMD_FILLER_2")
	private String lmdFiller2;

	@Temporal(TemporalType.DATE)
	@Column(name="LMD_MEETING_DATE")
	private Date lmdMeetingDate;

	@Column(name="LMD_MET_BY")
	private String lmdMetBy;

	@Column(name="LMD_MET_WHOM")
	private String lmdMetWhom;

	@Column(name="LMD_MODIFIED_BY")
	private String lmdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LMD_MODIFIED_ON")
	private Date lmdModifiedOn;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LMD_ROW_ID")
	private BigDecimal lmdRowId;

	@Column(name="LMD_SEQ_NO")
	private BigDecimal lmdSeqNo;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LMD_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpMeetingDet() {
	}

	public String getLmdCreatedBy() {
		return this.lmdCreatedBy;
	}

	public void setLmdCreatedBy(String lmdCreatedBy) {
		this.lmdCreatedBy = lmdCreatedBy;
	}

	public Date getLmdCreatedOn() {
		return this.lmdCreatedOn;
	}

	public void setLmdCreatedOn(Date lmdCreatedOn) {
		this.lmdCreatedOn = lmdCreatedOn;
	}

	public String getLmdFiller1() {
		return this.lmdFiller1;
	}

	public void setLmdFiller1(String lmdFiller1) {
		this.lmdFiller1 = lmdFiller1;
	}

	public String getLmdFiller2() {
		return this.lmdFiller2;
	}

	public void setLmdFiller2(String lmdFiller2) {
		this.lmdFiller2 = lmdFiller2;
	}

	public Date getLmdMeetingDate() {
		return this.lmdMeetingDate;
	}

	public void setLmdMeetingDate(Date lmdMeetingDate) {
		this.lmdMeetingDate = lmdMeetingDate;
	}

	public String getLmdMetBy() {
		return this.lmdMetBy;
	}

	public void setLmdMetBy(String lmdMetBy) {
		this.lmdMetBy = lmdMetBy;
	}

	public String getLmdMetWhom() {
		return this.lmdMetWhom;
	}

	public void setLmdMetWhom(String lmdMetWhom) {
		this.lmdMetWhom = lmdMetWhom;
	}

	public String getLmdModifiedBy() {
		return this.lmdModifiedBy;
	}

	public void setLmdModifiedBy(String lmdModifiedBy) {
		this.lmdModifiedBy = lmdModifiedBy;
	}

	public Date getLmdModifiedOn() {
		return this.lmdModifiedOn;
	}

	public void setLmdModifiedOn(Date lmdModifiedOn) {
		this.lmdModifiedOn = lmdModifiedOn;
	}

	public BigDecimal getLmdRowId() {
		return this.lmdRowId;
	}

	public void setLmdRowId(BigDecimal lmdRowId) {
		this.lmdRowId = lmdRowId;
	}

	public BigDecimal getLmdSeqNo() {
		return this.lmdSeqNo;
	}

	public void setLmdSeqNo(BigDecimal lmdSeqNo) {
		this.lmdSeqNo = lmdSeqNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}