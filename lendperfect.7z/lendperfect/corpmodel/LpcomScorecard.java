package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCOM_SCORECARD database table.
 * 
 */
@Entity
@Table(name="LPCOM_SCORECARD")
@NamedQuery(name="LpcomScorecard.findAll", query="SELECT l FROM LpcomScorecard l")
public class LpcomScorecard implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LS_ANS")
	private String lsAns;

	@Column(name="LS_ANS_WEIGHT")
	private BigDecimal lsAnsWeight;

	@Column(name="LS_CREATED_BY")
	private String lsCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LS_CREATED_ON")
	private Date lsCreatedOn;

	@Column(name="LS_HEADER_ID")
	private BigDecimal lsHeaderId;

	@Column(name="LS_MAX_SCORE")
	private BigDecimal lsMaxScore;

	@Column(name="LS_MODIFIED_BY")
	private String lsModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LS_MODIFIED_ON")
	private Date lsModifiedOn;

	@Column(name="LS_OBTAINED_SCORE")
	private BigDecimal lsObtainedScore;

	@Column(name="LS_QUES_DESC")
	private String lsQuesDesc;

	@Column(name="LS_QUES_ID")
	private BigDecimal lsQuesId;

	@Column(name="LS_QUES_WEIGHT")
	private BigDecimal lsQuesWeight;	
	
	@Column(name="LS_FAC_NO")
	private Long lsFacNo;
	
	public void setLsFacNo(Long lsFacNo) {
		this.lsFacNo = lsFacNo;
	}

	@Id
	@Column(name="LS_ROW_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private BigDecimal lsRowId;
	
	@Transient
	private BigDecimal lpstpMaster;

	@Column(name="LS_SCORECARD_TYPE")
	private String lsScorecardType;

	@Column(name="LS_UNIQUE_ID")
	private BigDecimal lsUniqueId;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LS_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcomScorecard() {
	}

	public String getLsAns() {
		return this.lsAns;
	}

	public void setLsAns(String lsAns) {
		this.lsAns = lsAns;
	}

	public BigDecimal getLsAnsWeight() {
		return this.lsAnsWeight;
	}

	public void setLsAnsWeight(BigDecimal lsAnsWeight) {
		this.lsAnsWeight = lsAnsWeight;
	}

	public String getLsCreatedBy() {
		return this.lsCreatedBy;
	}

	public void setLsCreatedBy(String lsCreatedBy) {
		this.lsCreatedBy = lsCreatedBy;
	}

	public Date getLsCreatedOn() {
		return this.lsCreatedOn;
	}

	public void setLsCreatedOn(Date lsCreatedOn) {
		this.lsCreatedOn = lsCreatedOn;
	}

	public BigDecimal getLsHeaderId() {
		return this.lsHeaderId;
	}

	public void setLsHeaderId(BigDecimal lsHeaderId) {
		this.lsHeaderId = lsHeaderId;
	}

	public BigDecimal getLsMaxScore() {
		return this.lsMaxScore;
	}

	public void setLsMaxScore(BigDecimal lsMaxScore) {
		this.lsMaxScore = lsMaxScore;
	}

	public String getLsModifiedBy() {
		return this.lsModifiedBy;
	}

	public void setLsModifiedBy(String lsModifiedBy) {
		this.lsModifiedBy = lsModifiedBy;
	}

	public Date getLsModifiedOn() {
		return this.lsModifiedOn;
	}

	public void setLsModifiedOn(Date lsModifiedOn) {
		this.lsModifiedOn = lsModifiedOn;
	}

	public BigDecimal getLsObtainedScore() {
		return this.lsObtainedScore;
	}

	public void setLsObtainedScore(BigDecimal lsObtainedScore) {
		this.lsObtainedScore = lsObtainedScore;
	}

	public String getLsQuesDesc() {
		return this.lsQuesDesc;
	}

	public void setLsQuesDesc(String lsQuesDesc) {
		this.lsQuesDesc = lsQuesDesc;
	}

	public BigDecimal getLsQuesId() {
		return this.lsQuesId;
	}

	public void setLsQuesId(BigDecimal lsQuesId) {
		this.lsQuesId = lsQuesId;
	}

	public BigDecimal getLsQuesWeight() {
		return this.lsQuesWeight;
	}

	public void setLsQuesWeight(BigDecimal lsQuesWeight) {
		this.lsQuesWeight = lsQuesWeight;
	}

	public BigDecimal getLsRowId() {
		return this.lsRowId;
	}

	public void setLsRowId(BigDecimal lsRowId) {
		this.lsRowId = lsRowId;
	}

	public String getLsScorecardType() {
		return this.lsScorecardType;
	}

	public void setLsScorecardType(String lsScorecardType) {
		this.lsScorecardType = lsScorecardType;
	}

	public BigDecimal getLsUniqueId() {
		return this.lsUniqueId;
	}

	public void setLsUniqueId(BigDecimal lsUniqueId) {
		this.lsUniqueId = lsUniqueId;
	}

	public BigDecimal getLpstpMaster() {
		return lpstpMaster;
	}

	public void setLpstpMaster(BigDecimal lpstpMaster) {
		this.lpstpMaster = lpstpMaster;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	@JsonIgnore
	public long getLsFacNo() {
		return lsFacNo;
	}

	public void setLsFacNo(long lsFacNo) {
		this.lsFacNo = lsFacNo;
	}

}
