package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;
import com.sai.lendperfect.setupmodel.LpstpProductDet;

/**
 * The persistent class for the LPCORP_CIR_ANNEX database table.
 * 
 */
@Entity
@Table(name = "LPCORP_CIR_ANNEX")
@NamedQuery(name = "LpcorpCirAnnex.findAll", query = "SELECT l FROM LpcorpCirAnnex l")
public class LpcorpCirAnnex implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "LCA_CREATED_BY")
	private String lcaCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LCA_CREATED_ON")
	private Date lcaCreatedOn;

	@Column(name = "LCA_DESCRIPTION")
	private String lcaDescription;

	@Column(name = "LCA_MODIFIED_BY")
	private String lcaModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name = "LCA_MODIFIED_ON")
	private Date lcaModifiedOn;

	@Column(name = "LCA_PARENT_ID")
	private BigDecimal lcaParentId;

	@Column(name = "LCA_ACTIVE")
	private String lcaActive;

	@Column(name = "LCA_REMARKS")
	private String lcaRemarks;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "LCA_ROW_ID")
	private BigDecimal lcaRowId;

	// bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "LCA_PROP_NO")
	private LpcomProposal lpcomProposal;

	// bi-directional many-to-one association to LpstpProductDet
	@ManyToOne
	@JoinColumn(name = "LCA_PROD_ID")
	private LpstpProductDet lpstpProductDet;

	@Column(name = "LCA_LAM_ROW_ID", nullable = false)
	private BigDecimal lcaLamRowId;

	public LpcorpCirAnnex() {
	}

	public String getLcaCreatedBy() {
		return this.lcaCreatedBy;
	}

	public void setLcaCreatedBy(String lcaCreatedBy) {
		this.lcaCreatedBy = lcaCreatedBy;
	}

	public Date getLcaCreatedOn() {
		return this.lcaCreatedOn;
	}

	public void setLcaCreatedOn(Date lcaCreatedOn) {
		this.lcaCreatedOn = lcaCreatedOn;
	}

	public String getLcaDescription() {
		return this.lcaDescription;
	}

	public void setLcaDescription(String lcaDescription) {
		this.lcaDescription = lcaDescription;
	}

	public String getLcaModifiedBy() {
		return this.lcaModifiedBy;
	}

	public void setLcaModifiedBy(String lcaModifiedBy) {
		this.lcaModifiedBy = lcaModifiedBy;
	}

	public Date getLcaModifiedOn() {
		return this.lcaModifiedOn;
	}

	public void setLcaModifiedOn(Date lcaModifiedOn) {
		this.lcaModifiedOn = lcaModifiedOn;
	}

	public BigDecimal getLcaParentId() {
		return this.lcaParentId;
	}

	public void setLcaParentId(BigDecimal lcaParentId) {
		this.lcaParentId = lcaParentId;
	}

	public String getLcaRemarks() {
		return this.lcaRemarks;
	}

	public void setLcaRemarks(String lcaRemarks) {
		this.lcaRemarks = lcaRemarks;
	}

	public BigDecimal getLcaRowId() {
		return this.lcaRowId;
	}

	public void setLcaRowId(BigDecimal lcaRowId) {
		this.lcaRowId = lcaRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

	public String getLcaActive() {
		return lcaActive;
	}

	public void setLcaActive(String lcaActive) {
		this.lcaActive = lcaActive;
	}

	public LpstpProductDet getLpstpProductDet() {
		return lpstpProductDet;
	}

	public void setLpstpProductDet(LpstpProductDet lpstpProductDet) {
		this.lpstpProductDet = lpstpProductDet;
	}

	public BigDecimal getLcaLamRowId() {
		return lcaLamRowId;
	}

	public void setLcaLamRowId(BigDecimal lcaLamRowId) {
		this.lcaLamRowId = lcaLamRowId;
	}

}