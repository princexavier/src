package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_CHRUN_CFDET database table.
 * 
 */
@Entity
@Table(name="LPCORP_CHRUN_CFDET")
@NamedQueries({
	@NamedQuery(name="LpcorpChrunCfdet.findAll", query="SELECT l FROM LpcorpChrunCfdet l"),
	@NamedQuery(name="LpcorpChrunCfdet.getDataByPreposalId", 
	query="SELECT l FROM LpcorpChrunCfdet l where l.lpchProposalId=:lpchProposalId "
			+ "and ( l.lpchAvailable is null or l.lpchAvailable=:lpchAvailable  ) "
			+ "and (l.lpchIsdelete is null or l.lpchIsdelete=:lpchIsdelete )  "
			+ "order by l.lpchMonthCounter asc"),
	@NamedQuery(name="LpcorpChrunCfdet.updateAvaiblableByPreposalId", 
	query="UPDATE LpcorpChrunCfdet s SET s.lpchAvailable=:lpchAvailable,s.lpchIsdelete=:lpchIsdelete WHERE  s.lpchProposalId=:lpchProposalId "),
	
})
public class LpcorpChrunCfdet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPCH_ROW_ID")
	private long lpchRowid;

	@Column(name="LPCH_AVAILABLE")
	private String lpchAvailable;

	@Column(name="LPCH_AVG_CC_OD")
	private BigDecimal lpchAvgCcOd;

	@Column(name="LPCH_BNK_ACC_RCPT")
	private BigDecimal lpchBnkAccRcpt;

	@Column(name="LPCH_CREATED_BY")
	private String lpchCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPCH_CREATED_ON")
	private Date lpchCreatedOn;

	@Column(name="LPCH_DRS_REALIZATN")
	private BigDecimal lpchDrsRealizatn;

	@Column(name="LPCH_IN_CHQ_RTN")
	private BigDecimal lpchInChqRtn;

	@Column(name="LPCH_INST_RATE")
	private BigDecimal lpchInstRate;

	@Column(name="LPCH_ISDELETE")
	private String lpchIsdelete;

	@Column(name="LPCH_LOW_CC_OD")
	private BigDecimal lpchLowCcOd;

	@Column(name="LPCH_LOW_INST_DBT_CC_ACC")
	private BigDecimal lpchLowInstDbtCcAcc;

	@Column(name="LPCH_MODIFIED_BY")
	private String lpchModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPCH_MODIFIED_ON")
	private Date lpchModifiedOn;

	@Column(name="LPCH_MONTH",nullable=false)
	private String lpchMonth;

	@Column(name="LPCH_MONTH_COUNTER",nullable=false)
	private BigDecimal lpchMonthCounter;

	@Column(name="LPCH_OUT_CHQ_RTN")
	private BigDecimal lpchOutChqRtn;

	@Column(name="LPCH_PEAK_CC_OD")
	private BigDecimal lpchPeakCcOd;

	@Column(name="LPCH_PROPOSAL_ID",nullable=false)
	private BigDecimal lpchProposalId;

	@Column(name="LPCH_RCPT_BY_DRS_PRTAGE")
	private BigDecimal lpchRcptByDrsPrtage;

	@Column(name="LPCH_VARIATION")
	private BigDecimal lpchVariation;

	public LpcorpChrunCfdet() {
	}

	public long getLpchRowid() {
		return this.lpchRowid;
	}

	public void setLpchRowid(long lpchRowid) {
		this.lpchRowid = lpchRowid;
	}

	public String getLpchAvailable() {
		return this.lpchAvailable;
	}

	public void setLpchAvailable(String lpchAvailable) {
		this.lpchAvailable = lpchAvailable;
	}

	public BigDecimal getLpchAvgCcOd() {
		return this.lpchAvgCcOd;
	}

	public void setLpchAvgCcOd(BigDecimal lpchAvgCcOd) {
		this.lpchAvgCcOd = lpchAvgCcOd;
	}

	public BigDecimal getLpchBnkAccRcpt() {
		return this.lpchBnkAccRcpt;
	}

	public void setLpchBnkAccRcpt(BigDecimal lpchBnkAccRcpt) {
		this.lpchBnkAccRcpt = lpchBnkAccRcpt;
	}

	public String getLpchCreatedBy() {
		return this.lpchCreatedBy;
	}

	public void setLpchCreatedBy(String lpchCreatedBy) {
		this.lpchCreatedBy = lpchCreatedBy;
	}

	public Date getLpchCreatedOn() {
		return this.lpchCreatedOn;
	}

	public void setLpchCreatedOn(Date lpchCreatedOn) {
		this.lpchCreatedOn = lpchCreatedOn;
	}

	public BigDecimal getLpchDrsRealizatn() {
		return this.lpchDrsRealizatn;
	}

	public void setLpchDrsRealizatn(BigDecimal lpchDrsRealizatn) {
		this.lpchDrsRealizatn = lpchDrsRealizatn;
	}

	public BigDecimal getLpchInChqRtn() {
		return this.lpchInChqRtn;
	}

	public void setLpchInChqRtn(BigDecimal lpchInChqRtn) {
		this.lpchInChqRtn = lpchInChqRtn;
	}

	public BigDecimal getLpchInstRate() {
		return this.lpchInstRate;
	}

	public void setLpchInstRate(BigDecimal lpchInstRate) {
		this.lpchInstRate = lpchInstRate;
	}

	public String getLpchIsdelete() {
		return this.lpchIsdelete;
	}

	public void setLpchIsdelete(String lpchIsdelete) {
		this.lpchIsdelete = lpchIsdelete;
	}

	public BigDecimal getLpchLowCcOd() {
		return this.lpchLowCcOd;
	}

	public void setLpchLowCcOd(BigDecimal lpchLowCcOd) {
		this.lpchLowCcOd = lpchLowCcOd;
	}

	public BigDecimal getLpchLowInstDbtCcAcc() {
		return this.lpchLowInstDbtCcAcc;
	}

	public void setLpchLowInstDbtCcAcc(BigDecimal lpchLowInstDbtCcAcc) {
		this.lpchLowInstDbtCcAcc = lpchLowInstDbtCcAcc;
	}

	public String getLpchModifiedBy() {
		return this.lpchModifiedBy;
	}

	public void setLpchModifiedBy(String lpchModifiedBy) {
		this.lpchModifiedBy = lpchModifiedBy;
	}

	public Date getLpchModifiedOn() {
		return this.lpchModifiedOn;
	}

	public void setLpchModifiedOn(Date lpchModifiedOn) {
		this.lpchModifiedOn = lpchModifiedOn;
	}

	public String getLpchMonth() {
		return this.lpchMonth;
	}

	public void setLpchMonth(String lpchMonth) {
		this.lpchMonth = lpchMonth;
	}

	public BigDecimal getLpchMonthCounter() {
		return this.lpchMonthCounter;
	}

	public void setLpchMonthCounter(BigDecimal lpchMonthCounter) {
		this.lpchMonthCounter = lpchMonthCounter;
	}

	public BigDecimal getLpchOutChqRtn() {
		return this.lpchOutChqRtn;
	}

	public void setLpchOutChqRtn(BigDecimal lpchOutChqRtn) {
		this.lpchOutChqRtn = lpchOutChqRtn;
	}

	public BigDecimal getLpchPeakCcOd() {
		return this.lpchPeakCcOd;
	}

	public void setLpchPeakCcOd(BigDecimal lpchPeakCcOd) {
		this.lpchPeakCcOd = lpchPeakCcOd;
	}

	public BigDecimal getLpchProposalId() {
		return this.lpchProposalId;
	}

	public void setLpchProposalId(BigDecimal lpchProposalId) {
		this.lpchProposalId = lpchProposalId;
	}

	public BigDecimal getLpchRcptByDrsPrtage() {
		return this.lpchRcptByDrsPrtage;
	}

	public void setLpchRcptByDrsPrtage(BigDecimal lpchRcptByDrsPrtage) {
		this.lpchRcptByDrsPrtage = lpchRcptByDrsPrtage;
	}

	public BigDecimal getLpchVariation() {
		return this.lpchVariation;
	}

	public void setLpchVariation(BigDecimal lpchVariation) {
		this.lpchVariation = lpchVariation;
	}

	/**
	 * @param lpchRowid
	 * @param lpchProposalId
	 * @param lpchMonth
	 * @param lpchMonthCounter
	 * @param lpchAvgCcOd
	 * @param lpchBnkAccRcpt
	 * @param lpchDrsRealizatn
	 * @param lpchInChqRtn
	 * @param lpchInstRate
	 * @param lpchLowCcOd
	 * @param lpchLowInstDbtCcAcc
	 * @param lpchOutChqRtn
	 * @param lpchPeakCcOd
	 * @param lpchRcptByDrsPrtage
	 * @param lpchVariation
	 * @param lpchAvailable
	 * @param lpchIsdelete
	 */
	public LpcorpChrunCfdet(long lpchRowid, BigDecimal lpchProposalId, String lpchMonth, BigDecimal lpchMonthCounter,
			BigDecimal lpchAvgCcOd, BigDecimal lpchBnkAccRcpt, BigDecimal lpchDrsRealizatn, BigDecimal lpchInChqRtn,
			BigDecimal lpchInstRate, BigDecimal lpchLowCcOd, BigDecimal lpchLowInstDbtCcAcc, BigDecimal lpchOutChqRtn,
			BigDecimal lpchPeakCcOd, BigDecimal lpchRcptByDrsPrtage, BigDecimal lpchVariation, String lpchAvailable,
			String lpchIsdelete) {
		this.lpchRowid = lpchRowid;
		this.lpchProposalId = lpchProposalId;
		this.lpchMonth = lpchMonth;
		this.lpchMonthCounter = lpchMonthCounter;
		this.lpchAvgCcOd = lpchAvgCcOd;
		this.lpchBnkAccRcpt = lpchBnkAccRcpt;
		this.lpchDrsRealizatn = lpchDrsRealizatn;
		this.lpchInChqRtn = lpchInChqRtn;
		this.lpchInstRate = lpchInstRate;
		this.lpchLowCcOd = lpchLowCcOd;
		this.lpchLowInstDbtCcAcc = lpchLowInstDbtCcAcc;
		this.lpchOutChqRtn = lpchOutChqRtn;
		this.lpchPeakCcOd = lpchPeakCcOd;
		this.lpchRcptByDrsPrtage = lpchRcptByDrsPrtage;
		this.lpchVariation = lpchVariation;
		this.lpchAvailable = lpchAvailable;
		this.lpchIsdelete = lpchIsdelete;
	}
	/**
	 * @param lpchRowid
	 * @param lpchProposalId
	 * @param lpchAvgCcOd
	 * @param lpchBnkAccRcpt
	 * @param lpchDrsRealizatn
	 * @param lpchInChqRtn
	 * @param lpchInstRate
	 * @param lpchLowCcOd
	 * @param lpchLowInstDbtCcAcc
	 * @param lpchOutChqRtn
	 * @param lpchPeakCcOd
	 * @param lpchRcptByDrsPrtage
	 * @param lpchVariation
	 * @param lpchAvailable
	 * @param lpchIsdelete
	 */
	public LpcorpChrunCfdet(long lpchRowid, BigDecimal lpchProposalId,
			BigDecimal lpchAvgCcOd, BigDecimal lpchBnkAccRcpt, BigDecimal lpchDrsRealizatn, BigDecimal lpchInChqRtn,
			BigDecimal lpchInstRate, BigDecimal lpchLowCcOd, BigDecimal lpchLowInstDbtCcAcc, BigDecimal lpchOutChqRtn,
			BigDecimal lpchPeakCcOd, BigDecimal lpchRcptByDrsPrtage, BigDecimal lpchVariation, String lpchAvailable,
			String lpchIsdelete) {
		this.lpchRowid = lpchRowid;
		this.lpchProposalId = lpchProposalId;
		this.lpchAvgCcOd = lpchAvgCcOd;
		this.lpchBnkAccRcpt = lpchBnkAccRcpt;
		this.lpchDrsRealizatn = lpchDrsRealizatn;
		this.lpchInChqRtn = lpchInChqRtn;
		this.lpchInstRate = lpchInstRate;
		this.lpchLowCcOd = lpchLowCcOd;
		this.lpchLowInstDbtCcAcc = lpchLowInstDbtCcAcc;
		this.lpchOutChqRtn = lpchOutChqRtn;
		this.lpchPeakCcOd = lpchPeakCcOd;
		this.lpchRcptByDrsPrtage = lpchRcptByDrsPrtage;
		this.lpchVariation = lpchVariation;
		this.lpchAvailable = lpchAvailable;
		this.lpchIsdelete = lpchIsdelete;
	}

}