package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_REFERENCE_DET database table.
 * 
 */
@Entity
@Table(name="LPCORP_REFERENCE_DET")
@NamedQuery(name="LpcorpReferenceDet.findAll", query="SELECT l FROM LpcorpReferenceDet l")
public class LpcorpReferenceDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LR_CREATED_BY")
	private String lrCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LR_CREATED_ON")
	private Date lrCreatedOn;

	@Column(name="LR_FILLER_1")
	private String lrFiller1;

	@Column(name="LR_FILLER_2")
	private String lrFiller2;

	@Column(name="LR_MODIFIED_BY")
	private String lrModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LR_MODIFIED_ON")
	private Date lrModifiedOn;

	@Column(name="LR_REF_BANK_RELATION")
	private String lrRefBankRelation;

	@Column(name="LR_REF_BRIEF")
	private String lrRefBrief;

	@Column(name="LR_REF_PERSON")
	private String lrRefPerson;

	@Column(name="LR_REF_TAKEN_BY")
	private String lrRefTakenBy;

	@Column(name="LR_REF_TYPE")
	private String lrRefType;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LR_ROW_ID")
	private BigDecimal lrRowId;

	@Column(name="LR_SEQ_NO")
	private BigDecimal lrSeqNo;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name="LR_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpReferenceDet() {
	}

	public String getLrCreatedBy() {
		return this.lrCreatedBy;
	}

	public void setLrCreatedBy(String lrCreatedBy) {
		this.lrCreatedBy = lrCreatedBy;
	}

	public Date getLrCreatedOn() {
		return this.lrCreatedOn;
	}

	public void setLrCreatedOn(Date lrCreatedOn) {
		this.lrCreatedOn = lrCreatedOn;
	}

	public String getLrFiller1() {
		return this.lrFiller1;
	}

	public void setLrFiller1(String lrFiller1) {
		this.lrFiller1 = lrFiller1;
	}

	public String getLrFiller2() {
		return this.lrFiller2;
	}

	public void setLrFiller2(String lrFiller2) {
		this.lrFiller2 = lrFiller2;
	}

	public String getLrModifiedBy() {
		return this.lrModifiedBy;
	}

	public void setLrModifiedBy(String lrModifiedBy) {
		this.lrModifiedBy = lrModifiedBy;
	}

	public Date getLrModifiedOn() {
		return this.lrModifiedOn;
	}

	public void setLrModifiedOn(Date lrModifiedOn) {
		this.lrModifiedOn = lrModifiedOn;
	}

	public String getLrRefBankRelation() {
		return this.lrRefBankRelation;
	}

	public void setLrRefBankRelation(String lrRefBankRelation) {
		this.lrRefBankRelation = lrRefBankRelation;
	}

	public String getLrRefBrief() {
		return this.lrRefBrief;
	}

	public void setLrRefBrief(String lrRefBrief) {
		this.lrRefBrief = lrRefBrief;
	}

	public String getLrRefPerson() {
		return this.lrRefPerson;
	}

	public void setLrRefPerson(String lrRefPerson) {
		this.lrRefPerson = lrRefPerson;
	}

	public String getLrRefTakenBy() {
		return this.lrRefTakenBy;
	}

	public void setLrRefTakenBy(String lrRefTakenBy) {
		this.lrRefTakenBy = lrRefTakenBy;
	}

	public String getLrRefType() {
		return this.lrRefType;
	}

	public void setLrRefType(String lrRefType) {
		this.lrRefType = lrRefType;
	}

	public BigDecimal getLrRowId() {
		return this.lrRowId;
	}

	public void setLrRowId(BigDecimal lrRowId) {
		this.lrRowId = lrRowId;
	}

	public BigDecimal getLrSeqNo() {
		return this.lrSeqNo;
	}

	public void setLrSeqNo(BigDecimal lrSeqNo) {
		this.lrSeqNo = lrSeqNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}