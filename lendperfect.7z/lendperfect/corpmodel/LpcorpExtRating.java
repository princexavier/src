package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_EXT_RATING database table.
 * 
 */
@Entity
@Table(name="LPCORP_EXT_RATING")
@NamedQuery(name="LpcorpExtRating.findAll", query="SELECT l FROM LpcorpExtRating l")
public class LpcorpExtRating implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LER_AGENCY_CHANGE")
	private String lerAgencyChange;

	@Column(name="LER_CREATED_BY")
	private String lerCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LER_CREATED_ON")
	private Date lerCreatedOn;

	@Column(name="LER_CURR_RATING")
	private String lerCurrRating;

	@Column(name="LER_LNG_TERM_FAC")
	private String lerLngTermFac;

	@Column(name="LER_LNG_TERM_RAT")
	private String lerLngTermRat;

	@Column(name="LER_MODIFIED_BY")
	private String lerModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LER_MODIFIED_ON")
	private Date lerModifiedOn;

	@Column(name="LER_PREV_RATING")
	private String lerPrevRating;

	@Column(name="LER_RAT_AGENCY")
	private String lerRatAgency;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="LER_ROW_ID")
	private BigDecimal lerRowId;

	@Column(name="LER_SEQ_NO")
	private BigDecimal lerSeqNo;

	@Column(name="LER_SHRT_TERM_FAC")
	private String lerShrtTermFac;

	@Column(name="LER_SHRT_TERM_RAT")
	private String lerShrtTermRat;

	@JsonIgnore 
	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JoinColumn(name="LER_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpExtRating() {
	}

	public String getLerAgencyChange() {
		return this.lerAgencyChange;
	}

	public void setLerAgencyChange(String lerAgencyChange) {
		this.lerAgencyChange = lerAgencyChange;
	}

	public String getLerCreatedBy() {
		return this.lerCreatedBy;
	}

	public void setLerCreatedBy(String lerCreatedBy) {
		this.lerCreatedBy = lerCreatedBy;
	}

	public Date getLerCreatedOn() {
		return this.lerCreatedOn;
	}

	public void setLerCreatedOn(Date lerCreatedOn) {
		this.lerCreatedOn = lerCreatedOn;
	}

	public String getLerCurrRating() {
		return this.lerCurrRating;
	}

	public void setLerCurrRating(String lerCurrRating) {
		this.lerCurrRating = lerCurrRating;
	}

	public String getLerLngTermFac() {
		return this.lerLngTermFac;
	}

	public void setLerLngTermFac(String lerLngTermFac) {
		this.lerLngTermFac = lerLngTermFac;
	}

	public String getLerLngTermRat() {
		return this.lerLngTermRat;
	}

	public void setLerLngTermRat(String lerLngTermRat) {
		this.lerLngTermRat = lerLngTermRat;
	}

	public String getLerModifiedBy() {
		return this.lerModifiedBy;
	}

	public void setLerModifiedBy(String lerModifiedBy) {
		this.lerModifiedBy = lerModifiedBy;
	}

	public Date getLerModifiedOn() {
		return this.lerModifiedOn;
	}

	public void setLerModifiedOn(Date lerModifiedOn) {
		this.lerModifiedOn = lerModifiedOn;
	}

	public String getLerPrevRating() {
		return this.lerPrevRating;
	}

	public void setLerPrevRating(String lerPrevRating) {
		this.lerPrevRating = lerPrevRating;
	}

	public String getLerRatAgency() {
		return this.lerRatAgency;
	}

	public void setLerRatAgency(String lerRatAgency) {
		this.lerRatAgency = lerRatAgency;
	}

	public BigDecimal getLerRowId() {
		return this.lerRowId;
	}

	public void setLerRowId(BigDecimal lerRowId) {
		this.lerRowId = lerRowId;
	}

	public BigDecimal getLerSeqNo() {
		return this.lerSeqNo;
	}

	public void setLerSeqNo(BigDecimal lerSeqNo) {
		this.lerSeqNo = lerSeqNo;
	}

	public String getLerShrtTermFac() {
		return this.lerShrtTermFac;
	}

	public void setLerShrtTermFac(String lerShrtTermFac) {
		this.lerShrtTermFac = lerShrtTermFac;
	}

	public String getLerShrtTermRat() {
		return this.lerShrtTermRat;
	}

	public void setLerShrtTermRat(String lerShrtTermRat) {
		this.lerShrtTermRat = lerShrtTermRat;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}