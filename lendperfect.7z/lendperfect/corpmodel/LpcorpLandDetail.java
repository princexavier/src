package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_LAND_DETAILS database table.
 * 
 */
@Entity
@Table(name="LPCORP_LAND_DETAILS")
@NamedQuery(name="LpcorpLandDetail.findAll", query="SELECT l FROM LpcorpLandDetail l")
public class LpcorpLandDetail implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LLD_CREATED_BY")
	private String lldCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LLD_CREATED_ON")
	private Date lldCreatedOn;

	@Column(name="LLD_LAND_UNIT")
	private String lldLandUnit;

	@Column(name="LLD_LEASED_LAND")
	private BigDecimal lldLeasedLand;

	@Column(name="LLD_MODIFIED_BY")
	private String lldModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LLD_MODIFIED_ON")
	private Date lldModifiedOn;

	@Column(name="LLD_OWNED_BY")
	private String lldOwnedBy;

	@Column(name="LLD_OWNED_LAND")
	private BigDecimal lldOwnedLand;

	@Id
	@Column(name="LLD_ROW_ID")
	private BigDecimal lldRowId;

	@Column(name="LLD_SEQ_NO")
	private BigDecimal lldSeqNo;

	@Column(name="LLD_TOTAL_LAND")
	private BigDecimal lldTotalLand;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JoinColumn(name="LLD_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpLandDetail() {
	}

	public String getLldCreatedBy() {
		return this.lldCreatedBy;
	}

	public void setLldCreatedBy(String lldCreatedBy) {
		this.lldCreatedBy = lldCreatedBy;
	}

	public Date getLldCreatedOn() {
		return this.lldCreatedOn;
	}

	public void setLldCreatedOn(Date lldCreatedOn) {
		this.lldCreatedOn = lldCreatedOn;
	}

	public String getLldLandUnit() {
		return this.lldLandUnit;
	}

	public void setLldLandUnit(String lldLandUnit) {
		this.lldLandUnit = lldLandUnit;
	}

	public BigDecimal getLldLeasedLand() {
		return this.lldLeasedLand;
	}

	public void setLldLeasedLand(BigDecimal lldLeasedLand) {
		this.lldLeasedLand = lldLeasedLand;
	}

	public String getLldModifiedBy() {
		return this.lldModifiedBy;
	}

	public void setLldModifiedBy(String lldModifiedBy) {
		this.lldModifiedBy = lldModifiedBy;
	}

	public Date getLldModifiedOn() {
		return this.lldModifiedOn;
	}

	public void setLldModifiedOn(Date lldModifiedOn) {
		this.lldModifiedOn = lldModifiedOn;
	}

	public String getLldOwnedBy() {
		return this.lldOwnedBy;
	}

	public void setLldOwnedBy(String lldOwnedBy) {
		this.lldOwnedBy = lldOwnedBy;
	}

	public BigDecimal getLldOwnedLand() {
		return this.lldOwnedLand;
	}

	public void setLldOwnedLand(BigDecimal lldOwnedLand) {
		this.lldOwnedLand = lldOwnedLand;
	}

	public BigDecimal getLldRowId() {
		return this.lldRowId;
	}

	public void setLldRowId(BigDecimal lldRowId) {
		this.lldRowId = lldRowId;
	}

	public BigDecimal getLldSeqNo() {
		return this.lldSeqNo;
	}

	public void setLldSeqNo(BigDecimal lldSeqNo) {
		this.lldSeqNo = lldSeqNo;
	}

	public BigDecimal getLldTotalLand() {
		return this.lldTotalLand;
	}

	public void setLldTotalLand(BigDecimal lldTotalLand) {
		this.lldTotalLand = lldTotalLand;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}