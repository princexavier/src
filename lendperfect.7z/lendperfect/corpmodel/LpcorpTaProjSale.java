package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_TA_PROJ_SALES database table.
 * 
 */
@Entity
@Table(name="LPCORP_TA_PROJ_SALES")
@NamedQuery(name="LpcorpTaProjSale.findAll", query="SELECT l FROM LpcorpTaProjSale l")
public class LpcorpTaProjSale implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LTPS_ADHOC_LIMIT")
	private BigDecimal ltpsAdhocLimit;

	@Column(name="LTPS_CREATED_BY")
	private String ltpsCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LTPS_CREATED_ON")
	private Date ltpsCreatedOn;

	@Column(name="LTPS_CREDIT_REMARKS")
	private String ltpsCreditRemarks;

	@Column(name="LTPS_CURR_OS")
	private BigDecimal ltpsCurrOs;

	@Column(name="LTPS_CUST_ID")
	private BigDecimal ltpsCustId;

	@Column(name="LTPS_DEALER_BG")
	private String ltpsDealerBg;

	@Column(name="LTPS_INC_SALES")
	private BigDecimal ltpsIncSales;

	@Column(name="LTPS_MODIFIED_BY")
	private String ltpsModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LTPS_MODIFIED_ON")
	private Date ltpsModifiedOn;

	@Column(name="LTPS_MONTH_1")
	private String ltpsMonth1;

	@Column(name="LTPS_MONTH_2")
	private String ltpsMonth2;

	@Column(name="LTPS_MONTH_3")
	private String ltpsMonth3;

	@Column(name="LTPS_ONE_TIME_ADHOC")
	private BigDecimal ltpsOneTimeAdhoc;

	@Column(name="LTPS_PERCNT_PROJ_SALES")
	private BigDecimal ltpsPercntProjSales;

	@Column(name="LTPS_PREV_YR_SALES")
	private BigDecimal ltpsPrevYrSales;

	@Column(name="LTPS_PROJ_SALES")
	private BigDecimal ltpsProjSales;

	@Column(name="LTPS_PROP_NO")
	private BigDecimal ltpsPropNo;

	@Column(name="LTPS_PROPOSED_LIMIT")
	private BigDecimal ltpsProposedLimit;

	@Column(name="LTPS_ROI")
	private BigDecimal ltpsRoi;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LTPS_ROW_ID")
	private BigDecimal ltpsRowId;

	@Column(name="LTPS_SALES_REMARKS")
	private String ltpsSalesRemarks;

	@Column(name="LTPS_TOT_LIMITS")
	private BigDecimal ltpsTotLimits;

	@Column(name="LTPS_TRANCHE")
	private BigDecimal ltpsTranche;

	public LpcorpTaProjSale() {
	}

	public BigDecimal getLtpsAdhocLimit() {
		return this.ltpsAdhocLimit;
	}

	public void setLtpsAdhocLimit(BigDecimal ltpsAdhocLimit) {
		this.ltpsAdhocLimit = ltpsAdhocLimit;
	}

	public String getLtpsCreatedBy() {
		return this.ltpsCreatedBy;
	}

	public void setLtpsCreatedBy(String ltpsCreatedBy) {
		this.ltpsCreatedBy = ltpsCreatedBy;
	}

	public Date getLtpsCreatedOn() {
		return this.ltpsCreatedOn;
	}

	public void setLtpsCreatedOn(Date ltpsCreatedOn) {
		this.ltpsCreatedOn = ltpsCreatedOn;
	}

	public String getLtpsCreditRemarks() {
		return this.ltpsCreditRemarks;
	}

	public void setLtpsCreditRemarks(String ltpsCreditRemarks) {
		this.ltpsCreditRemarks = ltpsCreditRemarks;
	}

	public BigDecimal getLtpsCurrOs() {
		return this.ltpsCurrOs;
	}

	public void setLtpsCurrOs(BigDecimal ltpsCurrOs) {
		this.ltpsCurrOs = ltpsCurrOs;
	}

	public BigDecimal getLtpsCustId() {
		return this.ltpsCustId;
	}

	public void setLtpsCustId(BigDecimal ltpsCustId) {
		this.ltpsCustId = ltpsCustId;
	}

	public String getLtpsDealerBg() {
		return this.ltpsDealerBg;
	}

	public void setLtpsDealerBg(String ltpsDealerBg) {
		this.ltpsDealerBg = ltpsDealerBg;
	}

	public BigDecimal getLtpsIncSales() {
		return this.ltpsIncSales;
	}

	public void setLtpsIncSales(BigDecimal ltpsIncSales) {
		this.ltpsIncSales = ltpsIncSales;
	}

	public String getLtpsModifiedBy() {
		return this.ltpsModifiedBy;
	}

	public void setLtpsModifiedBy(String ltpsModifiedBy) {
		this.ltpsModifiedBy = ltpsModifiedBy;
	}

	public Date getLtpsModifiedOn() {
		return this.ltpsModifiedOn;
	}

	public void setLtpsModifiedOn(Date ltpsModifiedOn) {
		this.ltpsModifiedOn = ltpsModifiedOn;
	}

	public String getLtpsMonth1() {
		return this.ltpsMonth1;
	}

	public void setLtpsMonth1(String ltpsMonth1) {
		this.ltpsMonth1 = ltpsMonth1;
	}

	public String getLtpsMonth2() {
		return this.ltpsMonth2;
	}

	public void setLtpsMonth2(String ltpsMonth2) {
		this.ltpsMonth2 = ltpsMonth2;
	}

	public String getLtpsMonth3() {
		return this.ltpsMonth3;
	}

	public void setLtpsMonth3(String ltpsMonth3) {
		this.ltpsMonth3 = ltpsMonth3;
	}

	public BigDecimal getLtpsOneTimeAdhoc() {
		return this.ltpsOneTimeAdhoc;
	}

	public void setLtpsOneTimeAdhoc(BigDecimal ltpsOneTimeAdhoc) {
		this.ltpsOneTimeAdhoc = ltpsOneTimeAdhoc;
	}

	public BigDecimal getLtpsPercntProjSales() {
		return this.ltpsPercntProjSales;
	}

	public void setLtpsPercntProjSales(BigDecimal ltpsPercntProjSales) {
		this.ltpsPercntProjSales = ltpsPercntProjSales;
	}

	public BigDecimal getLtpsPrevYrSales() {
		return this.ltpsPrevYrSales;
	}

	public void setLtpsPrevYrSales(BigDecimal ltpsPrevYrSales) {
		this.ltpsPrevYrSales = ltpsPrevYrSales;
	}

	public BigDecimal getLtpsProjSales() {
		return this.ltpsProjSales;
	}

	public void setLtpsProjSales(BigDecimal ltpsProjSales) {
		this.ltpsProjSales = ltpsProjSales;
	}

	public BigDecimal getLtpsPropNo() {
		return this.ltpsPropNo;
	}

	public void setLtpsPropNo(BigDecimal ltpsPropNo) {
		this.ltpsPropNo = ltpsPropNo;
	}

	public BigDecimal getLtpsProposedLimit() {
		return this.ltpsProposedLimit;
	}

	public void setLtpsProposedLimit(BigDecimal ltpsProposedLimit) {
		this.ltpsProposedLimit = ltpsProposedLimit;
	}

	public BigDecimal getLtpsRoi() {
		return this.ltpsRoi;
	}

	public void setLtpsRoi(BigDecimal ltpsRoi) {
		this.ltpsRoi = ltpsRoi;
	}

	public BigDecimal getLtpsRowId() {
		return this.ltpsRowId;
	}

	public void setLtpsRowId(BigDecimal ltpsRowId) {
		this.ltpsRowId = ltpsRowId;
	}

	public String getLtpsSalesRemarks() {
		return this.ltpsSalesRemarks;
	}

	public void setLtpsSalesRemarks(String ltpsSalesRemarks) {
		this.ltpsSalesRemarks = ltpsSalesRemarks;
	}

	public BigDecimal getLtpsTotLimits() {
		return this.ltpsTotLimits;
	}

	public void setLtpsTotLimits(BigDecimal ltpsTotLimits) {
		this.ltpsTotLimits = ltpsTotLimits;
	}

	public BigDecimal getLtpsTranche() {
		return this.ltpsTranche;
	}

	public void setLtpsTranche(BigDecimal ltpsTranche) {
		this.ltpsTranche = ltpsTranche;
	}

}