
package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.NamedNativeQuery;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_WC_ANALYSIS database table.
 * 
 */
@Entity
@Table(name="LPCORP_WC_ANALYSIS")
@NamedQueries({
	@NamedQuery(name="LpcorpWcAnalysis.findAll", query="SELECT l FROM LpcorpWcAnalysis l"),
	@NamedQuery(name="LpcorpWcAnalysis.getDataByPreposalId", 
	query="SELECT l FROM LpcorpWcAnalysis l where l.lpwcProposalId=:lpwcProposalId "
			+ "and ( l.lpwcAvailable is null or l.lpwcAvailable=:lpwcAvailable  ) "
			+ "and (l.lpwcIsdelete is null or l.lpwcIsdelete=:lpwcIsdelete )  "
			+ "order by l.lpwcMonthCounter asc"),
	@NamedQuery(name="LpcorpWcAnalysis.updateAvaiblableByPreposalId", 
	query="UPDATE LpcorpWcAnalysis s SET s.lpwcAvailable=:lpwcAvailable,s.lpwcIsdelete=:lpwcIsdelete WHERE  s.lpwcProposalId=:lpwcProposalId "),
	
	/*@NamedQuery(name="LpcorpWcAnalysis.getLast6monthData", 
	query="SELECT obj FROM ( select obj3 from LpcorpWcAnalysis obj3  where  obj3.lpwcMonthCounter!=( select max(obj2.lpwcMonthCounter )  from LpcorpWcAnalysis obj2 where obj2.lpwcProposalId=:lpwcProposalId"
					+ "and ( obj2.lpwcAvailable is null or obj2.lpwcAvailable=:lpwcAvailable  ) "
					+ "and (obj2.lpwcIsdelete is null or obj2.lpwcIsdelete=:lpwcIsdelete )  "
					+ " )    ORDER BY obj2.lpwcMonthCounter desc )    obj "
					+ "WHERE  obj.lpwcProposalId=:lpwcProposalId"
					+ "and ( obj.lpwcAvailable is null or obj.lpwcAvailable=:lpwcAvailable  ) "
					+ "and (obj.lpwcIsdelete is null or obj.lpwcIsdelete=:lpwcIsdelete )  "
					)*///+ " and  rownum <= 6 ORDER BY rownum desc")
})
@NamedNativeQuery(name="LpcorpWcAnalysis.getLast6monthData",
					query = "SELECT * FROM ( select * from LPCORP_WC_ANALYSIS obj3  where  obj3.LPWC_MONTH_COUNTER!=( select max(LPWC_MONTH_COUNTER )  from LPCORP_WC_ANALYSIS obj2  "
							+ " where obj2.LPWC_PROPOSAL_ID=:proposalId  and ( obj2.LPWC_AVAILABLE is null or obj2.LPWC_AVAILABLE=:avaivlable  ) "
							+ " and (obj2.LPWC_ISDELETE is null or obj2.LPWC_ISDELETE=:isdelete )  ) and "
							+ " obj3.LPWC_PROPOSAL_ID=:proposalId  and ( obj3.LPWC_AVAILABLE is null or obj3.LPWC_AVAILABLE=:avaivlable  ) "
							 + " and (obj3.LPWC_ISDELETE is null or obj3.LPWC_ISDELETE=:isdelete) "
							+ " ORDER BY obj3.LPWC_MONTH_COUNTER desc ) obj "
							+ " WHERE  obj.LPWC_PROPOSAL_ID=:proposalId and ( obj.LPWC_AVAILABLE is null or obj.LPWC_AVAILABLE=:avaivlable  ) "
							+ " and (obj.LPWC_ISDELETE is null or obj.LPWC_ISDELETE=:isdelete )   and  rownum <= 7    ORDER BY obj.LPWC_MONTH_COUNTER asc ",
							resultClass =LpcorpWcAnalysis.class
							 
					)
/*SELECT *
FROM (select * from LpcorpWcAnalysis s  where  LPWC_MONTH_COUNTER!=( select max(LPWC_MONTH_COUNTER )  from LPCORP_WC_ANALYSIS )ORDER BY LPWC_ROWID desc ) LPCORP_WC_ANALYSIS
WHERE rownum <= 6
ORDER BY rownum desc*/



public class LpcorpWcAnalysis implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LPWC_ROW_ID")
	private long lpwcRowid;

	@Column(name="LPWC_AVAILABLE")
	private String lpwcAvailable;

	@Column(name="LPWC_CREATED_BY")
	private String lpwcCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPWC_CREATED_ON")
	private Date lpwcCreatedOn;

	@Column(name="LPWC_CREDITORS")
	private BigDecimal lpwcCreditors;

	@Column(name="LPWC_DEB_LSR90_CHK_LST3MSALES")
	private BigDecimal lpwcDebLsr90ChkLst3msales;

	@Column(name="LPWC_DEB_LSR90_CHK_VARIATION")
	private BigDecimal lpwcDebLsr90ChkVariation;

	@Column(name="LPWC_DRAW_POWER")
	private BigDecimal lpwcDrawPower;

	@Column(name="LPWC_DTR_BTW_90TO180D")
	private BigDecimal lpwcDtrBtw90to180d;

	@Column(name="LPWC_DTR_LSR_180D")
	private BigDecimal lpwcDtrLsr180d;

	@Column(name="LPWC_DTR_LSR_90D")
	private BigDecimal lpwcDtrLsr90d;

	@Column(name="LPWC_ISDELETE")
	private String lpwcIsdelete;

	@Column(name="LPWC_MODIFIED_BY")
	private String lpwcModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LPWC_MODIFIED_ON")
	private Date lpwcModifiedOn;

	@Column(name="LPWC_MONTH",nullable=false)
	private String lpwcMonth;

	@Column(name="LPWC_MONTH_COUNTER",nullable=false)
	private BigDecimal lpwcMonthCounter;

	@Column(name="LPWC_NET_WORKING_CAPITAL")
	private BigDecimal lpwcNetWorkingCapital;

	@Column(name="LPWC_PROPOSAL_ID",nullable=false)
	private BigDecimal lpwcProposalId;

	@Column(name="LPWC_PURCHASES")
	private BigDecimal lpwcPurchases;

	@Column(name="LPWC_SALES")
	private BigDecimal lpwcSales;

	@Column(name="LPWC_SFC_GROSS_MARGIN_PRTAGE")
	private BigDecimal lpwcSfcGrossMarginPrtage;

	@Column(name="LPWC_SFC_TENTITIVE_STOCK")
	private BigDecimal lpwcSfcTentitiveStock;

	@Column(name="LPWC_SFC_VARIATION")
	private BigDecimal lpwcSfcVariation;

	@Column(name="LPWC_SFC_VARIATION_PRTAGE")
	private BigDecimal lpwcSfcVariationPrtage;

	@Column(name="LPWC_STOCK")
	private BigDecimal lpwcStock;

	@Column(name="LPWC_TOTAL_DTR")
	private BigDecimal lpwcTotalDtr;

	@Column(name="LPWC_WCCYL_CREDITOR")
	private BigDecimal lpwcWccylCreditor;

	@Column(name="LPWC_WCCYL_DEBTOR")
	private BigDecimal lpwcWccylDebtor;

	@Column(name="LPWC_WCCYL_NET")
	private BigDecimal lpwcWccylNet;

	@Column(name="LPWC_WCCYL_STOCK")
	private BigDecimal lpwcWccylStock;

	public LpcorpWcAnalysis() {
	}

	public long getLpwcRowid() {
		return this.lpwcRowid;
	}

	public void setLpwcRowid(long lpwcRowid) {
		this.lpwcRowid = lpwcRowid;
	}

	public String getLpwcAvailable() {
		return this.lpwcAvailable;
	}

	public void setLpwcAvailable(String lpwcAvailable) {
		this.lpwcAvailable = lpwcAvailable;
	}

	public String getLpwcCreatedBy() {
		return this.lpwcCreatedBy;
	}

	public void setLpwcCreatedBy(String lpwcCreatedBy) {
		this.lpwcCreatedBy = lpwcCreatedBy;
	}

	public Date getLpwcCreatedOn() {
		return this.lpwcCreatedOn;
	}

	public void setLpwcCreatedOn(Date lpwcCreatedOn) {
		this.lpwcCreatedOn = lpwcCreatedOn;
	}

	public BigDecimal getLpwcCreditors() {
		return this.lpwcCreditors;
	}

	public void setLpwcCreditors(BigDecimal lpwcCreditors) {
		this.lpwcCreditors = lpwcCreditors;
	}

	public BigDecimal getLpwcDebLsr90ChkLst3msales() {
		return this.lpwcDebLsr90ChkLst3msales;
	}

	public void setLpwcDebLsr90ChkLst3msales(BigDecimal lpwcDebLsr90ChkLst3msales) {
		this.lpwcDebLsr90ChkLst3msales = lpwcDebLsr90ChkLst3msales;
	}

	public BigDecimal getLpwcDebLsr90ChkVariation() {
		return this.lpwcDebLsr90ChkVariation;
	}

	public void setLpwcDebLsr90ChkVariation(BigDecimal lpwcDebLsr90ChkVariation) {
		this.lpwcDebLsr90ChkVariation = lpwcDebLsr90ChkVariation;
	}

	public BigDecimal getLpwcDrawPower() {
		return this.lpwcDrawPower;
	}

	public void setLpwcDrawPower(BigDecimal lpwcDrawPower) {
		this.lpwcDrawPower = lpwcDrawPower;
	}

	public BigDecimal getLpwcDtrBtw90to180d() {
		return this.lpwcDtrBtw90to180d;
	}

	public void setLpwcDtrBtw90to180d(BigDecimal lpwcDtrBtw90to180d) {
		this.lpwcDtrBtw90to180d = lpwcDtrBtw90to180d;
	}

	public BigDecimal getLpwcDtrLsr180d() {
		return this.lpwcDtrLsr180d;
	}

	public void setLpwcDtrLsr180d(BigDecimal lpwcDtrLsr180d) {
		this.lpwcDtrLsr180d = lpwcDtrLsr180d;
	}

	public BigDecimal getLpwcDtrLsr90d() {
		return this.lpwcDtrLsr90d;
	}

	public void setLpwcDtrLsr90d(BigDecimal lpwcDtrLsr90d) {
		this.lpwcDtrLsr90d = lpwcDtrLsr90d;
	}

	public String getLpwcIsdelete() {
		return this.lpwcIsdelete;
	}

	public void setLpwcIsdelete(String lpwcIsdelete) {
		this.lpwcIsdelete = lpwcIsdelete;
	}

	public String getLpwcModifiedBy() {
		return this.lpwcModifiedBy;
	}

	public void setLpwcModifiedBy(String lpwcModifiedBy) {
		this.lpwcModifiedBy = lpwcModifiedBy;
	}

	public Date getLpwcModifiedOn() {
		return this.lpwcModifiedOn;
	}

	public void setLpwcModifiedOn(Date lpwcModifiedOn) {
		this.lpwcModifiedOn = lpwcModifiedOn;
	}

	public String getLpwcMonth() {
		return this.lpwcMonth;
	}

	public void setLpwcMonth(String lpwcMonth) {
		this.lpwcMonth = lpwcMonth;
	}

	public BigDecimal getLpwcMonthCounter() {
		return this.lpwcMonthCounter;
	}

	public void setLpwcMonthCounter(BigDecimal lpwcMonthCounter) {
		this.lpwcMonthCounter = lpwcMonthCounter;
	}

	public BigDecimal getLpwcNetWorkingCapital() {
		return this.lpwcNetWorkingCapital;
	}

	public void setLpwcNetWorkingCapital(BigDecimal lpwcNetWorkingCapital) {
		this.lpwcNetWorkingCapital = lpwcNetWorkingCapital;
	}

	public BigDecimal getLpwcProposalId() {
		return this.lpwcProposalId;
	}

	public void setLpwcProposalId(BigDecimal lpwcProposalId) {
		this.lpwcProposalId = lpwcProposalId;
	}

	public BigDecimal getLpwcPurchases() {
		return this.lpwcPurchases;
	}

	public void setLpwcPurchases(BigDecimal lpwcPurchases) {
		this.lpwcPurchases = lpwcPurchases;
	}

	public BigDecimal getLpwcSales() {
		return this.lpwcSales;
	}

	public void setLpwcSales(BigDecimal lpwcSales) {
		this.lpwcSales = lpwcSales;
	}

	public BigDecimal getLpwcSfcGrossMarginPrtage() {
		return this.lpwcSfcGrossMarginPrtage;
	}

	public void setLpwcSfcGrossMarginPrtage(BigDecimal lpwcSfcGrossMarginPrtage) {
		this.lpwcSfcGrossMarginPrtage = lpwcSfcGrossMarginPrtage;
	}

	public BigDecimal getLpwcSfcTentitiveStock() {
		return this.lpwcSfcTentitiveStock;
	}

	public void setLpwcSfcTentitiveStock(BigDecimal lpwcSfcTentitiveStock) {
		this.lpwcSfcTentitiveStock = lpwcSfcTentitiveStock;
	}

	public BigDecimal getLpwcSfcVariation() {
		return this.lpwcSfcVariation;
	}

	public void setLpwcSfcVariation(BigDecimal lpwcSfcVariation) {
		this.lpwcSfcVariation = lpwcSfcVariation;
	}

	public BigDecimal getLpwcSfcVariationPrtage() {
		return this.lpwcSfcVariationPrtage;
	}

	public void setLpwcSfcVariationPrtage(BigDecimal lpwcSfcVariationPrtage) {
		this.lpwcSfcVariationPrtage = lpwcSfcVariationPrtage;
	}

	public BigDecimal getLpwcStock() {
		return this.lpwcStock;
	}

	public void setLpwcStock(BigDecimal lpwcStock) {
		this.lpwcStock = lpwcStock;
	}

	public BigDecimal getLpwcTotalDtr() {
		return this.lpwcTotalDtr;
	}

	public void setLpwcTotalDtr(BigDecimal lpwcTotalDtr) {
		this.lpwcTotalDtr = lpwcTotalDtr;
	}

	public BigDecimal getLpwcWccylCreditor() {
		return this.lpwcWccylCreditor;
	}

	public void setLpwcWccylCreditor(BigDecimal lpwcWccylCreditor) {
		this.lpwcWccylCreditor = lpwcWccylCreditor;
	}

	public BigDecimal getLpwcWccylDebtor() {
		return this.lpwcWccylDebtor;
	}

	public void setLpwcWccylDebtor(BigDecimal lpwcWccylDebtor) {
		this.lpwcWccylDebtor = lpwcWccylDebtor;
	}

	public BigDecimal getLpwcWccylNet() {
		return this.lpwcWccylNet;
	}

	public void setLpwcWccylNet(BigDecimal lpwcWccylNet) {
		this.lpwcWccylNet = lpwcWccylNet;
	}

	public BigDecimal getLpwcWccylStock() {
		return this.lpwcWccylStock;
	}

	public void setLpwcWccylStock(BigDecimal lpwcWccylStock) {
		this.lpwcWccylStock = lpwcWccylStock;
	}

	/**
	 * @param lpwcRowid
 	 * @param lpwcProposalId
	 * @param lpwcMonth
	 * @param lpwcMonthCounter
	 * @param lpwcSales
	 * @param lpwcPurchases
	 * @param lpwcStock
	 * @param lpwcDrawPower
	 * @param lpwcDtrLsr90d
	 * @param lpwcDtrBtw90to180d
	 * @param lpwcDtrLsr180d
	 * @param lpwcTotalDtr
	 * @param lpwcNetWorkingCapital
	 * @param lpwcCreditors
	 * @param lpwcWccylStock
	 * @param lpwcWccylCreditor
	 * @param lpwcWccylDebtor
	 * @param lpwcWccylNet
	 * @param lpwcSfcGrossMarginPrtage
	 * @param lpwcSfcTentitiveStock
	 * @param lpwcSfcVariation
	 * @param lpwcSfcVariationPrtage
	 * @param lpwcDebLsr90ChkLst3msales
	 * @param lpwcDebLsr90ChkVariation
	 * @param lpwcAvailable
	 * @param lpwcIsdelete
	 */
	public LpcorpWcAnalysis(long lpwcRowid,BigDecimal lpwcProposalId,String lpwcMonth,
			BigDecimal lpwcMonthCounter,BigDecimal lpwcSales,BigDecimal lpwcPurchases,
			BigDecimal lpwcStock, BigDecimal lpwcDrawPower,
			BigDecimal lpwcDtrLsr90d,BigDecimal lpwcDtrBtw90to180d,BigDecimal lpwcDtrLsr180d,
			BigDecimal lpwcTotalDtr, BigDecimal lpwcNetWorkingCapital, BigDecimal lpwcCreditors,
			BigDecimal lpwcWccylCreditor, BigDecimal lpwcWccylDebtor,
			BigDecimal lpwcWccylNet, BigDecimal lpwcWccylStock, 
			BigDecimal lpwcSfcGrossMarginPrtage,BigDecimal lpwcSfcTentitiveStock, BigDecimal lpwcSfcVariation, BigDecimal lpwcSfcVariationPrtage,
			BigDecimal lpwcDebLsr90ChkLst3msales,BigDecimal lpwcDebLsr90ChkVariation,
			String lpwcAvailable, String lpwcIsdelete) {
		this.lpwcRowid = lpwcRowid;
		this.lpwcAvailable = lpwcAvailable;
		this.lpwcCreditors = lpwcCreditors;
		this.lpwcDebLsr90ChkLst3msales = lpwcDebLsr90ChkLst3msales;
		this.lpwcDebLsr90ChkVariation = lpwcDebLsr90ChkVariation;
		this.lpwcDrawPower = lpwcDrawPower;
		this.lpwcDtrBtw90to180d = lpwcDtrBtw90to180d;
		this.lpwcDtrLsr180d = lpwcDtrLsr180d;
		this.lpwcDtrLsr90d = lpwcDtrLsr90d;
		this.lpwcIsdelete = lpwcIsdelete;
		this.lpwcMonth = lpwcMonth;
		this.lpwcMonthCounter = lpwcMonthCounter;
		this.lpwcNetWorkingCapital = lpwcNetWorkingCapital;
		this.lpwcProposalId = lpwcProposalId;
		this.lpwcPurchases = lpwcPurchases;
		this.lpwcSales = lpwcSales;
		this.lpwcSfcGrossMarginPrtage = lpwcSfcGrossMarginPrtage;
		this.lpwcSfcTentitiveStock = lpwcSfcTentitiveStock;
		this.lpwcSfcVariation = lpwcSfcVariation;
		this.lpwcSfcVariationPrtage = lpwcSfcVariationPrtage;
		this.lpwcStock = lpwcStock;
		this.lpwcTotalDtr = lpwcTotalDtr;
		this.lpwcWccylCreditor = lpwcWccylCreditor;
		this.lpwcWccylDebtor = lpwcWccylDebtor;
		this.lpwcWccylNet = lpwcWccylNet;
		this.lpwcWccylStock = lpwcWccylStock;
	}
	/**
	 * @param lpwcRowid
	 * @param lpwcMonth
	 * @param lpwcMonthCounter
	 * @param lpwcSales
	 * @param lpwcPurchases
	 * @param lpwcStock
	 * @param lpwcDrawPower
	 * @param lpwcDtrLsr90d
	 * @param lpwcDtrBtw90to180d
	 * @param lpwcDtrLsr180d
	 * @param lpwcTotalDtr
	 * @param lpwcNetWorkingCapital
	 * @param lpwcCreditors
	 * @param lpwcWccylStock
	 * @param lpwcWccylCreditor
	 * @param lpwcWccylDebtor
	 * @param lpwcWccylNet
	 * @param lpwcSfcGrossMarginPrtage
	 * @param lpwcSfcTentitiveStock
	 * @param lpwcSfcVariation
	 * @param lpwcSfcVariationPrtage
	 * @param lpwcDebLsr90ChkLst3msales
	 * @param lpwcDebLsr90ChkVariation
	 * @param lpwcAvailable
	 * @param lpwcIsdelete
	 */
	public LpcorpWcAnalysis(long lpwcRowid,BigDecimal lpwcProposalId,
			BigDecimal lpwcSales,BigDecimal lpwcPurchases,
			BigDecimal lpwcStock, BigDecimal lpwcDrawPower,
			BigDecimal lpwcDtrLsr90d,BigDecimal lpwcDtrBtw90to180d,BigDecimal lpwcDtrLsr180d,
			BigDecimal lpwcTotalDtr, BigDecimal lpwcNetWorkingCapital, BigDecimal lpwcCreditors,
			BigDecimal lpwcWccylCreditor, BigDecimal lpwcWccylDebtor,
			BigDecimal lpwcWccylNet, BigDecimal lpwcWccylStock, 
			BigDecimal lpwcSfcGrossMarginPrtage,BigDecimal lpwcSfcTentitiveStock, BigDecimal lpwcSfcVariation, BigDecimal lpwcSfcVariationPrtage,
			BigDecimal lpwcDebLsr90ChkLst3msales,BigDecimal lpwcDebLsr90ChkVariation,
			String lpwcAvailable, String lpwcIsdelete) {
		this.lpwcRowid = lpwcRowid;
		this.lpwcAvailable = lpwcAvailable;
		this.lpwcCreditors = lpwcCreditors;
		this.lpwcDebLsr90ChkLst3msales = lpwcDebLsr90ChkLst3msales;
		this.lpwcDebLsr90ChkVariation = lpwcDebLsr90ChkVariation;
		this.lpwcDrawPower = lpwcDrawPower;
		this.lpwcDtrBtw90to180d = lpwcDtrBtw90to180d;
		this.lpwcDtrLsr180d = lpwcDtrLsr180d;
		this.lpwcDtrLsr90d = lpwcDtrLsr90d;
		this.lpwcIsdelete = lpwcIsdelete;
		this.lpwcNetWorkingCapital = lpwcNetWorkingCapital;
		this.lpwcProposalId = lpwcProposalId;
		this.lpwcPurchases = lpwcPurchases;
		this.lpwcSales = lpwcSales;
		this.lpwcSfcGrossMarginPrtage = lpwcSfcGrossMarginPrtage;
		this.lpwcSfcTentitiveStock = lpwcSfcTentitiveStock;
		this.lpwcSfcVariation = lpwcSfcVariation;
		this.lpwcSfcVariationPrtage = lpwcSfcVariationPrtage;
		this.lpwcStock = lpwcStock;
		this.lpwcTotalDtr = lpwcTotalDtr;
		this.lpwcWccylCreditor = lpwcWccylCreditor;
		this.lpwcWccylDebtor = lpwcWccylDebtor;
		this.lpwcWccylNet = lpwcWccylNet;
		this.lpwcWccylStock = lpwcWccylStock;
	}
}