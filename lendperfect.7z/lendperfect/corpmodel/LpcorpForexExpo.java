package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_FOREX_EXPO database table.
 * 
 */
@Entity
@Table(name="LPCORP_FOREX_EXPO")
@NamedQuery(name="LpcorpForexExpo.findAll", query="SELECT l FROM LpcorpForexExpo l")
public class LpcorpForexExpo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LFE_CREATED_BY")
	private String lfeCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LFE_CREATED_ON")
	private Date lfeCreatedOn;

	@Column(name="LFE_LFY")
	private BigDecimal lfeLfy;

	@Column(name="LFE_MODIFIED_BY")
	private String lfeModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LFE_MODIFIED_ON")
	private Date lfeModifiedOn;

	@Column(name="LFE_ORDER_NO")
	private BigDecimal lfeOrderNo;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LFE_ROW_ID")
	private BigDecimal lfeRowId;

	@Column(name="LFE_YTD")
	private BigDecimal lfeYtd;

	//bi-directional many-to-one association to LpcomProposal\
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LFE_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpForexExpo() {
	}

	public String getLfeCreatedBy() {
		return this.lfeCreatedBy;
	}

	public void setLfeCreatedBy(String lfeCreatedBy) {
		this.lfeCreatedBy = lfeCreatedBy;
	}

	public Date getLfeCreatedOn() {
		return this.lfeCreatedOn;
	}

	public void setLfeCreatedOn(Date lfeCreatedOn) {
		this.lfeCreatedOn = lfeCreatedOn;
	}

	public BigDecimal getLfeLfy() {
		return this.lfeLfy;
	}

	public void setLfeLfy(BigDecimal lfeLfy) {
		this.lfeLfy = lfeLfy;
	}

	public String getLfeModifiedBy() {
		return this.lfeModifiedBy;
	}

	public void setLfeModifiedBy(String lfeModifiedBy) {
		this.lfeModifiedBy = lfeModifiedBy;
	}

	public Date getLfeModifiedOn() {
		return this.lfeModifiedOn;
	}

	public void setLfeModifiedOn(Date lfeModifiedOn) {
		this.lfeModifiedOn = lfeModifiedOn;
	}

	public BigDecimal getLfeOrderNo() {
		return this.lfeOrderNo;
	}

	public void setLfeOrderNo(BigDecimal lfeOrderNo) {
		this.lfeOrderNo = lfeOrderNo;
	}

	public BigDecimal getLfeRowId() {
		return this.lfeRowId;
	}

	public void setLfeRowId(BigDecimal lfeRowId) {
		this.lfeRowId = lfeRowId;
	}

	public BigDecimal getLfeYtd() {
		return this.lfeYtd;
	}

	public void setLfeYtd(BigDecimal lfeYtd) {
		this.lfeYtd = lfeYtd;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}