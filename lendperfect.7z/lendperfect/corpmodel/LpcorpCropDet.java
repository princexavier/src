package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_CROP_DET database table.
 * 
 */
@Entity
@Table(name="LPCORP_CROP_DET")
@NamedQuery(name="LpcorpCropDet.findAll", query="SELECT l FROM LpcorpCropDet l")
public class LpcorpCropDet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LCD_ACRE")
	private BigDecimal lcdAcre;

	@Column(name="LCD_COC_PER_ACRE")
	private BigDecimal lcdCocPerAcre;

	@Column(name="LCD_CREATED_BY")
	private String lcdCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCD_CREATED_ON")
	private Date lcdCreatedOn;

	@Column(name="LCD_CROP_ID")
	private String lcdCropId;

	@Column(name="LCD_CULTI_PRD")
	private BigDecimal lcdCultiPrd;

	@Column(name="LCD_GROSS_INC")
	private BigDecimal lcdGrossInc;

	@Column(name="LCD_MODIFIED_BY")
	private String lcdModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LCD_MODIFIED_ON")
	private Date lcdModifiedOn;

	@Column(name="LCD_NET_INC")
	private BigDecimal lcdNetInc;

	@Column(name="LCD_PRD_PER_QTL")
	private BigDecimal lcdPrdPerQtl;

	@Column(name="LCD_PRICE_PER_QTL")
	private BigDecimal lcdPricePerQtl;

	@Id
	@Column(name="LCD_ROW_ID")
	private BigDecimal lcdRowId;

	@Column(name="LCD_SEQ_NO")
	private BigDecimal lcdSeqNo;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JoinColumn(name="LCD_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpCropDet() {
	}

	public BigDecimal getLcdAcre() {
		return this.lcdAcre;
	}

	public void setLcdAcre(BigDecimal lcdAcre) {
		this.lcdAcre = lcdAcre;
	}

	public BigDecimal getLcdCocPerAcre() {
		return this.lcdCocPerAcre;
	}

	public void setLcdCocPerAcre(BigDecimal lcdCocPerAcre) {
		this.lcdCocPerAcre = lcdCocPerAcre;
	}

	public String getLcdCreatedBy() {
		return this.lcdCreatedBy;
	}

	public void setLcdCreatedBy(String lcdCreatedBy) {
		this.lcdCreatedBy = lcdCreatedBy;
	}

	public Date getLcdCreatedOn() {
		return this.lcdCreatedOn;
	}

	public void setLcdCreatedOn(Date lcdCreatedOn) {
		this.lcdCreatedOn = lcdCreatedOn;
	}

	public String getLcdCropId() {
		return this.lcdCropId;
	}

	public void setLcdCropId(String lcdCropId) {
		this.lcdCropId = lcdCropId;
	}

	public BigDecimal getLcdCultiPrd() {
		return this.lcdCultiPrd;
	}

	public void setLcdCultiPrd(BigDecimal lcdCultiPrd) {
		this.lcdCultiPrd = lcdCultiPrd;
	}

	public BigDecimal getLcdGrossInc() {
		return this.lcdGrossInc;
	}

	public void setLcdGrossInc(BigDecimal lcdGrossInc) {
		this.lcdGrossInc = lcdGrossInc;
	}

	public String getLcdModifiedBy() {
		return this.lcdModifiedBy;
	}

	public void setLcdModifiedBy(String lcdModifiedBy) {
		this.lcdModifiedBy = lcdModifiedBy;
	}

	public Date getLcdModifiedOn() {
		return this.lcdModifiedOn;
	}

	public void setLcdModifiedOn(Date lcdModifiedOn) {
		this.lcdModifiedOn = lcdModifiedOn;
	}

	public BigDecimal getLcdNetInc() {
		return this.lcdNetInc;
	}

	public void setLcdNetInc(BigDecimal lcdNetInc) {
		this.lcdNetInc = lcdNetInc;
	}

	public BigDecimal getLcdPrdPerQtl() {
		return this.lcdPrdPerQtl;
	}

	public void setLcdPrdPerQtl(BigDecimal lcdPrdPerQtl) {
		this.lcdPrdPerQtl = lcdPrdPerQtl;
	}

	public BigDecimal getLcdPricePerQtl() {
		return this.lcdPricePerQtl;
	}

	public void setLcdPricePerQtl(BigDecimal lcdPricePerQtl) {
		this.lcdPricePerQtl = lcdPricePerQtl;
	}

	public BigDecimal getLcdRowId() {
		return this.lcdRowId;
	}

	public void setLcdRowId(BigDecimal lcdRowId) {
		this.lcdRowId = lcdRowId;
	}

	public BigDecimal getLcdSeqNo() {
		return this.lcdSeqNo;
	}

	public void setLcdSeqNo(BigDecimal lcdSeqNo) {
		this.lcdSeqNo = lcdSeqNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}