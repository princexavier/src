package com.sai.lendperfect.corpmodel;

import java.io.Serializable;
import javax.persistence.*;

import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_BUYER_SUPPLIER database table.
 * 
 */
@Entity
@Table(name="LPCORP_BUYER_SUPPLIER")
@NamedQuery(name="LpcorpBuyerSupplier.findAll", query="SELECT l FROM LpcorpBuyerSupplier l")
public class LpcorpBuyerSupplier implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LBS_CREATED_BY")
	private String lbsCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBS_CREATED_ON")
	private Date lbsCreatedOn;

	@Column(name="LBS_CRILIC_CHECKED")
	private String lbsCrilicChecked;

	@Column(name="LBS_CRILIC_DET")
	private String lbsCrilicDet;

	@Column(name="LBS_CUST_ID")
	private BigDecimal lbsCustId;

	@Column(name="LBS_CY_AMT")
	private BigDecimal lbsCyAmt;

	@Column(name="LBS_CY_PERCENT")
	private BigDecimal lbsCyPercent;

	@Column(name="LBS_ENTRY_FOR")
	private String lbsEntryFor;

	@Column(name="LBS_MODIFIED_BY")
	private String lbsModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LBS_MODIFIED_ON")
	private Date lbsModifiedOn;

	@Column(name="LBS_NAME")
	private String lbsName;

	@Column(name="LBS_NCIF_CHECKED")
	private String lbsNcifChecked;

	@Column(name="LBS_NCIF_DET")
	private String lbsNcifDet;

	@Column(name="LBS_PY_AMT")
	private BigDecimal lbsPyAmt;

	@Column(name="LBS_PY_PERCENT")
	private BigDecimal lbsPyPercent;

	@Column(name="LBS_RELATION_SINCE")
	private BigDecimal lbsRelationSince;

	@Id
	@Column(name="LBS_ROW_ID")
	private BigDecimal lbsRowId;

	@Column(name="LBS_SEQ_NO")
	private BigDecimal lbsSeqNo;

	//bi-directional many-to-one association to LpcomProposal
	@ManyToOne
	@JoinColumn(name="LBS_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpBuyerSupplier() {
	}

	public String getLbsCreatedBy() {
		return this.lbsCreatedBy;
	}

	public void setLbsCreatedBy(String lbsCreatedBy) {
		this.lbsCreatedBy = lbsCreatedBy;
	}

	public Date getLbsCreatedOn() {
		return this.lbsCreatedOn;
	}

	public void setLbsCreatedOn(Date lbsCreatedOn) {
		this.lbsCreatedOn = lbsCreatedOn;
	}

	public String getLbsCrilicChecked() {
		return this.lbsCrilicChecked;
	}

	public void setLbsCrilicChecked(String lbsCrilicChecked) {
		this.lbsCrilicChecked = lbsCrilicChecked;
	}

	public String getLbsCrilicDet() {
		return this.lbsCrilicDet;
	}

	public void setLbsCrilicDet(String lbsCrilicDet) {
		this.lbsCrilicDet = lbsCrilicDet;
	}

	public BigDecimal getLbsCustId() {
		return this.lbsCustId;
	}

	public void setLbsCustId(BigDecimal lbsCustId) {
		this.lbsCustId = lbsCustId;
	}

	public BigDecimal getLbsCyAmt() {
		return this.lbsCyAmt;
	}

	public void setLbsCyAmt(BigDecimal lbsCyAmt) {
		this.lbsCyAmt = lbsCyAmt;
	}

	public BigDecimal getLbsCyPercent() {
		return this.lbsCyPercent;
	}

	public void setLbsCyPercent(BigDecimal lbsCyPercent) {
		this.lbsCyPercent = lbsCyPercent;
	}

	public String getLbsEntryFor() {
		return this.lbsEntryFor;
	}

	public void setLbsEntryFor(String lbsEntryFor) {
		this.lbsEntryFor = lbsEntryFor;
	}

	public String getLbsModifiedBy() {
		return this.lbsModifiedBy;
	}

	public void setLbsModifiedBy(String lbsModifiedBy) {
		this.lbsModifiedBy = lbsModifiedBy;
	}

	public Date getLbsModifiedOn() {
		return this.lbsModifiedOn;
	}

	public void setLbsModifiedOn(Date lbsModifiedOn) {
		this.lbsModifiedOn = lbsModifiedOn;
	}

	public String getLbsName() {
		return this.lbsName;
	}

	public void setLbsName(String lbsName) {
		this.lbsName = lbsName;
	}

	public String getLbsNcifChecked() {
		return this.lbsNcifChecked;
	}

	public void setLbsNcifChecked(String lbsNcifChecked) {
		this.lbsNcifChecked = lbsNcifChecked;
	}

	public String getLbsNcifDet() {
		return this.lbsNcifDet;
	}

	public void setLbsNcifDet(String lbsNcifDet) {
		this.lbsNcifDet = lbsNcifDet;
	}

	public BigDecimal getLbsPyAmt() {
		return this.lbsPyAmt;
	}

	public void setLbsPyAmt(BigDecimal lbsPyAmt) {
		this.lbsPyAmt = lbsPyAmt;
	}

	public BigDecimal getLbsPyPercent() {
		return this.lbsPyPercent;
	}

	public void setLbsPyPercent(BigDecimal lbsPyPercent) {
		this.lbsPyPercent = lbsPyPercent;
	}

	public BigDecimal getLbsRelationSince() {
		return this.lbsRelationSince;
	}

	public void setLbsRelationSince(BigDecimal lbsRelationSince) {
		this.lbsRelationSince = lbsRelationSince;
	}

	public BigDecimal getLbsRowId() {
		return this.lbsRowId;
	}

	public void setLbsRowId(BigDecimal lbsRowId) {
		this.lbsRowId = lbsRowId;
	}

	public BigDecimal getLbsSeqNo() {
		return this.lbsSeqNo;
	}

	public void setLbsSeqNo(BigDecimal lbsSeqNo) {
		this.lbsSeqNo = lbsSeqNo;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}