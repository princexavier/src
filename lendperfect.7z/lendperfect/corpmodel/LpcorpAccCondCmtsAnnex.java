package com.sai.lendperfect.corpmodel;


import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sai.lendperfect.commodel.LpcomProposal;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the LPCORP_ACC_COND_CMTS_ANNEX database table.
 * 
 */
@Entity
@Table(name="LPCORP_ACC_COND_CMTS_ANNEX")
@NamedQuery(name="LpcorpAccCondCmtsAnnex.findAll", query="SELECT l FROM LpcorpAccCondCmtsAnnex l")
public class LpcorpAccCondCmtsAnnex implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LACC_ACC_ID")
	private BigDecimal laccAccId;

	@Column(name="LACC_CREATED_BY")
	private String laccCreatedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LACC_CREATED_ON")
	private Date laccCreatedOn;

	@Column(name="LACC_DESC")
	private String laccDesc;

	@Column(name="LACC_MODIFIED_BY")
	private String laccModifiedBy;

	@Temporal(TemporalType.DATE)
	@Column(name="LACC_MODIFIED_ON")
	private Date laccModifiedOn;

	@Column(name="LACC_ORDER_NO")
	private BigDecimal laccOrderNo;

	@Column(name="LACC_PARENT_ID")
	private BigDecimal laccParentId;

	@Column(name="LACC_REMARKS")
	private String laccRemarks;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LACC_ROW_ID")
	private BigDecimal laccRowId;

	//bi-directional many-to-one association to LpcomProposal
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="LACC_PROP_NO")
	private LpcomProposal lpcomProposal;

	public LpcorpAccCondCmtsAnnex() {
	}

	public BigDecimal getLaccAccId() {
		return this.laccAccId;
	}

	public void setLaccAccId(BigDecimal laccAccId) {
		this.laccAccId = laccAccId;
	}

	public String getLaccCreatedBy() {
		return this.laccCreatedBy;
	}

	public void setLaccCreatedBy(String laccCreatedBy) {
		this.laccCreatedBy = laccCreatedBy;
	}

	public Date getLaccCreatedOn() {
		return this.laccCreatedOn;
	}

	public void setLaccCreatedOn(Date laccCreatedOn) {
		this.laccCreatedOn = laccCreatedOn;
	}

	public String getLaccDesc() {
		return this.laccDesc;
	}

	public void setLaccDesc(String laccDesc) {
		this.laccDesc = laccDesc;
	}

	public String getLaccModifiedBy() {
		return this.laccModifiedBy;
	}

	public void setLaccModifiedBy(String laccModifiedBy) {
		this.laccModifiedBy = laccModifiedBy;
	}

	public Date getLaccModifiedOn() {
		return this.laccModifiedOn;
	}

	public void setLaccModifiedOn(Date laccModifiedOn) {
		this.laccModifiedOn = laccModifiedOn;
	}

	public BigDecimal getLaccOrderNo() {
		return this.laccOrderNo;
	}

	public void setLaccOrderNo(BigDecimal laccOrderNo) {
		this.laccOrderNo = laccOrderNo;
	}

	public BigDecimal getLaccParentId() {
		return this.laccParentId;
	}

	public void setLaccParentId(BigDecimal laccParentId) {
		this.laccParentId = laccParentId;
	}

	public String getLaccRemarks() {
		return this.laccRemarks;
	}

	public void setLaccRemarks(String laccRemarks) {
		this.laccRemarks = laccRemarks;
	}

	public BigDecimal getLaccRowId() {
		return this.laccRowId;
	}

	public void setLaccRowId(BigDecimal laccRowId) {
		this.laccRowId = laccRowId;
	}

	public LpcomProposal getLpcomProposal() {
		return this.lpcomProposal;
	}

	public void setLpcomProposal(LpcomProposal lpcomProposal) {
		this.lpcomProposal = lpcomProposal;
	}

}